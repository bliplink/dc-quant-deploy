package com.app.common.replication;

import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.LongSupplier;

/**
 * Immutable node-scoped control snapshot shared by STRICT_QUORUM and
 * LOCAL_DURABLE_ASYNC WAL engines.
 *
 * This class has no ZooKeeper dependency. Exactly ONE control-plane verifier
 * authenticates an atomic batch of assignments and a node lease. Replication,
 * business apply, WAL fsync and client ACK use only the published in-memory
 * snapshot. It does not sign a certificate or persist a WAL.
 *
 * SECURITY REQUIREMENTS FOR THE CONTROL-PLANE ADAPTER:
 *  - verify node identity, actual ZK quorum/CAS and fenced old owner;
 *  - verify every partition Epoch and ACK-policy transition;
 *  - never authorize a new owner before every prior grant can no longer
 *    yield a valid ACK (max old TTL + clock uncertainty);
 *  - issue lease expiry from the BEGINNING of the quorum proof, not when
 *    it returns; revoke on session loss/Watch change.
 *
 * A snapshot/permit alone is NOT an ACK: the selected durability engine
 * MUST validate physical WAL/CommitIndex/Custody evidence separately.
 */
public final class NodePartitionGrantTable {
    public interface ControlVerifier {
        /** Called only by control-plane install, NEVER a WAL/ACK thread. */
        void verifyBatch(Batch batch) throws Exception;
    }
    public static final class Partition {
        public final String id,primary,replica;
        public final long epoch;
        public final DurableWalAckPolicy policy;

        public Partition(String id,long epoch,String primary,String replica,
                         DurableWalAckPolicy policy) {
            this.id=required(id,"partition");
            this.primary=required(primary,"primary");
            this.replica=replica==null?"":replica;
            if(epoch<=0 || this.primary.equals(this.replica))
                throw new IllegalArgumentException("invalid physical partition/epoch");
            this.epoch=epoch;
            this.policy=Objects.requireNonNull(policy,"ACK policy");
            if(policy==DurableWalAckPolicy.STRICT_QUORUM && this.replica.isEmpty())
                throw new IllegalArgumentException("strict partition requires a replica");
        }
        private boolean same(Partition other){
            return other!=null && epoch==other.epoch
                && id.equals(other.id) && primary.equals(other.primary)
                && replica.equals(other.replica) && policy==other.policy;
        }
    }
    public static final class Batch {
        public final String nodeId;
        public final long generation,proofStartedNanos,ttlNanos,activationDelayNanos;
        public final Map<String,Partition> partitions;
        private final byte[] quorumProof;

        public Batch(String nodeId,long generation,long proofStartedNanos,
                     long ttlNanos,long activationDelayNanos,
                     Map<String,Partition> partitions,byte[] quorumProof) {
            this.nodeId=required(nodeId,"node");
            if(generation<=0 || proofStartedNanos<0 || ttlNanos<=0
                    || activationDelayNanos<0)
                throw new IllegalArgumentException("bad controller grant");
            this.generation=generation;
            this.proofStartedNanos=proofStartedNanos;
            this.ttlNanos=ttlNanos;
            this.activationDelayNanos=activationDelayNanos;
            if(partitions==null || partitions.isEmpty())
                throw new IllegalArgumentException("empty partition batch");
            Map<String,Partition> copy=new HashMap<>();
            partitions.forEach((key,value)->{
                Objects.requireNonNull(value,"partition record");
                if(!key.equals(value.id))
                    throw new IllegalArgumentException("mismatched partition identity");
                copy.put(key,value);
            });
            this.partitions=Collections.unmodifiableMap(copy);
            this.quorumProof=Objects.requireNonNull(quorumProof,"quorumProof").clone();
            if(this.quorumProof.length==0)
                throw new IllegalArgumentException("missing control quorum evidence");
        }
        public byte[] quorumProof(){return quorumProof.clone();}
    }
    private static final class State {
        final Batch batch;
        final boolean revoked;
        State(Batch batch,boolean revoked){this.batch=batch;this.revoked=revoked;}
    }
    public final class Permit {
        private final State pinned;
        public final Partition partition;
        private final boolean replica;
        private Permit(State pinned,Partition partition,boolean replica){
            this.pinned=pinned;this.partition=partition;this.replica=replica;
        }
        /** Call before WAL append/signing AND immediately before client ACK. */
        public void requireCurrent() throws IOException {
            State now=current.get();
            if(now!=pinned || now==null || now.revoked)
                throw new IOException("grant revoked or node generation changed");
            valid(now.batch);
            if(replica ? !nodeId.equals(partition.replica)
                       : !nodeId.equals(partition.primary))
                throw new IOException("writer role revoked");
        }
        /** Call only after physical durability gate, not in place of it. */
        public void requireAckEvidence(String mode,boolean quorum,boolean dataLoss)
                throws IOException {
            if(replica)throw new IOException("replica cannot acknowledge clients");
            requireCurrent();
            partition.policy.requireAckEvidence(mode,quorum,dataLoss);
            requireCurrent();
        }
    }

    private final String nodeId;
    private final LongSupplier monotonicNanos;
    private final ControlVerifier authority;
    private final int maxPartitions;
    private final long maxLeaseNanos;
    private final AtomicReference<State> current=new AtomicReference<>();

    public NodePartitionGrantTable(String nodeId,LongSupplier monotonicNanos,
            ControlVerifier authority,int maxPartitions,long maxLeaseNanos){
        this.nodeId=required(nodeId,"node");
        this.monotonicNanos=Objects.requireNonNull(monotonicNanos);
        this.authority=Objects.requireNonNull(authority);
        if(maxPartitions<1 || maxLeaseNanos<=0)
            throw new IllegalArgumentException("invalid capacity/lease");
        this.maxPartitions=maxPartitions;this.maxLeaseNanos=maxLeaseNanos;
    }
    private static String required(String value,String name){
        if(value==null || value.trim().isEmpty())
            throw new IllegalArgumentException(name+" missing");
        return value;
    }
    private long unexpired(Batch batch)throws IOException {
        long now=monotonicNanos.getAsLong();
        long elapsed=now-batch.proofStartedNanos;
        if(elapsed<0 || elapsed>=batch.ttlNanos)
            throw new IOException("node quorum lease expired");
        return elapsed;
    }
    private void valid(Batch batch)throws IOException {
        if(unexpired(batch)<batch.activationDelayNanos)
            throw new IOException("new owner retirement fence incomplete");
    }

    /**
     * ONE externally proven control event installs up to maxPartitions.
     * Any partial batch is rejected; assignment topology replaces atomically.
     * A revoked/expired generation cannot be resurrected at the same epoch.
     */
    public synchronized void install(Batch batch)throws Exception {
        Objects.requireNonNull(batch,"verified grant");
        if(!nodeId.equals(batch.nodeId) || batch.partitions.size()>maxPartitions
                || batch.ttlNanos>maxLeaseNanos
                || batch.activationDelayNanos>=batch.ttlNanos)
            throw new IOException("invalid node control lease/partition capacity");
        // A slow ZK proof cannot be allowed to borrow time from a later clock.
        unexpired(batch);
        // Trust boundary: verifier MUST consult real ZK CAS/quorum & old fence.
        authority.verifyBatch(batch);
        unexpired(batch);
        State previous=current.get();
        if(previous!=null) {
            Batch old=previous.batch;
            if(batch.generation<old.generation)
                throw new IOException("stale node control generation");
            boolean oldExpired=expired(old);
            if((previous.revoked || oldExpired)
                    && batch.generation<=old.generation)
                throw new IOException("revoked node generation cannot renew");
            if(batch.generation==old.generation) {
                if(!sameTopology(batch.partitions,old.partitions))
                    throw new IOException("topology changed without new generation");
            } else {
                for(Partition next:batch.partitions.values()){
                    Partition prior=old.partitions.get(next.id);
                    if(prior!=null && next.epoch<prior.epoch)
                        throw new IOException("partition epoch rolled backward");
                    if(prior!=null && next.epoch==prior.epoch
                            && !next.same(prior))
                        throw new IOException("policy/owner changed without epoch");
                    if(prior!=null && (previous.revoked || oldExpired)
                            && next.epoch<=prior.epoch)
                        throw new IOException("revoked epoch cannot be resurrected");
                }
            }
        }
        current.set(new State(batch,false));
    }

    private static boolean sameTopology(Map<String,Partition> a,
                                         Map<String,Partition> b) {
        if(a.size()!=b.size())return false;
        for(Map.Entry<String,Partition> e:a.entrySet())
            if(!e.getValue().same(b.get(e.getKey())))return false;
        return true;
    }
    private boolean expired(Batch b){
        long elapsed=monotonicNanos.getAsLong()-b.proofStartedNanos;
        return elapsed<0 || elapsed>=b.ttlNanos;
    }
    /** ZK watch, session failure, revoked grant or explicit fence: fail closed. */
    public synchronized void revoke() {
        State s=current.get();
        if(s!=null)current.set(new State(s.batch,true));
    }
    public Permit primary(String partition,long epoch,
                          DurableWalAckPolicy policy)throws IOException {
        return permit(partition,epoch,policy,false);
    }
    public Permit replica(String partition,long epoch,
                          DurableWalAckPolicy policy)throws IOException {
        return permit(partition,epoch,policy,true);
    }
    private Permit permit(String id,long epoch,DurableWalAckPolicy policy,
                          boolean replica)throws IOException {
        State s=current.get();
        if(s==null || s.revoked)throw new IOException("control snapshot not READY");
        valid(s.batch);
        Partition p=s.batch.partitions.get(id);
        if(p==null || p.epoch!=epoch || p.policy!=policy)
            throw new IOException("stale partition epoch or ACK policy");
        if(!(replica?nodeId.equals(p.replica):nodeId.equals(p.primary)))
            throw new IOException("wrong node for WAL partition");
        Permit permit=new Permit(s,p,replica);
        permit.requireCurrent();
        return permit;
    }
    public int partitionCount(){
        State s=current.get();return s==null?0:s.batch.partitions.size();
    }
    public long generation(){
        State s=current.get();return s==null?0:s.batch.generation;
    }
}
