package com.opentradingcore.demo;

import com.app.common.replication.DurableWalAckPolicy;
import com.app.common.replication.NodePartitionGrantTable;
import com.app.common.replication.NodeClusterControlManager;
import java.util.Collections;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Isolated P000 adapter for the new reusable Common node-scoped grant table.
 * No ZooKeeper calls here: controller already proves the underlying CAS &
 * signed grant on a separate thread; this converts the verified LOCAL view.
 * This is NOT the future 256-shard ZK snapshot adapter.
 */
final class DemoV19NodeGrantBridge implements AutoCloseable {
    private final NodePartitionGrantTable grants;
    private final NodeClusterControlManager manager;
    DemoV19NodeGrantBridge(String node,DemoZkLeaseController controller,
                          DurableWalAckPolicy policy) {
        this.grants=new NodePartitionGrantTable(node,System::nanoTime,
            batch->{
                if(batch.partitions.size()!=1 || !batch.partitions.containsKey("P000"))
                    throw new java.io.IOException("unverified pilot partition set");
                NodePartitionGrantTable.Partition p=batch.partitions.get("P000");
                if(!"P000".equals(p.id) || p.policy!=policy)
                    throw new java.io.IOException("wrong policy of external ZK control");
                if(node.equals(p.primary))
                    controller.grantCache().requirePrimary("P000",p.epoch,p.primary);
                else if(node.equals(p.replica))
                    controller.grantCache().requireReplica("P000",p.epoch,p.primary,node);
                else throw new java.io.IOException("wrong local physical voter");
            },256,TimeUnit.MILLISECONDS.toNanos(1900L));
        this.manager=new NodeClusterControlManager(node,local->{
            DemoHotpathLeaseCache.GrantView v=controller.grantCache().view("P000");
            if(v.replicas.size()!=1)
                throw new java.io.IOException("RF2 exactly one physical buddy required");
            String buddy=v.replicas.iterator().next();
            Map<String,NodePartitionGrantTable.Partition> routes=Collections.singletonMap(
                "P000",new NodePartitionGrantTable.Partition(
                    "P000",v.epoch,v.primary,buddy,policy));
            // Control verifier rechecks the independently quorum-proven,
            // signed and bounded ZK grant. No network call in WAL threads.
            byte[] token=(v.primary+":"+v.epoch).getBytes("UTF-8");
            return new NodePartitionGrantTable.Batch(node,v.epoch,
                System.nanoTime(),TimeUnit.MILLISECONDS.toNanos(1900L),
                0L,routes,token);
        },grants,300L);
    }
    void start(){manager.start();}
    NodePartitionGrantTable table(){return grants;}
    @Override public void close(){manager.close();}
}
