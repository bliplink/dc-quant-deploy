package com.opentradingcore.demo;

import com.app.common.zk.ZookeeperClient;
import com.gateway.connector.utils.JsonUtils;
import org.apache.zookeeper.data.Stat;
import org.apache.zookeeper.Watcher;
import org.I0Itec.zkclient.IZkDataListener;
import org.I0Itec.zkclient.IZkStateListener;
import java.io.IOException;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * V19 isolated RF2 STRICT control-plane proof cache. ONLY the single daemon
 * refresher reads ZooKeeper, never the WAL/receipt/custody/ACK hot threads.
 *
 * On a changed assignment or disconnected session all old snapshots are
 * invalidated immediately; expired snapshots fail closed. The freshness
 * deadline is 2,000 ms from the BEGINNING of the ZK read, not completion.
 * Watch changes enqueue immediate rechecks; a slow 1,400-ms backup renewal
 * prevents indefinite use of snapshots if a watch notification is missed.
 * This is < the existing 2,200-ms signed control grant and 2,500-ms
 * old-owner-retirement barrier. It is NOT a production multi-shard controller.
 */
final class DemoV19Rf2StrictAssignmentCache implements AutoCloseable {
    static final String PATH=DemoZkFenceSource.ISOLATED_ROOT
            +"/harness/assignments/P000";
    static final long MAX_AGE_NS=TimeUnit.MILLISECONDS.toNanos(2000L);
    static final long BACKSTOP_RENEW_MS=1400L;
    private final ZookeeperClient zk;
    private final ScheduledExecutorService renewer;
    private volatile Snapshot latest;
    private volatile boolean closed;
    private volatile boolean sessionRevoked;
    private long invalidationGeneration;
    private long zkReadCount;
    private synchronized void invalidate(){invalidationGeneration++;latest=null;}
    private void watchChanged(){
        invalidate();
        // Never issue a synchronous ZK request on a ZooKeeper watcher thread.
        // Queue the one-shot control refresh to the same serial executor.
        if(renewer!=null && !closed)renewer.execute(()->{
            try{refresh();}catch(Exception ignored){invalidate();}
        });
    }

    static final class Snapshot {
        final int version;
        final String raw;
        final DemoV19Rf2DynamicReceiptService.Plan plan;
        final long beganAt;
        Snapshot(int version,String raw,
                DemoV19Rf2DynamicReceiptService.Plan plan,long beganAt){
            this.version=version;this.raw=raw;this.plan=plan;this.beganAt=beganAt;
        }
        void valid(long now)throws IOException {
            if(now<beganAt || now-beganAt>=MAX_AGE_NS)
                throw new IOException("strict control snapshot expired or clock drift");
        }
        void same(Snapshot other)throws IOException {
            if(other==null || version!=other.version || !raw.equals(other.raw))
                throw new IOException("strict epoch/configuration revoked");
        }
    }

    DemoV19Rf2StrictAssignmentCache(ZookeeperClient zk){
        this.zk=Objects.requireNonNull(zk);
        zk.subscribeDataChanges(PATH,new IZkDataListener(){
            @Override public void handleDataChange(String path,Object value) {
                watchChanged();
            }
            @Override public void handleDataDeleted(String path){watchChanged();}
        });
        zk.subscribeStateChanges(new IZkStateListener(){
            @Override public void handleStateChanged(Watcher.Event.KeeperState state){
                if(state!=Watcher.Event.KeeperState.SyncConnected) {
                    sessionRevoked=true;invalidate();
                }
            }
            @Override public void handleNewSession(){sessionRevoked=true;invalidate();}
            @Override public void handleSessionEstablishmentError(Throwable cause){
                sessionRevoked=true;invalidate();
            }
        });
        renewer=Executors.newSingleThreadScheduledExecutor(r->{
            Thread t=new Thread(r,"v19-strict-assignment-control");
            t.setDaemon(true);
            return t;
        });
        renewer.scheduleWithFixedDelay(()->{
            try {refresh();}
            catch(Exception denied){invalidate();}
        },0L,BACKSTOP_RENEW_MS,TimeUnit.MILLISECONDS);
    }

    /** Control thread only. Never use this method from Netty or WAL handlers. */
    private void refresh()throws Exception {
        if(closed || !zk.isConnected()) {invalidate();return;}
        final long generation;
        synchronized(this){generation=invalidationGeneration;}
        long began=System.nanoTime();
        Stat stat=new Stat();
        Object data=zk.readData(PATH,stat);
        long readNumber;
        synchronized(this){readNumber=++zkReadCount;}
        if(readNumber<=3 || readNumber%10==0)
            System.out.println("V19_STRICT_CONTROL_ZK_REFRESH reads="+readNumber+
                " periodMs="+BACKSTOP_RENEW_MS);
        if(data==null || stat.getVersion()<0) {invalidate();return;}
        String raw=String.valueOf(data);
        @SuppressWarnings("unchecked") Map<String,Object> m=
                JsonUtils.Deserialize(raw,Map.class);
        DemoV19Rf2DynamicReceiptService.Plan plan=
                DemoV19Rf2DynamicReceiptService.requirePlan(m);
        Snapshot read=new Snapshot(stat.getVersion(),raw,plan,began);
        read.valid(System.nanoTime());
        synchronized(this){
            if(closed || !zk.isConnected() || generation!=invalidationGeneration)
                return; // A watch invalidated this read while in flight.
            latest=read;
            // Session reconnection alone does not restore the separate local
            // grant. DemoHotpathControl must independently refresh and authorize.
            sessionRevoked=false;
        }
    }

    Snapshot current()throws IOException {
        Snapshot value=latest;
        if(closed || sessionRevoked || !zk.isConnected() || value==null)
            throw new IOException("strict control proof missing or session revoked");
        value.valid(System.nanoTime());
        return value;
    }

    void requireSame(Snapshot pinned)throws IOException {
        Snapshot value=current();
        pinned.same(value);
    }

    @Override public void close(){
        closed=true;invalidate();renewer.shutdownNow();
    }
}
