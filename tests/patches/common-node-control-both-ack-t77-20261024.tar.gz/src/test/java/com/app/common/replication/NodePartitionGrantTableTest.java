package com.app.common.replication;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import org.junit.Test;
import static org.junit.Assert.*;

public class NodePartitionGrantTableTest {
    private static final String A="NodeA",B="NodeB";
    private final AtomicLong time=new AtomicLong(100000000000L);
    private final AtomicInteger controlCalls=new AtomicInteger();
    private final NodePartitionGrantTable.ControlVerifier verifier=proof->{
        controlCalls.incrementAndGet();
        if(proof.quorumProof()[0]!=42)
            throw new IOException("invalid authenticated ZK control quorum");
    };
    private NodePartitionGrantTable table(String node) {
        return new NodePartitionGrantTable(node,time::get,verifier,256,1000000000L);
    }
    private Map<String,NodePartitionGrantTable.Partition> partitions(
            int total,long epoch,DurableWalAckPolicy mode,boolean swap) {
        Map<String,NodePartitionGrantTable.Partition> result=new HashMap<>();
        for(int i=0;i<total;i++){
            String id=String.format("P%03d",i);
            String owner=(i%2==0)^swap?A:B,replica=owner.equals(A)?B:A;
            result.put(id,new NodePartitionGrantTable.Partition(id,epoch,owner,
                replica,mode));
        }
        return result;
    }
    private NodePartitionGrantTable.Batch batch(long generation,long epoch,
            DurableWalAckPolicy mode,boolean swap) {
        return new NodePartitionGrantTable.Batch(A,generation,time.get(),
            900000000L,0L,partitions(256,epoch,mode,swap),new byte[]{42});
    }
    private static void denied(Checked runnable,String contains)throws Exception {
        try {runnable.go();fail("invalid grant was allowed");}
        catch(IOException expected){
            assertTrue(expected.getMessage(),expected.getMessage().contains(contains));
        }
    }
    interface Checked {void go()throws Exception;}

    @Test public void exactly256PartitionsOneNodeProofNoZkOnBusinessHotPath()
            throws Exception {
        NodePartitionGrantTable node=table(A);
        node.install(batch(1,1,DurableWalAckPolicy.STRICT_QUORUM,false));
        assertEquals(256,node.partitionCount());
        assertEquals(1,controlCalls.get());
        for(int i=0;i<200000;i++){
            String id=String.format("P%03d",i%256);
            if((i%256)%2==0){
                NodePartitionGrantTable.Permit p=node.primary(
                    id,1,DurableWalAckPolicy.STRICT_QUORUM);
                p.requireAckEvidence("QUORUM_DURABLE",true,false);
            }else{
                NodePartitionGrantTable.Permit p=node.replica(
                    id,1,DurableWalAckPolicy.STRICT_QUORUM);
                p.requireCurrent();
            }
        }
        assertEquals("no controller/ZK probes in business hot path",
                     1,controlCalls.get());
    }

    @Test public void asyncLocalAckHasSameZeroZkRoutingButAdmitsRpoRisk()
            throws Exception {
        NodePartitionGrantTable node=table(A);
        node.install(batch(1,1,DurableWalAckPolicy.LOCAL_DURABLE_ASYNC,false));
        NodePartitionGrantTable.Permit p=node.primary("P000",1,
            DurableWalAckPolicy.LOCAL_DURABLE_ASYNC);
        p.requireAckEvidence("LOCAL_DURABLE_ASYNC",false,true);
        denied(()->p.requireAckEvidence("QUORUM_DURABLE",true,false),
            "EVIDENCE_MISMATCH");
        denied(()->p.requireAckEvidence("LOCAL_DURABLE_ASYNC",false,false),
            "EVIDENCE_MISMATCH");
        denied(()->node.primary("P000",1,DurableWalAckPolicy.STRICT_QUORUM),
            "ACK policy");
        assertEquals(1,controlCalls.get());
    }

    @Test public void sameNodeGenerationCanRenewOnlySameTopology()throws Exception{
        NodePartitionGrantTable t=table(A);
        t.install(batch(1,1,DurableWalAckPolicy.STRICT_QUORUM,false));
        time.addAndGet(100000000L);
        t.install(batch(1,1,DurableWalAckPolicy.STRICT_QUORUM,false));
        assertEquals(2,controlCalls.get());
        denied(()->t.install(batch(1,1,
            DurableWalAckPolicy.LOCAL_DURABLE_ASYNC,false)),"topology");
        denied(()->t.install(batch(1,1,
            DurableWalAckPolicy.STRICT_QUORUM,true)),"topology");
    }

    @Test public void revocationCannotReAuthorizeSameEpochEvenNewGeneration()
            throws Exception {
        NodePartitionGrantTable t=table(A);
        t.install(batch(1,1,DurableWalAckPolicy.STRICT_QUORUM,false));
        NodePartitionGrantTable.Permit old=t.primary("P000",1,
            DurableWalAckPolicy.STRICT_QUORUM);
        t.revoke();
        denied(old::requireCurrent,"revoked");
        denied(()->t.install(batch(1,1,DurableWalAckPolicy.STRICT_QUORUM,false)),
            "revoked");
        denied(()->t.install(batch(2,1,DurableWalAckPolicy.STRICT_QUORUM,false)),
            "revoked epoch");
        time.addAndGet(1000000);
        t.install(batch(2,2,DurableWalAckPolicy.STRICT_QUORUM,true));
        assertEquals(2,t.generation());
        denied(old::requireCurrent,"generation");
        denied(()->t.primary("P000",1,DurableWalAckPolicy.STRICT_QUORUM),
            "stale partition");
        assertNotNull(t.replica("P000",2,DurableWalAckPolicy.STRICT_QUORUM));
    }

    @Test public void expiredNodeLeaseRequiresAuthorizedHigherEpoch()throws Exception{
        NodePartitionGrantTable t=table(A);
        t.install(batch(1,1,DurableWalAckPolicy.LOCAL_DURABLE_ASYNC,false));
        NodePartitionGrantTable.Permit p=t.primary("P000",1,
            DurableWalAckPolicy.LOCAL_DURABLE_ASYNC);
        time.addAndGet(900000000L);
        denied(p::requireCurrent,"expired");
        denied(()->t.install(batch(1,1,
            DurableWalAckPolicy.LOCAL_DURABLE_ASYNC,false)),"revoked");
        denied(()->t.install(batch(2,1,
            DurableWalAckPolicy.LOCAL_DURABLE_ASYNC,false)),"revoked epoch");
        t.install(batch(2,2,DurableWalAckPolicy.LOCAL_DURABLE_ASYNC,false));
        assertEquals(2,t.generation());
    }

    @Test public void newEpochCannotACKBeforeOldWriterRetirementBarrier()
            throws Exception {
        NodePartitionGrantTable t=table(A);
        t.install(new NodePartitionGrantTable.Batch(A,2,time.get(),
            900000000L,300000000L,
            partitions(256,2,DurableWalAckPolicy.STRICT_QUORUM,true),
            new byte[]{42}));
        denied(()->t.replica("P000",2,DurableWalAckPolicy.STRICT_QUORUM),
            "retirement fence");
        time.addAndGet(300000000L);
        t.replica("P000",2,DurableWalAckPolicy.STRICT_QUORUM).requireCurrent();
    }

    @Test public void forgedProofInvalidNodeOrTooManyPartitionsFailClosed()
            throws Exception {
        NodePartitionGrantTable t=table(A);
        denied(()->t.install(new NodePartitionGrantTable.Batch(A,1,time.get(),
            900000000L,0L,partitions(256,1,
            DurableWalAckPolicy.STRICT_QUORUM,false),new byte[]{99})),
            "invalid authenticated");
        assertEquals(0,t.partitionCount());
        denied(()->t.install(new NodePartitionGrantTable.Batch(B,1,time.get(),
            900000000L,0L,partitions(256,1,
            DurableWalAckPolicy.STRICT_QUORUM,false),new byte[]{42})),
            "node control");
        denied(()->t.install(new NodePartitionGrantTable.Batch(A,1,time.get(),
            900000000L,0L,partitions(257,1,
            DurableWalAckPolicy.STRICT_QUORUM,false),new byte[]{42})),
            "capacity");
    }

    @Test public void watchInvalidatesInFlightClientBeforeAck()throws Exception{
        NodePartitionGrantTable t=table(A);
        t.install(batch(1,1,DurableWalAckPolicy.LOCAL_DURABLE_ASYNC,false));
        NodePartitionGrantTable.Permit p=t.primary("P000",1,
            DurableWalAckPolicy.LOCAL_DURABLE_ASYNC);
        t.revoke();
        denied(()->p.requireAckEvidence("LOCAL_DURABLE_ASYNC",false,true),
            "revoked");
    }
}
