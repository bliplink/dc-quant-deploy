package com.app.common.partition;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
 * Per-partition, read-only ZK epoch/version fencing precondition.
 *
 * A logical primary cannot rely on process-local READY alone: its old epoch
 * must match the latest assignment's ZooKeeper stat.version, logical config
 * version, role, and RF2 membership on EVERY checked commit boundary.
 *
 * This check is NOT a grant, does NOT own a ZK controller lease, and cannot
 * independently make a non-atomic network/DB/WAL write linearizable with a
 * concurrent ZK CAS. Services must enforce an exclusive source-epoch write
 * barrier / verified publishing fence and recheck under that barrier.
 */
public final class PartitionEpochReadFence {
    public interface Connection {
        boolean isConnected();
    }

    public static final class Ticket {
        private final String partition;
        private final String primary;
        private final long epoch;
        private final long configuration;
        private final int zkVersion;
        private final List<String> replicas;

        private Ticket(String partition, String primary, long epoch,
                long configuration, int zkVersion, List<String> replicas) {
            this.partition=partition;
            this.primary=primary;
            this.epoch=epoch;
            this.configuration=configuration;
            this.zkVersion=zkVersion;
            this.replicas=Collections.unmodifiableList(new ArrayList<String>(replicas));
        }
        public String getPartitionId(){return partition;}
        public String getPrimary(){return primary;}
        public long getEpoch(){return epoch;}
        public long getAssignmentVersion(){return configuration;}
        public int getZkVersion(){return zkVersion;}
    }

    private final Connection connection;
    private final PartitionFailoverController.AssignmentStore assignments;

    public PartitionEpochReadFence(Connection connection,
            PartitionFailoverController.AssignmentStore assignments) {
        this.connection=Objects.requireNonNull(connection,"connection");
        this.assignments=Objects.requireNonNull(assignments,"assignments");
    }

    /** Returns a NON-transferable epoch ticket only for a strictly READY
     * locally recovered primary with two nonoverlapping RF2 voters. */
    public Ticket readCurrent(String partition, String node) {
        requireConnected();
        if (blank(partition) || blank(node))
            throw denied("partition and node required");
        PartitionFailoverController.VersionedAssignment current=assignments.read(partition);
        if(current==null || current.getAssignment()==null || current.getVersion()<0)
            throw denied("missing ZooKeeper assignment/version");
        PartitionAssignment a=current.getAssignment();
        requireEligible(partition,node,a);
        Ticket ticket=new Ticket(partition,node.trim(),a.getEpoch(),
                a.getAssignmentVersion(),current.getVersion(),normalized(a.replicaNodes()));
        requireConnected();
        return ticket;
    }

    /** Check immediately before issuing a WAL receipt and immediately before
     * client publication within the caller's serialized epoch barrier. */
    public void requireCurrent(Ticket ticket) {
        if(ticket==null)throw denied("absent epoch authorization ticket");
        requireConnected();
        PartitionFailoverController.VersionedAssignment current=
                assignments.read(ticket.partition);
        if(current==null || current.getAssignment()==null
                || current.getVersion()!=ticket.zkVersion)
            throw denied("stale ZooKeeper assignment CAS version");
        PartitionAssignment a=current.getAssignment();
        requireEligible(ticket.partition,ticket.primary,a);
        if(a.getEpoch()!=ticket.epoch
                || a.getAssignmentVersion()!=ticket.configuration
                || !normalized(a.replicaNodes()).equals(ticket.replicas))
            throw denied("changed epoch or RF2 member configuration");
        requireConnected();
    }

    private void requireEligible(String partition,String node,PartitionAssignment a) {
        if(!partition.equals(a.getPartitionId())
                || !"READY".equals(a.getState())
                || a.getEpoch()<=0
                || a.getAssignmentVersion()<0
                || !normalize(node).equals(normalize(a.getPrimary()))
                || a.replicaNodes().size()!=1
                || normalize(a.replicaNodes().get(0)).equals(normalize(node))
                || !PartitionAssignmentValidator.validate(a).isEmpty()
                || !PartitionReadinessGuard.isReady(node,partition,a.getEpoch()))
            throw denied("partition not READY with same local epoch and RF2 primary");
    }

    private void requireConnected(){
        if(!connection.isConnected())throw denied("ZooKeeper control unavailable");
    }
    private static List<String> normalized(List<String> members) {
        List<String> result=new ArrayList<String>();
        for(String member:members)result.add(normalize(member));
        return result;
    }
    private static String normalize(String node){
        return PartitionConfig.normalizeServerName(node == null ? "" : node).trim().toLowerCase();
    }
    private static boolean blank(String v){return v==null || v.trim().isEmpty();}
    private static IllegalStateException denied(String why){
        return new IllegalStateException("PARTITION_EPOCH_FENCED: "+why);
    }
}
