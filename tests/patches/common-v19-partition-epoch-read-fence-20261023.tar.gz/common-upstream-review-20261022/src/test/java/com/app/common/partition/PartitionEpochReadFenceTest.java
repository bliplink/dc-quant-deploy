package com.app.common.partition;

import java.util.Collections;
import org.junit.After;
import org.junit.Test;
import static org.junit.Assert.*;

public final class PartitionEpochReadFenceTest {
    private static final class Store implements PartitionFailoverController.AssignmentStore,
            PartitionEpochReadFence.Connection {
        boolean connected=true;
        PartitionAssignment a=ready("P000","A","B",7);
        int zkVersion=15;
        public boolean isConnected(){return connected;}
        public PartitionFailoverController.VersionedAssignment read(String partition){
            if(!"P000".equals(partition)||a==null)return null;
            return new PartitionFailoverController.VersionedAssignment(a,zkVersion);
        }
        public boolean compareAndSet(String partition,int expected,PartitionAssignment next){
            if(!connected || expected!=zkVersion || !"P000".equals(partition))return false;
            a=next;zkVersion++;return true;
        }
        PartitionEpochReadFence fence(){return new PartitionEpochReadFence(this,this);}
    }
    private static PartitionAssignment ready(String id,String primary,String replica,long epoch){
        PartitionAssignment a=new PartitionAssignment();
        a.setPartitionId(id);a.setPrimary(primary);a.setReplica(replica);
        a.setReplicas(Collections.singletonList(replica));
        a.setState("READY");a.setEpoch(epoch);a.setAssignmentVersion(2);
        return a;
    }
    private static void denied(Runnable r){
        try {r.run();fail("stale epoch accepted");}
        catch(IllegalStateException expected) {
            assertTrue(expected.getMessage().startsWith("PARTITION_EPOCH_FENCED:"));
        }
    }
    @After public void clear() {
        PartitionReadinessGuard.clear("A");PartitionReadinessGuard.clear("B");
    }
    @Test public void strictlyReadyMatchingPrimaryCanRecheckSameZkVersion(){
        Store s=new Store();
        PartitionReadinessGuard.markReady("A","P000",7);
        PartitionEpochReadFence.Ticket ticket=s.fence().readCurrent("P000","A");
        assertEquals(15,ticket.getZkVersion());
        assertEquals(7,ticket.getEpoch());
        s.fence().requireCurrent(ticket);
        denied(()->s.fence().readCurrent("P000","B"));
    }
    @Test public void sourceIsFencedAfterEpochCasAndNewPrimaryStillNeedsRecovery(){
        Store s=new Store();PartitionReadinessGuard.markReady("A","P000",7);
        PartitionEpochReadFence.Ticket old=s.fence().readCurrent("P000","A");
        PartitionAssignment next=ready("P000","B","A",8);
        next.setState("RECOVERING");
        next.setAssignmentVersion(3);
        assertTrue(s.compareAndSet("P000",15,next));
        denied(()->s.fence().requireCurrent(old));
        denied(()->s.fence().readCurrent("P000","A"));
        denied(()->s.fence().readCurrent("P000","B"));
        next.setState("READY");
        denied(()->s.fence().readCurrent("P000","B"));
        PartitionReadinessGuard.markReady("B","P000",8);
        PartitionEpochReadFence.Ticket recovered=s.fence().readCurrent("P000","B");
        assertEquals(16,recovered.getZkVersion());
        s.fence().requireCurrent(recovered);
        denied(()->s.fence().requireCurrent(old));
    }
    @Test public void sameEpochVersionChangeOrMembershipMutationRevokesOldTicket(){
        Store s=new Store();PartitionReadinessGuard.markReady("A","P000",7);
        PartitionEpochReadFence.Ticket old=s.fence().readCurrent("P000","A");
        s.zkVersion++;
        denied(()->s.fence().requireCurrent(old));
        PartitionEpochReadFence.Ticket newer=s.fence().readCurrent("P000","A");
        s.a.setReplica("C");s.a.setReplicas(Collections.singletonList("C"));
        denied(()->s.fence().requireCurrent(newer));
    }
    @Test public void zkDisconnectAndLostLocalReadyAlwaysDeny(){
        Store s=new Store();PartitionReadinessGuard.markReady("A","P000",7);
        PartitionEpochReadFence.Ticket old=s.fence().readCurrent("P000","A");
        s.connected=false;denied(()->s.fence().requireCurrent(old));
        s.connected=true;PartitionReadinessGuard.revoke("A","P000");
        denied(()->s.fence().requireCurrent(old));
    }
    @Test public void preparingAndInvalidBuddyMustNotProduceTicket(){
        Store s=new Store();PartitionReadinessGuard.markReady("A","P000",7);
        s.a.setState("PREPARING");denied(()->s.fence().readCurrent("P000","A"));
        s.a.setState("READY");s.a.setReplica("A");
        s.a.setReplicas(Collections.singletonList("A"));
        denied(()->s.fence().readCurrent("P000","A"));
        s.a=null;denied(()->s.fence().readCurrent("P000","A"));
    }
}
