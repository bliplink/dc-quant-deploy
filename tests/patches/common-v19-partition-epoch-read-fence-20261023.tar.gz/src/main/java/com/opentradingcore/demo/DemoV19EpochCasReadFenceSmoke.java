package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;
import com.app.common.partition.PartitionEpochReadFence;
import com.app.common.partition.PartitionFailoverController;
import com.app.common.partition.PartitionReadinessGuard;
import com.app.common.partition.ZkPartitionFailoverControlPlane;
import com.app.common.zk.ZookeeperClient;
import com.gateway.connector.utils.JsonUtils;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import org.apache.zookeeper.CreateMode;

/**
 * Real three-ZooKeeper CAS regression on a UNIQUE TEST-ONLY assignment root.
 * Never touches the actual 256 PREPARING assignments or physical WALs.
 * Synthetic READY and process-local ready here do not authorize production.
 */
public final class DemoV19EpochCasReadFenceSmoke {
    private DemoV19EpochCasReadFenceSmoke() {}
    private static void require(boolean ok,String message)throws IOException {
        if(!ok)throw new IOException("isolated real ZK Epoch CAS: "+message);
    }
    private static void deny(Runnable operation,String what)throws IOException {
        try{operation.run();}
        catch(IllegalStateException correctlyDenied){return;}
        throw new IOException("old/unauthorized Epoch accepted: "+what);
    }
    private static PartitionAssignment assignment(String primary,String replica,
            long epoch,long configuration,String state) {
        PartitionAssignment a=new PartitionAssignment();
        a.setPartitionId("P000");
        a.setPrimary(primary);
        a.setReplica(replica);
        a.setReplicas(java.util.Collections.singletonList(replica));
        a.setEpoch(epoch);
        a.setAssignmentVersion(configuration);
        a.setState(state);
        return a;
    }
    private static String json(PartitionAssignment a) {
        Map<String,Object> values=new LinkedHashMap<>();
        values.put("partitionId",a.getPartitionId());
        values.put("primary",a.getPrimary());
        values.put("replica",a.getReplica());
        values.put("replicas",a.getReplicas());
        values.put("epoch",a.getEpoch());
        values.put("assignmentVersion",a.getAssignmentVersion());
        values.put("state",a.getState());
        return JsonUtils.Serializer(values);
    }
    public static void main(String[] args)throws Exception {
        if(args.length!=1 || !"--test-only".equals(args[0]))
            throw new IllegalArgumentException("explicit --test-only required");
        final String path=DemoV19FourNodeShardCatalog.ROOT+
            "/epoch-read-fence-smoke/"+UUID.randomUUID().toString();
        final String assignments=path+"/assignments";
        final String partition=assignments+"/P000";
        ZookeeperClient one=new ZookeeperClient(DemoAssignmentBootstrap.HOSTS,null,null);
        ZookeeperClient two=new ZookeeperClient(DemoAssignmentBootstrap.HOSTS,null,null);
        try{
            for(int i=0;i<100 && !(one.isConnected() && two.isConnected());i++)
                Thread.sleep(100);
            require(one.isConnected() && two.isConnected(),"two live ZK sessions");
            DemoV19FourNodeShardCatalog.ensurePath(one,
                DemoV19FourNodeShardCatalog.ROOT+"/epoch-read-fence-smoke");
            DemoV19FourNodeShardCatalog.ensurePath(one,path);
            DemoV19FourNodeShardCatalog.ensurePath(one,assignments);
            one.create(partition,json(assignment("CommonHaDemoA","CommonHaDemoB",
                    41,2,"READY")),CreateMode.PERSISTENT);
            try(ZkPartitionFailoverControlPlane first=
                    new ZkPartitionFailoverControlPlane(one,assignments,
                        "/MDTService",path+"/first-control-lease","smoke-A");
                ZkPartitionFailoverControlPlane second=
                    new ZkPartitionFailoverControlPlane(two,assignments,
                        "/MDTService",path+"/second-control-lease","smoke-B")){
                PartitionReadinessGuard.markReady("CommonHaDemoA","P000",41);
                PartitionEpochReadFence guard=new PartitionEpochReadFence(one::isConnected,first);
                PartitionEpochReadFence.Ticket old=
                    guard.readCurrent("P000","CommonHaDemoA");
                require(old.getZkVersion()==0 && old.getEpoch()==41,
                    "old original ready ticket");
                PartitionAssignment next=assignment("CommonHaDemoB","CommonHaDemoA",
                    42,3,"RECOVERING");
                require(second.compareAndSet("P000",0,next),
                    "first ZK CAS should advance to recovering");
                require(!first.compareAndSet("P000",0,next),
                    "stale ZK stat.version 0 CAS MUST fail");
                deny(()->guard.requireCurrent(old),"old-primary stale ticket");
                deny(()->guard.readCurrent("P000","CommonHaDemoA"),
                    "old-primary read after epoch CAS");
                PartitionReadinessGuard.markReady("CommonHaDemoB","P000",42);
                deny(()->new PartitionEpochReadFence(two::isConnected,second)
                    .readCurrent("P000","CommonHaDemoB"),
                    "new primary RECOVERING is not READY");
                PartitionFailoverController.VersionedAssignment result=
                    second.read("P000");
                require(result!=null && result.getVersion()==1
                        && result.getAssignment().getEpoch()==42
                        && "RECOVERING".equals(result.getAssignment().getState()),
                    "actual ZK CAS epoch/version persisted");
                System.out.println("THREE_ZK_PARTITION_EPOCH_READ_FENCE_CAS_PASS"
                    +" tempAssignmentOnly=true"
                    +" oldEpoch=41 fencedByCAS=true newEpoch=42"
                    +" zkStatVersion=1 staleCasRejected=true"
                    +" oldPrimaryTicketRejected=true"
                    +" recoveringNewPrimaryDenied=true"
                    +" real256AssignmentsUntouched=true"
                    +" clientAck=false");
            }
        }finally{
            PartitionReadinessGuard.clear("CommonHaDemoA");
            PartitionReadinessGuard.clear("CommonHaDemoB");
            try{if(one.isConnected()){
                one.delete(partition);
                one.delete(assignments);
                one.delete(path);
            }}catch(Exception cleanup){System.err.println(
                "TEMP_ZK_SMOKE_CLEANUP_WARNING "+cleanup.getMessage());}
            one.close();
            two.close();
        }
    }
}
