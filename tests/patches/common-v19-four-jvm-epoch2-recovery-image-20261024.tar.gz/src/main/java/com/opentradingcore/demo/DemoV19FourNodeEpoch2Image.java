package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;
import com.app.common.replication.*;
import com.app.common.zk.ZookeeperClient;
import com.gateway.connector.utils.JsonUtils;
import java.io.*;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.*;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.*;
import java.util.concurrent.TimeUnit;
import org.I0Itec.zkclient.exception.ZkNodeExistsException;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.data.Stat;

/**
 * Frozen old epoch -> new epoch 2 RESTORABLE IMAGE PREPARE ONLY.
 * Requires prior 2/2 RSA revocation proof and two physically certified WAL
 * and custody heads. No new epoch assignment, READY, promotion or customer ACK.
 */
final class DemoV19FourNodeEpoch2Image {
    static final String OP="INTERNAL_EPOCH2_FROZEN_IMAGE_PREPARE_V1";
    static final String INTENTS=DemoV19FourNodeShardCatalog.ROOT+"/epoch2-image-intents";
    static final String PROOFS=DemoV19FourNodeShardCatalog.ROOT+"/epoch2-image-proofs";
    static final String SCOPE="FROZEN_EPOCH1_TO_EPOCH2_IMAGE_NO_READY_V1";
    private static final String SOURCE="PREPARING_SOURCE_EPOCH1_REVOKED_NO_READY";
    private final String node;
    private final Path root;
    private final PrivateKey signingKey;
    DemoV19FourNodeEpoch2Image(String node,Path root)throws Exception {
        this.node=node;this.root=root;
        signingKey=KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(
            Files.readAllBytes(root.resolve(".preflight-identity/local.pk8"))));
    }
    static String imagePath(String part){return ".pilot-epoch2-image-"+part;}
    private static String hash(byte[] payload)throws Exception{
        return DemoV19FourNodeGenesisCustody.sha(payload);
    }
    private static void ensureExactOldProof(ZookeeperClient zk,PartitionAssignment a,
            DurableWalCommitQuorum.Membership membership,String sha)throws Exception{
        DemoV19FourNodeCommonMembership.requireUnchanged(zk,a);
        String part=a.getPartitionId();
        Stat intentV=new Stat();
        Object raw=zk.readData(DemoV19FourNodeRemoteRevocation.intentPath(part),intentV);
        if(raw==null || intentV.getVersion()!=0)
            throw new IOException("missing immutable old source revoke intent");
        @SuppressWarnings("unchecked")
        Map<String,Object> intent=JsonUtils.Deserialize(String.valueOf(raw),Map.class);
        if(!SOURCE.equals(intent.get("scope")) || !part.equals(intent.get("partition"))
                || !membership.digest.equals(intent.get("membershipSha256"))
                || !sha.equals(intent.get("walSha256")))
            throw new IOException("old source revoked WAL evidence differs");
        Stat proofV=new Stat();
        Object physical=zk.readData(DemoV19FourNodeRemoteRevocation.proofPath(part),proofV);
        if(physical==null || proofV.getVersion()!=0)
            throw new IOException("two independent physical revoke RSA votes missing");
        @SuppressWarnings("unchecked")
        Map<String,Object> proof=JsonUtils.Deserialize(String.valueOf(physical),Map.class);
        if(!SOURCE.equals(proof.get("scope"))
            || !part.equals(proof.get("partition"))
            || !membership.digest.equals(proof.get("membershipSha256"))
            || !sha.equals(proof.get("walSha256"))
            || !(proof.get("nonce") instanceof String)
            || !(proof.get("votes") instanceof List)
            || ((List<?>)proof.get("votes")).size()!=2)
            throw new IOException("untrusted old source revoke quorum");
        List<?> entries=(List<?>)proof.get("votes");
        for(int i=0;i<2;i++){
            if(!(entries.get(i) instanceof Map))throw new IOException("malformed voter");
            DemoV19FourNodeRemoteRevocation.verify(zk,a,
                DemoV19FourNodeLiveRuntime.owners(a).get(i),
                (String)proof.get("nonce"),membership.digest,sha,
                ReplicationControlResponse.ok(DemoNettyBridge.json(entries.get(i))));
        }
        DemoV19FourNodeCommonMembership.requireUnchanged(zk,a);
    }
    static byte[] trustedSnapshot(DemoDurableJournal wal,PartitionAssignment a,
            String sourceSha)throws Exception{
        if(wal==null || a==null || wal.committedSeq()!=1 || wal.lastEpoch()!=1
                || !wal.isReadyForWrites()
                || !sourceSha.equals(wal.committedPrefixSha256Through(1))
                || !wal.hasPhysicalGenesis(1,a.getPartitionId(),
                    DemoV19FourNodeGenesisPreflight.exactAssignmentDigest(a)))
            throw new IOException("untrusted pre-recovery WAL boundary");
        DemoStateMachine source=wal.state();
        if(source.distinctRequests()!=1
            || source.appliedCount(DemoV19FourNodeSeq1NettyPilot.requestId(
                a.getPartitionId()))!=1
            || source.total()!=DemoV19FourNodeSeq1NettyPilot.delta(a.getPartitionId()))
            throw new IOException("unexpected source demo committed state");
        byte[] bytes=source.captureSnapshot();
        if(bytes.length==0 || bytes.length>1024*1024)
            throw new IOException("unbounded or missing state snapshot");
        DemoStateMachine restored=new DemoStateMachine();
        restored.snapshot(bytes);
        if(!restored.stateDigest().equals(source.stateDigest())
            || restored.total()!=source.total() || restored.distinctRequests()!=1)
            throw new IOException("state restore not identical");
        return bytes;
    }
    private static byte[] imageBytes(PartitionAssignment a,String membership,String walSha,
            byte[] state)throws Exception{
        String successor=a.getReplica();
        String prefix=SCOPE+"\n"+a.getPartitionId()+"\n"+successor+"\n"+
            a.getPrimary()+"\nnewEpoch=2\nsourceEpoch=1\nsourceSeq=1\nmember="+
            membership+"\nwal="+walSha+"\nimage="+hash(state)+"\n";
        ByteArrayOutputStream output=new ByteArrayOutputStream();
        output.write(prefix.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        output.write(state);
        return output.toByteArray();
    }
    private static void forceDirectory(Path dir)throws Exception{
        try(FileChannel channel=FileChannel.open(dir,StandardOpenOption.READ)){
            channel.force(true);
        }
    }
    static String install(Path root,PartitionAssignment a,String membership,String walSha,
            byte[] state)throws Exception{
        if(root==null || !root.isAbsolute() || Files.isSymbolicLink(root)
            || membership==null || !membership.matches("[a-f0-9]{64}")
            || walSha==null || !walSha.matches("[a-f0-9]{64}"))
            throw new IOException("untrusted epoch2 candidate");
        Path dir=root.resolve(imagePath(a.getPartitionId()));
        Files.createDirectories(dir);
        if(Files.isSymbolicLink(dir))throw new IOException("recovery directory symlink");
        Path head=dir.resolve("candidate.bin"),pending=dir.resolve("candidate.pending");
        if(Files.isSymbolicLink(head) || Files.exists(pending,LinkOption.NOFOLLOW_LINKS))
            throw new IOException("torn, redirected recovery image");
        byte[] bytes=imageBytes(a,membership,walSha,state);
        if(Files.exists(head,LinkOption.NOFOLLOW_LINKS)){
            if(!Arrays.equals(Files.readAllBytes(head),bytes))
                throw new IOException("existing image differs from immutable source");
            return hash(bytes);
        }
        try(FileChannel out=FileChannel.open(pending,
                StandardOpenOption.CREATE_NEW,StandardOpenOption.WRITE)){
            ByteBuffer wrapped=ByteBuffer.wrap(bytes);
            while(wrapped.hasRemaining())out.write(wrapped);
            out.force(true);
        }
        Files.move(pending,head,StandardCopyOption.ATOMIC_MOVE);
        forceDirectory(dir);forceDirectory(root);
        if(!Arrays.equals(Files.readAllBytes(head),bytes))
            throw new IOException("image not durable after fsync");
        return hash(bytes);
    }
    private static String statement(String part,String node,String member,
            String walSha,String imageSha,String headSha,String nonce){
        return "FOUR_NODE_EPOCH2_FROZEN_IMAGE_V1|"+part+"|"+node+
            "|sourceEpoch=1|recoveryEpoch=2|seq=1|"+member+"|"+walSha+
            "|"+imageSha+"|"+headSha+"|"+nonce;
    }
    private static String sign(PrivateKey key,String statement)throws Exception {
        Signature rsa=Signature.getInstance("SHA256withRSA");
        rsa.initSign(key);rsa.update(statement.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        return Base64.getEncoder().encodeToString(rsa.sign());
    }
    static void verify(ZookeeperClient zk,PartitionAssignment a,String node,
            String member,String walSha,String nonce,ReplicationControlResponse reply)
            throws Exception{
        if(reply==null || !reply.isSuccess())throw new IOException("physical image denied");
        Map<String,Object> fields=DemoNettyBridge.map(reply.getPayload());
        if(!SCOPE.equals(fields.get("scope")) || !a.getPartitionId().equals(fields.get("partition"))
            || !node.equals(fields.get("node")) || !nonce.equals(fields.get("nonce"))
            || !member.equals(fields.get("membershipSha256"))
            || !walSha.equals(fields.get("walSha256"))
            || !Boolean.FALSE.equals(fields.get("ready"))
            || !Boolean.FALSE.equals(fields.get("clientAck"))
            || !(fields.get("imageSha256") instanceof String)
            || !(fields.get("headSha256") instanceof String)
            || !(fields.get("signature") instanceof String))
            throw new IOException("incomplete physical epoch2 image proof");
        Signature rsa=Signature.getInstance("SHA256withRSA");
        rsa.initVerify(DemoV19FourNodeGenesisPreflight.pinned(zk,node));
        rsa.update(statement(a.getPartitionId(),node,member,walSha,
            (String)fields.get("imageSha256"),(String)fields.get("headSha256"),nonce)
            .getBytes(java.nio.charset.StandardCharsets.UTF_8));
        if(!rsa.verify(Base64.getDecoder().decode((String)fields.get("signature"))))
            throw new IOException("recovery image RSA forged");
    }
    static void prepareTwo(ZookeeperClient zk,List<PartitionAssignment> plan)throws Exception{
        if(!zk.isConnected())throw new IOException("missing three-ZK source quorum");
        DemoV19FourNodeShardCatalog.ensurePath(zk,INTENTS);
        DemoV19FourNodeShardCatalog.ensurePath(zk,PROOFS);
        try(DirectNettyReplicationTransport net=new DirectNettyReplicationTransport(
                10000,DirectNettyReplicationServer.DEFAULT_MAX_FRAME_BYTES)){
            for(char owner:new char[]{'A','C'}){
                String part=DemoV19FourNodeGenesisPreflight.firstShard(plan,owner);
                PartitionAssignment a=plan.get(Integer.parseInt(part.substring(1)));
                DurableWalCommitQuorum.Membership member=
                    DemoV19FourNodeCommonMembership.pinned(zk,a);
                String walSha=null;
                for(String source:DemoV19FourNodeLiveRuntime.owners(a)){
                    ReplicationControlResponse live=net.control(
                        DemoV19FourNodeLiveRuntime.exactEndpoint(source),
                        new ReplicationControlRequest(DemoV19FourNodeShardCatalog.SERVICE,
                            "CATALOG_STATUS_V1",part,new byte[0]))
                        .get(8,TimeUnit.SECONDS);
                    if(!live.isSuccess())throw new IOException("missing physical source");
                    Map<String,Object> status=DemoNettyBridge.map(live.getPayload());
                    if(!Boolean.FALSE.equals(status.get("ready"))
                        || !(status.get("committedSeq") instanceof Number)
                        || ((Number)status.get("committedSeq")).longValue()!=1
                        || !(status.get("committedPrefixSha256") instanceof String))
                        throw new IOException("source not safely frozen at seq1");
                    String current=(String)status.get("committedPrefixSha256");
                    if(walSha!=null && !walSha.equals(current))
                        throw new IOException("physical source WALs forked");
                    walSha=current;
                }
                ensureExactOldProof(zk,a,member,walSha);
                Object existing=zk.readData(
                    DemoV19FourNodeRemoteRevocation.proofPath(part));
                String oldProofHash=hash(String.valueOf(existing).getBytes(
                    java.nio.charset.StandardCharsets.UTF_8));
                Map<String,Object> intent=new LinkedHashMap<>();
                intent.put("scope",SCOPE);
                intent.put("partition",part);
                intent.put("membershipSha256",member.digest);
                intent.put("walSha256",walSha);
                intent.put("sourceRevokeProofSha256",oldProofHash);
                intent.put("newEpoch",2);
                intent.put("state","PREPARE_IMAGE_ONLY");
                String path=INTENTS+"/"+part;
                if(!zk.exists(path)){
                    try{zk.create(path,JsonUtils.Serializer(intent),CreateMode.PERSISTENT);}
                    catch(ZkNodeExistsException raced){}
                }
                Stat version=new Stat();
                Object actual=zk.readData(path,version);
                if(actual==null || version.getVersion()!=0
                    || !JsonUtils.Serializer(intent).equals(String.valueOf(actual)))
                    throw new IOException("immutable recovery preparation changed");
                byte[] challenge=new byte[32];new SecureRandom().nextBytes(challenge);
                String nonce=DemoV19FourNodeGenesisPreflight.hex(challenge);
                List<Map<String,Object>> signed=new ArrayList<>();
                String image=null,candidate=null;
                for(String physical:DemoV19FourNodeLiveRuntime.owners(a)){
                    ReplicationControlResponse reply=net.control(
                        DemoV19FourNodeLiveRuntime.exactEndpoint(physical),
                        new ReplicationControlRequest(DemoV19FourNodeShardCatalog.SERVICE,
                            OP,part,challenge)).get(8,TimeUnit.SECONDS);
                    verify(zk,a,physical,member.digest,walSha,nonce,reply);
                    Map<String,Object> fields=DemoNettyBridge.map(reply.getPayload());
                    String i=(String)fields.get("imageSha256");
                    String c=(String)fields.get("headSha256");
                    if(image!=null && !image.equals(i))
                        throw new IOException("state snapshot diverges across real peers");
                    if(candidate!=null && !candidate.equals(c))
                        throw new IOException("physical candidate image bytes differ");
                    image=i;candidate=c;
                    signed.add(fields);
                }
                Map<String,Object> proof=new LinkedHashMap<>();
                proof.put("scope",SCOPE);proof.put("partition",part);
                proof.put("membershipSha256",member.digest);
                proof.put("walSha256",walSha);
                proof.put("sourceRevokeProofSha256",oldProofHash);
                proof.put("imageSha256",image);
                proof.put("headSha256",candidate);
                proof.put("nonce",nonce);proof.put("votes",signed);
                String done=PROOFS+"/"+part;
                if(!zk.exists(done)){
                    try{zk.create(done,JsonUtils.Serializer(proof),CreateMode.PERSISTENT);}
                    catch(ZkNodeExistsException raced){}
                }
                Stat persistedVersion=new Stat();
                Object readback=zk.readData(done,persistedVersion);
                if(readback==null || persistedVersion.getVersion()!=0)
                    throw new IOException("untrusted epoch2 image proof version");
                @SuppressWarnings("unchecked")
                Map<String,Object> saved=JsonUtils.Deserialize(
                    String.valueOf(readback),Map.class);
                if(!SCOPE.equals(saved.get("scope")) || !part.equals(saved.get("partition"))
                    || !member.digest.equals(saved.get("membershipSha256"))
                    || !walSha.equals(saved.get("walSha256"))
                    || !oldProofHash.equals(saved.get("sourceRevokeProofSha256"))
                    || !image.equals(saved.get("imageSha256"))
                    || !candidate.equals(saved.get("headSha256"))
                    || !(saved.get("nonce") instanceof String)
                    || !(saved.get("votes") instanceof List)
                    || ((List<?>)saved.get("votes")).size()!=2)
                    throw new IOException("saved recovery image two-voter proof corrupted");
                List<?> votes=(List<?>)saved.get("votes");
                for(int i=0;i<2;i++) {
                    if(!(votes.get(i) instanceof Map))
                        throw new IOException("malformed durable recovery voter");
                    verify(zk,a,DemoV19FourNodeLiveRuntime.owners(a).get(i),
                        member.digest,walSha,(String)saved.get("nonce"),
                        ReplicationControlResponse.ok(DemoNettyBridge.json(votes.get(i))));
                }
                DemoV19FourNodeCommonMembership.requireUnchanged(zk,a);
                System.out.println("FOUR_NODE_EPOCH2_RECOVERY_IMAGE_PREPARED partition="+part+
                    " oldRevocationRsaVoters=2 sourceWalSeq=1"+
                    " imageSha256="+image+" candidateHeadSha256="+candidate+
                    " twoIndependentFsyncedImages=true twoImageRsaVoters=2"+
                    " zkRecoveryProofPersisted=true sourceAssignmentUnchanged=true"+
                    " epoch2NotReady=true clientAck=false");
            }
        }
    }

    ReplicationControlResponse handle(ZookeeperClient zk,List<PartitionAssignment> plan,
            DemoV19FourNodeLiveRuntime.HeldWal held,ReplicationControlRequest req){
        try{
            if(req==null || !OP.equals(req.getOperation()) || !held.node.equals(node)
                || !DemoV19FourNodeShardCatalog.SERVICE.equals(req.getServiceName())
                || req.getPayload()==null || req.getPayload().length!=32
                || !zk.isConnected())throw new IOException("unauthorized image request");
            String part=req.getPartitionId();
            if(!DemoV19FourNodeSeq1NettyPilot.selected(part))
                throw new IOException("unbounded image partition");
            PartitionAssignment a=plan.get(Integer.parseInt(part.substring(1)));
            if(!DemoV19FourNodeLiveRuntime.owners(a).contains(node))
                throw new IOException("image node is not a source buddy");
            DemoDurableJournal wal=held.owned.get(part);
            if(wal==null)throw new IOException("missing physical locked source WAL");
            synchronized(wal){
                DurableWalCommitQuorum.Membership member=
                    DemoV19FourNodeCommonMembership.pinned(zk,a);
                String sha=wal.committedPrefixSha256Through(1);
                ensureExactOldProof(zk,a,member,sha);
                String frozen=DemoV19FourNodeRemoteRevocation.expectedPayload(
                    a,member.digest,sha)+"\n";
                Path head=root.resolve(".pilot-old-epoch-revoked-"+part)
                    .resolve("head.bin");
                if(!Files.isRegularFile(head,LinkOption.NOFOLLOW_LINKS)
                    || Files.isSymbolicLink(head)
                    || !Arrays.equals(Files.readAllBytes(head),
                        frozen.getBytes(java.nio.charset.StandardCharsets.UTF_8)))
                    throw new IOException("old epoch physical fence not durable");
                try(DurableWalCertificateCustody source=new DurableWalCertificateCustody(
                    root.resolve(".pilot-common-custody-"+part),member,
                    (epoch,seq)->{
                        if(epoch!=1 || seq!=1)
                            throw new IOException("wrong source committed WAL epoch/seq");
                        return wal.committedPrefixSha256Through(1);
                    },
                    trusted->{if(!member.digest.equals(trusted.digest))
                        throw new IOException("foreign historical membership");})){
                    DurableWalCommitQuorum.Certificate certified=source.highestVerified();
                    if(certified==null || certified.committedSequence!=1
                        || !sha.equals(certified.commitPrefixSha256)
                        || certified.votes.size()!=2)
                        throw new IOException("source WAL not certified and custodied");
                }
                Stat version=new Stat();
                Object intentRaw=zk.readData(INTENTS+"/"+part,version);
                if(intentRaw==null || version.getVersion()!=0)
                    throw new IOException("missing immutable epoch2 recovery intent");
                @SuppressWarnings("unchecked")
                Map<String,Object> intent=JsonUtils.Deserialize(
                    String.valueOf(intentRaw),Map.class);
                if(!SCOPE.equals(intent.get("scope"))
                    || !part.equals(intent.get("partition"))
                    || !member.digest.equals(intent.get("membershipSha256"))
                    || !sha.equals(intent.get("walSha256"))
                    || !(intent.get("sourceRevokeProofSha256") instanceof String))
                    throw new IOException("wrong or uncommitted recovery intent");
                Object historical=zk.readData(
                    DemoV19FourNodeRemoteRevocation.proofPath(part));
                String proofSha=hash(String.valueOf(historical).getBytes(
                    java.nio.charset.StandardCharsets.UTF_8));
                if(!proofSha.equals(intent.get("sourceRevokeProofSha256")))
                    throw new IOException("recovery source two-signer proof replaced");
                byte[] image=trustedSnapshot(wal,a,sha);
                String imageSha=hash(image);
                String candidate=install(root,a,member.digest,sha,image);
                DemoV19FourNodeCommonMembership.requireUnchanged(zk,a);
                Map<String,Object> vote=new LinkedHashMap<>();
                String nonce=DemoV19FourNodeGenesisPreflight.hex(req.getPayload());
                vote.put("scope",SCOPE);vote.put("partition",part);
                vote.put("node",node);vote.put("nonce",nonce);
                vote.put("membershipSha256",member.digest);
                vote.put("walSha256",sha);vote.put("imageSha256",imageSha);
                vote.put("headSha256",candidate);
                vote.put("signature",sign(signingKey,statement(
                    part,node,member.digest,sha,imageSha,candidate,nonce)));
                vote.put("ready",false);vote.put("clientAck",false);
                return ReplicationControlResponse.ok(DemoNettyBridge.json(vote));
            }
        }catch(Exception e){
            return ReplicationControlResponse.error("EPOCH2_IMAGE_PREPARE_DENIED",
                e.getClass().getSimpleName()+": "+e.getMessage());
        }
    }
}
