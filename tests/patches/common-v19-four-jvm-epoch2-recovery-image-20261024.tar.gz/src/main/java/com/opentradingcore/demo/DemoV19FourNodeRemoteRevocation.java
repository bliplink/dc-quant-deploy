package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;
import com.app.common.replication.*;
import com.app.common.zk.ZookeeperClient;
import com.gateway.connector.utils.JsonUtils;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.*;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.*;
import java.util.concurrent.TimeUnit;
import org.I0Itec.zkclient.exception.ZkNodeExistsException;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.data.Stat;

/**
 * Isolated epoch1 PREPARING-only remote revocation proof.
 * Do NOT confuse with new-epoch election, READY, or actual user ACK.
 * Intent is ZK immutable; nodes independently fsync their own fence records
 * after proving local WAL seq1 and Common certified custody. Proof needs 2/2.
 */
final class DemoV19FourNodeRemoteRevocation {
    static final String OP="INTERNAL_OLD_EPOCH_REVOKE_V1";
    static final String INTENTS=DemoV19FourNodeShardCatalog.ROOT+"/old-epoch1-revoke-intents";
    static final String PROOFS=DemoV19FourNodeShardCatalog.ROOT+"/old-epoch1-revoke-proof";
    private static final String SCOPE="PREPARING_SOURCE_EPOCH1_REVOKED_NO_READY";
    private final String node;
    private final Path root;
    private final PrivateKey privateKey;
    DemoV19FourNodeRemoteRevocation(String node,Path root)throws Exception {
        this.node=node;this.root=root;
        this.privateKey=KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(
            Files.readAllBytes(root.resolve(".preflight-identity/local.pk8"))));
    }
    static String intentPath(String part){return INTENTS+"/"+part;}
    static String proofPath(String part){return PROOFS+"/"+part;}
    static void requireOldNotRevoked(ZookeeperClient zk,String part)throws Exception{
        if(zk==null || !zk.isConnected())throw new IOException("ZK majority unavailable");
        if(DemoV19FourNodeSeq1NettyPilot.selected(part)
                && zk.exists(intentPath(part)))
            throw new IOException("old epoch irrevocably denied by durable ZK intent");
        if(!zk.isConnected())throw new IOException("ZK lost after revoke check");
    }
    static void requireLocalOldNotRevoked(Path walRoot,String part)throws IOException {
        if(walRoot==null || !DemoV19FourNodeSeq1NettyPilot.selected(part))
            return;
        Path dir=walRoot.resolve(".pilot-old-epoch-revoked-"+part);
        if(Files.exists(dir,LinkOption.NOFOLLOW_LINKS))
            throw new IOException("permanent physical old-epoch source fence exists");
    }

    static String expectedPayload(PartitionAssignment a,String membership,String walSha)
            throws Exception {
        return SCOPE+"|"+a.getPartitionId()+"|"+a.getPrimary()+"|"+a.getReplica()
            +"|epoch=1|seq=1|member="+membership+"|wal="+walSha;
    }
    private static String localRoot(PartitionAssignment a){
        return ".pilot-old-epoch-revoked-"+a.getPartitionId();
    }
    private static void forceDir(Path dir)throws Exception{
        try(FileChannel channel=FileChannel.open(dir,StandardOpenOption.READ)){
            channel.force(true);
        }
    }
    static String installLocal(Path root,PartitionAssignment a,String intended)throws Exception{
        if(root==null||!root.isAbsolute()||Files.isSymbolicLink(root)
                ||intended==null||!intended.startsWith(SCOPE+"|"+a.getPartitionId()+"|"))
            throw new IOException("invalid old-epoch source fence proof");
        Path dir=root.resolve(localRoot(a));
        Files.createDirectories(dir);
        if(Files.isSymbolicLink(dir))throw new IOException("symlink fence directory");
        Path file=dir.resolve("head.bin"),pending=dir.resolve("head.pending");
        if(Files.exists(pending,LinkOption.NOFOLLOW_LINKS)
                || Files.isSymbolicLink(file))
            throw new IOException("torn or redirected revocation head");
        byte[] bytes=(intended+"\n").getBytes(java.nio.charset.StandardCharsets.UTF_8);
        if(Files.exists(file,LinkOption.NOFOLLOW_LINKS)){
            if(!Arrays.equals(Files.readAllBytes(file),bytes))
                throw new IOException("nonmatching durable old epoch head");
            return DemoV19FourNodeGenesisCustody.sha(bytes);
        }
        try(FileChannel channel=FileChannel.open(pending,
                StandardOpenOption.CREATE_NEW,StandardOpenOption.WRITE)){
            ByteBuffer wrapped=ByteBuffer.wrap(bytes);
            while(wrapped.hasRemaining())channel.write(wrapped);
            channel.force(true);
        }
        Files.move(pending,file,StandardCopyOption.ATOMIC_MOVE);
        forceDir(dir);forceDir(root);
        if(!Arrays.equals(Files.readAllBytes(file),bytes))
            throw new IOException("revocation head not durable");
        return DemoV19FourNodeGenesisCustody.sha(bytes);
    }
    private static String signedStatement(String part,String voter,String membership,
            String walSha,String headSha,String nonce){
        return "FOUR_NODE_OLD_EPOCH1_REVOKED_V1|"+part+"|"+voter+"|"+
                membership+"|"+walSha+"|"+headSha+"|"+nonce;
    }
    private static String sig(PrivateKey key,String message)throws Exception{
        Signature rsa=Signature.getInstance("SHA256withRSA");
        rsa.initSign(key);rsa.update(message.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        return Base64.getEncoder().encodeToString(rsa.sign());
    }
    static void verify(ZookeeperClient zk,PartitionAssignment a,
            String exactVoter,String nonce,String membership,String walSha,
            ReplicationControlResponse reply)throws Exception{
        if(reply==null || !reply.isSuccess())
            throw new IOException("physical remote revoke refused");
        Map<String,Object> fields=DemoNettyBridge.map(reply.getPayload());
        String part=a.getPartitionId();
        String text=expectedPayload(a,membership,walSha);
        String head=DemoV19FourNodeGenesisCustody.sha(
            (text+"\n").getBytes(java.nio.charset.StandardCharsets.UTF_8));
        if(!SCOPE.equals(fields.get("scope")) || !part.equals(fields.get("partition"))
                || !exactVoter.equals(fields.get("node"))
                || !nonce.equals(fields.get("nonce"))
                || !head.equals(fields.get("headSha256"))
                || !walSha.equals(fields.get("walSha256"))
                || !membership.equals(fields.get("membershipSha256"))
                || !Boolean.FALSE.equals(fields.get("ready"))
                || !Boolean.FALSE.equals(fields.get("clientAck"))
                || !(fields.get("signature") instanceof String))
            throw new IOException("incomplete remote old-epoch fence attestation");
        Signature rsa=Signature.getInstance("SHA256withRSA");
        rsa.initVerify(DemoV19FourNodeGenesisPreflight.pinned(zk,exactVoter));
        rsa.update(signedStatement(part,exactVoter,membership,walSha,head,nonce)
            .getBytes(java.nio.charset.StandardCharsets.UTF_8));
        if(!rsa.verify(Base64.getDecoder().decode((String)fields.get("signature"))))
            throw new IOException("RSA remote revoke signature invalid");
    }
    ReplicationControlResponse handle(ZookeeperClient zk,List<PartitionAssignment> plan,
            DemoV19FourNodeLiveRuntime.HeldWal held,ReplicationControlRequest request){
        try {
            if(request==null||!OP.equals(request.getOperation())
                    ||!DemoV19FourNodeShardCatalog.SERVICE.equals(request.getServiceName())
                    ||request.getPayload()==null||request.getPayload().length!=32
                    ||!zk.isConnected() || !held.node.equals(node))
                throw new IOException("remote revoke request not authorized");
            String part=request.getPartitionId();
            if(!DemoV19FourNodeSeq1NettyPilot.selected(part))
                throw new IOException("only bounded 2 buddy pilots");
            PartitionAssignment a=plan.get(Integer.parseInt(part.substring(1)));
            if(!DemoV19FourNodeLiveRuntime.owners(a).contains(node))
                throw new IOException("not source physical buddy");
            DemoDurableJournal wal=held.owned.get(part);
            if(wal==null)throw new IOException("missing physical WAL FileLock");
            synchronized(wal) {
                DemoV19FourNodeCommonMembership.requireUnchanged(zk,a);
                DurableWalCommitQuorum.Membership m=
                    DemoV19FourNodeCommonMembership.pinned(zk,a);
                Stat st=new Stat();Object raw=zk.readData(intentPath(part),st);
                if(raw==null||st.getVersion()!=0)
                    throw new IOException("missing immutable ZK revoke intent");
                @SuppressWarnings("unchecked")
                Map<String,Object> intent=JsonUtils.Deserialize(String.valueOf(raw),Map.class);
                if(intent==null || !SCOPE.equals(intent.get("scope"))
                    || !part.equals(intent.get("partition"))
                    || !m.digest.equals(intent.get("membershipSha256"))
                    || !(intent.get("walSha256") instanceof String))
                    throw new IOException("invalid durable revoke intent");
                DemoV19FourNodeSeq1NettyPilot.requireExactPilotWal(wal,a);
                String sha=wal.committedPrefixSha256Through(1);
                if(!sha.equals(intent.get("walSha256")))
                    throw new IOException("local source physical WAL fork");
                try(DurableWalCertificateCustody c=new DurableWalCertificateCustody(
                        root.resolve(".pilot-common-custody-"+part),m,
                        (epoch,seq)->{
                            if(epoch!=1||seq!=1)throw new IOException("wrong epoch WAL");
                            return wal.committedPrefixSha256Through(seq);
                        },
                        member->{if(!m.digest.equals(member.digest))
                            throw new IOException("unexpected membership");})){
                    DurableWalCommitQuorum.Certificate cert=c.highestVerified();
                    if(cert==null || cert.committedSequence!=1
                        || !sha.equals(cert.commitPrefixSha256)
                        || cert.votes.size()!=2)
                        throw new IOException("dual signed Common custody missing");
                }
                String image=expectedPayload(a,m.digest,sha);
                String head=installLocal(root,a,image);
                String nonce=DemoV19FourNodeGenesisPreflight.hex(request.getPayload());
                Map<String,Object> proof=new LinkedHashMap<>();
                proof.put("scope",SCOPE);proof.put("partition",part);
                proof.put("node",node);proof.put("nonce",nonce);
                proof.put("membershipSha256",m.digest);proof.put("walSha256",sha);
                proof.put("headSha256",head);
                proof.put("signature",sig(privateKey,signedStatement(
                    part,node,m.digest,sha,head,nonce)));
                proof.put("ready",false);proof.put("clientAck",false);
                DemoV19FourNodeCommonMembership.requireUnchanged(zk,a);
                return ReplicationControlResponse.ok(DemoNettyBridge.json(proof));
            }
        }catch(Exception e){
            return ReplicationControlResponse.error("OLD_EPOCH_REMOTE_REVOKE_DENIED",
                e.getClass().getSimpleName()+": "+e.getMessage());
        }
    }
    private static void ensure(ZookeeperClient zk,String path)throws Exception{
        DemoV19FourNodeShardCatalog.ensurePath(zk,path);
    }
    static void assertOldRpcDenied(List<PartitionAssignment> plan)throws Exception{
        try(DirectNettyReplicationTransport client=new DirectNettyReplicationTransport(
                9000,DirectNettyReplicationServer.DEFAULT_MAX_FRAME_BYTES)){
            for(char lead:new char[]{'A','C'}){
                String part=DemoV19FourNodeGenesisPreflight.firstShard(plan,lead);
                PartitionAssignment a=plan.get(Integer.parseInt(part.substring(1)));
                for(String node:DemoV19FourNodeLiveRuntime.owners(a)){
                    ReplicationControlResponse status=client.control(
                        DemoV19FourNodeLiveRuntime.exactEndpoint(node),
                        new ReplicationControlRequest(DemoV19FourNodeShardCatalog.SERVICE,
                            "CATALOG_STATUS_V1",part,new byte[0])).get(8,TimeUnit.SECONDS);
                    if(!status.isSuccess())throw new IOException("missing physical WAL node");
                    Map<String,Object> original=DemoNettyBridge.map(status.getPayload());
                    for(String op:new String[]{
                        DemoV19FourNodeSeq1NettyPilot.FSYNC,
                        DemoV19FourNodeSeq1NettyPilot.CERTIFY,
                        DemoV19FourNodeSeq1NettyPilot.CUSTODY}){
                        byte[] nonce=new byte[32];new SecureRandom().nextBytes(nonce);
                        ReplicationControlResponse declined=client.control(
                            DemoV19FourNodeLiveRuntime.exactEndpoint(node),
                            new ReplicationControlRequest(DemoV19FourNodeShardCatalog.SERVICE,
                                op,part,nonce)).get(8,TimeUnit.SECONDS);
                        if(declined.isSuccess())
                            throw new IOException("CRITICAL: old source operation accepted "+op);
                    }
                    ReplicationControlResponse afterwards=client.control(
                        DemoV19FourNodeLiveRuntime.exactEndpoint(node),
                        new ReplicationControlRequest(DemoV19FourNodeShardCatalog.SERVICE,
                            "CATALOG_STATUS_V1",part,new byte[0])).get(8,TimeUnit.SECONDS);
                    if(!afterwards.isSuccess())throw new IOException("missing WAL readback");
                    Map<String,Object> current=DemoNettyBridge.map(afterwards.getPayload());
                    if(!Objects.equals(original.get("committedPrefixSha256"),
                            current.get("committedPrefixSha256"))
                            || !Objects.equals(original.get("committedSeq"),
                                current.get("committedSeq"))
                            || !Boolean.FALSE.equals(current.get("ready")))
                        throw new IOException("denied old epoch request changed physical WAL");
                    System.out.println("FOUR_NODE_OLD_SOURCE_RPC_FENCED partition="+part+
                        " node="+node+" oldFsyncDenied=true oldCertifyDenied=true"+
                        " oldCustodyDenied=true walUnchanged=true clientAck=false");
                }
            }
        }
    }

    static void prove(ZookeeperClient zk,List<PartitionAssignment> plan)throws Exception{
        ensure(zk,INTENTS);ensure(zk,PROOFS);
        try(DirectNettyReplicationTransport tcp=new DirectNettyReplicationTransport(
                9000,DirectNettyReplicationServer.DEFAULT_MAX_FRAME_BYTES)){
            for(char lead:new char[]{'A','C'}){
                String part=DemoV19FourNodeGenesisPreflight.firstShard(plan,lead);
                PartitionAssignment a=plan.get(Integer.parseInt(part.substring(1)));
                DurableWalCommitQuorum.Membership m=
                    DemoV19FourNodeCommonMembership.pinned(zk,a);
                String sha=null;
                // Current real physical WALs MUST agree before imposing intent.
                for(String n:DemoV19FourNodeLiveRuntime.owners(a)){
                    ReplicationControlResponse status=tcp.control(
                        DemoV19FourNodeLiveRuntime.exactEndpoint(n),
                        new ReplicationControlRequest(DemoV19FourNodeShardCatalog.SERVICE,
                            "CATALOG_STATUS_V1",part,new byte[0])).get(8,TimeUnit.SECONDS);
                    if(!status.isSuccess())throw new IOException("source node unavailable");
                    Map<String,Object> x=DemoNettyBridge.map(status.getPayload());
                    if(!(x.get("committedSeq") instanceof Number) ||
                        ((Number)x.get("committedSeq")).longValue()!=1 ||
                        !Boolean.FALSE.equals(x.get("ready")))
                        throw new IOException("source invalid WAL head");
                    String h=String.valueOf(x.get("committedPrefixSha256"));
                    if(sha!=null&&!sha.equals(h))throw new IOException("divergent buddy WAL");
                    sha=h;
                }
                Map<String,Object> intent=new LinkedHashMap<>();
                intent.put("scope",SCOPE);intent.put("partition",part);
                intent.put("membershipSha256",m.digest);intent.put("walSha256",sha);
                String path=intentPath(part);
                if(!zk.exists(path)){
                    try{zk.create(path,JsonUtils.Serializer(intent),CreateMode.PERSISTENT);}
                    catch(ZkNodeExistsException concurrent){}
                }
                Stat check=new Stat();Object persisted=zk.readData(path,check);
                if(check.getVersion()!=0
                        || !JsonUtils.Serializer(intent).equals(String.valueOf(persisted)))
                    throw new IOException("source revoke intent differs");
                byte[] challenge=new byte[32];new SecureRandom().nextBytes(challenge);
                String nonce=DemoV19FourNodeGenesisPreflight.hex(challenge);
                List<Map<String,Object>> votes=new ArrayList<>();
                for(String n:DemoV19FourNodeLiveRuntime.owners(a)){
                    ReplicationControlResponse reply=tcp.control(
                        DemoV19FourNodeLiveRuntime.exactEndpoint(n),
                        new ReplicationControlRequest(DemoV19FourNodeShardCatalog.SERVICE,
                            OP,part,challenge)).get(8,TimeUnit.SECONDS);
                    verify(zk,a,n,nonce,m.digest,sha,reply);
                    votes.add(DemoNettyBridge.map(reply.getPayload()));
                }
                Map<String,Object> result=new LinkedHashMap<>();
                result.put("scope",SCOPE);result.put("partition",part);
                result.put("membershipSha256",m.digest);result.put("walSha256",sha);
                result.put("nonce",nonce);result.put("votes",votes);
                String done=proofPath(part);
                if(!zk.exists(done)){
                    try{zk.create(done,JsonUtils.Serializer(result),CreateMode.PERSISTENT);}
                    catch(ZkNodeExistsException competing){}
                }
                Stat st=new Stat();Object old=zk.readData(done,st);
                if(old==null||st.getVersion()!=0)
                    throw new IOException("missing immutable two-voter revoke completion");
                @SuppressWarnings("unchecked") Map<String,Object> doc=
                    JsonUtils.Deserialize(String.valueOf(old),Map.class);
                if(!SCOPE.equals(doc.get("scope")) || !part.equals(doc.get("partition"))
                        || !m.digest.equals(doc.get("membershipSha256"))
                        || !sha.equals(doc.get("walSha256"))
                        || !(doc.get("nonce") instanceof String)
                        || !(doc.get("votes") instanceof List)
                        || ((List<?>)doc.get("votes")).size()!=2)
                    throw new IOException("invalid durable ZK two-voter revocation proof");
                List<?> entries=(List<?>)doc.get("votes");
                for(int i=0;i<2;i++)verify(zk,a,
                    DemoV19FourNodeLiveRuntime.owners(a).get(i),
                    (String)doc.get("nonce"),m.digest,sha,
                    ReplicationControlResponse.ok(DemoNettyBridge.json(entries.get(i))));
                System.out.println("FOUR_NODE_TWO_PHYSICAL_JVM_REVOCATION_PASS partition="+part+
                    " twoWalFsynced=true twoCommonCustodyVerified=true"+
                    " twoLocalFenceFsynced=true twoIndependentRSAVotes=true"+
                    " zkProofPersisted=true oldEpochSourceDenied=true"+
                    " ready=false clientAck=false");
            }
        }
    }
}
