package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;
import java.io.IOException;
import java.nio.file.*;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import static org.junit.Assert.*;

public final class DemoV19FourNodeEpoch2ImageTest {
    @Rule public TemporaryFolder tmp=new TemporaryFolder();
    private static final String MEMBERSHIP=
        "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef";
    private static final String WAL=
        "abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789";
    private interface Action {void run()throws Exception;}
    private static void denies(Action action)throws Exception{
        try {action.run();fail("unsafe recovery image admitted");}
        catch(IOException expected) {}
    }
    @Test public void twoIndependentImagesAreByteIdenticalDurableAndImmutable()
            throws Exception{
        PartitionAssignment a=DemoV19FourNodeShardCatalog.layout().get(0);
        DemoStateMachine source=new DemoStateMachine();
        source.apply(new DemoStateMachine.Operation(
            DemoV19FourNodeSeq1NettyPilot.requestId("P000"),11).encode());
        byte[] image=source.captureSnapshot();
        Path left=tmp.newFolder("nodeA").toPath();
        Path right=tmp.newFolder("nodeB").toPath();
        String first=DemoV19FourNodeEpoch2Image.install(left,a,MEMBERSHIP,WAL,image);
        String second=DemoV19FourNodeEpoch2Image.install(right,a,MEMBERSHIP,WAL,image);
        assertEquals(first,second);assertEquals(64,first.length());
        Path one=left.resolve(DemoV19FourNodeEpoch2Image.imagePath("P000"))
            .resolve("candidate.bin");
        Path two=right.resolve(DemoV19FourNodeEpoch2Image.imagePath("P000"))
            .resolve("candidate.bin");
        assertArrayEquals(Files.readAllBytes(one),Files.readAllBytes(two));
        DemoStateMachine restored=new DemoStateMachine();
        restored.snapshot(image);
        assertEquals(source.stateDigest(),restored.stateDigest());
        assertEquals(11,restored.total());
        assertEquals(first,DemoV19FourNodeEpoch2Image.install(
            left,a,MEMBERSHIP,WAL,image));
        denies(()->DemoV19FourNodeEpoch2Image.install(
            left,a,MEMBERSHIP,MEMBERSHIP,image));
        assertArrayEquals(Files.readAllBytes(one),Files.readAllBytes(two));
    }
    @Test public void cannotOverwriteTamperedOrTornRecoveryImage()throws Exception{
        PartitionAssignment a=DemoV19FourNodeShardCatalog.layout().get(128);
        DemoStateMachine state=new DemoStateMachine();
        state.apply(new DemoStateMachine.Operation(
            DemoV19FourNodeSeq1NettyPilot.requestId("P128"),17).encode());
        byte[] image=state.captureSnapshot();
        Path root=tmp.newFolder("sourceC").toPath();
        DemoV19FourNodeEpoch2Image.install(root,a,MEMBERSHIP,WAL,image);
        Path dir=root.resolve(DemoV19FourNodeEpoch2Image.imagePath("P128"));
        Files.write(dir.resolve("candidate.bin"),new byte[]{1});
        denies(()->DemoV19FourNodeEpoch2Image.install(
            root,a,MEMBERSHIP,WAL,image));
        Files.delete(dir.resolve("candidate.bin"));
        Files.write(dir.resolve("candidate.pending"),new byte[]{1});
        denies(()->DemoV19FourNodeEpoch2Image.install(
            root,a,MEMBERSHIP,WAL,image));
    }
    @Test public void onlyExactlyCertifiedCommittedSourceCanProvideSnapshot()
            throws Exception{
        PartitionAssignment a=DemoV19FourNodeShardCatalog.layout().get(0);
        Path file=tmp.newFile("epoch1.wal").toPath();
        try(DemoDurableJournal wal=new DemoDurableJournal(file)){
            denies(()->DemoV19FourNodeEpoch2Image.trustedSnapshot(wal,a,WAL));
            wal.installEmptyGenesis(1,"P000",
                DemoV19FourNodeGenesisPreflight.exactAssignmentDigest(a));
            wal.prepareAndCommitSingleForce(1,1,
                new DemoStateMachine.Operation(
                    DemoV19FourNodeSeq1NettyPilot.requestId("P000"),11));
            String real=wal.committedPrefixSha256Through(1);
            byte[] snapshot=DemoV19FourNodeEpoch2Image.trustedSnapshot(wal,a,real);
            DemoStateMachine recovered=new DemoStateMachine();
            recovered.snapshot(snapshot);
            assertEquals(11,recovered.total());
            assertEquals(1,recovered.distinctRequests());
            denies(()->DemoV19FourNodeEpoch2Image.trustedSnapshot(wal,a,WAL));
        }
    }
}
