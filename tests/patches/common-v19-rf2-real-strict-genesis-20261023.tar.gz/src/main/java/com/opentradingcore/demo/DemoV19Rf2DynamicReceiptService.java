package com.opentradingcore.demo;

import com.app.common.replication.*;
import com.app.common.zk.ZookeeperClient;
import com.gateway.connector.utils.JsonUtils;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.*;
import org.apache.zookeeper.data.Stat;

/** A separately scoped, opt-in signed WAL receipt for proposed RF2 epochs.
 * It NEVER returns a client trade ACK and cannot itself publish READY.
 * Membership/epoch/configuration come only from a versioned, majority-backed
 * ZK assignment, not from the request. Old Epoch1 handler remains unchanged.
 */
final class DemoV19Rf2DynamicReceiptService {
    static final String OPERATION="V19_RF2_DYNAMIC_DURABLE_RECEIPT_V1";
    private static final String PATH=DemoZkFenceSource.ISOLATED_ROOT
            +"/harness/assignments/P000";
    private final ZookeeperClient zk;
    private final DemoJournalCatalog journals;
    private final String node;
    private final PrivateKey privateKey;
    private final List<DurableWalCommitQuorum.Member> configured;

    DemoV19Rf2DynamicReceiptService(ZookeeperClient zk,String node,
            DemoJournalCatalog journals)throws Exception {
        if(zk==null || journals==null
                || !("CommonHaDemoA".equals(node) || "CommonHaDemoB".equals(node)))
            throw new IllegalArgumentException("only isolated A/B data signer");
        this.zk=zk;this.node=node;this.journals=journals;
        KeyFactory rsa=KeyFactory.getInstance("RSA");
        List<DurableWalCommitQuorum.Member> voters=new ArrayList<>();
        for(char suffix='A';suffix<='B';suffix++){
            String id="CommonHaDemo"+suffix;
            voters.add(new DurableWalCommitQuorum.Member(id,
                    "simulated-single-mac-jvm-"+suffix,
                    rsa.generatePublic(new X509EncodedKeySpec(Files.readAllBytes(
                            Paths.get("/srv/v19/identities",id+".pub.der"))))));
        }
        this.configured=Collections.unmodifiableList(voters);
        this.privateKey=rsa.generatePrivate(new PKCS8EncodedKeySpec(Files.readAllBytes(
                Paths.get("/srv/v19/local-identity/node.pk8"))));
    }

    static final class Plan {
        final long epoch,configVersion,genesisSeq,oldCertifiedSeq;
        final String primary,replica,genesisSha,oldCertifiedSha;
        final boolean preparing;
        Plan(long epoch,long configVersion,long genesisSeq,long oldCertifiedSeq,
                String primary,String replica,String sha,String oldSha,boolean preparing){
            this.epoch=epoch;this.configVersion=configVersion;
            this.genesisSeq=genesisSeq;this.oldCertifiedSeq=oldCertifiedSeq;
            this.primary=primary;this.replica=replica;
            this.genesisSha=sha;this.oldCertifiedSha=oldSha;
            this.preparing=preparing;
        }
    }

    /** Validate trusted ZK content, not caller-supplied body. */
    static Plan requirePlan(Map<String,Object> a)throws IOException {
        if(a==null || !"P000".equals(a.get("partitionId")))
            throw new IOException("wrong RF2 assignment");
        long epoch=number(a,"epoch"),config=number(a,"strictConfigurationVersion"),
             genesis=number(a,"strictGenesisSeq"),
             oldCertified=number(a,"strictOldCertifiedSeq");
        if(epoch<2 || epoch>128 || config<2 || genesis<1 || oldCertified<1
                || genesis<oldCertified)
            throw new IOException("invalid dynamic membership version or Genesis");
        String primary=string(a,"primary");
        if(!"CommonHaDemoA".equals(primary) && !"CommonHaDemoB".equals(primary))
            throw new IOException("invalid strict primary");
        String replica="CommonHaDemoA".equals(primary)?"CommonHaDemoB":"CommonHaDemoA";
        Object peers=a.get("replicas"),learners=a.get("learners");
        if(!(peers instanceof List) || !((List<?>)peers).equals(Collections.singletonList(replica))
                || !(learners instanceof List) || !((List<?>)learners).isEmpty())
            throw new IOException("strict RF2 membership must be exactly two data voters");
        String state=string(a,"state"),policy=string(a,"durabilityPolicy"),
                sha=string(a,"strictGenesisSha256");
        String oldSha=string(a,"strictOldCertifiedSha256");
        if(!sha.matches("[0-9a-f]{64}") || !oldSha.matches("[0-9a-f]{64}"))
            throw new IOException("unsigned Genesis or old ACK hash");
        boolean preparing="RECOVERING".equals(state)
                && "STRICT_REJOIN_GENESIS_PREPARE".equals(policy)
                && Boolean.FALSE.equals(a.get("quorumDurable"))
                && "GENESIS_PENDING".equals(a.get("strictTransition"));
        boolean active="READY".equals(state)
                && "QUORUM_DURABLE".equals(policy)
                && Boolean.TRUE.equals(a.get("quorumDurable"))
                && "GENESIS_CERTIFIED".equals(a.get("strictTransition"));
        if(!preparing && !active)
            throw new IOException("strict epoch signing requires explicit ZK transition");
        return new Plan(epoch,config,genesis,oldCertified,primary,replica,
                sha,oldSha,preparing);
    }
    private static long number(Map<String,Object> m,String field)throws IOException {
        Object v=m.get(field);
        if(!(v instanceof Number))throw new IOException("missing numeric "+field);
        return ((Number)v).longValue();
    }
    private static String string(Map<String,Object> m,String key)throws IOException {
        Object v=m.get(key);if(!(v instanceof String))throw new IOException("missing "+key);
        return (String)v;
    }

    private Plan current(int requiredVersion,DurableWalCommitQuorum.Membership pinned)
            throws Exception {
        if(!zk.isConnected())throw new IOException("ZK quorum unavailable");
        Stat stat=new Stat();Object raw=zk.readData(PATH,stat);
        if(raw==null || stat.getVersion()!=requiredVersion)
            throw new IOException("strict membership changed");
        @SuppressWarnings("unchecked") Map<String,Object> map=
                JsonUtils.Deserialize(String.valueOf(raw),Map.class);
        Plan planned=requirePlan(map);
        if(planned.epoch!=pinned.epoch
                || planned.configVersion!=pinned.configurationVersion
                || !planned.primary.equals(pinned.primary)
                || !pinned.members.keySet().equals(
                        new java.util.TreeSet<>(Arrays.asList("CommonHaDemoA","CommonHaDemoB")))
                || !zk.isConnected())
            throw new IOException("dynamic membership no longer current");
        return planned;
    }

    ReplicationControlResponse handle(ReplicationControlRequest req) {
        try {
            if(req==null || !OPERATION.equals(req.getOperation())
                    || !"CommonHaDemo".equals(req.getServiceName())
                    || !"P000".equals(req.getPartitionId())
                    || req.getPayload()==null || req.getPayload().length!=28)
                throw new IOException("invalid bounded dynamic WAL receipt");
            ByteBuffer payload=ByteBuffer.wrap(req.getPayload());
            if(payload.getInt()!=1)throw new IOException("unsupported receipt version");
            long config=payload.getLong(),epoch=payload.getLong(),seq=payload.getLong();
            if(seq<=0)throw new IOException("invalid requested durable sequence");
            if(!zk.isConnected())throw new IOException("ZooKeeper quorum disconnected");
            Stat stat=new Stat();Object raw=zk.readData(PATH,stat);
            if(raw==null)throw new IOException("no strict ZK assignment");
            @SuppressWarnings("unchecked") Map<String,Object> values=
                    JsonUtils.Deserialize(String.valueOf(raw),Map.class);
            Plan planned=requirePlan(values);
            if(epoch!=planned.epoch || config!=planned.configVersion)
                throw new IOException("stale strict membership/epoch");
            if(planned.preparing && seq!=planned.genesisSeq)
                throw new IOException("unpublished epoch can sign ONLY frozen Genesis");
            if(seq<planned.genesisSeq)
                throw new IOException("cannot promote a prior uncertified tail");
            DurableWalCommitQuorum.Membership membership=new DurableWalCommitQuorum.Membership(
                    "CommonHaDemo","P000",planned.primary,epoch,config,configured);
            // Common validates cryptographic receipt, local fsynced WAL and
            // checks authority on BOTH sides of the signature boundary.
            DurableWalReceiptControlHandler signer=new DurableWalReceiptControlHandler(
                    membership,node,privateKey,(requestedEpoch,requestedSeq)->{
                        Plan still=current(stat.getVersion(),membership);
                        DemoDurableJournal wal=journals.journal("P000");
                        synchronized(wal) {
                            if(!wal.isReadyForWrites() || wal.committedSeq()<requestedSeq
                                    || wal.lastEpoch()>requestedEpoch
                                    || wal.committedSeq()<still.oldCertifiedSeq
                                    || !still.oldCertifiedSha.equals(
                                         wal.committedPrefixSha256Through(still.oldCertifiedSeq))
                                    || (still.preparing && requestedSeq!=still.genesisSeq)
                                    || (!still.preparing && requestedSeq>still.genesisSeq
                                            && wal.lastEpoch()!=requestedEpoch))
                                throw new IOException("no clean local WAL for strict epoch");
                            String hash=wal.committedPrefixSha256Through(requestedSeq);
                            if(requestedSeq==still.genesisSeq
                                    && !still.genesisSha.equals(hash))
                                throw new IOException("local strict Genesis does not match ZK hash");
                            return hash;
                        }
                    },ignored->current(stat.getVersion(),membership));
            return signer.handle(new ReplicationControlRequest(
                    "CommonHaDemo",DurableWalReceiptControlHandler.OPERATION,
                    "P000",req.getPayload()));
        }catch(Exception denied) {
            return ReplicationControlResponse.error("RF2_DYNAMIC_RECEIPT_DENIED",
                    denied.getClass().getSimpleName()+": "+denied.getMessage());
        }
    }
}
