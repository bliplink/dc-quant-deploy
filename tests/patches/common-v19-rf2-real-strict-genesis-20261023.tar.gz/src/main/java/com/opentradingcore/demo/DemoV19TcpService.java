package com.opentradingcore.demo;

import com.app.common.replication.ReplicationControlRequest;
import com.app.common.replication.ReplicationControlResponse;
import com.gateway.connector.utils.JsonUtils;

import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * v19 TEST ONLY: TCP control frames, NEVER an HTTP endpoint.
 * APPEND routes into the normal primary WAL state machine; STATUS is
 * a read-only physical-WAL audit message on the existing Netty socket.
 *
 * This experimental API is not the stable, production Common API.
 */
final class DemoV19TcpService {
    static final String APPEND = "V19_APPEND";
    static final String APPEND_GROUP = "V19_APPEND_GROUP";
    static final String STATUS = "V19_STATUS";
    static final String IMAGE_OPEN = "V19_IMAGE_OPEN";
    static final String IMAGE_CHUNK = "V19_IMAGE_CHUNK";
    static final String IMAGE_CLOSE = "V19_IMAGE_CLOSE";
    private final String node;
    private final DemoJournalCatalog journals;
    private final DemoPrimaryWriter writer;
    private final DemoAsyncReplicator async;
    private final DemoZkLeaseController controller;
    private final DemoV19DurableRuntime durable;
    private final DemoV19SnapshotExport images;
    private final DemoV19Rf2DynamicReceiptService dynamicReceipt;

    DemoV19TcpService(String node, DemoJournalCatalog journals,
            DemoPrimaryWriter writer, DemoAsyncReplicator async,
            DemoZkLeaseController controller) {
        this(node,journals,writer,async,controller,null);
    }

    DemoV19TcpService(String node,DemoJournalCatalog journals,
            DemoPrimaryWriter writer,DemoAsyncReplicator async,
            DemoZkLeaseController controller,DemoV19DurableRuntime durable) {
        this(durable==null?null:durable,node,journals,writer,async,controller,null);
    }

    DemoV19TcpService(DemoV19DurableRuntime durable,String node,
            DemoJournalCatalog journals,DemoPrimaryWriter writer,
            DemoAsyncReplicator async,DemoZkLeaseController controller,
            DemoV19Rf2DynamicReceiptService dynamicReceipt) {
        this.durable=durable;
        this.dynamicReceipt=dynamicReceipt;
        this.node = node;
        this.journals = journals;
        this.writer = writer;
        this.async = async;
        this.controller = controller;
        this.images = new DemoV19SnapshotExport(journals, node);
    }

    ReplicationControlResponse control(ReplicationControlRequest req) {
        if (!"CommonHaDemo".equals(req.getServiceName())
                || !"P000".equals(req.getPartitionId()))
            return ReplicationControlResponse.error("INVALID",
                    "v19 TCP API only accepts the isolated CommonHaDemo P000");
        if (DemoV19Rf2DynamicReceiptService.OPERATION.equals(req.getOperation()))
            return dynamicReceipt==null
                    ? ReplicationControlResponse.error("DISABLED","dynamic signer not configured")
                    : dynamicReceipt.handle(req);
        if (com.app.common.replication.DurableWalReceiptControlHandler.OPERATION
                .equals(req.getOperation())
                || com.app.common.replication.DurableWalCertificateCustodyControlHandler.OPERATION
                .equals(req.getOperation())
                || com.app.common.replication.DurableWalCertificateCustodyControlHandler.HEAD_QUERY_OPERATION
                .equals(req.getOperation())) {
            return durable==null
                    ? ReplicationControlResponse.error("DISABLED","quorum signer not enabled")
                    : durable.control(req);
        }
        if (IMAGE_OPEN.equals(req.getOperation()) || IMAGE_CHUNK.equals(req.getOperation())
                || IMAGE_CLOSE.equals(req.getOperation())) {
            if (req.getPayload().length > 512)
                return ReplicationControlResponse.error("TOO_LARGE", "image request too large");
            try {
                Map<String,Object> response;
                if (IMAGE_OPEN.equals(req.getOperation())) response = images.open();
                else if (IMAGE_CHUNK.equals(req.getOperation()))
                    response = images.chunk(DemoNettyBridge.map(req.getPayload()));
                else response = images.close(DemoNettyBridge.map(req.getPayload()));
                return ReplicationControlResponse.ok(DemoNettyBridge.json(response));
            } catch (Exception e) {
                return ReplicationControlResponse.error("IMAGE_DENIED",
                        e.getClass().getSimpleName() + ": " + e.getMessage());
            }
        }
        if (STATUS.equals(req.getOperation())) {
            try {
                Map<String,Object> data = new LinkedHashMap<String,Object>(
                        journals.physicalStatus("P000"));
                data.put("localNode", node);
                data.put("epoch1Granted", controller.permits("P000", 1));
                data.put("epoch2Granted", controller.permits("P000", 2));
                String peer = "CommonHaDemoA".equals(node)
                        ? "CommonHaDemoB" : "CommonHaDemoA";
                data.put("replicatedSeq", async.replicatedSeq(
                        "P000", Collections.singletonList(peer)));
                data.put("controlFailures", controller.failedControlProbes());
                data.put("v19Perf", DemoV19PerfCounters.status());                data.put("replicationStages",async.stageMetrics());

                return ReplicationControlResponse.ok(DemoNettyBridge.json(data));
            } catch (Exception failure) {
                return ReplicationControlResponse.error("STATUS_ERROR",
                        failure.getClass().getSimpleName() + ": " + failure.getMessage());
            }
        }
        if(APPEND_GROUP.equals(req.getOperation())) {
            if(req.getPayload().length>16384)
                return ReplicationControlResponse.error("TOO_LARGE","bounded group required");
            long start=System.nanoTime();
            try {
                Map<String,Object> result=writer.appendGroup(
                        DemoNettyBridge.map(req.getPayload()));
                Object code=result.get("code");
                if(!(code instanceof Number) || ((Number)code).intValue()!=0)
                    return ReplicationControlResponse.error("GROUP_NOT_DURABLE",
                            JsonUtils.Serializer(result));
                return ReplicationControlResponse.ok(DemoNettyBridge.json(result));
            } catch(Exception error) {
                return ReplicationControlResponse.error("GROUP_DENIED",
                        error.getClass().getSimpleName()+": "+error.getMessage());
            } finally {DemoV19PerfCounters.recordHandler(System.nanoTime()-start);}
        }
        if (APPEND.equals(req.getOperation())) {
            if (req.getPayload().length > 4096)
                return ReplicationControlResponse.error("TOO_LARGE", "bounded command required");
            long handlerStart = System.nanoTime();
            try {
                String raw = new String(req.getPayload(), StandardCharsets.UTF_8);
                Map<String,Object> result = writer.append(raw);
                Object code = result.get("code");
                if (!(code instanceof Number) || ((Number)code).intValue() != 0)
                    return ReplicationControlResponse.error("WRITE_DENIED",
                            "primary refused command: " + JsonUtils.Serializer(result));
                return ReplicationControlResponse.ok(DemoNettyBridge.json(result));
            } catch (Exception denied) {
                return ReplicationControlResponse.error("WRITE_DENIED",
                        denied.getClass().getSimpleName() + ": " + denied.getMessage());
            } finally {
                DemoV19PerfCounters.recordHandler(System.nanoTime() - handlerStart);
            }
        }
        return DemoNettyBridge.control(journals, node.substring(node.length() - 1), req);
    }
}
