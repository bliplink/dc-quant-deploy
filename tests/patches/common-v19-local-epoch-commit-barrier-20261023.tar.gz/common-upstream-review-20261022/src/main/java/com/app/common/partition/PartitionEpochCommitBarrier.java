package com.app.common.partition;

import java.util.Objects;
import java.util.concurrent.Callable;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Source-process epoch interlock for one partition.
 *
 * <p>All writes, WAL fsync, RSA receipts and success publication from the
 * service must pass through the same barrier. A cooperating controller must
 * first drain/revoke the writer through this barrier before applying its
 * ZooKeeper epoch CAS. A remote controller or external CAS writer does not
 * share this JVM lock: production HA additionally requires a distributed
 * revoke acknowledgement, lease fencing and independently verified custody.
 *
 * <p>A failed write boundary may have modified WAL even if no client success
 * was returned. This barrier permanently closes on uncertainty. Recovery must
 * inspect the journal and create a new authority for a new epoch.
 */
public final class PartitionEpochCommitBarrier {
    private final String partition;
    private final String primary;
    private final PartitionEpochReadFence epoch;
    private final PartitionFailoverController.Guard controller;
    private final PartitionFailoverController.AssignmentStore assignments;
    private final ReentrantLock writerMutex = new ReentrantLock(true);
    private boolean revoked;

    public PartitionEpochCommitBarrier(String partition,String primary,
            PartitionEpochReadFence epoch,
            PartitionFailoverController.Guard controller,
            PartitionFailoverController.AssignmentStore assignments) {
        if(partition==null || partition.trim().isEmpty()
                || primary==null || primary.trim().isEmpty())
            throw new IllegalArgumentException("exact partition and primary required");
        this.partition=partition.trim();
        this.primary=primary.trim();
        this.epoch=Objects.requireNonNull(epoch,"epoch");
        this.controller=Objects.requireNonNull(controller,"controller");
        this.assignments=Objects.requireNonNull(assignments,"assignments");
    }

    /**
     * Return success only if both sides of the serialized operation have
     * verified same READY epoch, assignment CAS version and controller lease.
     * Callers must NOT send any client ACK before this method returns.
     */
    public <T> T execute(Callable<T> walCertAndCustody) throws Exception {
        Objects.requireNonNull(walCertAndCustody,"walCertAndCustody");
        writerMutex.lock();
        try {
            requireNotRevoked();
            try {
                requireLease();
                PartitionEpochReadFence.Ticket ticket=epoch.readCurrent(partition,primary);
                epoch.requireCurrent(ticket);
                T result=walCertAndCustody.call();
                epoch.requireCurrent(ticket);
                requireLease();
                requireNotRevoked();
                return result;
            } catch(Exception uncertain) {
                revoked=true;
                PartitionReadinessGuard.revoke(primary,partition);
                throw uncertain;
            }
        } finally {
            writerMutex.unlock();
        }
    }

    /**
     * Cooperative, in-process source drain followed by versioned CAS to
     * RECOVERING, never READY. Controller must acquire its separate valid ZK
     * lease and secure independent physical custody before asking this method
     * to transfer an actual production partition.
     */
    public boolean drainAndCasRecovering(PartitionAssignment successor) {
        Objects.requireNonNull(successor,"successor");
        writerMutex.lock();
        try {
            requireNotRevoked();
            requireLease();
            PartitionEpochReadFence.Ticket ticket=epoch.readCurrent(partition,primary);
            epoch.requireCurrent(ticket);
            if(!partition.equals(successor.getPartitionId())
                    || !"RECOVERING".equals(successor.getState())
                    || successor.getEpoch()!=ticket.getEpoch()+1L
                    || successor.getAssignmentVersion()!=ticket.getAssignmentVersion()+1L
                    || PartitionConfig.normalizeServerName(primary).equalsIgnoreCase(
                         PartitionConfig.normalizeServerName(successor.getPrimary()))
                    || !PartitionAssignmentValidator.validate(successor).isEmpty()) {
                throw new IllegalArgumentException("unsafe successor is not next recovering epoch");
            }
            revoked=true; // irreversible even if CAS races or the ZooKeeper connection fails
            PartitionReadinessGuard.revoke(primary,partition);
            requireLease();
            return assignments.compareAndSet(partition,ticket.getZkVersion(),successor);
        } finally {
            writerMutex.unlock();
        }
    }

    public boolean isRevoked() {
        writerMutex.lock();
        try{return revoked;}
        finally{writerMutex.unlock();}
    }

    private void requireNotRevoked(){
        if(revoked)throw new IllegalStateException("PARTITION_EPOCH_WRITER_REVOKED");
    }
    private void requireLease(){
        if(!controller.isConnected() || !controller.hasLease())
            throw new IllegalStateException("PARTITION_EPOCH_CONTROL_LEASE_LOST");
    }
}
