package com.app.common.partition;

import java.util.Collections;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import org.junit.After;
import org.junit.Test;
import static org.junit.Assert.*;

public final class PartitionEpochCommitBarrierTest {
    private static final String P="P000",A="CommonHaDemoA",B="CommonHaDemoB";

    private static final class Control implements
            PartitionFailoverController.AssignmentStore,
            PartitionFailoverController.Guard,PartitionEpochReadFence.Connection {
        boolean connected=true,lease=true;
        int zkVersion=4;
        PartitionAssignment assignment=next(A,B,7,5,"READY");
        final AtomicInteger casCalls=new AtomicInteger();
        volatile boolean injectConcurrentCas;
        public boolean isConnected(){return connected;}
        public boolean hasLease(){return lease && connected;}
        public synchronized PartitionFailoverController.VersionedAssignment read(String id){
            return P.equals(id) ?new PartitionFailoverController.VersionedAssignment(
                assignment,zkVersion):null;
        }
        public synchronized boolean compareAndSet(String id,int expected,PartitionAssignment newA){
            casCalls.incrementAndGet();
            if(injectConcurrentCas) {
                injectConcurrentCas=false;
                zkVersion++;
            }
            if(!P.equals(id) || zkVersion!=expected || !connected)return false;
            assignment=newA;zkVersion++;return true;
        }
        PartitionEpochCommitBarrier barrier(){
            return new PartitionEpochCommitBarrier(P,A,
                new PartitionEpochReadFence(this,this),this,this);
        }
    }
    private static PartitionAssignment next(String primary,String replica,
            long epoch,long version,String state){
        PartitionAssignment a=new PartitionAssignment();
        a.setPartitionId(P);a.setPrimary(primary);a.setReplica(replica);
        a.setReplicas(Collections.singletonList(replica));
        a.setEpoch(epoch);a.setAssignmentVersion(version);a.setState(state);
        return a;
    }
    private static void denied(Callable<?> act)throws Exception{
        try{act.call();fail("old primary erroneously accepted");}
        catch(IllegalStateException expected){}
    }
    @After public void clean(){
        PartitionReadinessGuard.clear(A);PartitionReadinessGuard.clear(B);
    }
    @Test public void cooperatingCasWaitsForActiveWriteAndFencesEveryLaterWrite()
            throws Exception {
        Control c=new Control();
        PartitionReadinessGuard.markReady(A,P,7);
        PartitionEpochCommitBarrier b=c.barrier();
        CountDownLatch writing=new CountDownLatch(1),complete=new CountDownLatch(1);
        ExecutorService workers=Executors.newFixedThreadPool(2);
        try{
            Future<Integer> result=workers.submit(()->b.execute(()->{
                writing.countDown();
                if(!complete.await(6,TimeUnit.SECONDS))
                    throw new IllegalStateException("slow WAL simulation");
                return 1;
            }));
            assertTrue(writing.await(6,TimeUnit.SECONDS));
            Future<Boolean> transition=workers.submit(()->b.drainAndCasRecovering(
                next(B,A,8,6,"RECOVERING")));
            Thread.sleep(150L);
            assertEquals("CAS cannot overtake in-flight local WAL",0,c.casCalls.get());
            complete.countDown();
            assertEquals(Integer.valueOf(1),result.get(6,TimeUnit.SECONDS));
            assertTrue(transition.get(6,TimeUnit.SECONDS));
            assertEquals(1,c.casCalls.get());
            assertTrue(b.isRevoked());
            denied(()->b.execute(()->2));
            assertFalse(PartitionReadinessGuard.isReady(A,P,7));
            assertEquals("RECOVERING",c.assignment.getState());
            assertEquals(8,c.assignment.getEpoch());
        }finally{complete.countDown();workers.shutdownNow();}
    }
    @Test public void outsideCasDuringPhysicalWriteMustBlockClientSuccess()
            throws Exception {
        Control c=new Control();PartitionReadinessGuard.markReady(A,P,7);
        PartitionEpochCommitBarrier b=c.barrier();
        AtomicBoolean wrote=new AtomicBoolean(false);
        try{
            b.execute(()->{
                wrote.set(true); // physical WAL could have been forced already
                c.compareAndSet(P,4,next(B,A,8,6,"RECOVERING"));
                return "must never ACK";
            });
            fail("external concurrent CAS was not detected");
        }catch(IllegalStateException fenced){
            assertTrue(fenced.getMessage().contains("PARTITION_EPOCH_FENCED"));
        }
        assertTrue(wrote.get());
        assertTrue(b.isRevoked());
        denied(()->b.execute(()->"retry forbidden"));
    }
    @Test public void lostLeaseOrUnknownWriteResultPermanentlyRevokesWriter()
            throws Exception {
        Control control=new Control();PartitionReadinessGuard.markReady(A,P,7);
        PartitionEpochCommitBarrier b=control.barrier();
        control.lease=false;
        denied(()->b.execute(()->"unreachable"));
        assertTrue(b.isRevoked());
        control.lease=true;
        denied(()->b.execute(()->"no stale restart"));
    }
    @Test public void invalidSuccessorAndCasConflictAreBothFailClosed()
            throws Exception{
        Control c=new Control();PartitionReadinessGuard.markReady(A,P,7);
        PartitionEpochCommitBarrier b=c.barrier();
        try{b.drainAndCasRecovering(next(B,A,7,6,"READY"));fail("invalid epoch");}
        catch(IllegalArgumentException expected){}
        assertEquals(0,c.casCalls.get());
        assertFalse(b.isRevoked());
        // A competing controller commits a fresh stat.version after we read
        // the ticket but before this CAS reaches the store.
        c.injectConcurrentCas=true;
        assertFalse(b.drainAndCasRecovering(next(B,A,8,6,"RECOVERING")));
        assertEquals(1,c.casCalls.get());
        assertTrue(b.isRevoked());
        denied(()->b.execute(()->null));
        assertEquals("READY",c.assignment.getState());
    }
}
