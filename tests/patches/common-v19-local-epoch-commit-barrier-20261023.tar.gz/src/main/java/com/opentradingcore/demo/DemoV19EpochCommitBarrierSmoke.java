package com.opentradingcore.demo;

import com.app.common.partition.*;
import com.app.common.zk.ZookeeperClient;
import com.gateway.connector.utils.JsonUtils;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import org.apache.zookeeper.CreateMode;

/**
 * Two real ZooKeeper sessions with per-partition CAS on UNIQUE temporary paths.
 * Simulates a bounded write step; never writes a business WAL, customer order,
 * normal P000 assignment, READY certificate or trading ACK.
 */
public final class DemoV19EpochCommitBarrierSmoke {
    private static final String ROOT=DemoV19FourNodeShardCatalog.ROOT
        +"/epoch-commit-barrier-smoke";
    private static final String P="P000",A="CommonHaDemoA",B="CommonHaDemoB";
    private DemoV19EpochCommitBarrierSmoke(){}
    private static void check(boolean value,String reason)throws IOException{
        if(!value)throw new IOException("three-ZK barrier regression: "+reason);
    }
    private static PartitionAssignment assignment(String primary,String replica,
            long epoch,long version,String state){
        PartitionAssignment a=new PartitionAssignment();
        a.setPartitionId(P);a.setPrimary(primary);a.setReplica(replica);
        a.setReplicas(Collections.singletonList(replica));a.setEpoch(epoch);
        a.setAssignmentVersion(version);a.setState(state);
        return a;
    }
    private static String json(PartitionAssignment a){
        Map<String,Object> m=new LinkedHashMap<>();
        m.put("partitionId",a.getPartitionId());m.put("primary",a.getPrimary());
        m.put("replica",a.getReplica());m.put("replicas",a.getReplicas());
        m.put("epoch",a.getEpoch());m.put("assignmentVersion",a.getAssignmentVersion());
        m.put("state",a.getState());
        return JsonUtils.Serializer(m);
    }
    private static void denied(Callable<?> work,String reason)throws Exception{
        try{work.call();throw new IOException("stale write was admitted: "+reason);}
        catch(IllegalStateException correct){}
    }
    private static void run(String mode,ZookeeperClient one,ZookeeperClient two)
            throws Exception{
        String unique=ROOT+"/"+UUID.randomUUID().toString();
        String directory=unique+"/assignments";
        String data=directory+"/"+P;
        DemoV19FourNodeShardCatalog.ensurePath(one,ROOT);
        DemoV19FourNodeShardCatalog.ensurePath(one,unique);
        DemoV19FourNodeShardCatalog.ensurePath(one,directory);
        one.create(data,json(assignment(A,B,41,2,"READY")),CreateMode.PERSISTENT);
        PartitionReadinessGuard.markReady(A,P,41);
        ExecutorService threads=Executors.newFixedThreadPool(2);
        try(ZkPartitionFailoverControlPlane old=new ZkPartitionFailoverControlPlane(
                 one,directory,"/MDTService",unique+"/old-lease","same-logical-controller");
            ZkPartitionFailoverControlPlane other=new ZkPartitionFailoverControlPlane(
                 two,directory,"/MDTService",unique+"/other-lease","other-controller")) {
            check(old.tryAcquireLease(),"old controller lease missing");
            PartitionEpochReadFence guard=new PartitionEpochReadFence(one::isConnected,old);
            PartitionEpochCommitBarrier barrier=
                new PartitionEpochCommitBarrier(P,A,guard,old,old);
            PartitionAssignment proposed=assignment(B,A,42,3,"RECOVERING");
            if("COOPERATIVE".equals(mode)){
                CountDownLatch inside=new CountDownLatch(1),release=new CountDownLatch(1);
                AtomicBoolean simulatedDurableStep=new AtomicBoolean(false);
                Future<Boolean> write=threads.submit(()->barrier.execute(()->{
                    inside.countDown();
                    if(!release.await(6,TimeUnit.SECONDS))
                        throw new IOException("timeboxed simulated write did not release");
                    simulatedDurableStep.set(true);
                    return true;
                }));
                check(inside.await(6,TimeUnit.SECONDS),"simulated write never entered");
                Future<Boolean> handover=threads.submit(()->barrier.drainAndCasRecovering(
                    proposed));
                Thread.sleep(150L);
                check(old.read(P).getVersion()==0,
                    "cooperative CAS overtook in-flight write");
                release.countDown();
                check(write.get(8,TimeUnit.SECONDS),"simulated pre-CAS work incomplete");
                check(handover.get(8,TimeUnit.SECONDS),"cooperative CAS rejected");
                check(simulatedDurableStep.get(),"no simulated commit step");
                check(barrier.isRevoked(),"writer still live after CAS");
                denied(()->barrier.execute(()->"old ACK"),"old primary post CAS");
            }else if("EXTERNAL".equals(mode)){
                AtomicBoolean simulatedDurableStep=new AtomicBoolean(false);
                try{
                    barrier.execute(()->{
                        simulatedDurableStep.set(true);
                        if(!other.compareAndSet(P,0,proposed))
                            throw new IOException("external CAS could not be injected");
                        return "must never return customer ACK";
                    });
                    throw new IOException("CRITICAL: stale external-CAS success surfaced");
                }catch(IllegalStateException fenced){
                    check(fenced.getMessage().contains("PARTITION_EPOCH_FENCED"),
                        "external epoch change did not reject old ticket");
                }
                check(simulatedDurableStep.get(),"missing simulated uncertain write");
                check(barrier.isRevoked(),"external CAS did not close old writer");
                denied(()->barrier.execute(()->"forbidden retry"),"post external CAS");
            }else throw new IOException("unknown smoke mode");
            PartitionFailoverController.VersionedAssignment actual=other.read(P);
            check(actual.getVersion()==1 && actual.getAssignment().getEpoch()==42
                && "RECOVERING".equals(actual.getAssignment().getState()),
                "real independent ZK CAS/version missing");
            PartitionReadinessGuard.markReady(B,P,42);
            PartitionEpochReadFence successor=new PartitionEpochReadFence(two::isConnected,
                other);
            denied(()->successor.readCurrent(P,B),
                "RECOVERING successor was admitted early");
            System.out.println("THREE_ZK_EPOCH_COMMIT_BARRIER_"+mode+"_PASS"
                +" tempAssignment=true oldEpoch=41 newEpoch=42 zkVersion=1"
                +" sourceRevoked=true recoveringNotReady=true"
                +" realBusinessWalWrites=0 clientAck=false");
        }finally{
            threads.shutdownNow();
            PartitionReadinessGuard.clear(A);PartitionReadinessGuard.clear(B);
            try{one.delete(data);one.delete(directory);one.delete(unique);}
            catch(Exception problem){
                System.err.println("TEMP_ZK_BARRIER_CLEANUP_WARNING "+problem.getMessage());
            }
        }
    }
    public static void main(String[] args)throws Exception{
        if(args.length!=1 || !"--test-only".equals(args[0]))
            throw new IllegalArgumentException("explicit --test-only required");
        ZookeeperClient one=new ZookeeperClient(DemoAssignmentBootstrap.HOSTS,null,null);
        ZookeeperClient two=new ZookeeperClient(DemoAssignmentBootstrap.HOSTS,null,null);
        try{
            for(int i=0;i<100 && !(one.isConnected()&&two.isConnected());i++)
                Thread.sleep(100L);
            check(one.isConnected()&&two.isConnected(),"two separate ZK clients unavailable");
            run("COOPERATIVE",one,two);
            run("EXTERNAL",one,two);
        }finally{one.close();two.close();}
    }
}
