package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;
import java.util.List;
import org.junit.Test;
import static org.junit.Assert.*;

public class DemoV19FourNodeAdmissionVerdictTest {
    @Test public void currentRealDemoPartitionsCannotAdmitClientWrites() {
        for (PartitionAssignment a : DemoV19FourNodeShardCatalog.layout()) {
            List<String> missing = DemoV19FourNodeAdmissionVerdict.missingProofs(
                    a, a.getPrimary(), a.getEpoch(), false, false,
                    true, true, false);
            assertTrue(missing.contains("NOT_READY"));
            assertTrue(missing.contains("NO_CONTROL_LEASE"));
            assertTrue(missing.contains("OLD_PUBLISHER_NOT_ISOLATED"));
            assertTrue(missing.contains("FAULT_DOMAINS_NOT_INDEPENDENT"));
        }
    }

    @Test public void changedEpochAndWrongPrimaryRemainDenied() {
        PartitionAssignment a = DemoV19FourNodeShardCatalog.layout().get(128);
        a.setState("READY"); // local synthetic test object; never write to ZK
        List<String> reasons = DemoV19FourNodeAdmissionVerdict.missingProofs(
                a, a.getReplica(), a.getEpoch() - 1, true, true,
                true, true, true);
        assertTrue(reasons.contains("NOT_PRIMARY"));
        assertTrue(reasons.contains("STALE_EPOCH"));
    }

    @Test public void malformedRf2OrNegativeVersionCannotBePromoted() {
        PartitionAssignment a = DemoV19FourNodeShardCatalog.layout().get(0);
        a.setState("READY"); // synthetic object only; no ZK mutation
        a.setReplica(a.getPrimary());
        assertTrue(DemoV19FourNodeAdmissionVerdict.missingProofs(
                a, a.getPrimary(), 1, true, true, true, true, true)
                .contains("INVALID_RF2_MEMBERSHIP"));
        a.setReplica("CommonHaDemoB");
        a.setAssignmentVersion(-1);
        assertTrue(DemoV19FourNodeAdmissionVerdict.missingProofs(
                a, a.getPrimary(), 1, true, true, true, true, true)
                .contains("INVALID_RF2_MEMBERSHIP"));
    }

    @Test public void validRf2StillNeedsAllIndependentGates() {
        PartitionAssignment a = DemoV19FourNodeShardCatalog.layout().get(128);
        a.setState("READY"); // isolated synthetic positive-boundary test
        assertTrue(DemoV19FourNodeAdmissionVerdict.missingProofs(
                a, a.getPrimary(), a.getEpoch(), true, true, true, true, true).isEmpty());
        a.setState("PREPARING");
        assertTrue(DemoV19FourNodeAdmissionVerdict.missingProofs(
                a, a.getPrimary(), a.getEpoch(), true, true, true, true, true)
                .contains("NOT_READY"));
    }

    @Test public void custodyAndControlLeaseAreIndependentPrerequisites() {
        PartitionAssignment a = DemoV19FourNodeShardCatalog.layout().get(0);
        a.setState("READY"); // constructed only to exercise decision boundaries
        List<String> noCustody = DemoV19FourNodeAdmissionVerdict.missingProofs(
                a, a.getPrimary(), a.getEpoch(), true, true, true, false, true);
        assertEquals(1, noCustody.size());
        assertEquals("CUSTODY_NOT_VERIFIED", noCustody.get(0));

        List<String> noLease = DemoV19FourNodeAdmissionVerdict.missingProofs(
                a, a.getPrimary(), a.getEpoch(), false, true, true, true, true);
        assertTrue(noLease.contains("NO_CONTROL_LEASE"));
        assertTrue(DemoV19FourNodeAdmissionVerdict.missingProofs(
                null, null, 0, false, false, false, false, false)
                .contains("NOT_READY"));
    }
}
