package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Pure admission decision; never changes ZooKeeper or enables a writer. */
final class DemoV19FourNodeAdmissionVerdict {
    private DemoV19FourNodeAdmissionVerdict() {}

    static List<String> missingProofs(PartitionAssignment assignment,
            String candidate, long epoch, boolean controllerLease,
            boolean oldPublisherIsolated, boolean exactWalQuorum,
            boolean bothCustodiesDurable, boolean physicalHostsIndependent) {
        List<String> reasons = new ArrayList<>();
        if (assignment == null || !assignment.isRoutable()
                || !"READY".equals(assignment.getState()))
            reasons.add("NOT_READY");
        if (assignment == null || candidate == null
                || !candidate.equals(assignment.getPrimary()))
            reasons.add("NOT_PRIMARY");
        if (assignment == null || epoch <= 0 || epoch != assignment.getEpoch())
            reasons.add("STALE_EPOCH");
        if (assignment == null
                || assignment.replicaNodes().size() != 1
                || assignment.getPrimary() == null
                || assignment.getPrimary().equals(assignment.getReplica())
                || assignment.getAssignmentVersion() < 0)
            reasons.add("INVALID_RF2_MEMBERSHIP");
        if (!controllerLease) reasons.add("NO_CONTROL_LEASE");
        if (!oldPublisherIsolated) reasons.add("OLD_PUBLISHER_NOT_ISOLATED");
        if (!exactWalQuorum) reasons.add("WAL_QUORUM_NOT_VERIFIED");
        if (!bothCustodiesDurable) reasons.add("CUSTODY_NOT_VERIFIED");
        if (!physicalHostsIndependent) reasons.add("FAULT_DOMAINS_NOT_INDEPENDENT");
        return Collections.unmodifiableList(reasons);
    }
}
