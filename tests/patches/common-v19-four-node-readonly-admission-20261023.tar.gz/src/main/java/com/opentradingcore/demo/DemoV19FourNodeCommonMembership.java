package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;
import com.app.common.replication.DurableWalCommitQuorum;
import com.app.common.zk.ZookeeperClient;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.apache.zookeeper.data.Stat;

/**
 * Experimental bridge from immutable ZK P000/P128 PREPARING assignment and
 * pinned RSA public keys to Common's real signed WAL quorum Membership.
 * Four containers reside on ONE physical Mac; the process-distinct labels
 * MUST NOT be treated as evidence of independent physical fault domains.
 * This class cannot grant READY, sign a receipt or return a client ACK.
 */
final class DemoV19FourNodeCommonMembership {
    static final long EPOCH=1;
    static final long CONFIGURATION=1;
    private DemoV19FourNodeCommonMembership(){}

    static DurableWalCommitQuorum.Membership pinned(ZookeeperClient zk,
            PartitionAssignment assignment)throws Exception {
        if(assignment==null || zk==null || !zk.isConnected())
            throw new IOException("no live pinned ZK control quorum");
        String id=assignment.getPartitionId();
        if(!id.equals(DemoV19FourNodeGenesisPreflight.firstShard(
                DemoV19FourNodeShardCatalog.layout(),'A'))
                && !id.equals(DemoV19FourNodeGenesisPreflight.firstShard(
                DemoV19FourNodeShardCatalog.layout(),'C')))
            throw new IOException("only two bounded 4-node test partitions");
        requireUnchanged(zk,assignment);
        DemoV19FourNodeGenesisPreflight.requireSignedPreflight(zk,assignment);
        List<DurableWalCommitQuorum.Member> members=new ArrayList<>();
        for(String node:DemoV19FourNodeLiveRuntime.owners(assignment)){
            // Distinct JVM simulation, NOT two physical host failures.
            String isolatedLabel="same-mac-jvm-"+node;
            members.add(new DurableWalCommitQuorum.Member(
                node,isolatedLabel,DemoV19FourNodeGenesisPreflight.pinned(zk,node)));
        }
        DurableWalCommitQuorum.Membership membership=
            new DurableWalCommitQuorum.Membership(
                DemoV19FourNodeShardCatalog.SERVICE,id,assignment.getPrimary(),
                EPOCH,CONFIGURATION,members);
        requireUnchanged(zk,assignment);
        return membership;
    }
    static void requireUnchanged(ZookeeperClient zk,PartitionAssignment expected)
            throws Exception{
        if(zk==null || !zk.isConnected() || expected==null
                || !"PREPARING".equals(expected.getState()) || expected.isRoutable()
                || expected.getEpoch()!=EPOCH)
            throw new IOException("not an unchanged isolated PREPARING voter group");
        Stat stat=new Stat();
        Object content=zk.readData(
            DemoV19FourNodeShardCatalog.ASSIGNMENTS+"/"+expected.getPartitionId(),stat);
        if(content==null)throw new IOException("missing ZK assignment");
        DemoV19FourNodeShardCatalog.assertPersisted(
            expected,String.valueOf(content),stat.getVersion());
        if(!zk.isConnected())throw new IOException("ZK quorum lost");
    }
    static void probeTwoPairs(ZookeeperClient zk)throws Exception{
        List<PartitionAssignment> all=DemoV19FourNodeShardCatalog.layout();
        for(char primary:new char[]{'A','C'}){
            String id=DemoV19FourNodeGenesisPreflight.firstShard(all,primary);
            PartitionAssignment partition=all.get(Integer.parseInt(id.substring(1)));
            DurableWalCommitQuorum.Membership membership=pinned(zk,partition);
            if(membership.members.size()!=2 || membership.majority()!=2)
                throw new IOException("Common membership is not strict RF2");
            requireUnchanged(zk,partition);
            java.util.List<String> unmet=DemoV19FourNodeAdmissionVerdict.missingProofs(
                partition,partition.getPrimary(),partition.getEpoch(),
                false,false,true,true,false);
            if(!unmet.contains("NOT_READY") || unmet.isEmpty())
                throw new IOException("PREPARING admission was unexpectedly permitted");
            System.out.println("FOUR_NODE_ADMISSION_DENIED partition="+id
                +" blockers="+String.join(",",unmet)+" clientAck=false");
            System.out.println("FOUR_NODE_COMMON_MEMBERSHIP_ZK_PINNED partition="+id
                +" voters="+String.join(",",membership.members.keySet())
                +" quorum=2 membershipSha256="+membership.digest
                +" membersOnSameMac=true physicalFaultDomainVerified=false"
                +" ready=false clientAck=false");
        }
    }
}
