package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;
import com.app.common.partition.PartitionHasher;
import com.app.common.partition.PartitionReadinessGuard;
import com.app.common.replication.DurableWalAckPolicyBinding;
import com.gateway.connector.utils.JsonUtils;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Demo writer; asynchronous local-durable mode is explicit and opt-in. */
public final class DemoPrimaryWriter {
    // Async compaction is not yet certified for A/B or solo operation. Bound
    // the uncheckpointed local WAL instead of exhausting the isolated disk.
    private static final long MAX_ASYNC_UNCHECKPOINTED_BYTES = 4L * 1024 * 1024;
    private final String node;
    private final DemoJournalCatalog journals;
    private final DemoReplicaClient replicas;
    private final DemoAsyncReplicator async;

    public DemoPrimaryWriter(String node, DemoJournalCatalog journals, DemoReplicaClient replicas) {
        this(node, journals, replicas, null);
    }

    public DemoPrimaryWriter(String node, DemoJournalCatalog journals, DemoReplicaClient replicas,
            DemoAsyncReplicator async) {
        if (node == null || !node.matches("CommonHaDemo[ABC]")
                || ("CommonHaDemoC".equals(node)
                    && !"1".equals(System.getenv("DEMO_V19_THREE_DATA_NODES")))) {
            throw new IllegalArgumentException("unconfigured primary-capable node");
        }
        // The node name does not grant primary authority. Each append must
        // still present a current Common-assignment-bound epoch/fencing grant.
        this.node = node;
        this.journals = journals;
        this.replicas = replicas;
        this.async = async;
    }

    private volatile DemoV19DurableRuntime experimentalQuorum;
    private volatile DemoV19Rf2StrictAckRuntime dynamicStrict;
    private volatile DemoV19AckPolicy ackPolicy;
    void useAckPolicy(DemoV19AckPolicy selected){
        if(selected==null || ackPolicy!=null)
            throw new IllegalArgumentException("ACK policy installed exactly once at startup");
        ackPolicy=selected;
    }
    void useDynamicStrictAck(DemoV19Rf2StrictAckRuntime runtime){
        if(runtime==null || dynamicStrict!=null || async==null)
            throw new IllegalArgumentException("strict dynamic RF2 requires one Netty async runtime");
        dynamicStrict=runtime;
    }

    private final Object reliableAckOrder=new Object();

    /** Isolated opt-in only; must be installed before the Netty listener starts. */
    void useExperimentalQuorum(DemoV19DurableRuntime runtime) {
        if (runtime==null || experimentalQuorum!=null || async==null)
            throw new IllegalArgumentException("one async experimental quorum required");
        experimentalQuorum=runtime;
    }

    public Map<String,Object> append(String content) {
        if(dynamicStrict!=null && dynamicStrict.strictReadyFor(node))
            return appendDynamicStrict(content);
        DemoV19DurableRuntime quorum=experimentalQuorum;
        // A pinned STRICT_QUORUM policy MUST NOT silently downgrade client
        // durability merely because the ZK controller staged a solo epoch.
        // Dynamic mode changes require a separate certified epoch cutover.
        if(ackPolicy!=null && ackPolicy.strict() && degradedLocalPilot()){
            Map<String,Object> denied=new LinkedHashMap<String,Object>();
            denied.put("code",503);
            denied.put("msg","STRICT_QUORUM_POLICY_REQUIRES_AUTHORIZED_MODE_CUTOVER");
            denied.put("node",node);
            denied.put("quorumDurable",false);
            return denied;
        }
        if(localStreamPilot() || degradedLocalPilot())return appendLocalStream(content);
        if(quorum==null)return appendLocally(content);
        // Serialize acknowledgement ordering without holding the WAL monitor
        // while background replica copy works on its fsynced backlog.
        synchronized(reliableAckOrder) {
            // The single-record endpoint must obey the SAME durable-backlog
            // admission barrier as group append; never allow an alternate
            // TCP operation to silently extend an uncertified WAL tail.
            try {
                @SuppressWarnings("unchecked") Map<String,Object> input=
                        JsonUtils.Deserialize(content,Map.class);
                if(input!=null && "P000".equals(input.get("partitionId"))) {
                    String requestId=string(input,"requestId");
                    DemoDurableJournal journal=journals.journal("P000");
                    if(journal.committedRequest(requestId)==null) {
                        PartitionAssignment current=DemoHotpathControl.read("P000");
                        quorum.requireFreshWriteAdmission(current.getEpoch(),journal);
                    }
                }
            } catch(Exception unsafe) {
                Map<String,Object> denied=new LinkedHashMap<String,Object>();
                denied.put("code",503);
                denied.put("msg","DEMO_UNCERTIFIED_BACKLOG: "+unsafe.getMessage());
                denied.put("partitionId","P000");
                denied.put("node",node);
                return denied;
            }
            Map<String,Object> local=appendLocally(content);
            if(!(local.get("code") instanceof Number)
                    || ((Number)local.get("code")).intValue()!=0)return local;
            try {
                long epoch=((Number)local.get("epoch")).longValue();
                long seq=((Number)local.get("committedSeq")).longValue();
                com.app.common.replication.DurableWalCommitAckGate.Confirmed certified =
                        quorum.certify(epoch,seq);
                local.put("durabilityMode", "QUORUM_DURABLE_SINGLE_HOST_TEST");
                local.put("certifiedSeq",certified.sequence);
                local.put("certifiedPrefixSha256",certified.prefixSha256);
                return local;
            } catch(Exception notDurable) {
                // An fsynced local WAL record MUST NOT turn into a successful
                // client ACK when no authenticated 2/3 certificate exists.
                Map<String,Object> denied=new LinkedHashMap<String,Object>();
                denied.put("code",503);
                denied.put("msg","DEMO_QUORUM_NOT_DURABLE: "+notDurable.getMessage());
                denied.put("node",node);
                denied.put("partitionId",local.get("partitionId"));
                denied.put("requestId",local.get("requestId"));
                denied.put("localCommittedSeqUnacknowledged",local.get("committedSeq"));
                return denied;
            }
        }
    }

    /** Strict external success is issued AFTER remote WAL fsync, two signed
     * receipts, persisted CommitIndex and BOTH physical custody witnesses.
     * On failure a forced local WAL remains UNACKNOWLEDGED, never code=0.
     */
    private Map<String,Object> appendDynamicStrict(String content){
        synchronized(reliableAckOrder){
            String id=null;
            try {
                @SuppressWarnings("unchecked") Map<String,Object> request=
                    JsonUtils.Deserialize(content,Map.class);
                if(request==null || !"P000".equals(request.get("partitionId")))
                    throw new IOException("strict pilot only covers P000");
                id=string(request,"requestId");
                long delta=number(request,"delta");
                dynamicStrict.beforeAppend(id,delta);
                Map<String,Object> local=appendLocally(content);
                if(!(local.get("code") instanceof Number)
                        || ((Number)local.get("code")).intValue()!=0)
                    return local;
                long epoch=((Number)local.get("epoch")).longValue();
                long seq=((Number)local.get("committedSeq")).longValue();
                com.app.common.replication.DurableWalCommitAckGate.Confirmed cert=
                    dynamicStrict.certifyAfterAppend(epoch,seq);
                local.put("quorumDurable",true);
                local.put("durabilityMode","QUORUM_DURABLE");
                local.put("certifiedSeq",cert.sequence);
                local.put("certifiedPrefixSha256",cert.prefixSha256);
                local.put("possibleDataLossIfPrimaryPermanentlyLost",false);
                local.put("replicationPolicy","TWO_NODE_SYNC_DURABLE_WAL");
                if(ackPolicy!=null)
                    DurableWalAckPolicyBinding.requireAck(ackPolicy.mode,
                        String.valueOf(local.get("durabilityMode")),
                        Boolean.TRUE.equals(local.get("quorumDurable")),
                        Boolean.TRUE.equals(local.get(
                            "possibleDataLossIfPrimaryPermanentlyLost")));
                return local;
            }catch(Exception failed){
                Map<String,Object> denied=new LinkedHashMap<String,Object>();
                denied.put("code",503);
                denied.put("msg","RF2_STRICT_ACK_NOT_DURABLE: "+failed.getMessage());
                denied.put("node",node);
                denied.put("partitionId","P000");
                if(id!=null)denied.put("requestId",id);
                denied.put("quorumDurable",false);
                return denied;
            }
        }
    }

    /** Isolated Common RF2 strict GROUP writer: 8 real WAL records / one
     * forced group and ONE signed high-water certificate, both physical
     * Custody stores. Every individual request must match the proven prefix.
     * No public business API and never implicit local-only ACK.
     */
    private Map<String,Object> appendDynamicStrictGroup(Map<String,Object> request){
        Map<String,Object> out=new LinkedHashMap<>();
        long lastUnacknowledged=0;
        long queued=System.nanoTime();
        synchronized(reliableAckOrder){
            long acquired=System.nanoTime(),admission=0,forced=0,certified=0,covered=0;
            try{
                Object rows=request==null?null:request.get("commands");
                if(!(rows instanceof List) || ((List<?>)rows).isEmpty()
                        || ((List<?>)rows).size()>32)
                    throw new IOException("strict group must contain 1..32 requests");
                List<DemoStateMachine.Operation> operations=new ArrayList<>();
                java.util.Set<String> unique=new java.util.HashSet<>();
                for(Object raw:(List<?>)rows){
                    if(!(raw instanceof Map))throw new IOException("malformed strict group command");
                    @SuppressWarnings("unchecked") Map<String,Object> cmd=(Map<String,Object>)raw;
                    if(!"P000".equals(string(cmd,"partitionId"))
                            || !"P000".equals(PartitionHasher.partitionId(
                                string(cmd,"partitionKey"),256)))
                        throw new IOException("strict group not in approved partition");
                    String requestId=string(cmd,"requestId");
                    if(!unique.add(requestId))
                        throw new IOException("duplicate requestId in strict batch");
                    operations.add(new DemoStateMachine.Operation(requestId,
                        number(cmd,"delta")));
                }
                // Reject a stale primary and dirty/corrupt certified frontier
                // BEFORE mutating its durable journal.
                dynamicStrict.beforeAppend(operations.get(0).requestId,
                    operations.get(0).delta);
                admission=System.nanoTime();
                PartitionAssignment grant=DemoHotpathControl.read("P000");
                long epoch=grant.getEpoch();
                if(!grant.isRoutable() || !node.equals(grant.getPrimary())
                        || !PartitionReadinessGuard.isReady(node,"P000",epoch))
                    throw new IOException("strict group primary epoch not READY");
                DemoDurableJournal journal=journals.journal("P000");
                long first,last;
                boolean allPresent;
                synchronized(journal){
                    DemoHotpathControl.requireCurrent("P000",epoch,node,null);
                    if(!journal.isReadyForWrites()
                            || journal.uncheckpointedBytes()>=MAX_ASYNC_UNCHECKPOINTED_BYTES)
                        throw new IOException("strict WAL dirty or at capacity");
                    int present=0;
                    long firstSeen=-1;
                    for(int i=0;i<operations.size();i++){
                        DemoStateMachine.Operation op=operations.get(i);
                        DemoDurableJournal.CommittedRequest found=
                            journal.committedRequest(op.requestId);
                        if(found!=null){
                            if(found.delta!=op.delta
                                    || (firstSeen!=-1 && found.seq!=firstSeen+i))
                                throw new IOException("idempotent group order/amount mismatch");
                            if(firstSeen==-1)firstSeen=found.seq-i;
                            present++;
                        }
                    }
                    if(present>0 && present!=operations.size())
                        throw new IOException("partial strict group retry requires explicit recovery");
                    allPresent=present==operations.size();
                    if(allPresent){
                        first=firstSeen;
                        last=first+operations.size()-1;
                    } else {
                        first=journal.committedSeq()+1;
                        com.app.common.replication.DurableWalGroupCommit.CommittedBatch group=
                            journal.prepareAndCommitGroupForce(epoch,operations);
                        last=group.lastSequence;
                        lastUnacknowledged=last;
                    }
                    DemoHotpathControl.requireCurrent("P000",epoch,node,null);
                }
                forced=System.nanoTime();
                if(!allPresent)
                    dynamicStrict.certifyAfterAppend(epoch,first,last);
                certified=System.nanoTime();
                // The Common certified cumulative prefix covers every
                // exact forced command only if these independent ACK gates pass.
                dynamicStrict.requireCoveredCommands(epoch,first,operations);
                covered=System.nanoTime();
                System.out.println("T68_STRICT_BATCH_BREAKDOWN seq="+last+
                    " queueMs="+((acquired-queued)/1000000)+
                    " admissionMs="+((admission-acquired)/1000000)+
                    " forcedMs="+((forced-admission)/1000000)+
                    " certificateMs="+((certified-forced)/1000000)+
                    " coveredMs="+((covered-certified)/1000000));
                List<Map<String,Object>> items=new ArrayList<>();
                for(int i=0;i<operations.size();i++){
                    Map<String,Object> each=new LinkedHashMap<>();
                    each.put("requestId",operations.get(i).requestId);
                    each.put("committedSeq",first+i);
                    each.put("appliedCount",journal.state().appliedCount(
                        operations.get(i).requestId));
                    items.add(each);
                }
                out.put("code",0);out.put("node",node);
                out.put("partitionId","P000");out.put("epoch",epoch);
                out.put("firstSeq",first);out.put("committedSeq",last);
                out.put("count",operations.size());out.put("requests",items);
                out.put("durabilityMode","QUORUM_DURABLE");
                out.put("quorumDurable",true);
                out.put("possibleDataLossIfPrimaryPermanentlyLost",false);
                out.put("replicationPolicy","TWO_NODE_SYNC_DURABLE_WAL");
                if(ackPolicy!=null)
                    DurableWalAckPolicyBinding.requireAck(ackPolicy.mode,
                        String.valueOf(out.get("durabilityMode")),
                        Boolean.TRUE.equals(out.get("quorumDurable")),
                        Boolean.TRUE.equals(out.get(
                            "possibleDataLossIfPrimaryPermanentlyLost")));
                return out;
            } catch(Exception denied){
                out.put("code",503);out.put("node",node);
                out.put("partitionId","P000");out.put("quorumDurable",false);
                out.put("msg","RF2_DYNAMIC_STRICT_BATCH_NOT_DURABLE: "+
                    denied.getClass().getSimpleName()+": "+denied.getMessage());
                if(lastUnacknowledged>0)
                    out.put("localCommittedSeqUnacknowledged",lastUnacknowledged);
                return out;
            }
        }
    }

    private boolean localStreamPilot() {
        if(ackPolicy!=null)return async!=null && ackPolicy.local();
        return async!=null
                && "1".equals(System.getenv("DEMO_V19_LOCAL_ACK_STREAM_PILOT"));
    }

    /** Old 2/2 was certified before the controller switched to an explicit
     * single-writer, single-WAL epoch. Grant cache contains a ZK-authenticated
     * READY owner; no per-order ZK RPC or fake quorum ACK here.
     */
    private boolean degradedLocalPilot() {
        if (async==null || experimentalQuorum==null
                || !"1".equals(System.getenv("DEMO_V19_RF2_AUTO_DEGRADE"))) return false;
        try {
            PartitionAssignment grant=DemoHotpathControl.read("P000");
            return DemoV19Rf2DegradedPolicy.mayUseLocalAck(true,true,grant,node);
        } catch (RuntimeException noGrant) { return false; }
    }

    /**
     * Explicit local-durable ACK, independent of the B/C data-node status.
     * This is NOT zero-loss HA and never claims QUORUM_DURABLE. ZK majority
     * still owns the bounded epoch/grant independently of the data replicas.
     */
    private Map<String,Object> appendLocalStream(String content) {
        synchronized(reliableAckOrder) {
            if(ackPolicy!=null && ackPolicy.strict()){
                Map<String,Object> denied=new LinkedHashMap<String,Object>();
                denied.put("code",503);
                denied.put("msg","STRICT_QUORUM_POLICY_REQUIRES_AUTHORIZED_MODE_CUTOVER");
                denied.put("quorumDurable",false);
                return denied;
            }
            boolean degraded=degradedLocalPilot();
            if(experimentalQuorum!=null && !degraded) {
                Map<String,Object> denied=new LinkedHashMap<String,Object>();
                denied.put("code",503);
                denied.put("msg","local and quorum durability policies cannot be combined");
                return denied;
            }
            Map<String,Object> result=appendLocally(content);
            if(!(result.get("code") instanceof Number)
                    || ((Number)result.get("code")).intValue()!=0)
                return result;
            String partition=String.valueOf(result.get("partitionId"));
            long epoch=((Number)result.get("epoch")).longValue();
            long seq=((Number)result.get("committedSeq")).longValue();
            String requestId=String.valueOf(result.get("requestId"));
            try {
                @SuppressWarnings("unchecked") Map<String,Object> original=
                        JsonUtils.Deserialize(content,Map.class);
                long delta=number(original,"delta");
                DemoDurableJournal wal=journals.journal(partition);
                com.app.common.replication.DurableWalLocalAckGate.Confirmed ack=
                        com.app.common.replication.DurableWalLocalAckGate.requireLocalDurable(
                                partition,epoch,seq,
                                (e,s)->wal.requireForcedCommitted(e,s,requestId,delta),
                                (p,e)->DemoHotpathControl.requireCurrent(p,e,node,null));
                result.put("durabilityMode",degraded
                        ? "AUTO_DEGRADED_LOCAL_DURABLE" : ack.durabilityMode);
                result.put("quorumDurable",false);
                result.put("autoDegradedRf2",degraded);
                result.put("replicationPolicy","ONE_WAY_ASYNC_WAL_STREAM");
                Object remote=result.get("lastReplicatedSeq");
                long confirmedRemote=remote instanceof Number
                        ?((Number)remote).longValue():0L;
                result.put("unreplicatedRecordsAtAck",Math.max(0L,seq-confirmedRemote));
                result.put("possibleDataLossIfPrimaryPermanentlyLost",true);
                if(ackPolicy!=null)
                    DurableWalAckPolicyBinding.requireAck(ackPolicy.mode,
                        String.valueOf(result.get("durabilityMode")),
                        Boolean.TRUE.equals(result.get("quorumDurable")),
                        Boolean.TRUE.equals(result.get(
                            "possibleDataLossIfPrimaryPermanentlyLost")));
                return result;
            } catch(Exception unsafe) {
                Map<String,Object> denied=new LinkedHashMap<String,Object>();
                denied.put("code",503);
                denied.put("msg","LOCAL_DURABLE_ACK_DENIED: "+unsafe.getMessage());
                denied.put("partitionId",partition);
                denied.put("node",node);
                denied.put("requestId",requestId);
                denied.put("localCommittedSeqUnacknowledged",seq);
                return denied;
            }
        }
    }

    /**
     * Isolated explicit group TCP test, not the public trading API.
     * Common orchestrates group WAL force and cumulative majority proof.
     * No client success can escape before all 2/3 receipts and cert force.
     */
    Map<String,Object> appendGroup(Map<String,Object> request) {
        if(dynamicStrict!=null && dynamicStrict.strictReadyFor(node))
            return appendDynamicStrictGroup(request);
        Map<String,Object> result=new LinkedHashMap<String,Object>();
        if(experimentalQuorum==null || async==null
                || !"1".equals(System.getenv("DEMO_V19_GROUP_FORCE_PILOT"))) {
            result.put("code",503);
            result.put("msg","group quorum pilot not enabled");
            return result;
        }
        Object rows=request==null?null:request.get("commands");
        if(!(rows instanceof List) || ((List<?>)rows).isEmpty()
                || ((List<?>)rows).size()>8) {
            result.put("code",503);
            result.put("msg","bounded group commands of 1..8 required");
            return result;
        }
        synchronized(reliableAckOrder) {
            String partition="P000";
            long first=0L,last=0L,epoch=0L;
            try {
                List<DemoStateMachine.Operation> operations=
                        new ArrayList<DemoStateMachine.Operation>();
                java.util.Set<String> ids=new java.util.HashSet<String>();
                for(Object row:(List<?>)rows) {
                    if(!(row instanceof Map))throw new IllegalArgumentException("invalid batch command");
                    @SuppressWarnings("unchecked") Map<String,Object> item=(Map<String,Object>)row;
                    String key=string(item,"partitionKey");
                    if(!partition.equals(string(item,"partitionId"))
                            || !partition.equals(PartitionHasher.partitionId(key,256)))
                        throw new IllegalArgumentException("invalid group partition");
                    String id=string(item,"requestId");
                    if(!ids.add(id))throw new IllegalArgumentException("duplicate group request");
                    operations.add(new DemoStateMachine.Operation(id,number(item,"delta")));
                }
                PartitionAssignment assignment=DemoHotpathControl.read(partition);
                epoch=assignment.getEpoch();
                if(!assignment.isRoutable() || !node.equals(assignment.getPrimary())
                        || !PartitionReadinessGuard.isReady(node,partition,epoch))
                    throw new IllegalStateException("not current writable primary");
                DemoDurableJournal journal=journals.journal(partition);
                // Durability admission is separate from idempotent retry:
                // if an earlier WAL group was locally fsynced but its 2/3
                // certificate is absent, do NOT append more fresh requests.
                // Attempt one bounded, signed 64-record catch-up step. Only
                // existing matching requestIds may bypass this fresh-write
                // barrier and recheck their historical certified inclusion.
                boolean freshGroup=false;
                for(DemoStateMachine.Operation operation:operations) {
                    if(journal.committedRequest(operation.requestId)==null) {
                        freshGroup=true;
                        break;
                    }
                }
                if(freshGroup)
                    experimentalQuorum.requireFreshWriteAdmission(epoch,journal);

                synchronized(journal) {
                    DemoHotpathControl.requireCurrent(partition,epoch,node,null);
                    DemoHotpathControl.requireWritableQuorum(partition,epoch,node);
                    if(!journal.isReadyForWrites())
                        throw new IOException("group WAL is dirty; certified recovery required");
                    int present=0;
                    long priorSeq=-1;
                    for(DemoStateMachine.Operation op:operations) {
                        DemoDurableJournal.CommittedRequest prior=
                                journal.committedRequest(op.requestId);
                        if(prior!=null) {
                            if(prior.delta!=op.delta || (priorSeq!=-1 && prior.seq!=priorSeq+1))
                                throw new IllegalStateException("group requestId payload or order conflict");
                            priorSeq=prior.seq;
                            present++;
                        }
                    }
                    if(present!=0 && present!=operations.size())
                        throw new IOException("partially present group requires offline recovery");
                    if(present==operations.size()) {
                        last=priorSeq;first=last-operations.size()+1;
                    } else {
                        if(journal.uncheckpointedBytes()>=MAX_ASYNC_UNCHECKPOINTED_BYTES)
                            throw new IOException("bounded async WAL storage exhausted");
                        first=journal.committedSeq()+1;
                        com.app.common.replication.DurableWalGroupCommit.CommittedBatch group=
                                journal.prepareAndCommitGroupForce(epoch,operations);
                        last=group.lastSequence;
                    }
                    DemoHotpathControl.requireCurrent(partition,epoch,node,null);
                    DemoHotpathControl.requireWritableQuorum(partition,epoch,node);
                    async.signal(partition);
                }
                experimentalQuorum.certifyBatch(epoch,first,last);
                List<Map<String,Object>> individual=new ArrayList<Map<String,Object>>();
                for(int i=0;i<operations.size();i++) {
                    long seq=first+i;
                    experimentalQuorum.certifyCovered(epoch,seq);
                    Map<String,Object> each=new LinkedHashMap<String,Object>();
                    each.put("requestId",operations.get(i).requestId);
                    each.put("committedSeq",seq);
                    each.put("appliedCount",journals.journal(partition).state()
                            .appliedCount(operations.get(i).requestId));
                    individual.add(each);
                }
                result.put("code",0);
                result.put("node",node);
                result.put("partitionId",partition);
                result.put("epoch",epoch);
                result.put("firstSeq",first);
                result.put("committedSeq",last);
                result.put("count",operations.size());
                result.put("durabilityMode","QUORUM_DURABLE_SINGLE_HOST_TEST");
                result.put("requests",individual);
                return result;
            } catch(Exception rejected) {
                result.put("code",503);
                result.put("msg","DEMO_GROUP_NOT_DURABLE: "
                        +rejected.getClass().getSimpleName()+": "+rejected.getMessage());
                result.put("node",node);
                result.put("partitionId",partition);
                result.put("localCommittedSeqUnacknowledged",last);
                return result;
            }
        }
    }

    private Map<String, Object> appendLocally(String content) {
        String partitionId = null;
        try {
            @SuppressWarnings("unchecked") Map<String, Object> command = JsonUtils.Deserialize(content, Map.class);
            if (command == null) throw new IllegalArgumentException("command required");
            String requestId = string(command, "requestId");
            String key = string(command, "partitionKey");
            partitionId = string(command, "partitionId");
            if (!PartitionHasher.partitionId(key, 256).equals(partitionId)) {
                throw new IllegalArgumentException("partition key and ID disagree");
            }
            DemoStateMachine.Operation operation = new DemoStateMachine.Operation(requestId, number(command, "delta"));
            PartitionAssignment assignment = DemoHotpathControl.read(partitionId);
            long epoch = assignment.getEpoch();
            if (!assignment.isRoutable() || !node.equals(assignment.getPrimary())
                    || !PartitionReadinessGuard.isReady(node, partitionId, epoch)) {
                throw new IllegalStateException("partition is not ready on current primary");
            }
            List<String> assigned = assignment.replicaNodes();
            if ((async == null && assigned.isEmpty()) || assigned.size() > 2) {
                throw new IllegalStateException("independent assigned synchronous replica required");
            }
            DemoDurableJournal journal = journals.journal(partitionId);
            synchronized (journal) {
                DemoHotpathControl.requireCurrent(partitionId, epoch, node, null);
                if (!journal.isReadyForWrites()) throw new IllegalStateException("local dirty tail blocks ACK");
                DemoDurableJournal.CommittedRequest prior = journal.committedRequest(requestId);
                if (prior != null) {
                    if (prior.delta != operation.delta) throw new IllegalStateException("requestId payload conflict");
                    if (async == null) certifyReplicas(partitionId, assigned, journal);
                    DemoHotpathControl.requireWritableQuorum(partitionId, epoch, node);
                    DemoHotpathControl.requireCurrent(partitionId, epoch, node, null);
                    return ack(partitionId, epoch, prior.seq, operation, journal, assigned);
                }
                long seq = journal.committedSeq() + 1;
                DemoFaultHook fault = DemoFaultHook.forRequest(partitionId, requestId);
                DemoHotpathControl.requireWritableQuorum(partitionId, epoch, node);
                DemoHotpathControl.requireCurrent(partitionId, epoch, node, null);
                if (async != null && journal.uncheckpointedBytes() >= MAX_ASYNC_UNCHECKPOINTED_BYTES) {
                    throw new IOException("async WAL reached fail-closed capacity before certified checkpoint");
                }
                long v19WalStart = DemoHotpathControl.enabled(partitionId)
                        ? System.nanoTime() : 0L;
                boolean v19SingleForce = async != null
                        && DemoHotpathControl.enabled(partitionId)
                        && "1".equals(System.getenv("DEMO_V19_SINGLE_FORCE_PILOT"));
                if (v19SingleForce) journal.prepareAndCommitSingleForce(epoch, seq, operation);
                else journal.prepare(epoch, seq, operation);
                if (async == null) {
                    for (String replica : assigned) {
                        replicas.send(replica, "prepare", partitionId, node, epoch, seq, operation);
                    }
                    List<String> commitOrder = fault == null
                            ? assigned : fault.commitOrder(new ArrayList<String>(assigned));
                    for (String replica : commitOrder) {
                        replicas.send(replica, "commit", partitionId, node, epoch, seq, operation);
                        if (fault != null) fault.afterCommit(replica);
                    }
                }
                // Local commit is always forced before ACK. In async mode the
                // durable WAL itself is the restart-safe replication backlog.
                if (!v19SingleForce) journal.commit(epoch, seq, operation);
                if (v19WalStart != 0L)
                    DemoV19PerfCounters.recordWal(System.nanoTime() - v19WalStart);
                if (async == null) certifyReplicas(partitionId, assigned, journal);
                DemoHotpathControl.requireWritableQuorum(partitionId, epoch, node);
                DemoHotpathControl.requireCurrent(partitionId, epoch, node, null);
                if (async != null) async.signal(partitionId);
                return ack(partitionId, epoch, seq, operation, journal, assigned);
            }
        } catch (Exception unsafe) {
            if (partitionId != null && partitionId.matches("P\\d{3}")) {
                // Fail closed first. An event-driven recheck is only a request to
                // repeat the full majority/epoch/WAL proof; never a direct READY.
                PartitionReadinessGuard.revoke(node, partitionId);
                String why = String.valueOf(unsafe.getMessage()).replace('\n',' ');
                System.err.println("DEMO_PRIMARY_REVOKED node=" + node
                        + " partition=" + partitionId + " cause=" + unsafe.getClass().getSimpleName()
                        + " reason=" + why.substring(0, Math.min(why.length(), 220)));
                DemoReadinessRuntime.afterPrimaryRevoked(node, partitionId);
            }
            Map<String, Object> failure = new LinkedHashMap<String, Object>();
            failure.put("code", 503);
            failure.put("msg", "DEMO_NOT_READY: " + unsafe.getClass().getSimpleName() + ": " + unsafe.getMessage());
            failure.put("node", node);
            if (partitionId != null) failure.put("partitionId", partitionId);
            return failure;
        }
    }

    private void certifyReplicas(String partitionId, List<String> assigned,
            DemoDurableJournal journal) throws IOException {
        String prefix = journal.committedPrefixSha256();
        long seq = journal.committedSeq();
        String state = journal.state().stateDigest();
        for (String replica : assigned) {
            Map<String, Object> status = replicas.status(replica, partitionId);
            if (!Boolean.TRUE.equals(status.get("clean"))
                    || !equalNumber(seq, status.get("committedSeq"))
                    || !prefix.equals(status.get("committedPrefixSha256"))
                    || !state.equals(status.get("stateDigest"))) {
                throw new IOException("replica " + replica + " lacks exact durable prefix proof");
            }
        }
    }

    private Map<String, Object> ack(String partitionId, long epoch, long seq,
            DemoStateMachine.Operation operation, DemoDurableJournal journal,
            List<String> assigned) {
        Map<String, Object> result = new LinkedHashMap<String, Object>();
        result.put("code", 0);
        result.put("requestId", operation.requestId);
        result.put("appliedCount", journal.state().appliedCount(operation.requestId));
        result.put("node", node);
        result.put("partitionId", partitionId);
        result.put("epoch", epoch);
        result.put("committedSeq", seq);
        result.put("durabilityMode", async == null ? "SYNC_DURABLE" :
                assigned.isEmpty() ? "LOCAL_DURABLE" : "ASYNC_LOCAL_DURABLE");
        result.put("lastReplicatedSeq", async == null ? seq :
                async.replicatedSeq(partitionId, assigned));
        // The full sorted-map state digest is O(all historic requests) and is
        // still recomputed on physical-status, checkpoint, and offline audit.
        // It is not an ACK/durability proof: the journal has already been fsynced.
        // Explicit isolated opt-in avoids walking the entire in-memory state
        // under the primary WAL lock for every trading request.
        if (includeFullDigestOnAck()) {
            result.put("stateDigest", journal.state().stateDigest());
        } else {
            // Explicit test-only wire contract, never impersonate full-digest ACK.
            result.put("stateDigestDeferred", true);
            result.put("ackProofMode", "SEQUENCE_ONLY_FULL_AUDIT_REQUIRED");
        }
        return result;
    }

    static boolean includeFullDigestOnAck() {
        return !"false".equalsIgnoreCase(System.getProperty("demo.ack.fullDigest", "true"));
    }

    private static String string(Map<String, Object> command, String key) {
        Object value = command.get(key);
        if (!(value instanceof String) || ((String) value).isEmpty()) {
            throw new IllegalArgumentException(key + " required");
        }
        return (String) value;
    }

    private static long number(Map<String, Object> command, String key) {
        Object value = command.get(key);
        if (!(value instanceof Number) || ((Number) value).longValue() <= 0) {
            throw new IllegalArgumentException(key + " must be positive");
        }
        return ((Number) value).longValue();
    }

    private static boolean equalNumber(long expected, Object actual) {
        return actual instanceof Number && ((Number) actual).longValue() == expected;
    }
}
