package com.opentradingcore.demo;

import com.app.common.zk.ZookeeperClient;
import com.app.common.replication.DurableWalAckPolicy;
import com.app.common.replication.DurableWalAckPolicyBinding;
import java.io.IOException;
import org.apache.zookeeper.CreateMode;

/** One explicit ACK-policy selector for the isolated RF2 Common pilot.
 * This is a STARTUP policy for a newly bootstrapped ZK assignment, NOT a
 * runtime grant or an online mode transition. A different policy on the
 * same durable ZK ensemble must fail closed rather than weaken prior ACKs.
 * Production requires an authenticated epoch CAS + old-writer revocation.
 */
final class DemoV19AckPolicy {
    private static final String ROOT=DemoZkFenceSource.ISOLATED_ROOT
            +"/harness/ack-policy";
    final DurableWalAckPolicy mode;
    private DemoV19AckPolicy(DurableWalAckPolicy mode){this.mode=mode;}
    static DemoV19AckPolicy fromEnvironment(){
        String value=System.getenv("DEMO_V19_ACK_POLICY");
        if(value==null || value.trim().isEmpty())return null; // legacy test configs
        if(!value.equals(value.trim()))
            throw new IllegalArgumentException("ACK policy has whitespace");
        try {return new DemoV19AckPolicy(DurableWalAckPolicy.parse(value));}
        catch(IllegalArgumentException invalid){
            throw new IllegalArgumentException(
                "unknown DEMO_V19_ACK_POLICY; use STRICT_QUORUM or LOCAL_DURABLE_ASYNC");
        }
    }
    boolean strict(){return mode==DurableWalAckPolicy.STRICT_QUORUM;}
    boolean local(){return mode==DurableWalAckPolicy.LOCAL_DURABLE_ASYNC;}
    private static DurableWalAckPolicyBinding.Store store(ZookeeperClient zk){
        return new DurableWalAckPolicyBinding.Store(){
            @Override public String read(){
                return zk.exists(ROOT)?String.valueOf(zk.readData(ROOT)):null;
            }
            @Override public void createIfAbsent(String policy){
                try {zk.create(ROOT,policy,CreateMode.PERSISTENT);}
                catch(org.I0Itec.zkclient.exception.ZkNodeExistsException concurrent){
                    // Always re-read and reject conflicting concurrent selection.
                }
            }
        };
    }
    /** Bootstrap may only create the immutable mode pin. It never rewrites
     * the policy or changes the already-authorized writer epoch. */
    void bootstrap(ZookeeperClient zk){
        try {DurableWalAckPolicyBinding.bootstrap(store(zk),mode);}
        catch(Exception invalid){throw new IllegalStateException(invalid.getMessage(),invalid);}
    }
    /** All peers verify the same Common policy contract at startup. */
    void requireCurrent(ZookeeperClient zk){
        try {DurableWalAckPolicyBinding.requirePinned(store(zk),mode);}
        catch(Exception invalid){throw new IllegalStateException(invalid.getMessage(),invalid);}
    }
}
