package com.app.common.replication;

import java.util.concurrent.atomic.AtomicReference;
import org.junit.Test;
import static org.junit.Assert.*;

public class DurableWalAckPolicyBindingTest {
    private static final class MemoryStore
            implements DurableWalAckPolicyBinding.Store {
        final AtomicReference<String> mode=new AtomicReference<>();
        @Override public String read(){return mode.get();}
        @Override public void createIfAbsent(String value){
            mode.compareAndSet(null,value);
        }
    }

    interface Checked {void run() throws Exception;}
    private static void denied(Checked operation, String msg)throws Exception {
        try {operation.run();fail("accepted unsupported change");}
        catch(java.io.IOException expected){assertTrue(expected.getMessage(),
            expected.getMessage().contains(msg));}
    }

    @Test public void firstWriterPinsAndJoinIsIdempotent() throws Exception {
        MemoryStore store=new MemoryStore();
        DurableWalAckPolicyBinding.bootstrap(
            store,DurableWalAckPolicy.STRICT_QUORUM);
        DurableWalAckPolicyBinding.bootstrap(
            store,DurableWalAckPolicy.STRICT_QUORUM);
        assertEquals("STRICT_QUORUM",store.read());
        DurableWalAckPolicyBinding.requirePinned(
            store,DurableWalAckPolicy.STRICT_QUORUM);
    }
    @Test public void priorAsyncPolicyCannotBeOverwritten() throws Exception {
        MemoryStore store=new MemoryStore();
        DurableWalAckPolicyBinding.bootstrap(
            store,DurableWalAckPolicy.LOCAL_DURABLE_ASYNC);
        denied(()->DurableWalAckPolicyBinding.bootstrap(
            store,DurableWalAckPolicy.STRICT_QUORUM),"CUTOVER");
        assertEquals("LOCAL_DURABLE_ASYNC",store.read());
    }
    @Test public void firstWriterRaceMustNotDowngradeStrict() throws Exception {
        MemoryStore store=new MemoryStore();
        store.mode.set("STRICT_QUORUM");
        denied(()->DurableWalAckPolicyBinding.bootstrap(
            store,DurableWalAckPolicy.LOCAL_DURABLE_ASYNC),"CUTOVER");
        assertEquals("STRICT_QUORUM",store.read());
    }
    @Test public void absentPolicyOnJoinFailsClosed() throws Exception {
        MemoryStore store=new MemoryStore();
        denied(()->DurableWalAckPolicyBinding.requirePinned(
            store,DurableWalAckPolicy.STRICT_QUORUM),"CUTOVER");
    }
    @Test public void clientAckEvidenceIsPolicySpecific() throws Exception {
        DurableWalAckPolicyBinding.requireAck(
            DurableWalAckPolicy.STRICT_QUORUM,"QUORUM_DURABLE",true,false);
        DurableWalAckPolicyBinding.requireAck(
            DurableWalAckPolicy.LOCAL_DURABLE_ASYNC,
            "LOCAL_DURABLE_ASYNC",false,true);
        denied(()->DurableWalAckPolicyBinding.requireAck(
            DurableWalAckPolicy.STRICT_QUORUM,"LOCAL_DURABLE_ASYNC",
            false,true),"MISMATCH");
        denied(()->DurableWalAckPolicyBinding.requireAck(
            DurableWalAckPolicy.LOCAL_DURABLE_ASYNC,"LOCAL_DURABLE_ASYNC",
            false,false),"MISMATCH");
    }
}
