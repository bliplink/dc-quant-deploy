package com.app.common.replication;

import java.io.IOException;
import org.junit.Test;
import static org.junit.Assert.*;

public class DurableWalAckPolicyTest {
    interface Checked { void run() throws Exception; }
    private static void denied(Checked job, String expected) throws Exception {
        try {job.run();fail("unsafe ACK policy action accepted");}
        catch(IOException | IllegalArgumentException exception) {
            assertTrue(String.valueOf(exception.getMessage()),
                exception.getMessage().contains(expected));
        }
    }

    @Test public void exactlyTwoUnambiguousPolicies() throws Exception {
        assertEquals(DurableWalAckPolicy.STRICT_QUORUM,
            DurableWalAckPolicy.parse("STRICT_QUORUM"));
        assertEquals(DurableWalAckPolicy.LOCAL_DURABLE_ASYNC,
            DurableWalAckPolicy.parse("LOCAL_DURABLE_ASYNC"));
        denied(()->DurableWalAckPolicy.parse("SYNC"),"UNKNOWN");
        denied(()->DurableWalAckPolicy.parse("STRICT_QUORUM "),"UNKNOWN");
        denied(()->DurableWalAckPolicy.parse(null),"required");
        denied(()->DurableWalAckPolicy.parse("AUTO_DEGRADED_LOCAL_DURABLE"),"UNKNOWN");
    }

    @Test public void strictNeverConfusesLocalOrSoloWithQuorum() throws Exception {
        DurableWalAckPolicy p=DurableWalAckPolicy.STRICT_QUORUM;
        p.requireAckEvidence("QUORUM_DURABLE",true,false);
        denied(()->p.requireAckEvidence("LOCAL_DURABLE_ASYNC",false,true),"MISMATCH");
        denied(()->p.requireAckEvidence("AUTO_DEGRADED_LOCAL_DURABLE",false,true),"MISMATCH");
        denied(()->p.requireAckEvidence("QUORUM_DURABLE",false,false),"MISMATCH");
        denied(()->p.requireAckEvidence("QUORUM_DURABLE",true,true),"MISMATCH");
    }

    @Test public void localDurableNeverPromisedRpoZero() throws Exception {
        DurableWalAckPolicy p=DurableWalAckPolicy.LOCAL_DURABLE_ASYNC;
        p.requireAckEvidence("LOCAL_DURABLE_ASYNC",false,true);
        denied(()->p.requireAckEvidence("QUORUM_DURABLE",true,false),"MISMATCH");
        denied(()->p.requireAckEvidence("LOCAL_DURABLE_ASYNC",false,false),"MISMATCH");
        denied(()->p.requireAckEvidence("LOCAL_DURABLE_ASYNC",true,true),"MISMATCH");
    }

    @Test public void changingPolicyRequiresAuthenticatedHigherEpoch() throws Exception {
        DurableWalAckPolicy strict=DurableWalAckPolicy.STRICT_QUORUM;
        DurableWalAckPolicy local=DurableWalAckPolicy.LOCAL_DURABLE_ASYNC;
        strict.requirePinned("STRICT_QUORUM");
        local.requirePinned("LOCAL_DURABLE_ASYNC");
        denied(()->strict.requirePinned("LOCAL_DURABLE_ASYNC"),"CUTOVER");
        denied(()->local.requirePinned("STRICT_QUORUM"),"CUTOVER");
        denied(()->strict.requirePinned(null),"CUTOVER");
        strict.requireSameWriterEpoch(strict,3,3);
        denied(()->strict.requireSameWriterEpoch(strict,3,2),"FENCED");
        denied(()->strict.requireSameWriterEpoch(local,3,3),"FENCED");
        denied(()->strict.requireSameWriterEpoch(strict,0,0),"FENCED");
    }
}
