package com.app.common.replication;

import java.io.IOException;
import java.util.Objects;

/**
 * Business-neutral durable ACK policy pin, shared by Order/Trade/MD adapters.
 *
 * A Store must implement an atomic create-if-absent operation (e.g. ZooKeeper
 * persistent CREATE, never SET). A client may read a stable policy only after
 * the partition has its independent fencing/epoch grant. No runtime
 * policy switch is authorized by this class.
 */
public final class DurableWalAckPolicyBinding {
    public interface Store {
        /** Returns null if no policy has ever been committed. */
        String read() throws Exception;
        /** Must never overwrite an existing policy. Atomic on collisions. */
        void createIfAbsent(String mode) throws Exception;
    }

    private DurableWalAckPolicyBinding() {}

    /** For new partitions only; concurrent bootstraps MUST never silently
     * override a policy chosen by another legitimate participant. */
    public static void bootstrap(Store store, DurableWalAckPolicy selected)
            throws Exception {
        Objects.requireNonNull(store,"policy store");
        Objects.requireNonNull(selected,"ACK policy");
        if(store.read()==null)store.createIfAbsent(selected.name());
        requirePinned(store,selected);
    }

    /** Fail closed on missing, stale or conflicting policy during join. */
    public static void requirePinned(Store store, DurableWalAckPolicy selected)
            throws Exception {
        Objects.requireNonNull(store,"policy store");
        Objects.requireNonNull(selected,"ACK policy");
        String installed=store.read();
        if(installed==null)installed="MISSING";
        selected.requirePinned(installed);
    }

    /** Must be enforced on client ACK path AFTER the real durability gate.
     * Never infer quorum from an asynchronous replication transport flag. */
    public static void requireAck(DurableWalAckPolicy selected,
            String actualDurabilityMode, boolean quorum, boolean rpoRisk)
            throws IOException {
        if(selected==null)throw new IOException("ACK_POLICY_NOT_CONFIGURED");
        selected.requireAckEvidence(actualDurabilityMode,quorum,rpoRisk);
    }
}
