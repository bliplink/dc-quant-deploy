package com.app.common.replication;

import java.io.IOException;

/**
 * Business-neutral client acknowledgement contract for replicated WAL.
 *
 * This is not a replication transport switch. A quorum ACK can only be
 * issued after the real WAL/CommitIndex/Custody quorum gates succeeded;
 * local durable ACK knowingly permits RPO > 0.
 *
 * Policy is immutable for an installed writer epoch. Migration requires
 * externally verified revocation and an atomic, higher-epoch install.
 */
public enum DurableWalAckPolicy {
    STRICT_QUORUM("QUORUM_DURABLE", true, false),
    LOCAL_DURABLE_ASYNC("LOCAL_DURABLE_ASYNC", false, true);

    public final String ackDurabilityMode;
    public final boolean quorumDurable;
    public final boolean possibleDataLossIfPrimaryPermanentlyLost;

    DurableWalAckPolicy(String mode, boolean quorum, boolean risk) {
        this.ackDurabilityMode=mode;
        this.quorumDurable=quorum;
        this.possibleDataLossIfPrimaryPermanentlyLost=risk;
    }

    /** Deliberately does not accept aliases, whitespace, or a third policy. */
    public static DurableWalAckPolicy parse(String raw) {
        if(raw==null)throw new IllegalArgumentException("ACK policy required");
        for(DurableWalAckPolicy policy:values())
            if(policy.name().equals(raw))return policy;
        throw new IllegalArgumentException("ACK_POLICY_UNKNOWN: "+raw);
    }

    /** Fail closed on a stored policy change, including a restart with
     * stale configuration. Never infer mode from replica availability. */
    public void requirePinned(String onDiskOrZk) throws IOException {
        if(!name().equals(onDiskOrZk))
            throw new IOException("ACK_POLICY_CHANGE_REQUIRES_AUTHORIZED_EPOCH_CUTOVER: configured="
                    +name()+" stored="+onDiskOrZk);
    }

    /** Called AFTER the underlying durability gate. Exact response
     * classification prevents a caller from relabeling a local ACK quorum. */
    public void requireAckEvidence(String actualMode, boolean hasQuorum,
            boolean possibleLoss) throws IOException {
        if(!ackDurabilityMode.equals(actualMode)
                || quorumDurable!=hasQuorum
                || possibleDataLossIfPrimaryPermanentlyLost!=possibleLoss)
            throw new IOException("ACK_POLICY_EVIDENCE_MISMATCH: selected="+name()
                    +" actual="+actualMode+" quorum="+hasQuorum+" rpoRisk="+possibleLoss);
    }

    /** A caller cannot weaken an already installed epoch in-place.
     * No authorization to change epochs or grant new writers is provided. */
    public void requireSameWriterEpoch(DurableWalAckPolicy active,
            long installedEpoch, long requestEpoch) throws IOException {
        if(active!=this || installedEpoch<=0 || installedEpoch!=requestEpoch)
            throw new IOException("ACK_POLICY_EPOCH_FENCED");
    }
}
