package com.app.common.partition;

import java.util.HashMap;
import java.util.Map;

import org.apache.zookeeper.CreateMode;
import org.junit.Assert;
import org.junit.Test;

public class ZkPartitionFailoverControlPlaneTest {
    @Test
    public void leaseIsExclusiveAndOwnershipIsRechecked() {
        FakeOps ops = new FakeOps();
        ops.connected = true;
        ops.values.put("/dc", value("", 0));
        ops.values.put("/dc/cluster", value("", 0));

        ZkPartitionFailoverControlPlane plane = plane(ops);
        Assert.assertTrue(plane.tryAcquireLease());
        Assert.assertTrue(plane.hasLease());
        Assert.assertTrue(ops.values.get("/dc/cluster/controller-lease").data
                .startsWith("controller-1#"));

        ops.values.put("/dc/cluster/controller-lease", value("controller-2", 1));
        Assert.assertFalse(plane.hasLease());
    }

    @Test
    public void sameLogicalOwnerIdOnAnotherControllerCannotStealLease() {
        FakeOps ops = new FakeOps();
        ops.connected = true;
        ZkPartitionFailoverControlPlane first = plane(ops);
        ZkPartitionFailoverControlPlane contender = plane(ops);
        Assert.assertTrue(first.tryAcquireLease());
        String token = ops.values.get("/dc/cluster/controller-lease").data;
        Assert.assertFalse("same owner string must not confer ZK authority",
                contender.tryAcquireLease());
        Assert.assertFalse(contender.hasLease());
        contender.close();
        // FakeOps represents a shared ZK server and tracks connected as one
        // Boolean; restoring that flag models the independent first session.
        ops.connected = true;
        Assert.assertEquals("nonowner close must not delete original lease",
                token, ops.values.get("/dc/cluster/controller-lease").data);
        Assert.assertTrue(first.hasLease());
    }

    @Test
    public void expiredSessionCannotMistakeReusedOwnerIdForOldLease() {
        FakeOps ops = new FakeOps();
        ops.connected = true;
        ZkPartitionFailoverControlPlane old = plane(ops);
        Assert.assertTrue(old.tryAcquireLease());
        String oldToken = ops.values.get("/dc/cluster/controller-lease").data;
        // Simulate ephemeral disappearance and new controller with the same
        // logical ownerId connecting under a distinct ZooKeeper session.
        ops.values.remove("/dc/cluster/controller-lease");
        ZkPartitionFailoverControlPlane replacement = plane(ops);
        Assert.assertTrue(replacement.tryAcquireLease());
        String newToken = ops.values.get("/dc/cluster/controller-lease").data;
        Assert.assertNotEquals(oldToken, newToken);
        Assert.assertFalse("old session is fenced despite matching ownerId",
                old.hasLease());
        Assert.assertFalse(old.tryAcquireLease());
        ops.values.remove("/dc/cluster/controller-lease");
        Assert.assertFalse("revoked old controller must never reacquire an empty lease",
                old.tryAcquireLease());
        ops.values.put("/dc/cluster/controller-lease", value(newToken, 0));
        old.close();
        // Simulated replacement has its own connection, unlike shared FakeOps.
        ops.connected = true;
        Assert.assertEquals("stale owner cannot delete replacement lease",
                newToken, ops.values.get("/dc/cluster/controller-lease").data);
        Assert.assertTrue(replacement.hasLease());
    }

    @Test
    public void disconnectedControllerMustUseFreshEpochAuthorityAfterReconnect() {
        FakeOps ops = new FakeOps();
        ops.connected = true;
        ZkPartitionFailoverControlPlane stale = plane(ops);
        Assert.assertTrue(stale.tryAcquireLease());
        ops.connected = false;
        Assert.assertFalse(stale.hasLease());
        ops.connected = true;
        ops.values.remove("/dc/cluster/controller-lease");
        Assert.assertFalse("lost controller must never reacquire its old lease",
                stale.tryAcquireLease());
        ZkPartitionFailoverControlPlane replacement = plane(ops);
        Assert.assertTrue(replacement.tryAcquireLease());
        Assert.assertFalse(stale.hasLease());
        Assert.assertTrue(replacement.hasLease());
    }

    @Test
    public void membershipUsesEphemeralServiceRegistrationPath() {
        FakeOps ops = new FakeOps();
        ops.connected = true;
        ops.values.put("/MDTService/OrderSvrB/OrderSvrB", value("Host:127.0.0.1", 0));
        ZkPartitionFailoverControlPlane plane = plane(ops);

        Assert.assertTrue(plane.isLive("SERVER.OrderSvrB"));
        Assert.assertFalse(plane.isLive("OrderSvrA"));
    }

    @Test
    public void assignmentCasPreservesUnknownFieldsAndHonorsVersion() {
        FakeOps ops = new FakeOps();
        ops.connected = true;
        String path = "/dc/cluster/ordersvr-dev/partitions/P027";
        ops.values.put(path, value("{"
                + "\"partitionId\":\"P027\",\"epoch\":8,\"assignmentVersion\":4,"
                + "\"primary\":\"OrderSvrA\",\"replica\":\"OrderSvrB\","
                + "\"replicas\":[\"OrderSvrB\",\"OrderSvrC\"],\"learners\":[],"
                + "\"state\":\"READY\",\"futureField\":\"keep\"}", 12));
        ZkPartitionFailoverControlPlane plane = plane(ops);

        PartitionFailoverController.VersionedAssignment read = plane.read("P027");
        Assert.assertEquals(12, read.getVersion());
        PartitionAssignment updated = PartitionFailoverController.buildFailoverAssignment(
                read.getAssignment(), "OrderSvrB",
                java.util.Arrays.asList("OrderSvrB", "OrderSvrC"));

        Assert.assertFalse(plane.compareAndSet("P027", 11, updated));
        Assert.assertTrue(plane.compareAndSet("P027", 12, updated));
        Assert.assertTrue(ops.values.get(path).data.contains("\"futureField\":\"keep\""));
        Assert.assertTrue(ops.values.get(path).data.contains("\"primary\":\"OrderSvrB\""));
        Assert.assertEquals(13, ops.values.get(path).version);
    }

    @Test
    public void listsPartitionsAndInstallsMembershipWatchers() {
        FakeOps ops = new FakeOps();
        ops.connected = true;
        ops.values.put("/dc/cluster/ordersvr-dev/partitions/P027", value("{}", 1));
        ops.values.put("/dc/cluster/ordersvr-dev/partitions/P132", value("{}", 1));
        ops.values.put("/dc/cluster/ordersvr-dev/partitions/not-a-partition", value("{}", 1));
        ops.values.put("/MDTService/OrderSvrA", value("", 0));
        ops.values.put("/MDTService/OrderSvrB", value("", 0));
        ZkPartitionFailoverControlPlane plane = plane(ops);

        Assert.assertEquals(java.util.Arrays.asList("P027", "P132"), plane.listPartitionIds());
        final java.util.concurrent.atomic.AtomicInteger changes = new java.util.concurrent.atomic.AtomicInteger();
        plane.watchMembershipNodes(java.util.Arrays.asList("OrderSvrA", "OrderSvrB"), changes::incrementAndGet);

        ops.fire("/MDTService/OrderSvrA");
        Assert.assertEquals(1, changes.get());
        Assert.assertEquals(2, ops.watchers.size());
    }

    @Test
    public void closeReleasesOwnedLeaseBeforeClosingOps() {
        FakeOps ops = new FakeOps();
        ops.connected = true;
        ops.values.put("/dc", value("", 0));
        ops.values.put("/dc/cluster", value("", 0));
        ZkPartitionFailoverControlPlane plane = plane(ops);

        Assert.assertTrue(plane.tryAcquireLease());
        Assert.assertTrue(ops.values.containsKey("/dc/cluster/controller-lease"));

        plane.close();

        Assert.assertFalse(ops.values.containsKey("/dc/cluster/controller-lease"));
        Assert.assertTrue(ops.closed);
    }

    @Test
    public void disconnectedPlaneFailsClosed() {
        FakeOps ops = new FakeOps();
        ZkPartitionFailoverControlPlane plane = plane(ops);
        Assert.assertFalse(plane.tryAcquireLease());
        Assert.assertFalse(plane.hasLease());
        Assert.assertFalse(plane.isLive("OrderSvrA"));
    }

    private static ZkPartitionFailoverControlPlane plane(FakeOps ops) {
        return new ZkPartitionFailoverControlPlane(ops,
                "/dc/cluster/ordersvr-dev/partitions",
                "/MDTService",
                "/dc/cluster/controller-lease",
                "controller-1");
    }

    private static ZkPartitionFailoverControlPlane.Value value(String data, int version) {
        return new ZkPartitionFailoverControlPlane.Value(data, version);
    }

    private static final class FakeOps implements ZkPartitionFailoverControlPlane.Ops {
        boolean connected;
        boolean closed;
        final Map<String, ZkPartitionFailoverControlPlane.Value> values =
                new HashMap<String, ZkPartitionFailoverControlPlane.Value>();

        @Override public boolean isConnected() { return connected; }
        @Override public boolean exists(String path) { return values.containsKey(path); }
        @Override public ZkPartitionFailoverControlPlane.Value read(String path) { return values.get(path); }

        final Map<String, Runnable> watchers = new HashMap<String, Runnable>();

        @Override
        public java.util.List<String> children(String path) {
            java.util.Set<String> children = new java.util.TreeSet<String>();
            String prefix = path.endsWith("/") ? path : path + "/";
            for (String candidate : values.keySet()) {
                if (!candidate.startsWith(prefix)) continue;
                String rest = candidate.substring(prefix.length());
                int slash = rest.indexOf('/');
                children.add(slash < 0 ? rest : rest.substring(0, slash));
            }
            return new java.util.ArrayList<String>(children);
        }

        @Override
        public void watchChildren(String path, Runnable listener) {
            watchers.put(path, listener);
        }

        void fire(String path) {
            Runnable listener = watchers.get(path);
            if (listener != null) listener.run();
        }

        @Override
        public boolean create(String path, String data, CreateMode mode) {
            if (values.containsKey(path)) return false;
            values.put(path, value(data, 0));
            return true;
        }

        @Override
        public boolean compareAndSet(String path, int expectedVersion, String data) {
            ZkPartitionFailoverControlPlane.Value current = values.get(path);
            if (current == null || current.version != expectedVersion) return false;
            values.put(path, value(data, expectedVersion + 1));
            return true;
        }

        @Override
        public boolean delete(String path) {
            return values.remove(path) != null;
        }

        @Override public void close() { closed = true; connected = false; }
    }
}
