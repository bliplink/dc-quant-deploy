package com.app.common.partition;

import java.util.ArrayList;
import java.util.List;
import java.util.Collections;

import org.I0Itec.zkclient.exception.ZkBadVersionException;
import org.I0Itec.zkclient.exception.ZkNodeExistsException;
import org.I0Itec.zkclient.IZkChildListener;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.data.Stat;

import com.app.common.zk.ZookeeperClient;

/**
 * ZooKeeper-backed persistent control plane for {@link PartitionFailoverController}.
 *
 * <p>The instance owns its ZooKeeper client. Closing it relinquishes the
 * ephemeral controller lease and invalidates all failover authority.</p>
 */
public final class ZkPartitionFailoverControlPlane implements
        PartitionFailoverController.Guard,
        PartitionFailoverController.Membership,
        PartitionFailoverController.AssignmentStore,
        AutoCloseable {

    interface Ops {
        boolean isConnected();
        boolean exists(String path);
        Value read(String path);
        boolean create(String path, String data, CreateMode mode);
        boolean compareAndSet(String path, int expectedVersion, String data);
        default boolean delete(String path) { return false; }
        List<String> children(String path);
        void watchChildren(String path, Runnable listener);
        void close();
    }

    static final class Value {
        final String data;
        final int version;
        Value(String data, int version) {
            this.data = data;
            this.version = version;
        }
    }

    private static final class ClientOps implements Ops {
        private final ZookeeperClient client;
        private final boolean closeClient;

        ClientOps(ZookeeperClient client) {
            this(client, true);
        }

        ClientOps(ZookeeperClient client, boolean closeClient) {
            if (client == null) throw new IllegalArgumentException("ZooKeeper client is required");
            this.client = client;
            this.closeClient = closeClient;
        }

        @Override public boolean isConnected() { return client.isConnected(); }
        @Override public boolean exists(String path) { return client.exists(path); }

        @Override
        public List<String> children(String path) {
            try {
                List<String> children = client.getChildren(path);
                return children == null ? Collections.<String>emptyList() : children;
            } catch (RuntimeException missingOrDisconnected) {
                return Collections.emptyList();
            }
        }

        @Override
        public void watchChildren(String path, final Runnable listener) {
            client.subscribeChildChanges(path, new IZkChildListener() {
                @Override
                public void handleChildChange(String parentPath, List<String> currentChilds) throws Exception {
                    listener.run();
                }
            });
        }

        @Override
        public Value read(String path) {
            try {
                Stat stat = new Stat();
                Object data = client.readData(path, stat);
                return new Value(data == null ? "" : String.valueOf(data), stat.getVersion());
            } catch (RuntimeException missingOrDisconnected) {
                return null;
            }
        }

        @Override
        public boolean create(String path, String data, CreateMode mode) {
            try {
                client.create(path, data, mode);
                return true;
            } catch (ZkNodeExistsException exists) {
                return false;
            }
        }

        @Override
        public boolean compareAndSet(String path, int expectedVersion, String data) {
            try {
                client.writeDataReturnStat(path, data, expectedVersion);
                return true;
            } catch (ZkBadVersionException conflict) {
                return false;
            }
        }

        @Override
        public boolean delete(String path) {
            return client.delete(path);
        }

        @Override
        public void close() {
            if (closeClient) client.close();
        }
    }

    private final Ops ops;
    private final String assignmentRoot;
    private final String membershipRoot;
    private final String leasePath;
    private final String ownerId;
    /** Unpredictable per-control-plane-instance lease token. A reused logical
     * ownerId MUST NOT impersonate a new ZooKeeper session or controller. */
    private final String leaseToken;
    private volatile boolean leaseCreatedByThisInstance;
    /** A lost ZK session/lease permanently revokes this controller object.
     * Caller must construct a fresh controller and revalidate the source epoch. */
    private volatile boolean leaseRevoked;
    private volatile boolean closed;

    public ZkPartitionFailoverControlPlane(String hosts, String username, String password,
            String assignmentRoot, String membershipRoot, String leasePath, String ownerId) {
        this(new ClientOps(new ZookeeperClient(hosts, username, password)),
                assignmentRoot, membershipRoot, leasePath, ownerId);
    }

    /**
     * Borrows an already-established ZooKeeper session. Closing this control
     * plane does not close the supplied client.
     */
    public ZkPartitionFailoverControlPlane(ZookeeperClient client,
            String assignmentRoot, String membershipRoot, String leasePath, String ownerId) {
        this(new ClientOps(client, false), assignmentRoot, membershipRoot, leasePath, ownerId);
    }

    ZkPartitionFailoverControlPlane(Ops ops, String assignmentRoot, String membershipRoot,
            String leasePath, String ownerId) {
        if (ops == null) throw new IllegalArgumentException("ZooKeeper ops are required");
        this.assignmentRoot = path(assignmentRoot, "assignmentRoot");
        this.membershipRoot = path(membershipRoot, "membershipRoot");
        this.leasePath = path(leasePath, "leasePath");
        if (blank(ownerId)) throw new IllegalArgumentException("ownerId is required");
        this.ownerId = ownerId.trim();
        this.leaseToken = this.ownerId + "#" + java.util.UUID.randomUUID().toString();
        this.ops = ops;
    }

    /** Acquire or confirm the ephemeral controller lease. */
    public boolean tryAcquireLease() {
        if (leaseRevoked) return false;
        if (!isConnected()) {
            if (leaseCreatedByThisInstance) leaseRevoked = true;
            return false;
        }
        ensurePersistentParents(leasePath);
        Value existing = ops.read(leasePath);
        if (leaseCreatedByThisInstance) {
            if (existing == null || !leaseToken.equals(existing.data)) {
                leaseRevoked = true;
                return false;
            }
            return true;
        }
        if (existing != null) return false;
        boolean createdByUs = ops.create(leasePath, leaseToken, CreateMode.EPHEMERAL);
        if (!createdByUs) return false;
        leaseCreatedByThisInstance = true;
        Value current = ops.read(leasePath);
        if (current == null || !leaseToken.equals(current.data)) {
            leaseRevoked = true;
            return false;
        }
        return true;
    }

    @Override
    public boolean isConnected() {
        return !closed && ops.isConnected();
    }

    @Override
    public boolean hasLease() {
        if (leaseRevoked || !leaseCreatedByThisInstance) return false;
        if (!isConnected()) {
            leaseRevoked = true;
            return false;
        }
        Value current = ops.read(leasePath);
        if (current == null || !leaseToken.equals(current.data)) {
            leaseRevoked = true;
            return false;
        }
        return true;
    }

    @Override
    public boolean isLive(String node) {
        if (!isConnected() || blank(node)) return false;
        String normalized = PartitionConfig.normalizeServerName(node);
        if (blank(normalized)) return false;
        String service = normalized.trim();
        return ops.exists(membershipRoot + "/" + service + "/" + service);
    }

    @Override
    public PartitionFailoverController.VersionedAssignment read(String partitionId) {
        String normalized = partitionId(partitionId);
        Value value = ops.read(assignmentRoot + "/" + normalized);
        if (value == null) return null;
        PartitionAssignment assignment = PartitionAssignmentCodec.decode(value.data, normalized);
        if (assignment == null) return null;
        return new PartitionFailoverController.VersionedAssignment(assignment, value.version);
    }

    @Override
    public boolean compareAndSet(String partitionId, int expectedVersion, PartitionAssignment updated) {
        String normalized = partitionId(partitionId);
        if (updated == null || !normalized.equals(updated.getPartitionId())) {
            throw new IllegalArgumentException("updated assignment partition mismatch");
        }
        PartitionAssignmentValidator.requireValid(updated);
        String zkPath = assignmentRoot + "/" + normalized;
        Value current = ops.read(zkPath);
        if (current == null || current.version != expectedVersion) return false;
        String merged = PartitionAssignmentCodec.merge(current.data, updated);
        return ops.compareAndSet(zkPath, expectedVersion, merged);
    }

    public List<String> listPartitionIds() {
        if (!isConnected()) return Collections.emptyList();
        List<String> result = new ArrayList<String>();
        for (String child : ops.children(assignmentRoot)) {
            try { result.add(partitionId(child)); }
            catch (IllegalArgumentException ignored) { }
        }
        Collections.sort(result);
        return Collections.unmodifiableList(result);
    }

    public void watchMembershipNodes(List<String> nodes, Runnable listener) {
        if (nodes == null || listener == null) throw new IllegalArgumentException("nodes and listener are required");
        for (String node : nodes) {
            if (blank(node)) continue;
            String service = PartitionConfig.normalizeServerName(node).trim();
            String path = membershipRoot + "/" + service;
            if (ops.exists(path)) ops.watchChildren(path, listener);
        }
    }

    public void watchAssignmentChildren(Runnable listener) {
        if (listener == null) throw new IllegalArgumentException("listener is required");
        if (ops.exists(assignmentRoot)) ops.watchChildren(assignmentRoot, listener);
    }

    @Override
    public void close() {
        if (closed) return;
        try {
            if (ops.isConnected()) {
                Value current = ops.read(leasePath);
                if (leaseCreatedByThisInstance && !leaseRevoked && current != null
                        && leaseToken.equals(current.data)) {
                    ops.delete(leasePath);
                }
            }
        } finally {
            closed = true;
            ops.close();
        }
    }

    private void ensurePersistentParents(String leafPath) {
        int lastSlash = leafPath.lastIndexOf('/');
        if (lastSlash <= 0) return;
        String parent = leafPath.substring(0, lastSlash);
        String[] parts = parent.split("/");
        String current = "";
        for (String part : parts) {
            if (blank(part)) continue;
            current += "/" + part;
            if (!ops.exists(current)) ops.create(current, "", CreateMode.PERSISTENT);
        }
    }

    private static String partitionId(String value) {
        if (value == null) throw new IllegalArgumentException("partitionId is required");
        String normalized = value.trim();
        if (!normalized.matches("P\\d{3,10}") && !PlacementPartitionId.isNamespaced(normalized)) {
            throw new IllegalArgumentException("invalid partitionId: " + value);
        }
        return normalized;
    }

    private static String path(String value, String name) {
        if (blank(value) || !value.startsWith("/") || value.contains("//")
                || value.contains("..") || (value.length() > 1 && value.endsWith("/"))) {
            throw new IllegalArgumentException(name + " must be an absolute ZooKeeper path");
        }
        return value;
    }

    private static boolean blank(String value) {
        return value == null || value.trim().isEmpty();
    }
}
