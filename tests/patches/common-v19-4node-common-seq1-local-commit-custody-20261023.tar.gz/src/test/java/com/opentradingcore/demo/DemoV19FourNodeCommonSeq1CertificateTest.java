package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;
import com.app.common.replication.DurableWalCommitQuorum;
import com.app.common.replication.DurableWalCommitIndex;
import com.app.common.replication.DurableWalCertificateCustody;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import java.io.IOException;
import java.nio.file.*;
import java.security.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import static org.junit.Assert.*;

/**
 * Isolated WAL unit integration, NOT a broker order or READY grant.
 * It verifies real Common seq=1 RSA CommitIndex and two independent
 * DurableWalCertificateCustody stores over two physical fsynced WAL files.
 * Host names are SIMULATED for this test only; do not mistake for independent
 * physical fault domains.
 */
public class DemoV19FourNodeCommonSeq1CertificateTest {
    @Rule public TemporaryFolder temp=new TemporaryFolder();

    private static KeyPair newIdentity() throws Exception {
        KeyPairGenerator gen=KeyPairGenerator.getInstance("RSA");gen.initialize(2048);
        return gen.generateKeyPair();
    }
    private static class Pair implements AutoCloseable {
        final PartitionAssignment assignment;
        final KeyPair leftKey,rightKey;
        final DemoDurableJournal left,right;
        final Path leftPath,rightPath;
        final DurableWalCommitQuorum.Membership membership;
        final AtomicBoolean authorized=new AtomicBoolean(true);
        final String commandId;
        Pair(Path root,PartitionAssignment a)throws Exception{
            assignment=a;
            leftPath=root.resolve("first");rightPath=root.resolve("second");
            Files.createDirectories(leftPath);Files.createDirectories(rightPath);
            leftKey=newIdentity();rightKey=newIdentity();
            left=new DemoDurableJournal(leftPath.resolve(a.getPartitionId()+".wal"));
            right=new DemoDurableJournal(rightPath.resolve(a.getPartitionId()+".wal"));
            String sha=DemoV19FourNodeGenesisPreflight.exactAssignmentDigest(a);
            left.installEmptyGenesis(1,a.getPartitionId(),sha);
            right.installEmptyGenesis(1,a.getPartitionId(),sha);
            membership=new DurableWalCommitQuorum.Membership(
                "CommonHaDemo",a.getPartitionId(),a.getPrimary(),1,1,
                Arrays.asList(
                    new DurableWalCommitQuorum.Member(a.getPrimary(),
                        "simulated-host-primary",leftKey.getPublic()),
                    new DurableWalCommitQuorum.Member(a.getReplica(),
                        "simulated-host-replica",rightKey.getPublic())));
            commandId="isolated-fsynced-seq1-"+a.getPartitionId();
        }
        void appendBoth()throws Exception{
            left.prepareAndCommitSingleForce(1,1,
                new DemoStateMachine.Operation(commandId,5));
            right.prepareAndCommitSingleForce(1,1,
                new DemoStateMachine.Operation(commandId,5));
            assertEquals(left.committedPrefixSha256(),right.committedPrefixSha256());
        }
        DurableWalCommitQuorum.LocalDurability forced(DemoDurableJournal wal){
            return (epoch,seq)->{
                if(!authorized.get() || epoch!=1 || seq!=1 ||
                    !wal.isReadyForWrites() || wal.committedSeq()!=1 ||
                    wal.lastEpoch()!=1 ||
                    !wal.hasPhysicalGenesis(1,assignment.getPartitionId(),
                        DemoV19FourNodeGenesisPreflight.exactAssignmentDigest(assignment)))
                    throw new IOException("fenced or missing exact durable seq1");
                return wal.committedPrefixSha256Through(seq);
            };
        }
        DurableWalCommitQuorum.Receipt leftVote()throws Exception{
            return DurableWalCommitQuorum.sign(membership,assignment.getPrimary(),1,
                forced(left),leftKey.getPrivate());
        }
        DurableWalCommitQuorum.Receipt rightVote()throws Exception{
            return DurableWalCommitQuorum.sign(membership,assignment.getReplica(),1,
                forced(right),rightKey.getPrivate());
        }
        DurableWalCommitQuorum.Certificate index()throws Exception{
            try(DurableWalCommitIndex index=new DurableWalCommitIndex(
                leftPath.resolve(".strict-commit-index"),membership)){
                return index.certifyAndPersist(1,left.committedPrefixSha256(),
                    Arrays.asList(leftVote(),rightVote()));
            }
        }
        void custody(DurableWalCommitQuorum.Certificate cert)throws Exception{
            DurableWalCertificateCustody.Authority token=old->{
                if(!authorized.get() || !old.digest.equals(membership.digest))
                    throw new IOException("old epoch no longer allowed");
            };
            try(DurableWalCertificateCustody a=new DurableWalCertificateCustody(
                    leftPath.resolve(".custody"),membership,forced(left),token);
                DurableWalCertificateCustody b=new DurableWalCertificateCustody(
                    rightPath.resolve(".custody"),membership,forced(right),token)){
                assertEquals(1,a.install(cert));
                assertEquals(1,b.install(cert));
                assertEquals(cert.commitPrefixSha256,a.highestVerified().commitPrefixSha256);
                assertEquals(cert.commitPrefixSha256,b.highestVerified().commitPrefixSha256);
                assertEquals(1,a.signInstalled(assignment.getPrimary(),
                    leftKey.getPrivate()).sequence);
                assertEquals(1,b.signInstalled(assignment.getReplica(),
                    rightKey.getPrivate()).sequence);
            }
        }
        @Override public void close()throws Exception{left.close();right.close();}
    }

    @Test public void bothBuddyPairsUseRealCommonSeq1CertificateAndDoubleCustody()
            throws Exception {
        List<PartitionAssignment> all=DemoV19FourNodeShardCatalog.layout();
        for(char leader:new char[]{'A','C'}){
            String part=DemoV19FourNodeGenesisPreflight.firstShard(all,leader);
            PartitionAssignment a=all.get(Integer.parseInt(part.substring(1)));
            try(Pair pair=new Pair(temp.newFolder("pair-"+part).toPath(),a)){
                pair.appendBoth();
                DurableWalCommitQuorum.Certificate cert=pair.index();
                assertFalse("certificate must not grant READY",cert.authorizesReady());
                assertEquals(1,cert.committedSequence);
                assertEquals(2,cert.votes.size());
                pair.custody(cert);
                try(DurableWalCommitIndex reopened=new DurableWalCommitIndex(
                    pair.leftPath.resolve(".strict-commit-index"),pair.membership)){
                    assertEquals(1,reopened.committedSequence());
                    reopened.requireExactCertified(1,1,pair.left.committedPrefixSha256());
                }
                pair.custody(cert); // independent files reload + idempotent install
            }
        }
    }
    @Test public void physicalWalAndTwoCommonCustodiesSurviveJVMRestart()
            throws Exception {
        PartitionAssignment a=DemoV19FourNodeShardCatalog.layout().get(128);
        Path root=temp.newFolder("real-physical-replay").toPath();
        DurableWalCommitQuorum.Membership membership;
        String hash,commandId;
        try(Pair pair=new Pair(root,a)){
            pair.appendBoth();
            DurableWalCommitQuorum.Certificate cert=pair.index();
            pair.custody(cert);
            membership=pair.membership;
            hash=cert.commitPrefixSha256;
            commandId=pair.commandId;
        }
        // Both independent Java FileLocks released; a new JVM can now
        // acquire each WAL plus its own Common custody and commit ledger.
        Path one=root.resolve("first"),two=root.resolve("second");
        try(DemoDurableJournal left=new DemoDurableJournal(one.resolve("P128.wal"));
            DemoDurableJournal right=new DemoDurableJournal(two.resolve("P128.wal"));
            DurableWalCommitIndex index=new DurableWalCommitIndex(
                one.resolve(".strict-commit-index"),membership);
            DurableWalCertificateCustody lc=new DurableWalCertificateCustody(
                one.resolve(".custody"),membership,
                (epoch,seq)->left.committedPrefixSha256Through(seq),
                current->{if(!current.digest.equals(membership.digest))
                    throw new IOException("membership changed");});
            DurableWalCertificateCustody rc=new DurableWalCertificateCustody(
                two.resolve(".custody"),membership,
                (epoch,seq)->right.committedPrefixSha256Through(seq),
                current->{if(!current.digest.equals(membership.digest))
                    throw new IOException("membership changed");})) {
            assertEquals(1,index.committedSequence());
            index.requireExactCertified(1,1,hash);
            assertEquals(hash,left.committedPrefixSha256());
            assertEquals(hash,right.committedPrefixSha256());
            assertTrue(left.hasPhysicalGenesis(1,"P128",
                DemoV19FourNodeGenesisPreflight.exactAssignmentDigest(a)));
            assertTrue(right.hasPhysicalGenesis(1,"P128",
                DemoV19FourNodeGenesisPreflight.exactAssignmentDigest(a)));
            assertEquals(1,left.committedSeq());
            assertEquals(1,right.committedSeq());
            assertEquals(1,left.state().appliedCount(commandId));
            assertEquals(1,right.state().appliedCount(commandId));
            assertEquals(hash,lc.highestVerified().commitPrefixSha256);
            assertEquals(hash,rc.highestVerified().commitPrefixSha256);
            assertFalse(index.verifiedHighestCertificate().authorizesReady());
        }
    }

    @Test public void oneReplicaMissingOrForkedNeverYieldsQuorum()throws Exception{
        PartitionAssignment a=DemoV19FourNodeShardCatalog.layout().get(0);
        try(Pair pair=new Pair(temp.newFolder("no-replica").toPath(),a)){
            pair.left.prepareAndCommitSingleForce(1,1,
                new DemoStateMachine.Operation(pair.commandId,5));
            try(DurableWalCommitIndex index=new DurableWalCommitIndex(
                    pair.leftPath.resolve(".strict-commit-index"),pair.membership)){
                assertThrows(Exception.class,()->index.certifyAndPersist(1,
                    pair.left.committedPrefixSha256(),Collections.singletonList(pair.leftVote())));
                assertEquals(0,index.committedSequence());
            }
            pair.right.prepareAndCommitSingleForce(1,1,
                new DemoStateMachine.Operation(pair.commandId,99));
            assertThrows(Exception.class,pair::index);
        }
    }
    @Test public void revokedAuthorizationPreventsSignerAndCustody()throws Exception {
        PartitionAssignment a=DemoV19FourNodeShardCatalog.layout().get(128);
        try(Pair pair=new Pair(temp.newFolder("revoked").toPath(),a)){
            pair.appendBoth();
            DurableWalCommitQuorum.Certificate cert=pair.index();
            pair.authorized.set(false);
            assertThrows(Exception.class,pair::leftVote);
            assertThrows(Exception.class,()->pair.custody(cert));
        }
    }
}
