package com.opentradingcore.demo;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;
import java.util.Arrays;
import java.util.TreeMap;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.zip.CRC32;

/**
 * Physical two-record WAL for one isolated Demo partition.
 *
 * <p>PREPARE and COMMIT are individually forced to disk. An unmatched prepare
 * or malformed final frame is never truncated or accepted as committed. This
 * class does not supply replica proof; its caller must keep the partition NOT
 * READY until an independent, certified recovery transaction resolves it.</p>
 */
public final class DemoDurableJournal implements AutoCloseable {
    private static final int MAGIC = 0x44454d31;
    private static final int PREPARE = 1;
    private static final int COMMIT = 2;
    private static final int SNAPSHOT = 3;
    private static final int GENESIS = 4; // non-business fsynced empty-state marker
    private static final int HEADER = 32;
    private static final int MAX_PAYLOAD = 8192;
    private static final int MAX_SNAPSHOT = 8 * 1024 * 1024;

    public static final class DirtyTail {
        public final long committedSeq;
        public final long offset;
        public final long length;
        public final String sha256;
        public final long pendingSeq;
        public final String pendingRequestId;

        DirtyTail(long committedSeq, long offset, long length, String sha256,
                long pendingSeq, String pendingRequestId) {
            this.committedSeq = committedSeq;
            this.offset = offset;
            this.length = length;
            this.sha256 = sha256;
            this.pendingSeq = pendingSeq;
            this.pendingRequestId = pendingRequestId;
        }
    }

    public static final class CommittedRequest {
        public final long delta;
        public final long seq;
        CommittedRequest(long delta, long seq) { this.delta = delta; this.seq = seq; }
    }

    /** A committed post-snapshot frame pair, replayable after process restart. */
    public static final class CommittedRecord {
        public final long epoch;
        public final long seq;
        public final DemoStateMachine.Operation operation;
        CommittedRecord(long epoch, long seq, DemoStateMachine.Operation operation) {
            this.epoch = epoch;
            this.seq = seq;
            this.operation = operation;
        }
    }

    private final Path path;
    private final FileChannel channel;
    private final FileLock lock;
    private final DemoStateMachine state = new DemoStateMachine();
    private final Map<String, CommittedRequest> requests = new HashMap<String, CommittedRequest>();
    private final TreeMap<Long, CommittedRecord> replayableRecords =
            new TreeMap<Long, CommittedRecord>();
    private final TreeMap<Long, Long> committedEnds = new TreeMap<Long, Long>();
    private long committedSeq;
    private long committedEnd;
    private long snapshotEnd;
    private long snapshotSeq;
    private long lastEpoch;
    private String snapshotSourcePrefix;
    private String genesisPartition;
    private String genesisMembershipHash;
    private long pendingEpoch;
    private long pendingSeq;
    private byte[] pendingCommand;
    private long pendingOffset;
    private boolean poisoned;
    private boolean closed;

    public DemoDurableJournal(Path path) throws IOException {
        if (path == null) throw new IllegalArgumentException("journal path is required");
        this.path = path;
        channel = FileChannel.open(path, StandardOpenOption.CREATE, StandardOpenOption.READ,
                StandardOpenOption.WRITE);
        FileLock held = null;
        try {
            held = channel.tryLock();
            if (held == null) throw new IOException("journal already owned: " + path);
            lock = held;
            committedEnds.put(0L, 0L);
            replay();
        } catch (IOException | RuntimeException failure) {
            if (held != null) held.release();
            channel.close();
            throw failure;
        }
    }

    /** Pure metadata Genesis, with NO synthetic business request or ACK.
     * Physical force(true) precedes publication of the in-memory boundary.
     * Cluster control MUST separately prove ZK assignment authority and both
     * peers before invoking this API; the API alone NEVER grants READY.
     */
    public synchronized void installEmptyGenesis(long epoch,String partition,
            String assignmentSha256)throws IOException {
        if(epoch<=0 || partition==null || !partition.matches("P[0-9]{3}")
                || assignmentSha256==null || !assignmentSha256.matches("[0-9a-f]{64}"))
            throw new IllegalArgumentException("invalid genesis partition or membership");
        if(genesisPartition!=null){
            if(lastEpoch!=epoch || !partition.equals(genesisPartition)
                    || !assignmentSha256.equals(genesisMembershipHash) || !isReadyForWrites()
                    || committedSeq!=0)
                throw new IOException("conflicting or advanced durable Genesis");
            channel.force(true);
            return;
        }
        if(!isReadyForWrites() || committedSeq!=0 || lastEpoch!=0 || channel.size()!=0)
            throw new IOException("genesis requires an empty unmodified physical WAL");
        byte[] payload=emptyGenesisPayload(partition,assignmentSha256);
        // Any failure after a partial write poisons this journal; restart
        // detects the dirty frame and blocks READY rather than truncating.
        poisoned=true;
        append(GENESIS,epoch,0,payload);
        channel.force(true);
        genesisPartition=partition;
        genesisMembershipHash=assignmentSha256;
        committedEnd=channel.size();
        committedEnds.put(0L,committedEnd);
        lastEpoch=epoch;
        poisoned=false;
    }
    /** Genesis identity remains immutable after subsequent real business
     * commits. This check is not an authorization for any command or ACK.
     */
    public synchronized boolean hasPhysicalGenesis(long epoch,String partition,
            String assignmentSha256){
        return isReadyForWrites() && lastEpoch==epoch
                && partition!=null && partition.equals(genesisPartition)
                && assignmentSha256!=null
                && assignmentSha256.equals(genesisMembershipHash);
    }

    public synchronized boolean hasEmptyGenesis(long epoch,String partition,
            String assignmentSha256){
        return isReadyForWrites() && committedSeq==0 && lastEpoch==epoch
                && partition!=null && partition.equals(genesisPartition)
                && assignmentSha256!=null
                && assignmentSha256.equals(genesisMembershipHash);
    }
    private static byte[] emptyGenesisPayload(String partition,String sha)throws IOException{
        ByteArrayOutputStream bytes=new ByteArrayOutputStream(128);
        DataOutputStream writer=new DataOutputStream(bytes);
        writer.writeInt(1);writer.writeUTF(partition);writer.writeUTF(sha);
        writer.flush();return bytes.toByteArray();
    }
    private void replayGenesis(byte[] payload)throws IOException{
        DataInputStream read=new DataInputStream(new ByteArrayInputStream(payload));
        if(read.readInt()!=1)throw new IOException("unknown empty Genesis version");
        String partition=read.readUTF(),sha=read.readUTF();
        if(!partition.matches("P[0-9]{3}") || !sha.matches("[0-9a-f]{64}")
                || read.read()!=-1 || !Arrays.equals(payload,emptyGenesisPayload(partition,sha)))
            throw new IOException("invalid partition membership in Genesis");
        genesisPartition=partition;
        genesisMembershipHash=sha;
    }

    public synchronized boolean isReadyForWrites() {
        return !closed && !poisoned && pendingCommand == null;
    }
    public synchronized long committedSeq() { return committedSeq; }
    /** One-node fsync boundary for Common LOCAL_DURABLE_ASYNC ACK.
     * committedEnds is advanced ONLY AFTER FileChannel.force(true) (or
     * safely replayed complete frames at process restart). It is not a
     * replica quorum watermark. No historical SHA256 scan in the hot path.
     */
    public synchronized void requireForcedCommitted(long epoch,long sequence,
            String requestId,long delta) throws IOException {
        if(!isReadyForWrites() || epoch<=0 || lastEpoch!=epoch
                || sequence<=0 || sequence>committedSeq || requestId==null)
            throw new IOException("local WAL not clean, current, or committed");
        CommittedRequest record=requests.get(requestId);
        Long offset=committedEnds.get(sequence);
        if(record==null || record.seq!=sequence || record.delta!=delta
                || offset==null || offset.longValue()>committedEnd)
            throw new IOException("exact local forced WAL command not present");
    }

    public synchronized String committedPrefixSha256() throws IOException { return sha256(0, committedEnd); }
    public synchronized CommittedRecord committedRecord(long seq) {
        return replayableRecords.get(seq);
    }
    public synchronized long oldestReplayableSeq() { return snapshotSeq + 1; }
    public synchronized String committedPrefixSha256Through(long seq) throws IOException {
        Long end = committedEnds.get(seq);
        if (end == null) throw new IOException("sequence is outside active snapshot plus WAL tail: " + seq);
        return sha256(0, end);
    }
    public synchronized byte[] committedPrefixBytes() throws IOException {
        if (committedEnd > 16 * 1024 * 1024) throw new IOException("snapshot exceeds bounded transfer size");
        byte[] data = new byte[(int) committedEnd];
        readFully(ByteBuffer.wrap(data), 0);
        return data;
    }
    /**
     * A complete, independently replayable baseline. A caller may install it
     * only under the cluster-wide frozen writer gate and after every assigned
     * replica has certified the same committed boundary. This method performs
     * no deletion or live journal replacement.
     */
    public synchronized byte[] snapshotWalBytes() throws IOException {
        if (!isReadyForWrites() || committedSeq == 0) {
            throw new IOException("only a clean committed journal may be snapshotted");
        }
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        DataOutputStream output = new DataOutputStream(bytes);
        output.writeInt(1);
        output.writeLong(committedSeq);
        output.writeLong(lastEpoch);
        output.writeUTF(committedPrefixSha256());
        output.writeUTF(state.stateDigest());
        if (requests.size() > 1000000) throw new IOException("snapshot request index too large");
        output.writeInt(requests.size());
        TreeMap<Long, Map.Entry<String, CommittedRequest>> ordered =
                new TreeMap<Long, Map.Entry<String, CommittedRequest>>();
        for (Map.Entry<String, CommittedRequest> item : requests.entrySet()) {
            if (ordered.put(item.getValue().seq, item) != null) {
                throw new IOException("duplicate committed sequence in snapshot index");
            }
        }
        for (Map.Entry<Long, Map.Entry<String, CommittedRequest>> item : ordered.entrySet()) {
            byte[] id = item.getValue().getKey().getBytes(StandardCharsets.UTF_8);
            if (id.length == 0 || id.length > 4096) throw new IOException("invalid request ID in snapshot");
            output.writeLong(item.getKey());
            output.writeInt(id.length);
            output.write(id);
            output.writeLong(item.getValue().getValue().delta);
        }
        output.flush();
        byte[] payload = bytes.toByteArray();
        if (payload.length > MAX_SNAPSHOT) throw new IOException("snapshot exceeds bounded frame size");
        ByteBuffer frame = ByteBuffer.allocate(HEADER + payload.length);
        frame.putInt(MAGIC).putInt(SNAPSHOT).putLong(lastEpoch).putLong(committedSeq)
                .putInt(payload.length).putInt(checksum(SNAPSHOT, lastEpoch, committedSeq, payload))
                .put(payload).flip();
        return frame.array();
    }
    public synchronized Path path() { return path; }
    public synchronized long activeBytes() throws IOException { return channel.size(); }
    public synchronized long uncheckpointedBytes() throws IOException { return channel.size() - snapshotEnd; }
    public synchronized long snapshotSeq() { return snapshotSeq; }
    public synchronized String snapshotSourcePrefix() { return snapshotSourcePrefix; }
    public synchronized long lastEpoch() { return lastEpoch; }
    public synchronized DemoStateMachine state() { return state; }
    public synchronized CommittedRequest committedRequest(String requestId) { return requests.get(requestId); }
    public synchronized DemoStateMachine.Operation pendingOperation() {
        return pendingCommand == null || poisoned ? null
                : DemoStateMachine.Operation.decode(pendingCommand);
    }

    /** Compare logical committed history across different WAL checkpoint generations. */
    public synchronized boolean isCommittedPrefixOf(DemoDurableJournal candidate) {
        if (candidate == null || committedSeq > candidate.committedSeq) return false;
        for (Map.Entry<String, CommittedRequest> item : requests.entrySet()) {
            CommittedRequest other = candidate.requests.get(item.getKey());
            if (other == null || other.seq != item.getValue().seq
                    || other.delta != item.getValue().delta) return false;
        }
        return requests.size() == committedSeq;
    }

    /** First old committed request not present at the same sequence in a replacement history. */
    public synchronized long firstOrphanedSeq(DemoDurableJournal replacement) {
        long first = Long.MAX_VALUE;
        for (Map.Entry<String, CommittedRequest> item : requests.entrySet()) {
            CommittedRequest other = replacement.requests.get(item.getKey());
            if (other == null || other.seq != item.getValue().seq
                    || other.delta != item.getValue().delta) {
                first = Math.min(first, item.getValue().seq);
            }
        }
        return first == Long.MAX_VALUE ? -1L : first;
    }

    public synchronized long orphanedRequestCount(DemoDurableJournal replacement) {
        long count = 0;
        for (Map.Entry<String, CommittedRequest> item : requests.entrySet()) {
            CommittedRequest other = replacement.requests.get(item.getKey());
            if (other == null || other.seq != item.getValue().seq
                    || other.delta != item.getValue().delta) count++;
        }
        return count;
    }

    public synchronized DirtyTail dirtyTail() throws IOException {
        if (pendingCommand == null && !poisoned) return null;
        long start = pendingOffset;
        long length = channel.size() - start;
        String requestId = pendingCommand != null && !poisoned
                ? DemoStateMachine.Operation.decode(pendingCommand).requestId : null;
        return new DirtyTail(committedSeq, start, length, sha256(start, length),
                requestId == null ? -1 : pendingSeq, requestId);
    }

    public synchronized void prepare(long epoch, long seq, DemoStateMachine.Operation operation) throws IOException {
        if (operation != null && !closed && !poisoned && pendingCommand == null
                && committedSeq == seq && lastEpoch == epoch) {
            CommittedRequest prior = requests.get(operation.requestId);
            if (prior != null && prior.seq == seq && prior.delta == operation.delta) {
                channel.force(true);
                return;
            }
        }
        if (epoch <= 0 || epoch < lastEpoch || seq != committedSeq + 1 || operation == null) {
            throw new IllegalArgumentException("invalid epoch, sequence or operation");
        }
        byte[] command = operation.encode();
        if (!closed && !poisoned && pendingCommand != null && pendingEpoch == epoch
                && pendingSeq == seq && Arrays.equals(pendingCommand, command)) {
            channel.force(true);
            return;
        }
        requireWritable();
        CommittedRequest prior = requests.get(operation.requestId);
        if (prior != null) throw new IllegalStateException("requestId already committed at seq " + prior.seq);
        if (command.length > MAX_PAYLOAD) throw new IllegalArgumentException("command too large");
        long start = channel.size();
        pendingOffset = start;
        poisoned = true;
        append(PREPARE, epoch, seq, command);
        channel.force(true);
        pendingOffset = start;
        pendingEpoch = epoch;
        pendingSeq = seq;
        pendingCommand = command;
        poisoned = false;
    }

    /**
     * Isolated v19 ASYNC primary pilot: append PREPARE+COMMIT using the same
     * replay-compatible WAL, then issue ONE fsync before acknowledging.
     * Any I/O failure leaves this journal poisoned; never apply this to the
     * synchronous two-phase replication mode. Not multi-request group commit.
     */
    public synchronized void prepareAndCommitSingleForce(long epoch, long seq,
            DemoStateMachine.Operation operation) throws IOException {
        if (epoch <= 0 || epoch < lastEpoch || seq != committedSeq + 1
                || operation == null) throw new IllegalArgumentException("invalid atomic append");
        requireWritable();
        if (requests.containsKey(operation.requestId))
            throw new IllegalStateException("requestId already committed");
        byte[] command = operation.encode();
        if (command.length > MAX_PAYLOAD) throw new IllegalArgumentException("command too large");
        long start = channel.size();
        pendingOffset = start;
        poisoned = true;
        append(PREPARE, epoch, seq, command);
        append(COMMIT, epoch, seq, new byte[0]);
        channel.force(true);
        applyCommitted(command, epoch, seq);
        committedSeq = seq;
        committedEnd = channel.size();
        committedEnds.put(seq, committedEnd);
        lastEpoch = epoch;
        pendingCommand = null;
        poisoned = false;
    }

    /**
     * Isolated v19 real WAL multi-command group fsync pilot. The business
     * journal only supplies replay-compatible frames and byte[] state apply;
     * Common DurableWalGroupCommit owns ordering and the one-force barrier.
     * Never call this while a staged PREPARE tail is present. It does not
     * generate any client ACK or network majority certificate by itself.
     */
    public synchronized com.app.common.replication.DurableWalGroupCommit.CommittedBatch
            prepareAndCommitGroupForce(long epoch,
                    java.util.List<DemoStateMachine.Operation> commands) throws Exception {
        requireWritable();
        if(epoch<=0 || epoch<lastEpoch || committedSeq==Long.MAX_VALUE
                || commands==null || commands.isEmpty()
                || commands.size()>com.app.common.replication.DurableWalGroupCommit.MAX_BATCH)
            throw new IllegalArgumentException("invalid WAL group epoch or bound");
        java.util.List<byte[]> serialized=new java.util.ArrayList<byte[]>(commands.size());
        java.util.Set<String> seen=new java.util.HashSet<String>();
        for(DemoStateMachine.Operation command:commands) {
            if(command==null || !seen.add(command.requestId)
                    || requests.containsKey(command.requestId))
                throw new IllegalArgumentException("duplicate or invalid group requestId");
            serialized.add(command.encode());
        }
        final long first=committedSeq+1;
        final java.util.TreeMap<Long,Long> stagedEnds=new java.util.TreeMap<Long,Long>();
        final long[] previousEnd={channel.size()};
        return com.app.common.replication.DurableWalGroupCommit.forceThenPublish(
                epoch,first,serialized,
                new com.app.common.replication.DurableWalGroupCommit.Writer() {
                    @Override public void appendUnforced(long signedEpoch,long seq,
                            byte[] encoded)throws IOException {
                        if(stagedEnds.isEmpty()) {
                            pendingOffset=previousEnd[0];
                            poisoned=true;
                        }
                        if(seq!=first+stagedEnds.size() || !poisoned)
                            throw new IOException("noncontiguous or unpoisoned WAL group");
                        append(PREPARE,signedEpoch,seq,encoded);
                        append(COMMIT,signedEpoch,seq,new byte[0]);
                        stagedEnds.put(seq,channel.size());
                    }
                    @Override public void forceBatch()throws IOException {
                        if(stagedEnds.size()!=serialized.size())
                            throw new IOException("incomplete WAL group before fsync");
                        channel.force(true);
                    }
                    @Override public void publishCommitted(long signedEpoch,long seq,
                            byte[] encoded)throws IOException {
                        if(!poisoned || seq!=committedSeq+1
                                || !stagedEnds.containsKey(seq))
                            throw new IOException("WAL group publish out of order");
                        applyCommitted(encoded,signedEpoch,seq);
                        committedSeq=seq;
                        committedEnd=stagedEnds.get(seq);
                        committedEnds.put(seq,committedEnd);
                        lastEpoch=signedEpoch;
                        if(seq==first+stagedEnds.size()-1) {
                            pendingCommand=null;
                            pendingEpoch=0;
                            pendingSeq=0;
                            poisoned=false;
                        }
                    }
                    @Override public void poison(Throwable problem) {
                        poisoned=true;
                    }
                });
    }

    public synchronized void commit(long epoch, long seq) throws IOException {
        if (closed || poisoned || pendingCommand == null || epoch != pendingEpoch || seq != pendingSeq) {
            throw new IllegalStateException("no matching durable prepare");
        }
        poisoned = true;
        append(COMMIT, epoch, seq, new byte[0]);
        channel.force(true);
        applyCommitted(pendingCommand, epoch, seq);
        committedSeq = seq;
        committedEnd = channel.size();
        committedEnds.put(seq, committedEnd);
        lastEpoch = epoch;
        pendingCommand = null;
        poisoned = false;
    }

    public synchronized void commit(long epoch, long seq, DemoStateMachine.Operation operation) throws IOException {
        if (operation == null) throw new IllegalArgumentException("operation required");
        if (!closed && !poisoned && pendingCommand == null && committedSeq == seq && lastEpoch == epoch) {
            CommittedRequest prior = requests.get(operation.requestId);
            if (prior != null && prior.seq == seq && prior.delta == operation.delta) {
                channel.force(true);
                return;
            }
        }
        if (pendingCommand == null || !Arrays.equals(pendingCommand, operation.encode())) {
            throw new IllegalStateException("commit command differs from durable prepare");
        }
        commit(epoch, seq);
    }

    private void replay() throws IOException {
        long size = channel.size();
        long offset = 0;
        while (offset < size) {
            long frameStart = offset;
            if (size - offset < HEADER) {
                poisoned = true;
                if (pendingCommand == null) pendingOffset = frameStart;
                return;
            }
            ByteBuffer header = ByteBuffer.allocate(HEADER);
            readFully(header, offset);
            header.flip();
            int magic = header.getInt();
            int type = header.getInt();
            long epoch = header.getLong();
            long seq = header.getLong();
            int length = header.getInt();
            int checksum = header.getInt();
            if (magic != MAGIC || (type != PREPARE && type != COMMIT && type != SNAPSHOT && type != GENESIS)
                    || epoch <= 0 || length < 0
                    || length > (type == SNAPSHOT ? MAX_SNAPSHOT : MAX_PAYLOAD)
                    || length > size - offset - HEADER) {
                poisoned = true;
                if (pendingCommand == null) pendingOffset = frameStart;
                return;
            }
            byte[] payload = new byte[length];
            readFully(ByteBuffer.wrap(payload), offset + HEADER);
            if (checksum != checksum(type, epoch, seq, payload)) {
                poisoned = true;
                if (pendingCommand == null) pendingOffset = frameStart;
                return;
            }
            offset += HEADER + length;
            if(type==GENESIS){
                if(frameStart!=0 || seq!=0 || committedSeq!=0 || lastEpoch!=0
                        || pendingCommand!=null || genesisPartition!=null) {
                    poisoned=true;pendingOffset=frameStart;return;
                }
                try{replayGenesis(payload);}
                catch(IOException | RuntimeException malformed){
                    poisoned=true;pendingOffset=frameStart;return;
                }
                committedEnd=offset;
                committedEnds.put(0L,offset);
                lastEpoch=epoch;
            } else if (type == SNAPSHOT) {
                if (frameStart != 0 || committedSeq != 0 || pendingCommand != null) {
                    poisoned = true;
                    pendingOffset = frameStart;
                    return;
                }
                try { restoreSnapshot(payload, epoch, seq); }
                catch (RuntimeException | IOException malformed) {
                    poisoned = true;
                    pendingOffset = frameStart;
                    return;
                }
                committedEnd = offset;
                snapshotEnd = offset;
                snapshotSeq = seq;
                committedEnds.put(seq, offset);
            } else if (type == PREPARE) {
                if (pendingCommand != null || seq != committedSeq + 1 || epoch < lastEpoch || length == 0) {
                    poisoned = true;
                    if (pendingCommand == null) pendingOffset = frameStart;
                    return;
                }
                try { DemoStateMachine.Operation.decode(payload); }
                catch (RuntimeException malformed) {
                    poisoned = true;
                    if (pendingCommand == null) pendingOffset = frameStart;
                    return;
                }
                pendingCommand = payload;
                pendingEpoch = epoch;
                pendingSeq = seq;
                pendingOffset = frameStart;
            } else {
                if (length != 0 || pendingCommand == null || pendingEpoch != epoch || pendingSeq != seq) {
                    poisoned = true;
                    if (pendingCommand == null) pendingOffset = frameStart;
                    return;
                }
                try { applyCommitted(pendingCommand, epoch, seq); }
                catch (RuntimeException malformed) {
                    poisoned = true;
                    if (pendingCommand == null) pendingOffset = frameStart;
                    return;
                }
                committedSeq = seq;
                committedEnd = offset;
                committedEnds.put(seq, offset);
                lastEpoch = epoch;
                pendingCommand = null;
            }
        }
    }

    private void restoreSnapshot(byte[] payload, long frameEpoch, long frameSeq) throws IOException {
        DataInputStream input = new DataInputStream(new ByteArrayInputStream(payload));
        if (input.readInt() != 1) throw new IOException("unsupported journal snapshot version");
        long baseline = input.readLong();
        long epoch = input.readLong();
        String previousPrefix = input.readUTF();
        String digest = input.readUTF();
        int count = input.readInt();
        if (baseline <= 0 || baseline != frameSeq || epoch != frameEpoch
                || !previousPrefix.matches("[0-9a-f]{64}") || !digest.matches("[0-9a-f]{64}")
                || count <= 0 || count > 1000000 || count != baseline) {
            throw new IOException("invalid journal snapshot boundary");
        }
        for (long expected = 1; expected <= count; expected++) {
            if (input.readLong() != expected) throw new IOException("snapshot request sequence gap");
            int length = input.readInt();
            if (length <= 0 || length > 4096) throw new IOException("invalid snapshot request ID length");
            byte[] id = new byte[length];
            input.readFully(id);
            long delta = input.readLong();
            DemoStateMachine.Operation operation = new DemoStateMachine.Operation(
                    new String(id, StandardCharsets.UTF_8), delta);
            if (requests.put(operation.requestId, new CommittedRequest(delta, expected)) != null) {
                throw new IOException("duplicate snapshot request ID");
            }
            state.apply(operation.encode());
        }
        if (input.read() != -1 || !digest.equals(state.stateDigest())) {
            throw new IOException("snapshot state digest or trailing bytes mismatch");
        }
        committedSeq = baseline;
        lastEpoch = epoch;
        snapshotSourcePrefix = previousPrefix;
    }

    private void applyCommitted(byte[] command, long epoch, long seq) {
        DemoStateMachine.Operation operation = DemoStateMachine.Operation.decode(command);
        CommittedRequest previous = requests.get(operation.requestId);
        if (previous != null && previous.delta != operation.delta) {
            throw new IllegalStateException("conflicting committed request ID");
        }
        state.apply(command);
        if (previous == null) requests.put(operation.requestId, new CommittedRequest(operation.delta, seq));
        replayableRecords.put(seq, new CommittedRecord(epoch, seq, operation));
    }

    private void append(int type, long epoch, long seq, byte[] payload) throws IOException {
        ByteBuffer frame = ByteBuffer.allocate(HEADER + payload.length);
        frame.putInt(MAGIC).putInt(type).putLong(epoch).putLong(seq).putInt(payload.length)
                .putInt(checksum(type, epoch, seq, payload)).put(payload).flip();
        long position = channel.size();
        while (frame.hasRemaining()) position += channel.write(frame, position);
    }

    private void readFully(ByteBuffer buffer, long start) throws IOException {
        long position = start;
        while (buffer.hasRemaining()) {
            int read = channel.read(buffer, position);
            if (read <= 0) throw new IOException("short journal read");
            position += read;
        }
    }

    private String sha256(long start, long length) throws IOException {
        try {
            MessageDigest hash = MessageDigest.getInstance("SHA-256");
            ByteBuffer block = ByteBuffer.allocate(8192);
            long position = start;
            long remaining = length;
            while (remaining > 0) {
                block.clear();
                block.limit((int) Math.min(block.capacity(), remaining));
                readFully(block, position);
                hash.update(block.array(), 0, block.limit());
                position += block.limit();
                remaining -= block.limit();
            }
            StringBuilder hex = new StringBuilder(64);
            for (byte b : hash.digest()) hex.append(String.format("%02x", b & 0xff));
            return hex.toString();
        } catch (NoSuchAlgorithmException impossible) {
            throw new IllegalStateException(impossible);
        }
    }

    private static int checksum(int type, long epoch, long seq, byte[] payload) {
        ByteBuffer input = ByteBuffer.allocate(20 + payload.length);
        input.putInt(type).putLong(epoch).putLong(seq).put(payload);
        CRC32 crc = new CRC32();
        crc.update(input.array());
        return (int) crc.getValue();
    }

    private void requireWritable() {
        if (!isReadyForWrites()) throw new IllegalStateException("journal not ready; preserve tail for certified recovery");
    }

    @Override public synchronized void close() throws IOException {
        if (closed) return;
        closed = true;
        try { lock.release(); } finally { channel.close(); }
    }
}
