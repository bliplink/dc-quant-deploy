package com.opentradingcore.demo;

import com.app.common.partition.ZkPartitionFailoverControlPlane;
import com.app.common.zk.ZookeeperClient;
import java.io.IOException;
import java.util.UUID;

/**
 * Isolated three-ZooKeeper integration regression for controller lease
 * instance identity. Does not modify any real partition assignment, READY,
 * WAL, or production membership. Creates a unique ephemeral test lease.
 */
public final class DemoV19ControllerLeaseSmoke {
    private static final String ROOT =
        "/dc/cluster/commonhademo/v19-four-node-placement-pilot";
    private DemoV19ControllerLeaseSmoke(){}

    private static ZkPartitionFailoverControlPlane newController(
            ZookeeperClient client,String leaf) {
        return new ZkPartitionFailoverControlPlane(client,
            ROOT+"/assignments", "/MDTService",leaf,"CommonHaDemoSameOwner");
    }
    private static void require(boolean value,String message)throws IOException{
        if(!value)throw new IOException("ZK lease integration failed: "+message);
    }
    public static void main(String[] argv)throws Exception {
        if(argv.length!=1 || !"--test-only".equals(argv[0]))
            throw new IllegalArgumentException("isolated --test-only required");
        final String leaf=ROOT+"/lease-exclusivity-smoke/lease-"+
                UUID.randomUUID().toString();
        ZookeeperClient first=new ZookeeperClient(DemoAssignmentBootstrap.HOSTS,null,null);
        ZookeeperClient second=new ZookeeperClient(DemoAssignmentBootstrap.HOSTS,null,null);
        try {
            for(int i=0;i<80 && !(first.isConnected() && second.isConnected());i++)
                Thread.sleep(100L);
            require(first.isConnected()&&second.isConnected(),"two real sessions");
            try(ZkPartitionFailoverControlPlane original=newController(first,leaf);
                ZkPartitionFailoverControlPlane contender=newController(second,leaf)) {
                require(original.tryAcquireLease(),"first acquire");
                require(original.hasLease(),"first has lease");
                require(!contender.tryAcquireLease(),
                    "same logical owner must not impersonate separate session");
                require(!contender.hasLease(),"second has no authority");
                contender.close();
                require(original.hasLease(),"failed contender close preserved lease");
                // Real ZK session loss, not only FakeOps simulation.
                first.close();
                require(!original.hasLease(),"old controller lost its session");
                try(ZkPartitionFailoverControlPlane replacement=newController(second,leaf)) {
                    boolean acquired=false;
                    for(int i=0;i<100 && !acquired;i++){
                        acquired=replacement.tryAcquireLease();
                        if(!acquired)Thread.sleep(100L);
                    }
                    require(acquired,"new session acquired after stale session death");
                    require(!original.tryAcquireLease(),
                            "stale controller must not reacquire old authority");
                    original.close();
                    require(replacement.hasLease(),
                            "old controller close must preserve replacement");
                }
            }
            System.out.println("THREE_ZK_REAL_SAME_OWNER_CONTROLLER_LEASE_PASS"
                +" twoDistinctSessions=true sameOwnerCollisionRejected=true"
                +" nonownerCloseSafe=true staleSessionRevoked=true"
                +" replacementLeaseSurvivedOldClose=true"
                +" partitionAssignmentWrites=0 ready=false clientAck=false");
        }finally{
            first.close();
            second.close();
        }
    }
}
