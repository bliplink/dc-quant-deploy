package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;

/** Pure additional guard. ZK grants, process readiness, local WAL fsync and
 * fencing checks remain mandatory in their original service boundaries. */
final class DemoV19Rf2DegradedPolicy {
    private DemoV19Rf2DegradedPolicy() {}

    static boolean mayUseLocalAck(boolean optedIn, boolean quorumRuntimePresent,
            PartitionAssignment grant, String localNode) {
        return optedIn && quorumRuntimePresent && grant!=null
                && "P000".equals(grant.getPartitionId())
                && grant.isRoutable() && grant.getEpoch()>=2L
                && localNode!=null && localNode.equals(grant.getPrimary())
                && grant.replicaNodes().isEmpty();
    }
}
