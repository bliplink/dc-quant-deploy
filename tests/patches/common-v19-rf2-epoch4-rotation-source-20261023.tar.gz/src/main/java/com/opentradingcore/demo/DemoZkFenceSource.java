package com.opentradingcore.demo;

import com.app.common.zk.ZookeeperClient;
import com.gateway.connector.utils.JsonUtils;
import org.I0Itec.zkclient.exception.ZkBadVersionException;
import org.apache.zookeeper.data.Stat;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * REAL ZooKeeper, strictly control-plane-only, versioned-CAS fence source.
 * v19 experimental namespace intentionally DOES NOT share any legacy v17
 * write-proof nodes. This class must never be invoked by WAL data threads.
 */
final class DemoZkFenceSource implements DemoEpochFenceArbiter.Source, AutoCloseable {
    static final String ISOLATED_ROOT = "/dc/cluster/commonhademo/v19-fence-test";
    private static final String DEFAULT_ASSIGNMENT_ROOT = DemoAssignmentBootstrap.ROOT;

    private final ZookeeperClient zk;
    private final String gateRoot;
    private final String assignmentRoot;

    DemoZkFenceSource(ZookeeperClient zk, String gateRoot) {
        this(zk, gateRoot, DEFAULT_ASSIGNMENT_ROOT);
    }

    DemoZkFenceSource(ZookeeperClient zk, String gateRoot, String assignmentRoot) {
        if (zk == null) throw new IllegalArgumentException("ZK client required");
        if (gateRoot == null ||
                !(ISOLATED_ROOT.equals(gateRoot) || gateRoot.startsWith(ISOLATED_ROOT + "/")))
            throw new IllegalArgumentException("fencing source must use v19 isolated namespace");
        if (assignmentRoot == null || !(DEFAULT_ASSIGNMENT_ROOT.equals(assignmentRoot)
                || assignmentRoot.startsWith(ISOLATED_ROOT + "/")))
            throw new IllegalArgumentException("assignment root outside Demo/v19 isolated namespace");
        this.zk = zk;
        this.gateRoot = gateRoot;
        this.assignmentRoot = assignmentRoot;
    }

    @Override public DemoEpochFenceArbiter.Assignment readAssignment(String partition) {
        checkPartition(partition);
        if (!zk.isConnected()) throw new IllegalStateException("control plane disconnected");
        Stat stat = new Stat();
        Object raw = zk.readData(assignmentRoot + "/" + partition, stat);
        if (raw == null) throw new IllegalStateException("assignment missing");
        @SuppressWarnings("unchecked") Map<String, Object> values =
                JsonUtils.Deserialize(String.valueOf(raw), Map.class);
        if (values == null || !partition.equals(String.valueOf(values.get("partitionId"))))
            throw new IllegalStateException("invalid assignment");
        long epoch = requiredNumber(values.get("epoch"));
        long appVersion = requiredNumber(values.get("assignmentVersion"));
        String primary = String.valueOf(values.get("primary"));
        if (!"CommonHaDemoA".equals(primary) && !"CommonHaDemoB".equals(primary))
            throw new IllegalStateException("unsupported Demo primary");
        String state = String.valueOf(values.get("state"));
        Set<String> replicas = new HashSet<String>();
        Object list = values.get("replicas");
        if (!(list instanceof Iterable)) throw new IllegalStateException("assignment replicas missing");
        for (Object item : (Iterable<?>) list) {
            String replica = String.valueOf(item);
            if (!"CommonHaDemoA".equals(replica) && !"CommonHaDemoB".equals(replica)
                    && !"CommonHaDemoC".equals(replica))
                throw new IllegalStateException("invalid replica membership");
            replicas.add(replica);
        }
        requireValidDurabilityPolicy(values,epoch,state,replicas);
        if (!zk.isConnected()) throw new IllegalStateException("disconnected after assignment read");
        // Both ZK stat version and application assignmentVersion are preserved,
        // so the before/after recheck fences either kind of transition.
        return new DemoEpochFenceArbiter.Assignment(
                epoch, (((long) stat.getVersion()) << 32) | (appVersion & 0xffffffffL),
                primary, replicas, "READY".equals(state));
    }

    /** A singleton READY requires an explicit persisted, auditable downgrade.
     * Never infer one-data-voter permission solely from the replica list.
     */
    static void requireValidDurabilityPolicy(Map<String,Object> values,long epoch,
            String state,Set<String> replicas) {
        if ("READY".equals(state) && replicas.isEmpty()) {
            if (epoch<2L
                    || !"1".equals(System.getenv("DEMO_V19_RF2_AUTO_DEGRADE"))
                    || !"AUTO_DEGRADED_LOCAL_DURABLE".equals(values.get("durabilityPolicy"))
                    || !Boolean.FALSE.equals(values.get("quorumDurable")))
                throw new IllegalStateException("unapproved singleton write durability policy");
        }
    }

    /**
     * Recovery-only second ZK read: replica list is NOT sufficient to prove
     * a node has left the cluster, because it may still be a learner. Require
     * both stat and app version to match the caller's current assignment.
     * Fail closed when the membership schema is missing or unexpected.
     */
    void requireUnassignedMember(String partition, String target, long assignmentVersion) {
        checkPartition(partition);
        if (!zk.isConnected()) throw new IllegalStateException("control-plane unavailable");
        Stat stat = new Stat();
        Object raw = zk.readData(assignmentRoot + "/" + partition, stat);
        if (raw == null) throw new IllegalStateException("assignment missing");
        @SuppressWarnings("unchecked") Map<String,Object> fields =
                JsonUtils.Deserialize(String.valueOf(raw), Map.class);
        if (fields == null || !partition.equals(fields.get("partitionId")))
            throw new IllegalStateException("malformed assignment");
        long actualVersion = (((long)stat.getVersion()) << 32)
                | (requiredNumber(fields.get("assignmentVersion")) & 0xffffffffL);
        if (actualVersion != assignmentVersion)
            throw new IllegalStateException("membership changed during recovery authorization");
        requireNotMember(fields, target);
        if (!zk.isConnected()) throw new IllegalStateException("ZK disconnected while proving membership");
    }

    static void requireNotMember(Map<String,Object> fields, String target) {
        if (fields == null || target == null || !target.matches("CommonHaDemo[ABC]"))
            throw new IllegalStateException("invalid membership proof");
        if (target.equals(fields.get("primary")) || target.equals(fields.get("replica")))
            throw new IllegalStateException("target is active primary or replica");
        for (String field : new String[] {"replicas", "learners"}) {
            Object members = fields.get(field);
            if (!(members instanceof Iterable))
                throw new IllegalStateException("membership field missing: " + field);
            for (Object member : (Iterable<?>)members) {
                if (!(member instanceof String) || !String.valueOf(member).matches("CommonHaDemo[ABC]"))
                    throw new IllegalStateException("unrecognized cluster member");
                if (target.equals(member))
                    throw new IllegalStateException("target still listed in " + field);
            }
        }
    }

    @Override public DemoEpochFenceArbiter.Gate readGate(String partition) {
        checkPartition(partition);
        if (!zk.isConnected()) throw new IllegalStateException("control plane disconnected");
        // Gate nodes MUST be explicitly created from genesis in a quiescent
        // test namespace; missing gates fail closed. No implicit auto-create.
        String path = gateRoot + "/" + partition;
        if (!zk.exists(path)) return null;
        Stat stat = new Stat();
        Object raw = zk.readData(path, stat);
        if (raw == null) return null;
        return decode(String.valueOf(raw), stat.getVersion());
    }

    @Override public boolean compareAndSetGate(String partition, long expectedVersion,
            DemoEpochFenceArbiter.Gate replacement) {
        checkPartition(partition);
        if (replacement == null || replacement.frozen
                || replacement.epoch <= 0
                || (!"CommonHaDemoA".equals(replacement.primary)
                    && !"CommonHaDemoB".equals(replacement.primary))
                || expectedVersion < 0 || expectedVersion > Integer.MAX_VALUE)
            throw new IllegalArgumentException("invalid fencing CAS");
        if (!zk.isConnected()) throw new IllegalStateException("ZooKeeper disconnected");
        try {
            zk.writeDataReturnStat(gateRoot + "/" + partition,
                    encode(replacement.epoch, replacement.primary, false),
                    (int) expectedVersion);
        } catch (ZkBadVersionException conflict) {
            return false;
        }
        // A returned ZK quorum commit is NOT enough if our session dropped
        // before we could finish checking assignment and local TTL.
        if (!zk.isConnected()) throw new IllegalStateException("ZK disconnected after fencing CAS");
        return true;
    }

    /** Encode safe, fixed grammar; bootstrap marker 0|-|OPEN only. */
    static String encode(long epoch, String primary, boolean frozen) {
        if (epoch < 0 || primary == null || primary.indexOf('|') >= 0)
            throw new IllegalArgumentException("bad fence metadata");
        return epoch + "|" + primary + "|" + (frozen ? "FROZEN" : "OPEN");
    }

    static DemoEpochFenceArbiter.Gate decode(String raw, long version) {
        String[] parts = raw.split("\\|", -1);
        if (parts.length != 3 || version < 0) throw new IllegalStateException("fence gate malformed");
        final long epoch;
        try { epoch = Long.parseLong(parts[0]); }
        catch (NumberFormatException bad) { throw new IllegalStateException("fence epoch invalid", bad); }
        if (epoch < 0) throw new IllegalStateException("negative fence epoch");
        String owner = parts[1];
        if (!(epoch == 0 && "-".equals(owner))
                && !"CommonHaDemoA".equals(owner) && !"CommonHaDemoB".equals(owner))
            throw new IllegalStateException("fence owner invalid");
        if (!"FROZEN".equals(parts[2]) && !"OPEN".equals(parts[2]))
            throw new IllegalStateException("fence state invalid");
        return new DemoEpochFenceArbiter.Gate(version, epoch, owner,
                "FROZEN".equals(parts[2]));
    }

    private static long requiredNumber(Object value) {
        if (!(value instanceof Number)) throw new IllegalStateException("number missing");
        return ((Number) value).longValue();
    }

    private static void checkPartition(String partition) {
        if (partition == null || !partition.matches("P\\d{3}"))
            throw new IllegalArgumentException("bad partition");
    }

    @Override public void close() { zk.close(); }
}
