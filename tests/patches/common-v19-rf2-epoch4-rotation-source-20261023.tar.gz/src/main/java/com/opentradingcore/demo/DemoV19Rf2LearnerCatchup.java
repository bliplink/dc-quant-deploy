package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;
import com.app.common.partition.PartitionFailoverController;
import com.app.common.partition.ZkPartitionFailoverControlPlane;
import java.io.IOException;

/** One partition, opt-in automatic A learner catch-up over authenticated
 * ZooKeeper ownership plus bounded Netty WAL image. Does NOT promote A.
 */
final class DemoV19Rf2LearnerCatchup {
    private final String local;
    private final ZkPartitionFailoverControlPlane plane;
    private final DemoJournalCatalog journals;

    DemoV19Rf2LearnerCatchup(String local,ZkPartitionFailoverControlPlane plane,
            DemoJournalCatalog journals) {
        if (!("CommonHaDemoA".equals(local) || "CommonHaDemoB".equals(local))
                || plane==null || journals==null)
            throw new IllegalArgumentException("only the fenced old A may recover as learner");
        this.local=local;this.plane=plane;this.journals=journals;
    }

    boolean once() throws Exception {
        if (!plane.isConnected()) return false;
        PartitionFailoverController.VersionedAssignment v=plane.read("P000");
        if (v==null || !valid(v.getAssignment())) return false;
        String source=v.getAssignment().getPrimary();
        if (!plane.isLive(source)) return false;
        try(DemoV19TcpClient tcp=new DemoV19TcpClient()) {
            DemoV19TcpSnapshotReceiver.Image image=tcp.snapshot(source);
            if (image.epoch!=v.getAssignment().getEpoch() || !source.equals(image.node))
                throw new IOException("untrusted new owner image");
            return journals.installRf2LearnerImage("P000",image,()->{
                if (!plane.isConnected() || !plane.isLive(source))
                    throw new IOException("source owner ZK membership revoked");
                PartitionFailoverController.VersionedAssignment current=plane.read("P000");
                if (current==null || current.getVersion()!=v.getVersion()
                        || !valid(current.getAssignment()))
                    throw new IOException("epoch or learner set changed during WAL installation");
            });
        }
    }

    private boolean valid(PartitionAssignment a) {
        return a!=null && "P000".equals(a.getPartitionId())
                && a.getEpoch()>=2 && a.getEpoch()<=8 && a.isRoutable()
                && !local.equals(a.getPrimary())
                && ("CommonHaDemoA".equals(a.getPrimary()) || "CommonHaDemoB".equals(a.getPrimary()))
                && a.replicaNodes().isEmpty() && a.isLearner(local);
    }
}
