package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;
import java.util.Collections;
import org.junit.Test;
import static org.junit.Assert.*;

public final class DemoV19Rf2DegradedPolicyTest {
    private static PartitionAssignment assignment(String state,long epoch,String primary,
            boolean hasReplica) {
        PartitionAssignment a=new PartitionAssignment();
        a.setPartitionId("P000"); a.setPrimary(primary); a.setEpoch(epoch);
        a.setState(state);
        a.setReplicas(hasReplica?Collections.singletonList("CommonHaDemoA"):
                Collections.<String>emptyList());
        return a;
    }
    @Test public void soleEpoch2OwnerCanUseLocalContractWhenOptedIn() {
        assertTrue(DemoV19Rf2DegradedPolicy.mayUseLocalAck(true,true,
                assignment("READY",2,"CommonHaDemoB",false),"CommonHaDemoB"));
    }
    @Test public void reverseFailureRequiresNewEpochAndExistingLocalAckOptIn() {
        assertTrue(DemoV19Rf2DegradedPolicy.mayUseLocalAck(true,true,
                assignment("READY",3,"CommonHaDemoA",false),"CommonHaDemoA"));
        assertFalse(DemoV19Rf2DegradedPolicy.mayUseLocalAck(false,true,
                assignment("READY",3,"CommonHaDemoA",false),"CommonHaDemoA"));
        assertFalse(DemoV19Rf2DegradedPolicy.mayUseLocalAck(true,true,
                assignment("RECOVERING",3,"CommonHaDemoA",false),"CommonHaDemoA"));
        assertFalse(DemoV19Rf2DegradedPolicy.mayUseLocalAck(true,true,
                assignment("READY",3,"CommonHaDemoA",true),"CommonHaDemoA"));
    }
    @Test public void noImplicitFallbackInOriginalStrictEpoch() {
        assertFalse(DemoV19Rf2DegradedPolicy.mayUseLocalAck(true,true,
                assignment("READY",1,"CommonHaDemoB",false),"CommonHaDemoB"));
    }
    @Test public void recoveringIsNotClientWritable() {
        assertFalse(DemoV19Rf2DegradedPolicy.mayUseLocalAck(true,true,
                assignment("RECOVERING",2,"CommonHaDemoB",false),"CommonHaDemoB"));
    }
    @Test public void replicasPresentForbidLocalDowngrade() {
        assertFalse(DemoV19Rf2DegradedPolicy.mayUseLocalAck(true,true,
                assignment("READY",2,"CommonHaDemoB",true),"CommonHaDemoB"));
    }
    @Test public void noOptInNoQuorumRuntimeOrWrongOwnerForbid() {
        PartitionAssignment a=assignment("READY",2,"CommonHaDemoB",false);
        assertFalse(DemoV19Rf2DegradedPolicy.mayUseLocalAck(false,true,a,"CommonHaDemoB"));
        assertFalse(DemoV19Rf2DegradedPolicy.mayUseLocalAck(true,false,a,"CommonHaDemoB"));
        assertFalse(DemoV19Rf2DegradedPolicy.mayUseLocalAck(true,true,a,"CommonHaDemoA"));
    }
}
