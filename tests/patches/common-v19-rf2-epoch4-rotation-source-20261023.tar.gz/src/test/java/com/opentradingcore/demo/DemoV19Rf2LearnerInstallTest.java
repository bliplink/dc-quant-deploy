package com.opentradingcore.demo;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import java.io.IOException;
import java.nio.file.Path;
import java.util.concurrent.atomic.AtomicInteger;
import static org.junit.Assert.*;

/** No ZK authority here: the caller's frozen Learner proof is separately tested. */
public final class DemoV19Rf2LearnerInstallTest {
    @Rule public TemporaryFolder temp=new TemporaryFolder();

    private static void append(DemoDurableJournal wal,long epoch,long seq,
            String requestId,long delta) throws Exception {
        wal.prepareAndCommitSingleForce(epoch,seq,new DemoStateMachine.Operation(requestId,delta));
    }
    private static DemoV19TcpSnapshotReceiver.Image image(DemoDurableJournal wal)
            throws Exception {
        return new DemoV19TcpSnapshotReceiver.Image(wal.committedPrefixBytes(),
                wal.committedSeq(),wal.lastEpoch(),wal.committedPrefixSha256(),
                wal.state().stateDigest(),"CommonHaDemoB");
    }
    @Test public void confirmedOldAckPrefixIsKeptAndCaughtUpWithoutReady() throws Exception {
        Path r=temp.newFolder("recovery").toPath();
        try(DemoJournalCatalog a=new DemoJournalCatalog("A",r.resolve("A"));
            DemoDurableJournal b=new DemoDurableJournal(r.resolve("B.wal"))) {
            DemoDurableJournal before=a.journal("P000");
            append(before,1,1,"old-1",1);append(b,1,1,"old-1",1);
            append(b,2,2,"new-2",2);
            AtomicInteger authorization=new AtomicInteger();
            assertTrue(a.installRf2LearnerImage("P000",image(b),authorization::incrementAndGet));
            assertEquals(1,authorization.get());
            assertEquals(2,a.journal("P000").committedSeq());
            assertEquals(2,a.journal("P000").lastEpoch());
            assertEquals(b.committedPrefixSha256(),a.journal("P000").committedPrefixSha256());
            assertEquals(1,a.journal("P000").state().appliedCount("old-1"));
            assertEquals(1,a.journal("P000").state().appliedCount("new-2"));
            assertFalse(a.installRf2LearnerImage("P000",image(b),authorization::incrementAndGet));
            assertEquals(1,authorization.get());
        }
    }
    @Test public void divergentCommittedHistoryNeverReplaced() throws Exception {
        Path r=temp.newFolder("diverged").toPath();
        try(DemoJournalCatalog a=new DemoJournalCatalog("A",r.resolve("A"));
            DemoDurableJournal b=new DemoDurableJournal(r.resolve("B.wal"))) {
            append(a.journal("P000"),1,1,"ack-on-a",4);
            append(b,1,1,"different-ack",4);
            append(b,2,2,"new-2",5);
            String oldSha=a.journal("P000").committedPrefixSha256();
            try {a.installRf2LearnerImage("P000",image(b),()->{});
                fail("divergent confirmed ACK overwritten");
            }catch(IOException expected) { }
            assertEquals(1,a.journal("P000").committedSeq());
            assertEquals(oldSha,a.journal("P000").committedPrefixSha256());
        }
    }
    @Test public void staleMembershipBeforeAtomicInstallLeavesOldWal() throws Exception {
        Path r=temp.newFolder("stale").toPath();
        try(DemoJournalCatalog a=new DemoJournalCatalog("A",r.resolve("A"));
            DemoDurableJournal b=new DemoDurableJournal(r.resolve("B.wal"))) {
            append(a.journal("P000"),1,1,"old-1",1);
            append(b,1,1,"old-1",1);append(b,2,2,"new-2",2);
            try {a.installRf2LearnerImage("P000",image(b),()->{
                    throw new IOException("epoch lease was revoked");
                });fail("stale membership permitted install");
            } catch(IOException expected) { }
            assertEquals(1,a.journal("P000").committedSeq());
            assertEquals(1,a.journal("P000").lastEpoch());
        }
    }
    @Test public void fakeImageHashCannotAlterWal() throws Exception {
        Path r=temp.newFolder("fake").toPath();
        try(DemoJournalCatalog a=new DemoJournalCatalog("A",r.resolve("A"));
            DemoDurableJournal b=new DemoDurableJournal(r.resolve("B.wal"))) {
            append(b,2,1,"new-1",1);
            DemoV19TcpSnapshotReceiver.Image trueImage=image(b);
            DemoV19TcpSnapshotReceiver.Image forged=new DemoV19TcpSnapshotReceiver.Image(
                    trueImage.bytes,trueImage.committedSeq,trueImage.epoch,
                    new String(new char[64]).replace("\0","0"),trueImage.stateDigest,trueImage.node);
            try {a.installRf2LearnerImage("P000",forged,()->{});
                fail("tampered WAL accepted");
            }catch(IOException expected) { }
            assertEquals(0,a.journal("P000").committedSeq());
        }
    }
}
