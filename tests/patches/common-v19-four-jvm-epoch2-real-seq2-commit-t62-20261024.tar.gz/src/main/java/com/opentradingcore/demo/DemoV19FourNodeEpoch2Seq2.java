package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;
import com.app.common.replication.*;
import com.app.common.zk.ZookeeperClient;
import com.gateway.connector.utils.JsonUtils;
import java.io.*;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.*;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.*;
import java.util.concurrent.TimeUnit;
import org.I0Itec.zkclient.exception.ZkNodeExistsException;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.data.Stat;

/**
 * T62 bounded NON-TRADING real Epoch2 seq2 write/replication pilot.
 * Not a public order API, not READY, and never sends a customer ACK.
 *
 * Both JVMs independently fsync PREPARE and COMMIT to NEW active WALs.
 * After both COMMITs, Common verifies signed seq2 receipts, persists
 * DurableWalCommitIndex on the new primary, and persists two independent
 * DurableWalCertificateCustody heads. A 2/2 ZK evidence record is create-only.
 * Crash at either intermediate step fails closed and may be resumed with
 * the SAME deterministic request ID; no partial commit is acknowledged.
 */
final class DemoV19FourNodeEpoch2Seq2 {
    static final String PREPARE="INTERNAL_EPOCH2_SEQ2_PREPARE_V1";
    static final String COMMIT="INTERNAL_EPOCH2_SEQ2_COMMIT_V1";
    static final String SIGN="INTERNAL_EPOCH2_SEQ2_SIGN_V1";
    static final String INDEX="INTERNAL_EPOCH2_SEQ2_INDEX_V1";
    static final String CUSTODY="INTERNAL_EPOCH2_SEQ2_CUSTODY_V1";
    static final String SCOPE="EPOCH2_SEQ2_COMMON_2OF2_NONTRADING_NO_ACK_V1";
    static final String PROOFS=DemoV19FourNodeShardCatalog.ROOT+"/epoch2-seq2-proofs";
    private final String node;
    private final Path root;
    private final PrivateKey key;
    DemoV19FourNodeEpoch2Seq2(String node,Path root)throws Exception {
        if(node==null || !node.matches("CommonHaDemo[ABCD]")
                || root==null || !root.isAbsolute())
            throw new IOException("invalid physical Epoch2 seq2 signer");
        this.node=node;this.root=root;
        key=KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(
            Files.readAllBytes(root.resolve(".preflight-identity/local.pk8"))));
    }
    static String dir(String part){return ".pilot-epoch2-active-"+part;}
    static String requestId(String part){return "INTERNAL-NON-TRADING-EPOCH2-SEQ2-"+part;}
    static long delta(String part){return "P000".equals(part)?19:23;}
    private static DemoStateMachine.Operation command(String part) {
        return new DemoStateMachine.Operation(requestId(part),delta(part));
    }
    private static Path active(Path root,String part){
        return root.resolve(dir(part)).resolve("active.wal");
    }
    private static void forceDir(Path path)throws Exception{
        try(FileChannel ch=FileChannel.open(path,StandardOpenOption.READ)){
            ch.force(true);
        }
    }
    private static void ensureActiveWal(Path root,String part)throws Exception {
        Path folder=root.resolve(dir(part));
        Path installed=root.resolve(DemoV19FourNodeEpoch2Install.recoveryDir(part))
            .resolve("recovered.wal");
        if(Files.isSymbolicLink(root) || Files.isSymbolicLink(folder)
                || Files.isSymbolicLink(installed)
                || !Files.isRegularFile(installed,LinkOption.NOFOLLOW_LINKS))
            throw new IOException("invalid frozen Epoch2 WAL baseline");
        Files.createDirectories(folder);
        Path dst=active(root,part),pending=folder.resolve("active.pending");
        if(Files.isSymbolicLink(dst) || Files.exists(pending,LinkOption.NOFOLLOW_LINKS))
            throw new IOException("torn or redirected active WAL install");
        if(Files.exists(dst,LinkOption.NOFOLLOW_LINKS)){
            if(!Files.isRegularFile(dst,LinkOption.NOFOLLOW_LINKS))
                throw new IOException("unsafe current active Epoch2 WAL");
            return;
        }
        byte[] bytes=Files.readAllBytes(installed);
        if(bytes.length==0 || bytes.length>1024*1024)
            throw new IOException("unbounded trusted Epoch2 baseline");
        try(FileChannel output=FileChannel.open(pending,
                StandardOpenOption.CREATE_NEW,StandardOpenOption.WRITE)){
            ByteBuffer buffer=ByteBuffer.wrap(bytes);
            while(buffer.hasRemaining())output.write(buffer);
            output.force(true);
        }
        Files.move(pending,dst,StandardCopyOption.ATOMIC_MOVE);
        forceDir(folder);forceDir(root);
    }
    static final class Status {
        final String sha;
        final String digest;
        final long seq;
        Status(String sha,String digest,long seq) {
            this.sha=sha;this.digest=digest;this.seq=seq;
        }
    }
    private static Status validateActive(DemoDurableJournal active,
            String part,String sourceSha,boolean committed)throws Exception{
        if(committed){
            if(!active.isReadyForWrites() || active.committedSeq()!=2
                    || active.lastEpoch()!=2 || active.snapshotSeq()!=1
                    || !sourceSha.equals(active.snapshotSourcePrefix())
                    || active.state().distinctRequests()!=2
                    || active.state().appliedCount(requestId(part))!=1
                    || active.state().total()!=DemoV19FourNodeSeq1NettyPilot.delta(part)+
                        delta(part))
                throw new IOException("real Epoch2 seq2 WAL not fully committed");
        }else if(active.committedSeq()!=1 || active.lastEpoch()!=2
                || active.snapshotSeq()!=1
                || !sourceSha.equals(active.snapshotSourcePrefix()))
            throw new IOException("active WAL cannot extend exact Epoch2 snapshot");
        return new Status(active.committedPrefixSha256(),
            active.state().stateDigest(),active.committedSeq());
    }
    @SuppressWarnings("unchecked")
    private static String requireFrozen(ZookeeperClient zk,PartitionAssignment old,
            String node,Path root,DemoDurableJournal source)throws Exception{
        DemoV19FourNodeReadyPreflight.requireExactRecoveryAssignment(zk,old);
        DemoV19FourNodeEpoch2Transition.requireLocalImage(zk,old,node,root,source);
        DemoV19FourNodeEpoch2Common.verifyLocalAfterRestart(zk,old,node,root);
        Map<String,Object> installed=JsonUtils.Deserialize(String.valueOf(
            zk.readData(DemoV19FourNodeEpoch2Install.PROOFS+"/"+
                old.getPartitionId())),Map.class);
        String baseline=(String)installed.get("recoveredWalSha256");
        String srcSha=(String)installed.get("sourceSha256");
        if(source.lastEpoch()!=1 || source.committedSeq()!=1
                || !srcSha.equals(source.committedPrefixSha256Through(1)))
            throw new IOException("old source mutated while attempting Epoch2 write");
        // The complete pre-ready old publisher revocation remains mandatory,
        // and new sequence operation cannot be used to reauthorize Epoch1.
        Path oldHead=root.resolve(".pilot-old-epoch-revoked-"+old.getPartitionId())
            .resolve("head.bin");
        String oldMember=DemoV19FourNodeEpoch2Transition.historicMembership(
            zk,old).digest;
        String expected=DemoV19FourNodeRemoteRevocation.expectedPayload(
            old,oldMember,srcSha)+"\n";
        if(Files.isSymbolicLink(oldHead)
                || !Files.isRegularFile(oldHead,LinkOption.NOFOLLOW_LINKS)
                || !Arrays.equals(Files.readAllBytes(oldHead),
                    expected.getBytes(java.nio.charset.StandardCharsets.UTF_8)))
            throw new IOException("old primary not irreversibly revoked");
        return baseline;
    }
    private static Status operate(DemoDurableJournal wal,String part,String baseline,
            String op)throws Exception{
        String sourcePrefix;
        try(DemoDurableJournal frozen=new DemoDurableJournal(wal.path().getParent()
                .getParent().resolve(DemoV19FourNodeEpoch2Install.recoveryDir(part))
                .resolve("recovered.wal"))){
            if(frozen.committedSeq()!=1 || frozen.lastEpoch()!=2)
                throw new IOException("original Epoch2 installed baseline missing");
            sourcePrefix=frozen.snapshotSourcePrefix();
        }
        validateActive(wal,part,sourcePrefix,false);
        if(PREPARE.equals(op))wal.prepare(2,2,command(part));
        else if(COMMIT.equals(op))wal.commit(2,2,command(part));
        else throw new IOException("unsupported active WAL state change");
        return new Status(wal.committedPrefixSha256(),wal.state().stateDigest(),
            wal.committedSeq());
    }
    private static DurableWalCommitQuorum.LocalDurability durability(
            String part,Path root,String expectedSource){
        return (epoch,seq)->{
            if(epoch!=2 || seq!=2)throw new IOException("not true Epoch2 seq2");
            try(DemoDurableJournal wal=new DemoDurableJournal(active(root,part))){
                validateActive(wal,part,expectedSource,true);
                return wal.committedPrefixSha256Through(2);
            }
        };
    }
    ReplicationControlResponse handle(ZookeeperClient zk,List<PartitionAssignment> plan,
            DemoV19FourNodeLiveRuntime.HeldWal held,ReplicationControlRequest request){
        try{
            if(request==null || !DemoV19FourNodeShardCatalog.SERVICE.equals(
                    request.getServiceName()) || !node.equals(held.node)
                    || !zk.isConnected()
                    || !(PREPARE.equals(request.getOperation())
                        || COMMIT.equals(request.getOperation())
                        || SIGN.equals(request.getOperation())
                        || INDEX.equals(request.getOperation())
                        || CUSTODY.equals(request.getOperation())))
                throw new IOException("invalid bounded Epoch2 seq2 operation");
            String part=request.getPartitionId();
            if(!DemoV19FourNodeSeq1NettyPilot.selected(part))
                throw new IOException("new epoch write outside two isolated shards");
            PartitionAssignment old=plan.get(Integer.parseInt(part.substring(1)));
            if(!DemoV19FourNodeLiveRuntime.owners(old).contains(node))
                throw new IOException("physical writer not in new membership");
            DemoDurableJournal source=held.owned.get(part);
            if(source==null)throw new IOException("old WAL not locked");
            synchronized(source){
                requireFrozen(zk,old,node,root,source);
                String installedSource=source.committedPrefixSha256Through(1);
                ensureActiveWal(root,part);
                String mode=request.getOperation();
                String currentSha;
                String digest;
                if(PREPARE.equals(mode) || COMMIT.equals(mode)){
                    if(request.getPayload()==null || request.getPayload().length!=32)
                        throw new IOException("seq2 needs bounded challenge");
                    try(DemoDurableJournal live=new DemoDurableJournal(active(root,part))){
                        if(live.committedSeq()==2 && live.isReadyForWrites()){
                            validateActive(live,part,installedSource,true);
                        } else {
                            if(PREPARE.equals(mode)){
                                // Existing prepared tail will be safely idempotent.
                                if(live.pendingOperation()!=null)
                                    live.prepare(2,2,command(part));
                                else operate(live,part,"",PREPARE);
                            }else {
                                if(live.pendingOperation()==null)
                                    throw new IOException("cannot commit without durable prepare");
                                live.commit(2,2,command(part));
                            }
                        }
                        currentSha=live.committedPrefixSha256();
                        digest=live.state().stateDigest();
                        DemoV19FourNodeReadyPreflight.requireExactRecoveryAssignment(
                            zk,old);
                    }
                    Map<String,Object> out=new LinkedHashMap<>();
                    out.put("scope",SCOPE);out.put("partition",part);
                    out.put("node",node);out.put("phase",mode);
                    out.put("committed",COMMIT.equals(mode));
                    out.put("ready",false);out.put("clientAck",false);
                    out.put("sha",currentSha);out.put("stateDigest",digest);
                    return ReplicationControlResponse.ok(DemoNettyBridge.json(out));
                }
                if(SIGN.equals(mode)){
                    if(request.getPayload()==null || request.getPayload().length!=32)
                        throw new IOException("fresh signed seq2 challenge required");
                    String state;
                    try(DemoDurableJournal wal=new DemoDurableJournal(active(root,part))){
                        state=wal.state().stateDigest();
                        validateActive(wal,part,installedSource,true);
                    }
                    DurableWalCommitQuorum.Membership member=
                        DemoV19FourNodeEpoch2Install.successorMembership(zk,old);
                    DurableWalCommitQuorum.Receipt signed=DurableWalCommitQuorum.sign(
                        member,node,2,durability(part,root,installedSource),key);
                    DurableWalCommitQuorum.requireValidReceipt(member,signed);
                    DemoV19FourNodeReadyPreflight.requireExactRecoveryAssignment(zk,old);
                    Map<String,Object> out=new LinkedHashMap<>();
                    out.put("scope",SCOPE);out.put("partition",part);
                    out.put("nonce",DemoV19FourNodeGenesisPreflight.hex(
                        request.getPayload()));
                    out.put("vote",DemoV19FourNodeSeq1NettyPilot.wire(signed));
                    out.put("stateDigest",state);
                    out.put("ready",false);out.put("clientAck",false);
                    return ReplicationControlResponse.ok(DemoNettyBridge.json(out));
                }
                if(request.getPayload()==null || request.getPayload().length<20
                        || request.getPayload().length>8192)
                    throw new IOException("invalid seq2 double vote");
                @SuppressWarnings("unchecked")
                Map<String,Object> fields=JsonUtils.Deserialize(
                    new String(request.getPayload(),java.nio.charset.StandardCharsets.UTF_8),
                    Map.class);
                if(!SCOPE.equals(fields.get("scope")) ||
                        !part.equals(fields.get("partition")))
                    throw new IOException("cross-partition seq2 receipts");
                List<DurableWalCommitQuorum.Receipt> voters=
                    DemoV19FourNodeSeq1NettyPilot.receiveTwoVotes(fields.get("votes"));
                DurableWalCommitQuorum.Membership member=
                    DemoV19FourNodeEpoch2Install.successorMembership(zk,old);
                String localSha=durability(part,root,installedSource)
                    .requireFsyncedPrefix(2,2);
                DurableWalCommitQuorum.Certificate cert=DurableWalCommitQuorum.verify(
                    member,2,localSha,voters);
                if(cert.authorizesReady())
                    throw new IOException("Common commit certificate cannot grant READY");
                if(INDEX.equals(mode)){
                    if(!node.equals(old.getReplica()))
                        throw new IOException("only new Epoch2 primary can certify index");
                    try(DurableWalCommitIndex index=new DurableWalCommitIndex(
                            root.resolve(".pilot-epoch2-seq2-index-"+part),member)){
                        if(index.committedSequence()==0)
                            index.certifyAndPersist(2,localSha,voters);
                        index.requireExactCertified(2,2,localSha);
                    }
                    DemoV19FourNodeReadyPreflight.requireExactRecoveryAssignment(zk,old);
                    Map<String,Object> ok=new LinkedHashMap<>();
                    ok.put("scope",SCOPE);ok.put("partition",part);
                    ok.put("walSha256",localSha);ok.put("seq",2);
                    ok.put("ready",false);ok.put("clientAck",false);
                    return ReplicationControlResponse.ok(DemoNettyBridge.json(ok));
                }
                DurableWalCertificateCustody.Authority authority=pinned->{
                    DemoV19FourNodeReadyPreflight.requireExactRecoveryAssignment(zk,old);
                    if(!member.digest.equals(pinned.digest))
                        throw new IOException("invalid successor membership for custody");
                };
                DurableWalCustodyQuorum.Receipt receipt;
                try(DurableWalCertificateCustody custody=new DurableWalCertificateCustody(
                        root.resolve(".pilot-epoch2-seq2-custody-"+part),member,
                        durability(part,root,installedSource),authority)){
                    if(custody.install(cert)!=2)
                        throw new IOException("Common seq2 custody not durably installed");
                    receipt=custody.signInstalled(node,key);
                    DurableWalCustodyQuorum.requireValidReceipt(member,cert,receipt);
                }
                DemoV19FourNodeReadyPreflight.requireExactRecoveryAssignment(zk,old);
                Map<String,Object> out=new LinkedHashMap<>();
                out.put("scope",SCOPE);out.put("partition",part);
                out.put("custody",DemoV19FourNodeSeq1NettyPilot.custodyWire(receipt));
                out.put("ready",false);out.put("clientAck",false);
                return ReplicationControlResponse.ok(DemoNettyBridge.json(out));
            }
        }catch(Exception failure){
            return ReplicationControlResponse.error("EPOCH2_SEQ2_INTERNAL_DENIED",
                failure.getClass().getSimpleName()+": "+failure.getMessage());
        }
    }
    @SuppressWarnings("unchecked")
    static void verifySaved(ZookeeperClient zk,PartitionAssignment old)throws Exception{
        String part=old.getPartitionId();
        Stat stat=new Stat();
        Object raw=zk.readData(PROOFS+"/"+part,stat);
        if(raw==null || stat.getVersion()!=0)
            throw new IOException("absent immutable complete seq2 commit proof");
        Map<String,Object> saved=JsonUtils.Deserialize(String.valueOf(raw),Map.class);
        DurableWalCommitQuorum.Membership member=
            DemoV19FourNodeEpoch2Install.successorMembership(zk,old);
        String sha=(String)saved.get("walSha256");
        if(!SCOPE.equals(saved.get("scope")) || !part.equals(saved.get("partition"))
                || !member.digest.equals(saved.get("membershipSha256"))
                || sha==null || !sha.matches("[a-f0-9]{64}")
                || !(saved.get("votes") instanceof List)
                || !(saved.get("custodies") instanceof List))
            throw new IOException("bad isolated seq2 Common ZK proof");
        List<DurableWalCommitQuorum.Receipt> votes=
            DemoV19FourNodeSeq1NettyPilot.receiveTwoVotes(saved.get("votes"));
        DurableWalCommitQuorum.Certificate cert=DurableWalCommitQuorum.verify(
            member,2,sha,votes);
        List<?> physical=(List<?>)saved.get("custodies");
        if(physical.size()!=2)throw new IOException("missing 2/2 durable seq2 custodians");
        List<DurableWalCustodyQuorum.Receipt> heads=new ArrayList<>();
        for(Object value:physical)heads.add(
            DemoV19FourNodeSeq1NettyPilot.custodyFromWire(value));
        DurableWalCustodyQuorum.CustodiedCertificate trusted=
            DurableWalCustodyQuorum.verify(member,cert,heads);
        if(trusted.sequence!=2 || trusted.physicalCustodians!=2
                || trusted.authorizesPromotion())
            throw new IOException("seq2 authority untrusted or grants READY");
    }

    /**
     * After a real process restart, independently verify the complete
     * physical seq2 WAL and LOCAL Common custody. A stale ZK proof or a
     * missing/corrupted local active WAL must prevent this JVM starting.
     */
    @SuppressWarnings("unchecked")
    static void verifyLocalAfterRestart(ZookeeperClient zk,PartitionAssignment old,
            String voter,Path root)throws Exception{
        String part=old.getPartitionId();
        if(!zk.exists(PROOFS+"/"+part))return;
        verifySaved(zk,old);
        Map<String,Object> proof=JsonUtils.Deserialize(String.valueOf(
            zk.readData(PROOFS+"/"+part)),Map.class);
        Map<String,Object> install=JsonUtils.Deserialize(String.valueOf(
            zk.readData(DemoV19FourNodeEpoch2Install.PROOFS+"/"+part)),Map.class);
        String required=(String)proof.get("walSha256");
        String expectedState=(String)proof.get("stateSha256");
        String source=(String)install.get("sourceSha256");
        if(expectedState==null || !expectedState.matches("[a-f0-9]{64}")
                || required==null || !required.matches("[a-f0-9]{64}"))
            throw new IOException("invalid recorded active state or WAL digest");
        try(DemoDurableJournal wal=new DemoDurableJournal(active(root,part))){
            Status actual=validateActive(wal,part,source,true);
            if(!required.equals(actual.sha)
                    || !expectedState.equals(actual.digest))
                throw new IOException("signed seq2 state differs from physical recovery");
        }
        DurableWalCommitQuorum.Membership member=
            DemoV19FourNodeEpoch2Install.successorMembership(zk,old);
        DurableWalCertificateCustody.Authority authority=pinned->{
            if(!member.digest.equals(pinned.digest))
                throw new IOException("tampered new Epoch2 custody membership");
        };
        try(DurableWalCertificateCustody custody=new DurableWalCertificateCustody(
                root.resolve(".pilot-epoch2-seq2-custody-"+part),member,
                durability(part,root,source),authority)){
            DurableWalCommitQuorum.Certificate top=custody.highestVerified();
            if(top==null || top.committedSequence!=2
                    || !required.equals(top.commitPrefixSha256))
                throw new IOException("physical seq2 Common custody not durable");
        }
        if(voter.equals(old.getReplica())){
            try(DurableWalCommitIndex index=new DurableWalCommitIndex(
                    root.resolve(".pilot-epoch2-seq2-index-"+part),member)){
                index.requireExactCertified(2,2,required);
            }
        }
        DemoV19FourNodeReadyPreflight.requireExactRecoveryAssignment(zk,old);
    }

    static void runTwo(ZookeeperClient zk,List<PartitionAssignment> plan)throws Exception{
        DemoV19FourNodeShardCatalog.ensurePath(zk,PROOFS);
        try(DirectNettyReplicationTransport tcp=new DirectNettyReplicationTransport(
                10000,DirectNettyReplicationServer.DEFAULT_MAX_FRAME_BYTES)){
            for(char lead:new char[]{'A','C'}){
                String part=DemoV19FourNodeGenesisPreflight.firstShard(plan,lead);
                PartitionAssignment old=plan.get(Integer.parseInt(part.substring(1)));
                DemoV19FourNodeReadyPreflight.requireExactRecoveryAssignment(zk,old);
                DemoV19FourNodeEpoch2Common.verifyProof(zk,old);
                String prior=PROOFS+"/"+part;
                if(zk.exists(prior))verifySaved(zk,old);
                byte[] nonce=new byte[32];new SecureRandom().nextBytes(nonce);
                String challenge=DemoV19FourNodeGenesisPreflight.hex(nonce);
                String[] peers=DemoV19FourNodeLiveRuntime.owners(old)
                    .toArray(new String[0]);
                for(String phase:new String[]{PREPARE,COMMIT}){
                    for(String peer:peers){
                        ReplicationControlResponse response=tcp.control(
                            DemoV19FourNodeLiveRuntime.exactEndpoint(peer),
                            new ReplicationControlRequest(
                                DemoV19FourNodeShardCatalog.SERVICE,phase,part,nonce))
                            .get(8,TimeUnit.SECONDS);
                        if(!response.isSuccess())throw new IOException(
                            "physical seq2 "+phase+" refused "+peer+": "+response.getMessage());
                        Map<String,Object> receipt=DemoNettyBridge.map(response.getPayload());
                        if(!SCOPE.equals(receipt.get("scope"))
                                || !peer.equals(receipt.get("node"))
                                || !phase.equals(receipt.get("phase"))
                                || !Boolean.FALSE.equals(receipt.get("clientAck")))
                            throw new IOException("seq2 partial staging forged");
                    }
                }
                DurableWalCommitQuorum.Membership member=
                    DemoV19FourNodeEpoch2Install.successorMembership(zk,old);
                String walSha=null,stateSha=null;
                List<DurableWalCommitQuorum.Receipt> signed=new ArrayList<>();
                List<Map<String,Object>> votes=new ArrayList<>();
                for(String peer:peers){
                    ReplicationControlResponse response=tcp.control(
                        DemoV19FourNodeLiveRuntime.exactEndpoint(peer),
                        new ReplicationControlRequest(DemoV19FourNodeShardCatalog.SERVICE,
                            SIGN,part,nonce)).get(8,TimeUnit.SECONDS);
                    if(!response.isSuccess())throw new IOException(
                        "missing committed seq2 signature "+peer+": "+response.getMessage());
                    Map<String,Object> reply=DemoNettyBridge.map(response.getPayload());
                    if(!SCOPE.equals(reply.get("scope"))
                            || !challenge.equals(reply.get("nonce"))
                            || !Boolean.FALSE.equals(reply.get("ready"))
                            || !Boolean.FALSE.equals(reply.get("clientAck")))
                        throw new IOException("scope of seq2 commit vote differs");
                    DurableWalCommitQuorum.Receipt verified=
                        DemoV19FourNodeSeq1NettyPilot.fromWire(reply.get("vote"));
                    if(!peer.equals(verified.node))
                        throw new IOException("seq2 voter impersonation");
                    String digest=(String)reply.get("stateDigest");
                    if(walSha!=null && (!walSha.equals(verified.commitPrefixSha256)
                            || !stateSha.equals(digest)))
                        throw new IOException("physical seq2 WAL/state divergence");
                    walSha=verified.commitPrefixSha256;stateSha=digest;
                    DurableWalCommitQuorum.requireValidReceipt(member,verified);
                    signed.add(verified);
                    votes.add(DemoV19FourNodeSeq1NettyPilot.wire(verified));
                }
                DurableWalCommitQuorum.Certificate cert=DurableWalCommitQuorum.verify(
                    member,2,walSha,signed);
                Map<String,Object> commit=new LinkedHashMap<>();
                commit.put("scope",SCOPE);commit.put("partition",part);commit.put("votes",votes);
                ReplicationControlResponse idx=tcp.control(
                    DemoV19FourNodeLiveRuntime.exactEndpoint(old.getReplica()),
                    new ReplicationControlRequest(DemoV19FourNodeShardCatalog.SERVICE,
                        INDEX,part,DemoNettyBridge.json(commit))).get(8,TimeUnit.SECONDS);
                if(!idx.isSuccess())throw new IOException(
                    "new Epoch2 primary seq2 index refused: "+idx.getMessage());
                List<Map<String,Object>> custodyWire=new ArrayList<>();
                List<DurableWalCustodyQuorum.Receipt> custodians=new ArrayList<>();
                for(String peer:peers){
                    ReplicationControlResponse saved=tcp.control(
                        DemoV19FourNodeLiveRuntime.exactEndpoint(peer),
                        new ReplicationControlRequest(DemoV19FourNodeShardCatalog.SERVICE,
                            CUSTODY,part,DemoNettyBridge.json(commit))).get(8,TimeUnit.SECONDS);
                    if(!saved.isSuccess())throw new IOException(
                        "physical Common seq2 custody missing "+peer+": "+saved.getMessage());
                    Map<String,Object> body=DemoNettyBridge.map(saved.getPayload());
                    DurableWalCustodyQuorum.Receipt receipt=
                        DemoV19FourNodeSeq1NettyPilot.custodyFromWire(body.get("custody"));
                    if(!peer.equals(receipt.node))throw new IOException("wrong signed custodian");
                    DurableWalCustodyQuorum.requireValidReceipt(member,cert,receipt);
                    custodians.add(receipt);
                    custodyWire.add(DemoV19FourNodeSeq1NettyPilot.custodyWire(receipt));
                }
                DurableWalCustodyQuorum.CustodiedCertificate quorum=
                    DurableWalCustodyQuorum.verify(member,cert,custodians);
                if(quorum.sequence!=2 || quorum.physicalCustodians!=2
                        || quorum.authorizesPromotion())
                    throw new IOException("real seq2 custody not two independent replicas");
                Map<String,Object> record=new LinkedHashMap<>();
                record.put("scope",SCOPE);record.put("partition",part);
                record.put("membershipSha256",member.digest);
                record.put("walSha256",walSha);record.put("stateSha256",stateSha);
                record.put("votes",votes);record.put("custodies",custodyWire);
                if(!zk.exists(prior)){
                    try{zk.create(prior,JsonUtils.Serializer(record),CreateMode.PERSISTENT);}
                    catch(ZkNodeExistsException raced){}
                }
                verifySaved(zk,old);
                DemoV19FourNodeReadyPreflight.requireExactRecoveryAssignment(zk,old);
                System.out.println("FOUR_NODE_EPOCH2_REAL_SEQ2_COMMIT_PASS partition="+part+
                    " epoch=2 seq=2 independentPhysicalCommits=2"+
                    " commonCommitIndex=true signedReceipts=2 signedCustodies=2"+
                    " sha256="+walSha+" stateSha256="+stateSha+
                    " zkState=RECOVERING ready=false realClientAck=false");
            }
        }
    }
}