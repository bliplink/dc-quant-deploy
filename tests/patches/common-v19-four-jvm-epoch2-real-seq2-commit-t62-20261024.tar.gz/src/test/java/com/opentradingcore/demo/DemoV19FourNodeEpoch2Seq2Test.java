package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;
import java.io.IOException;
import java.nio.file.*;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import static org.junit.Assert.*;

/** Durable Epoch2 seq2 data-state tests: no ZK, no customer ACK. */
public final class DemoV19FourNodeEpoch2Seq2Test {
    @Rule public TemporaryFolder folder=new TemporaryFolder();

    private Path baseline(String partition)throws Exception{
        Path root=folder.newFolder("source-"+partition).toPath();
        PartitionAssignment old=DemoV19FourNodeShardCatalog.layout().get(
            Integer.parseInt(partition.substring(1)));
        Path original=root.resolve("epoch1.wal");
        byte[] state,baseline;
        try(DemoDurableJournal previous=new DemoDurableJournal(original)){
            previous.installEmptyGenesis(1,partition,
                DemoV19FourNodeGenesisPreflight.exactAssignmentDigest(old));
            previous.prepareAndCommitSingleForce(1,1,new DemoStateMachine.Operation(
                DemoV19FourNodeSeq1NettyPilot.requestId(partition),
                DemoV19FourNodeSeq1NettyPilot.delta(partition)));
            state=previous.state().captureSnapshot();
            baseline=previous.certifiedEpoch2SnapshotWalBytes(
                previous.committedPrefixSha256Through(1),state);
        }
        Path active=root.resolve("active.wal");
        Files.write(active,baseline,StandardOpenOption.CREATE_NEW);
        return active;
    }

    @Test public void preparedEpoch2WalHasNoCommitUntilForcedCommitAfterRestart()
            throws Exception {
        Path active=baseline("P000");
        DemoStateMachine.Operation op=new DemoStateMachine.Operation(
            DemoV19FourNodeEpoch2Seq2.requestId("P000"),19);
        String before;
        try(DemoDurableJournal wal=new DemoDurableJournal(active)){
            assertEquals(1,wal.committedSeq());
            before=wal.committedPrefixSha256Through(1);
            wal.prepare(2,2,op);
            assertEquals(1,wal.committedSeq());
            assertEquals(11,wal.state().total());
            assertEquals(0,wal.state().appliedCount(op.requestId));
        }
        try(DemoDurableJournal wal=new DemoDurableJournal(active)){
            assertNotNull(wal.pendingOperation());
            assertEquals(1,wal.committedSeq());
            assertEquals(11,wal.state().total());
            wal.prepare(2,2,op); // same already forced PREPARE
            wal.commit(2,2,op);
            assertEquals(2,wal.committedSeq());
            assertEquals(30,wal.state().total());
            assertEquals(1,wal.state().appliedCount(op.requestId));
            assertNotEquals(before,wal.committedPrefixSha256Through(2));
        }
        try(DemoDurableJournal wal=new DemoDurableJournal(active)){
            assertTrue(wal.isReadyForWrites());
            assertEquals(2,wal.lastEpoch());
            assertEquals(2,wal.committedSeq());
            assertEquals(2,wal.state().distinctRequests());
            assertEquals(30,wal.state().total());
            wal.commit(2,2,op); // exact retry does not apply twice
            assertEquals(1,wal.state().appliedCount(op.requestId));
            assertEquals(30,wal.state().total());
        }
    }

    @Test public void differentRequestCannotStealPreparedSeq2()throws Exception{
        Path active=baseline("P128");
        DemoStateMachine.Operation good=new DemoStateMachine.Operation(
            DemoV19FourNodeEpoch2Seq2.requestId("P128"),23);
        try(DemoDurableJournal wal=new DemoDurableJournal(active)){
            wal.prepare(2,2,good);
        }
        try(DemoDurableJournal wal=new DemoDurableJournal(active)){
            try{
                wal.commit(2,2,new DemoStateMachine.Operation("FORKED",99));
                fail("conflicting transaction committed");
            }catch(IllegalStateException expected){}
            assertEquals(1,wal.committedSeq());
            wal.commit(2,2,good);
            assertEquals(2,wal.committedSeq());
            assertEquals(40,wal.state().total());
        }
        try(DemoDurableJournal wal=new DemoDurableJournal(active)){
            assertEquals(2,wal.committedSeq());
            assertEquals(40,wal.state().total());
            assertEquals(1,wal.state().appliedCount(good.requestId));
        }
    }
}