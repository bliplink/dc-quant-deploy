package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;
import java.nio.file.*;
import java.util.*;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import static org.junit.Assert.*;

public final class DemoV19FourNodeWalSlotsTest {
    @Rule public TemporaryFolder folder=new TemporaryFolder();
    @Test public void opensOnly128BalancedWalFilesOnEachNode() throws Exception {
        List<PartitionAssignment> plan=DemoV19FourNodeShardCatalog.layout();
        for(char suffix='A';suffix<='D';suffix++){
            Path root=folder.newFolder("wal-"+suffix).toPath();
            assertEquals(128,DemoV19FourNodeWalSlots.initialize(
                    plan,"CommonHaDemo"+suffix,root));
            try(java.util.stream.Stream<Path> files=Files.list(root)){
                assertEquals(128L,files.count());
            }
            assertEquals(128,DemoV19FourNodeWalSlots.initialize(
                    plan,"CommonHaDemo"+suffix,root));
        }
    }
    @Test public void refusesOverlappingOrForeignWalOnOneVolume() throws Exception {
        List<PartitionAssignment> plan=DemoV19FourNodeShardCatalog.layout();
        Path root=folder.newFolder("mixed").toPath();
        assertEquals(128,DemoV19FourNodeWalSlots.initialize(plan,"CommonHaDemoA",root));
        try{
            DemoV19FourNodeWalSlots.initialize(plan,"CommonHaDemoC",root);
            fail("foreign pair must never own another buddy WAL");
        }catch(java.io.IOException expected) {}
    }
    @Test public void neverClearsPreviouslyWrittenOrDirtyWal() throws Exception{
        List<PartitionAssignment> plan=DemoV19FourNodeShardCatalog.layout();
        Path root=folder.newFolder("dirty").toPath();
        DemoV19FourNodeWalSlots.initialize(plan,"CommonHaDemoA",root);
        try(DemoDurableJournal journal=new DemoDurableJournal(root.resolve("P000.wal"))){
            journal.prepare(1,1,new DemoStateMachine.Operation("must-keep",1));
        }
        try{
            DemoV19FourNodeWalSlots.initialize(plan,"CommonHaDemoA",root);
            fail("cannot accept dirty WAL as empty new Genesis");
        }catch(java.io.IOException expected){}
        assertTrue(Files.size(root.resolve("P000.wal"))>0);
    }
}
