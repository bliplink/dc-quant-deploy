package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;
import java.util.*;
import org.junit.Test;
import static org.junit.Assert.*;

public class DemoV19FourNodeShardCatalogTest {
    @Test public void exactly256PartitionsAnd64Primary64StandbyForEveryNode(){
        List<PartitionAssignment> plan=DemoV19FourNodeShardCatalog.layout();
        assertEquals(256,plan.size());
        for(char c='A';c<='D';c++){
            DemoV19FourNodeShardCatalog.Counts count=
                DemoV19FourNodeShardCatalog.verifyLayout(plan,"CommonHaDemo"+c);
            assertEquals(64,count.primary);
            assertEquals(64,count.replica);
            assertEquals(128,count.other);
        }
    }
    @Test public void neverAuthorizeReadyByCatalogOnly(){
        for(PartitionAssignment a:DemoV19FourNodeShardCatalog.layout()){
            assertEquals("PREPARING",a.getState());
            assertFalse(a.isRoutable());
            assertEquals(2,a.getProtocolVersion()); // planning protocol; still PREPARING
        }
    }
    @Test public void zkCatalogRejectsCASVersionChangesAndForks(){
        PartitionAssignment a=DemoV19FourNodeShardCatalog.layout().get(0);
        String expected=DemoV19FourNodeShardCatalog.encode(a);
        DemoV19FourNodeShardCatalog.assertPersisted(a,expected,0);
        denied(()->DemoV19FourNodeShardCatalog.assertPersisted(a,expected,1));
        denied(()->DemoV19FourNodeShardCatalog.assertPersisted(a,expected.replace(
            "PREPARING","READY"),0));
        denied(()->DemoV19FourNodeShardCatalog.assertPersisted(a,expected+" ",0));
    }
    @Test public void layoutRejectsOutOfPairAssignments(){
        List<PartitionAssignment> broken=new ArrayList<>(DemoV19FourNodeShardCatalog.layout());
        broken.get(0).setReplicas(Collections.singletonList("CommonHaDemoD"));
        denied(()->DemoV19FourNodeShardCatalog.verifyLayout(broken,"CommonHaDemoA"));
    }
    @Test public void layoutRejectsPrematureReadyAndUnexpectedMember(){
        List<PartitionAssignment> broken=new ArrayList<>(DemoV19FourNodeShardCatalog.layout());
        broken.get(0).setState("READY");
        denied(()->DemoV19FourNodeShardCatalog.verifyLayout(broken,"CommonHaDemoA"));
        denied(()->DemoV19FourNodeShardCatalog.verifyLayout(
            DemoV19FourNodeShardCatalog.layout(),"CommonHaDemoE"));
    }
    private static void denied(Runnable action){
        try{action.run();fail("unauthorized metadata accepted");}
        catch(IllegalArgumentException|IllegalStateException expected){}
    }
}
