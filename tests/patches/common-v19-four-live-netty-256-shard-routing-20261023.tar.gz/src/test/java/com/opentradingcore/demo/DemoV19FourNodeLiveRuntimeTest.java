package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;
import com.app.common.replication.ReplicationEndpoint;
import java.util.*;
import org.junit.Test;
import static org.junit.Assert.*;

public class DemoV19FourNodeLiveRuntimeTest {
    @Test public void preciseNodePortsAndNoFifthNode(){
        for(char c='A';c<='D';c++){
            ReplicationEndpoint e=DemoV19FourNodeLiveRuntime.exactEndpoint("CommonHaDemo"+c);
            assertEquals("otc-ha-agent-"+Character.toLowerCase(c),e.getHost());
            assertEquals(35411+c-'A',e.getPort());
        }
        try{
            DemoV19FourNodeLiveRuntime.exactEndpoint("CommonHaDemoE");
            fail("fifth node must be rejected");
        }catch(IllegalArgumentException expected){}
    }
    @Test public void bothBuddyTargetsArePartitionBound(){
        for(PartitionAssignment a:DemoV19FourNodeShardCatalog.layout()){
            List<String> targets=DemoV19FourNodeLiveRuntime.owners(a);
            assertEquals(2,targets.size());
            assertEquals(a.getPrimary(),targets.get(0));
            assertEquals(a.getReplica(),targets.get(1));
            assertNotEquals(targets.get(0),targets.get(1));
        }
    }
    @Test public void rejectForgedReadyAndWrongMemberEvidence()throws Exception{
        Map<String,Object> status=new LinkedHashMap<>();
        status.put("partitionId","P000");
        status.put("node","CommonHaDemoA");
        status.put("role","PRIMARY_SLOT");
        status.put("state","PREPARING");
        status.put("ready",false);
        status.put("quorumDurable",false);
        status.put("clean",true);
        status.put("committedSeq",0);
        status.put("zkVersion",0);
        DemoV19FourNodeLiveRuntime.assertStatus(status,"P000",
            "CommonHaDemoA","PRIMARY_SLOT");
        status.put("ready",true);
        denied(()->DemoV19FourNodeLiveRuntime.assertStatus(
            status,"P000","CommonHaDemoA","PRIMARY_SLOT"));
        status.put("ready",false);
        denied(()->DemoV19FourNodeLiveRuntime.assertStatus(
            status,"P000","CommonHaDemoB","PRIMARY_SLOT"));
        status.put("state","READY");
        denied(()->DemoV19FourNodeLiveRuntime.assertStatus(
            status,"P000","CommonHaDemoA","PRIMARY_SLOT"));
    }
    private interface Unsafe{void run()throws Exception;}
    private static void denied(Unsafe action){
        try{action.run();fail("accepted forged four-node READY or identity");}
        catch(Exception expected){}
    }
}
