package com.opentradingcore.demo;

import com.app.common.replication.*;
import java.nio.file.Path;
import java.util.Collections;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

/** Real Common Netty client/server framing, without changing cluster state. */
public class DemoNettyBridgeTest {
    @Rule public TemporaryFolder folder = new TemporaryFolder();

    @Test public void exactFourNodeBridgePortsHaveNoAccidentalExtraPeers(){
        for(char suffix='A';suffix<='D';suffix++){
            ReplicationEndpoint route=DemoNettyBridge.endpoint("CommonHaDemo"+suffix);
            Assert.assertEquals(35411+suffix-'A',route.getPort());
            Assert.assertEquals("otc-ha-demo-"+Character.toLowerCase(suffix),route.getHost());
        }
        try{
            DemoNettyBridge.endpoint("CommonHaDemoE");
            Assert.fail("illegal fifth replica must be rejected");
        }catch(IllegalArgumentException expected){}
    }

    @Test public void statusAndFailClosedBatchOnExactNettyPeer() throws Exception {
        Path path = folder.newFolder("wal").toPath();
        try (DemoJournalCatalog catalog = new DemoJournalCatalog("A", path);
             DirectNettyReplicationServer server = new DirectNettyReplicationServer(
                     "127.0.0.1", 0,
                     batch -> DemoNettyBridge.apply(catalog, "A", batch),
                     request -> DemoNettyBridge.control(catalog, "A", request));
             DirectNettyReplicationTransport tcp = new DirectNettyReplicationTransport()) {
            server.start();
            ReplicationEndpoint destination = new ReplicationEndpoint("CommonHaDemoA",
                    "127.0.0.1", server.getBoundPort());
            ReplicationControlResponse reply = tcp.control(destination,
                    new ReplicationControlRequest("CommonHaDemo", "STATUS", "P000", new byte[0]))
                    .get(6, TimeUnit.SECONDS);
            Assert.assertTrue(reply.isSuccess());
            Map<String,Object> status = DemoNettyBridge.map(reply.getPayload());
            Assert.assertEquals("A", status.get("node"));
            Assert.assertEquals("P000", status.get("partitionId"));
            Assert.assertEquals(0L, ((Number) status.get("committedSeq")).longValue());
            Assert.assertEquals(true, status.get("clean"));
            ReplicationBatch invalid = new ReplicationBatch("WrongService", "P000", 1L,
                    Collections.singletonList(new ReplicationRecord(1L, "DEMO_WAL_COMMIT",
                            "wrong-service", 0L, new byte[] {1, 2, 3})));
            ReplicationAck ack = tcp.replicate(destination, invalid).get(6, TimeUnit.SECONDS);
            Assert.assertFalse(ack.isSuccess());
            ReplicationControlResponse unsupported = tcp.control(destination,
                    new ReplicationControlRequest("CommonHaDemo", "NO_SUCH_OP", "P000", new byte[0]))
                    .get(6, TimeUnit.SECONDS);
            Assert.assertFalse(unsupported.isSuccess());
            Assert.assertEquals(0L, catalog.journal("P000").committedSeq());
        }
    }
}
