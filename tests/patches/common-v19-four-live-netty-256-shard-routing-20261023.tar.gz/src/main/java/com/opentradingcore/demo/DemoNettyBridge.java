package com.opentradingcore.demo;

import com.app.common.replication.*;
import com.gateway.connector.utils.JsonUtils;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/** Isolated Demo adapter of the EXISTING Common direct Netty TCP frames.
 * Snapshot and recovery management intentionally remain on their existing paths.
 * Do not use this adapter to declare the production Common mechanism validated.
 */
final class DemoNettyBridge {
    private static final String SERVICE = "CommonHaDemo";
    private static final String EVENT = "DEMO_WAL_COMMIT";
    private static final int BATCH_MAX = 8;
    private static final long WAIT_SECONDS = 14;
    // A dead peer must not consume the entire 1.8s quorum certificate window
    // before the other replica gets its independent WAL replication pass.
    // STATUS is an advisory read-only locator, NOT a signed ACK or authority.
    private static final long STATUS_WAIT_MILLIS = 280L;
    static long controlWaitMillis(String operation) {
        return "STATUS".equals(operation)
                ? STATUS_WAIT_MILLIS : TimeUnit.SECONDS.toMillis(WAIT_SECONDS);
    }
    private static volatile DirectNettyReplicationTransport transport;
    private DemoNettyBridge() {}

    static boolean enabled() {
        return "netty".equals(System.getenv("DEMO_REPLICATION_TRANSPORT"));
    }

    static synchronized DirectNettyReplicationTransport transport() {
        if (transport == null) transport = new DirectNettyReplicationTransport(12000,
                DirectNettyReplicationServer.DEFAULT_MAX_FRAME_BYTES);
        return transport;
    }

    static synchronized void closeClient() {
        if (transport != null) { transport.close(); transport = null; }
    }

    static ReplicationEndpoint endpoint(String replica) {
        if (replica == null || !replica.matches("CommonHaDemo[ABCD]"))
            throw new IllegalArgumentException("unsupported exact Netty replica: " + replica);
        char suffix = Character.toLowerCase(replica.charAt(replica.length() - 1));
        return new ReplicationEndpoint(replica, "otc-ha-demo-" + suffix,
                35411 + suffix - 'a');
    }

    static byte[] json(Object object) { return JsonUtils.Serializer(object).getBytes(StandardCharsets.UTF_8); }

    @SuppressWarnings("unchecked")
    static Map<String, Object> map(byte[] value) throws IOException {
        Map<String, Object> result = JsonUtils.Deserialize(new String(value, StandardCharsets.UTF_8), Map.class);
        if (result == null) throw new IOException("Netty control payload missing");
        return result;
    }

    static ReplicationControlResponse control(DemoJournalCatalog journals, String node,
            ReplicationControlRequest request) {
        try {
            if (!SERVICE.equals(request.getServiceName()))
                throw new IOException("wrong replicated service");
            String partition = request.getPartitionId();
            if (!partition.matches("P\\d{3}")) throw new IOException("partition invalid");
            DemoDurableJournal wal = journals.journal(partition);
            if ("STATUS".equals(request.getOperation())) {
                return ReplicationControlResponse.ok(json(journals.physicalStatus(partition)));
            }
            if ("HASH_THROUGH".equals(request.getOperation())) {
                Map<String,Object> values = map(request.getPayload());
                long seq = number(values.get("seq"));
                Map<String,Object> response = new LinkedHashMap<String,Object>();
                synchronized (wal) {
                    if (!wal.isReadyForWrites() || seq > wal.committedSeq())
                        throw new IOException("replica is not clean or not durable through requested sequence");
                    response.put("committedPrefixSha256", wal.committedPrefixSha256Through(seq));
                    response.put("committedSeq", seq);
                }
                response.put("partitionId", partition);
                response.put("node", SERVICE + node);
                return ReplicationControlResponse.ok(json(response));
            }
            if ("PREPARE".equals(request.getOperation()) || "COMMIT".equals(request.getOperation())) {
                Map<String,Object> values = map(request.getPayload());
                long epoch = number(values.get("epoch"));
                long seq = number(values.get("seq"));
                String primary = required(values.get("primary"));
                DemoStateMachine.Operation op = new DemoStateMachine.Operation(
                        required(values.get("requestId")), number(values.get("delta")));
                String replica = SERVICE + node;
                DemoHotpathControl.requireCurrent(partition, epoch, primary, replica);
                Map<String,Object> response = new LinkedHashMap<String,Object>();
                synchronized (wal) {
                    DemoHotpathControl.requireCurrent(partition, epoch, primary, replica);
                    DemoHotpathControl.requireReplicaQuorum(partition, epoch, primary, replica);
                    if ("PREPARE".equals(request.getOperation())) wal.prepare(epoch,seq,op);
                    else wal.commit(epoch,seq,op);
                    DemoHotpathControl.requireCurrent(partition, epoch, primary, replica);
                    response.put("node", replica);
                    response.put("partitionId", partition);
                    response.put("epoch", epoch);
                    response.put("seq", seq);
                    response.put("committedSeq", wal.committedSeq());
                    response.put("committedPrefixSha256", wal.committedPrefixSha256());
                    response.put("ok", true);
                }
                return ReplicationControlResponse.ok(json(response));
            }
            throw new IOException("unsupported Netty control operation");
        } catch (Exception failure) {
            return ReplicationControlResponse.error("DENIED",
                    failure.getClass().getSimpleName() + ": " + failure.getMessage());
        }
    }

    static ReplicationAck apply(DemoJournalCatalog journals,String node,ReplicationBatch batch) {
        return apply(journals,node,batch,null);
    }

    static ReplicationAck apply(DemoJournalCatalog journals,String node,
            ReplicationBatch batch,DemoV19DurableRuntime signer) {
        String partition = batch.getPartitionId();
        try {
            if (!enabled() || !"1".equals(System.getenv("DEMO_ASYNC_REPLICATION"))
                    || !"1".equals(System.getenv("DEMO_TWO_NODE_ASYNC")))
                throw new IOException("Netty async replica is not explicitly enabled");
            if (!SERVICE.equals(batch.getServiceName()) || batch.size() > BATCH_MAX
                    || !partition.matches("P\\d{3}")) throw new IOException("invalid demo Netty batch");
            String replica = SERVICE + node;
            DemoDurableJournal wal = journals.journal(partition);
            synchronized (wal) {
                if (batch.getFirstSeq() != wal.committedSeq() + 1)
                    return new ReplicationAck(ReplicationStatus.GAP, partition, batch.getEpoch(),
                            wal.committedSeq(), wal.committedSeq() + 1, "replica durable boundary differs");
                boolean noFaultInjectedRecords=true;
                for(ReplicationRecord item:batch.getRecords()) {
                    if(DemoFaultHook.forRequest(partition,item.getEventId())!=null) {
                        noFaultInjectedRecords=false;
                        break;
                    }
                }
                if ("1".equals(System.getenv("DEMO_V19_GROUP_FORCE_PILOT"))
                        && batch.size() > 1 && noFaultInjectedRecords) {
                    // All records and epoch grants validated before any WAL
                    // bytes are written. Only Common handles group force.
                    List<DemoStateMachine.Operation> group =
                            new ArrayList<DemoStateMachine.Operation>();
                    long expected=wal.committedSeq()+1;
                    String source=null;
                    for (ReplicationRecord item : batch.getRecords()) {
                        if(!EVENT.equals(item.getEventType())
                                || item.getPayload().length>8192
                                || item.getSeq()!=expected++)
                            throw new IOException("bad ordered WAL replica group");
                        Map<String,Object> details=map(item.getPayload());
                        String primary=required(details.get("primary"));
                        if(source!=null && !source.equals(primary))
                            throw new IOException("mixed group primary not allowed");
                        source=primary;
                        DemoHotpathControl.requireCurrent(partition,batch.getEpoch(),primary,replica);
                        DemoHotpathControl.requireReplicaQuorum(partition,batch.getEpoch(),primary,replica);
                        group.add(new DemoStateMachine.Operation(
                                required(item.getEventId()),number(details.get("delta"))));
                    }
                    wal.prepareAndCommitGroupForce(batch.getEpoch(),group);
                    DemoHotpathControl.requireCurrent(partition,batch.getEpoch(),source,replica);
                    DemoHotpathControl.requireReplicaQuorum(partition,batch.getEpoch(),source,replica);
                    ReplicationAck done=ReplicationAck.ok(partition,batch.getEpoch(),wal.committedSeq());
                    return signer!=null && "1".equals(System.getenv("DEMO_V19_SIGNED_BATCH_ACK_PILOT"))
                            ? signer.signedBatchAck(done):done;
                }
                for (ReplicationRecord item : batch.getRecords()) {
                    if (!EVENT.equals(item.getEventType()) || item.getPayload().length > 8192)
                        throw new IOException("unrecognized or oversized WAL record");
                    Map<String,Object> details = map(item.getPayload());
                    String primary = required(details.get("primary"));
                    DemoStateMachine.Operation operation = new DemoStateMachine.Operation(
                            required(item.getEventId()), number(details.get("delta")));
                    DemoHotpathControl.requireCurrent(partition, batch.getEpoch(), primary, replica);
                    DemoHotpathControl.requireReplicaQuorum(partition, batch.getEpoch(), primary, replica);
                    wal.prepare(batch.getEpoch(), item.getSeq(), operation);
                    DemoHotpathControl.requireCurrent(partition, batch.getEpoch(), primary, replica);
                    DemoHotpathControl.requireReplicaQuorum(partition, batch.getEpoch(), primary, replica);
                    wal.commit(batch.getEpoch(), item.getSeq(), operation);
                    DemoHotpathControl.requireCurrent(partition, batch.getEpoch(), primary, replica);
                }
                ReplicationAck done=ReplicationAck.ok(partition,batch.getEpoch(),wal.committedSeq());
                return signer!=null && "1".equals(System.getenv("DEMO_V19_SIGNED_BATCH_ACK_PILOT"))
                        ? signer.signedBatchAck(done):done;
            }
        } catch (Exception failure) {
            return new ReplicationAck(ReplicationStatus.ERROR, partition, batch.getEpoch(),
                    0L, batch.getFirstSeq(), failure.getClass().getSimpleName() + ": " + failure.getMessage());
        }
    }

    static DirectNettyReplicationServer server(String node, DemoJournalCatalog journals) {
        return server(node, journals, request -> control(journals, node, request));
    }

    static DirectNettyReplicationServer server(String node,DemoJournalCatalog journals,
            ReplicationControlHandler controlHandler) {
        return server(node,journals,controlHandler,null);
    }

    static DirectNettyReplicationServer server(String node,DemoJournalCatalog journals,
            ReplicationControlHandler controlHandler,DemoV19DurableRuntime signer) {
        if(node == null || !node.matches("[ABCD]"))
            throw new IllegalArgumentException("only exact A/B/C/D Netty node supported");
        int port=35411+node.charAt(0)-'A';
        return new DirectNettyReplicationServer("0.0.0.0", port,
                batch -> apply(journals,node,batch,signer),
                controlHandler);
    }

    static Map<String,Object> call(String replica, String operation, String partition, Object payload)
            throws IOException {
        ReplicationControlRequest request = new ReplicationControlRequest(
                SERVICE, operation, partition, json(payload == null ? new LinkedHashMap<String,Object>() : payload));
        ReplicationControlResponse response;
        java.util.concurrent.Future<ReplicationControlResponse> pending=null;
        try {
            pending=transport().control(endpoint(replica), request);
            response=pending.get(controlWaitMillis(operation),TimeUnit.MILLISECONDS);
        } catch (InterruptedException interruption) {
            Thread.currentThread().interrupt();
            throw new IOException("Netty control interrupted", interruption);
        } catch (ExecutionException | TimeoutException failure) {
            throw new IOException("Netty control failed " + operation, failure);
        } finally {
            if(pending!=null && !pending.isDone())pending.cancel(true);
        }
        if (!response.isSuccess()) throw new IOException("Netty " + operation + " denied: " + response.getMessage());
        Map<String,Object> decoded = map(response.getPayload());
        String expectedNode = "STATUS".equals(operation)
                ? replica.substring(replica.length() - 1) : replica;
        if (!expectedNode.equals(decoded.get("node")) || !partition.equals(decoded.get("partitionId")))
            throw new IOException("Netty control peer identity/partition mismatch");
        return decoded;
    }

    static Map<String,Object> send(String replica, String phase, String partition, String primary,
            long epoch, long seq, DemoStateMachine.Operation op) throws IOException {
        Map<String,Object> command = new LinkedHashMap<String,Object>();
        command.put("primary", primary);
        command.put("epoch", epoch);
        command.put("seq", seq);
        command.put("requestId", op.requestId);
        command.put("delta", op.delta);
        Map<String,Object> response = call(replica, phase.toUpperCase(java.util.Locale.ROOT), partition, command);
        if (!Boolean.TRUE.equals(response.get("ok")) || number(response.get("epoch")) != epoch
                || number(response.get("seq")) != seq || ("commit".equals(phase)
                && number(response.get("committedSeq")) != seq))
            throw new IOException("Netty prepare/commit response not at durable boundary");
        return response;
    }

    static Map<String,Object> batch(String replica, String partition, String primary,
            long epoch, List<DemoDurableJournal.CommittedRecord> records) throws IOException {
        if (records == null || records.isEmpty() || records.size() > BATCH_MAX)
            throw new IOException("invalid batch size");
        List<ReplicationRecord> entries = new ArrayList<ReplicationRecord>();
        long expected = records.get(0).seq;
        for (DemoDurableJournal.CommittedRecord record : records) {
            if (record.seq != expected++ || record.epoch != epoch)
                throw new IOException("mixed epoch or non-contiguous batch");
            Map<String,Object> data = new LinkedHashMap<String,Object>();
            data.put("primary",primary);
            data.put("delta",record.operation.delta);
            entries.add(new ReplicationRecord(record.seq, EVENT, record.operation.requestId, 0L, json(data)));
        }
        ReplicationBatch batch = new ReplicationBatch(SERVICE, partition, epoch, entries);
        ReplicationAck ack;
        try {
            ack = transport().replicate(endpoint(replica), batch).get(WAIT_SECONDS, TimeUnit.SECONDS);
        } catch (InterruptedException interruption) {
            Thread.currentThread().interrupt();
            throw new IOException("Netty batch interrupted", interruption);
        } catch (ExecutionException | TimeoutException failure) {
            throw new IOException("Netty batch RPC failed", failure);
        }
        if (!ack.isSuccess() || !partition.equals(ack.getPartitionId())
                || ack.getEpoch() != epoch || ack.getReplicatedSeq() != batch.getLastSeq())
            throw new IOException("Netty peer rejected batch: " + ack);
        if("1".equals(System.getenv("DEMO_V19_SIGNED_BATCH_ACK_PILOT"))) {
            // No separate HASH_THROUGH RTT. The caller must independently
            // verify RSA/epoch/identity and expected local hash BEFORE
            // publishing any replica watermark or using as a quorum vote.
            Map<String,Object> deferred=new LinkedHashMap<String,Object>();
            deferred.put("signedBatchAck",ack);
            deferred.put("committedSeq",ack.getReplicatedSeq());
            deferred.put("epoch",ack.getEpoch());
            deferred.put("ok",true);
            return deferred;
        }
        Map<String,Object> query = new LinkedHashMap<String,Object>();
        query.put("seq",batch.getLastSeq());
        Map<String,Object> verified = call(replica,"HASH_THROUGH",partition,query);
        if (number(verified.get("committedSeq")) != batch.getLastSeq()
                || !(verified.get("committedPrefixSha256") instanceof String))
            throw new IOException("Netty prefix proof not at exact batch boundary");
        verified.put("ok",true);
        verified.put("epoch",epoch);
        return verified;
    }

    private static String required(Object value) throws IOException {
        if (!(value instanceof String) || ((String) value).trim().isEmpty())
            throw new IOException("missing required Netty identity");
        return (String) value;
    }
    private static long number(Object value) throws IOException {
        if (!(value instanceof Number)) throw new IOException("invalid Netty numeric field");
        return ((Number) value).longValue();
    }
}
