package com.opentradingcore.demo;

import com.gateway.connector.utils.JsonUtils;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.nio.channels.FileChannel;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;
import java.util.Base64;
import java.nio.file.DirectoryStream;
import com.app.common.replication.LocalArchiveQuarantineFileOps;
import com.app.common.replication.CertifiedDirtyTailBoundaryGuard;

/** Owns independent physical WAL files and a read-only, bridge-local proof endpoint. */
public final class DemoJournalCatalog implements AutoCloseable {
    private final String node;
    private final Map<String, DemoDurableJournal> journals = new ConcurrentHashMap<String, DemoDurableJournal>();
    private HttpServer statusServer;

    public DemoJournalCatalog(String node, Path dataRoot) throws IOException {
        if(node == null || !node.matches("[ABCD]")) {
            throw new IllegalArgumentException("node must be A/B/C/D");
        }
        if (dataRoot == null) throw new IllegalArgumentException("data root required");
        this.node = node;
        Files.createDirectories(dataRoot);
        try {
            for (int index = 0; index < 256; index++) {
                String partitionId = String.format("P%03d", index);
                journals.put(partitionId, new DemoDurableJournal(dataRoot.resolve(partitionId + ".wal")));
            }
        } catch (IOException | RuntimeException failure) {
            close();
            throw failure;
        }
    }

    public synchronized void startReadOnlyStatus(int port) throws IOException {
        if (Boolean.getBoolean("demo.v19.hotpath.enabled"))
            throw new IOException("v19 forbids HTTP endpoints; use Common Netty TCP control frames");
        if (statusServer != null) throw new IllegalStateException("status server already started");
        HttpServer server = HttpServer.create(new InetSocketAddress("0.0.0.0", port), 16);
        server.createContext("/internal/status", this::handleStatus);
        server.createContext("/internal/snapshot", this::handleSnapshot);
        server.createContext("/internal/prepare", exchange -> handleWrite(exchange, false));
        server.createContext("/internal/commit", exchange -> handleWrite(exchange, true));
        server.createContext("/internal/batch", this::handleCertifiedBatch);
        server.createContext("/internal/recover", this::handleRecovery);
        server.createContext("/internal/forward-recover", this::handleForwardRecovery);
        server.createContext("/internal/checkpoint", this::handleCheckpoint);
        server.createContext("/internal/archive-proof", this::handleArchiveProof);
        server.createContext("/internal/rollback-checkpoint", this::handleCheckpointRollback);
        server.setExecutor(java.util.concurrent.Executors.newFixedThreadPool(16, runnable -> {
            Thread thread = new Thread(runnable, "demo-status-" + node);
            thread.setDaemon(true);
            return thread;
        }));
        server.start();
        statusServer = server;
    }

    public DemoDurableJournal journal(String partitionId) {
        DemoDurableJournal journal = journals.get(partitionId);
        if (journal == null) throw new IllegalArgumentException("unknown partition " + partitionId);
        return journal;
    }

    /** v19 isolated learner catch-up. A is still non-writable and remains a
     * learner after install; this never changes membership or grants READY.
     * Original WAL is fsync-archived before a fully replayed copy replaces it.
     */
    synchronized boolean installRf2LearnerImage(String partitionId,
            DemoV19TcpSnapshotReceiver.Image image,
            Rf2LearnerRecheck proof) throws Exception {
        if (!"P000".equals(partitionId) || image==null || proof==null
                || image.bytes==null || image.bytes.length==0
                || image.bytes.length>DemoV19SnapshotExport.MAX_BYTES
                || image.committedSeq<1 || image.epoch<2 || image.epoch>DemoV19Rf2EpochLimits.MAX_EPOCH
                || !("CommonHaDemo"+("A".equals(node)?"B":"A")).equals(image.node))
            throw new IOException("invalid certified learner image");
        DemoDurableJournal old=journal(partitionId);
        synchronized (old) {
            if (!old.isReadyForWrites() || old.committedSeq()>image.committedSeq)
                throw new IOException("learner WAL dirty or ahead of source");
            if (!DemoV19SnapshotExport.sha256(image.bytes).equals(image.sha256))
                throw new IOException("remote image digest mismatch");
            if (old.committedSeq()==image.committedSeq) {
                if (!old.committedPrefixSha256().equals(image.sha256))
                    throw new IOException("same-index learner history diverged");
                return false;
            }
            Path active=old.path();
            Path evidence=active.getParent().resolve(".rf2-learner-evidence");
            Files.createDirectories(evidence);
            String ticket="P000-epoch2-"+UUID.randomUUID();
            Path archive=evidence.resolve(ticket+".original.wal");
            Path staged=evidence.resolve(ticket+".staged.wal");
            Path receipt=evidence.resolve(ticket+".receipt.json");
            byte[] original=Files.readAllBytes(active);
            if (original.length>16*1024*1024)
                throw new IOException("old learner WAL exceeds bounded archive");
            Files.write(staged,image.bytes,StandardOpenOption.CREATE_NEW,StandardOpenOption.WRITE);
            forceFile(staged);
            try (DemoDurableJournal candidate=new DemoDurableJournal(staged)) {
                if (!candidate.isReadyForWrites() || candidate.committedSeq()!=image.committedSeq
                        || candidate.lastEpoch()!=image.epoch
                        || !image.sha256.equals(candidate.committedPrefixSha256())
                        || !image.stateDigest.equals(candidate.state().stateDigest())
                        || !old.isCommittedPrefixOf(candidate))
                    throw new IOException("learner WAL cannot prove append-only source history");
            }
            Files.write(archive,original,StandardOpenOption.CREATE_NEW,StandardOpenOption.WRITE);
            forceFile(archive);
            if (!sha256(original).equals(sha256(Files.readAllBytes(archive))))
                throw new IOException("old learner evidence archive mismatch");
            Map<String,Object> record=new LinkedHashMap<String,Object>();
            record.put("kind","RF2_EPOCH2_LEARNER_INSTALL_UNACTIVATED");
            record.put("partitionId",partitionId);
            record.put("node","CommonHaDemo"+node);
            record.put("source",image.node);
            record.put("sourceEpoch",image.epoch);
            record.put("oldSeq",old.committedSeq());
            record.put("oldSha256",old.committedPrefixSha256());
            record.put("sourceSeq",image.committedSeq);
            record.put("sourceSha256",image.sha256);
            record.put("sourceStateDigest",image.stateDigest);
            record.put("archivedWal",archive.toString());
            record.put("activated",false);
            Files.write(receipt,JsonUtils.Serializer(record).getBytes(StandardCharsets.UTF_8),
                    StandardOpenOption.CREATE_NEW,StandardOpenOption.WRITE);
            forceFile(receipt);
            forceDirectory(evidence);
            proof.requireStillLearner();
            old.close();
            try {
                Files.move(staged,active,StandardCopyOption.ATOMIC_MOVE,
                        StandardCopyOption.REPLACE_EXISTING);
                forceDirectory(active.getParent());
            } finally {
                try { journals.put(partitionId,new DemoDurableJournal(active)); }
                catch(IOException failure) {
                    journals.remove(partitionId);
                    throw failure;
                }
            }
            DemoDurableJournal installed=journal(partitionId);
            if (!installed.isReadyForWrites() || installed.committedSeq()!=image.committedSeq
                    || !image.sha256.equals(installed.committedPrefixSha256())
                    || !image.stateDigest.equals(installed.state().stateDigest()))
                throw new IOException("learner installed WAL replay mismatch");
            return true;
        }
    }

    interface Rf2LearnerRecheck { void requireStillLearner() throws Exception; }

    public Map<String, Object> physicalStatus(String partitionId) throws IOException {
        DemoDurableJournal journal = journal(partitionId);
        synchronized (journal) {
            Map<String, Object> status = new LinkedHashMap<String, Object>();
            status.put("node", node);
            status.put("partitionId", partitionId);
            status.put("committedSeq", journal.committedSeq());
            status.put("committedPrefixSha256", journal.committedPrefixSha256());
            status.put("lastEpoch", journal.lastEpoch());
            status.put("stateDigest", journal.state().stateDigest());
            status.put("distinctRequests", journal.state().distinctRequests());
            status.put("activeWalBytes", journal.activeBytes());
            status.put("uncheckpointedWalBytes", journal.uncheckpointedBytes());
            status.put("snapshotSeq", journal.snapshotSeq());
            status.put("snapshotSourcePrefixSha256", journal.snapshotSourcePrefix());
            DemoDurableJournal.DirtyTail tail = journal.dirtyTail();
            status.put("clean", tail == null && journal.isReadyForWrites());
            if (tail != null) {
                Map<String, Object> evidence = new LinkedHashMap<String, Object>();
                evidence.put("committedSeq", tail.committedSeq);
                evidence.put("offset", tail.offset);
                evidence.put("length", tail.length);
                evidence.put("sha256", tail.sha256);
                evidence.put("pendingSeq", tail.pendingSeq);
                evidence.put("pendingRequestId", tail.pendingRequestId);
                status.put("dirtyTail", evidence);
            }
            return status;
        }
    }

    /** Called only while a persistent, majority-backed partition gate is frozen. */
    public synchronized void installCheckpoint(String partitionId, String ticket, long seq,
            String sourcePrefix, String expectedDigest) throws IOException {
        if (ticket == null || !ticket.startsWith("ARCHIVE:")) throw new IOException("checkpoint ticket required");
        DemoControl.requireFrozen(partitionId, ticket);
        com.app.common.partition.PartitionAssignment assignment = DemoControl.read(partitionId);
        String local = "CommonHaDemo" + node;
        if (!assignment.isRoutable() || (!local.equals(assignment.getPrimary())
                && !assignment.isReplica(local))) throw new IOException("node is not an assigned data holder");
        DemoDurableJournal original = journal(partitionId);
        synchronized (original) {
            if (!original.isReadyForWrites() || original.committedSeq() != seq
                    || !expectedDigest.equals(original.state().stateDigest())) {
                throw new IOException("checkpoint state boundary changed");
            }
            if (sourcePrefix.equals(original.snapshotSourcePrefix())) return; // prior atomic install
            if (!sourcePrefix.equals(original.committedPrefixSha256())) {
                throw new IOException("checkpoint source prefix changed");
            }
            Path active = original.path();
            Path root = active.getParent().resolve(".archive");
            Files.createDirectories(root);
            Path archived = root.resolve(partitionId + "-epoch" + assignment.getEpoch()
                    + "-seq" + seq + "-" + System.currentTimeMillis());
            Files.createDirectory(archived);
            Path old = archived.resolve("original.wal");
            Path staged = archived.resolve("next.wal");
            Path seal = archived.resolve("seal.json");
            String oldHash = sha256(Files.readAllBytes(active));
            if (!oldHash.equals(sourcePrefix)) throw new IOException("checkpoint physical source hash changed");
            Files.copy(active, old);
            forceFile(old);
            if (!oldHash.equals(sha256(Files.readAllBytes(old)))) {
                throw new IOException("checkpoint archive copy differs");
            }
            byte[] image = original.snapshotWalBytes();
            Files.write(staged, image, StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE);
            forceFile(staged);
            try (DemoDurableJournal check = new DemoDurableJournal(staged)) {
                if (!check.isReadyForWrites() || check.committedSeq() != seq
                        || !sourcePrefix.equals(check.snapshotSourcePrefix())
                        || !expectedDigest.equals(check.state().stateDigest())) {
                    throw new IOException("snapshot image fails independent replay");
                }
            }
            Map<String, Object> certificate = new LinkedHashMap<String, Object>();
            certificate.put("kind", "DEMO_CHECKPOINT_ARCHIVE_SEAL");
            certificate.put("partitionId", partitionId);
            certificate.put("node", local);
            certificate.put("epoch", assignment.getEpoch());
            certificate.put("assignmentVersion", assignment.getAssignmentVersion());
            certificate.put("ticket", ticket);
            certificate.put("throughSeq", seq);
            certificate.put("originalWalSha256", oldHash);
            certificate.put("snapshotWalSha256", sha256(image));
            certificate.put("stateDigest", expectedDigest);
            Files.write(seal, JsonUtils.Serializer(certificate).getBytes(StandardCharsets.UTF_8),
                    StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE);
            forceFile(seal);
            forceDirectory(archived);
            forceDirectory(root);
            DemoControl.requireFrozen(partitionId, ticket);
            com.app.common.partition.PartitionAssignment fresh = DemoControl.read(partitionId);
            if (fresh.getEpoch() != assignment.getEpoch()
                    || fresh.getAssignmentVersion() != assignment.getAssignmentVersion()
                    || !fresh.getPrimary().equals(assignment.getPrimary())) {
                throw new IOException("assignment changed during checkpoint");
            }
            original.close();
            try {
                Files.move(staged, active, StandardCopyOption.ATOMIC_MOVE,
                        StandardCopyOption.REPLACE_EXISTING);
                forceDirectory(active.getParent());
            } finally {
                try { journals.put(partitionId, new DemoDurableJournal(active)); }
                catch (IOException reopenFailure) {
                    journals.remove(partitionId);
                    throw reopenFailure;
                }
            }
        }
    }

    /** External-to-archive durable digest, tied to the installed snapshot. */
    public synchronized Map<String, Object> checkpointArchiveProof(String partitionId,
            String ticket) throws IOException {
        DemoControl.requireFrozen(partitionId, ticket);
        DemoDurableJournal active = journal(partitionId);
        Path root = active.path().getParent().resolve(".archive");
        if (!Files.isDirectory(root)) throw new IOException("checkpoint archive root missing");
        String activeHash = active.committedPrefixSha256();
        try (DirectoryStream<Path> entries = Files.newDirectoryStream(root,
                partitionId + "-epoch*-seq*-*")) {
            for (Path archived : entries) {
                if (!Files.isDirectory(archived) || Files.isSymbolicLink(archived)) continue;
                Path seal = archived.resolve("seal.json");
                Path old = archived.resolve("original.wal");
                if (!Files.isRegularFile(seal) || !Files.isRegularFile(old)) continue;
                @SuppressWarnings("unchecked") Map<String, Object> data = JsonUtils.Deserialize(
                        new String(Files.readAllBytes(seal), StandardCharsets.UTF_8), Map.class);
                if (data == null || !ticket.equals(data.get("ticket"))
                        || !partitionId.equals(data.get("partitionId"))
                        || !(data.get("throughSeq") instanceof Number)
                        || ((Number) data.get("throughSeq")).longValue() != active.committedSeq()
                        || !activeHash.equals(data.get("snapshotWalSha256"))
                        || !sha256(Files.readAllBytes(old)).equals(data.get("originalWalSha256"))) continue;
                String archiveId = archived.getFileName().toString();
                String digest = LocalArchiveQuarantineFileOps.digest(archived);
                Path ledgerRoot = active.path().getParent().resolve(".archive-seals");
                Files.createDirectories(ledgerRoot);
                Path ledger = ledgerRoot.resolve(archiveId + ".json");
                Map<String, Object> certificate = new LinkedHashMap<String, Object>();
                certificate.put("archiveId", archiveId);
                certificate.put("partitionId", partitionId);
                certificate.put("node", "CommonHaDemo" + node);
                certificate.put("ticket", ticket);
                certificate.put("throughSeq", active.committedSeq());
                certificate.put("archiveDigest", digest);
                certificate.put("originalWalSha256", data.get("originalWalSha256"));
                certificate.put("snapshotWalSha256", activeHash);
                byte[] encoded = JsonUtils.Serializer(certificate).getBytes(StandardCharsets.UTF_8);
                if (Files.exists(ledger)) {
                    if (!Arrays.equals(encoded, Files.readAllBytes(ledger))) {
                        throw new IOException("durable archive seal ledger changed");
                    }
                } else {
                    Path staged = ledgerRoot.resolve(archiveId + "." + UUID.randomUUID() + ".tmp");
                    Files.write(staged, encoded, StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE);
                    forceFile(staged);
                    Files.move(staged, ledger, StandardCopyOption.ATOMIC_MOVE);
                    forceDirectory(ledgerRoot);
                }
                return certificate;
            }
        }
        throw new IOException("no sealed archive matches installed snapshot and gate ticket");
    }

    /** Restore exact sealed pre-checkpoint bytes if its coordinator died frozen. */
    public synchronized void rollbackCheckpoint(String partitionId, String ticket,
            String oldPrefix) throws IOException {
        DemoControl.requireFrozen(partitionId, ticket);
        DemoDurableJournal original = journal(partitionId);
        synchronized (original) {
            if (!original.isReadyForWrites()) throw new IOException("dirty checkpoint image cannot roll back");
            if (oldPrefix.equals(original.committedPrefixSha256())) return;
            if (!oldPrefix.equals(original.snapshotSourcePrefix())) {
                throw new IOException("checkpoint image does not descend from frozen source");
            }
            Map<String, Object> proof = checkpointArchiveProof(partitionId, ticket);
            Path active = original.path();
            Path archive = active.getParent().resolve(".archive")
                    .resolve(String.valueOf(proof.get("archiveId"))).resolve("original.wal");
            if (!Files.isRegularFile(archive) || Files.isSymbolicLink(archive)
                    || !oldPrefix.equals(sha256(Files.readAllBytes(archive)))) {
                throw new IOException("exact original WAL archive unavailable");
            }
            Path evidence = active.getParent().resolve("recovery-evidence");
            Files.createDirectories(evidence);
            String id = partitionId + "-checkpoint-rollback-" + UUID.randomUUID();
            Path preserved = evidence.resolve(id + ".original-snapshot.wal");
            Path staged = evidence.resolve(id + ".staged.wal");
            Path record = evidence.resolve(id + ".proof.json");
            String snapshotHash = sha256(Files.readAllBytes(active));
            Files.copy(active, preserved);
            forceFile(preserved);
            if (!snapshotHash.equals(sha256(Files.readAllBytes(preserved)))) {
                throw new IOException("original checkpoint image preservation failed");
            }
            Files.copy(archive, staged);
            forceFile(staged);
            try (DemoDurableJournal candidate = new DemoDurableJournal(staged)) {
                if (!candidate.isReadyForWrites()
                        || candidate.committedSeq() != original.committedSeq()
                        || !oldPrefix.equals(candidate.committedPrefixSha256())
                        || !original.state().stateDigest().equals(candidate.state().stateDigest())) {
                    throw new IOException("sealed pre-checkpoint WAL does not reconstruct exact state");
                }
            }
            Map<String, Object> audit = new LinkedHashMap<String, Object>();
            audit.put("kind", "CHECKPOINT_ROLLBACK");
            audit.put("partitionId", partitionId);
            audit.put("node", "CommonHaDemo" + node);
            audit.put("ticket", ticket);
            audit.put("snapshotWalSha256", snapshotHash);
            audit.put("restoredWalSha256", oldPrefix);
            audit.put("sourceArchive", archive.toString());
            Files.write(record, JsonUtils.Serializer(audit).getBytes(StandardCharsets.UTF_8),
                    StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE);
            forceFile(record);
            forceDirectory(evidence);
            DemoControl.requireFrozen(partitionId, ticket);
            original.close();
            try {
                Files.move(staged, active, StandardCopyOption.ATOMIC_MOVE,
                        StandardCopyOption.REPLACE_EXISTING);
                forceDirectory(active.getParent());
            } finally {
                try { journals.put(partitionId, new DemoDurableJournal(active)); }
                catch (IOException reopenFailure) {
                    journals.remove(partitionId);
                    throw reopenFailure;
                }
            }
        }
    }

    /**
     * Replace only a learner's local WAL, retaining the complete original as
     * immutable evidence. The staged replacement is replayed and checked
     * before an atomic swap; ownership is never changed by this method.
     */
    public synchronized void installLearnerSnapshot(String partitionId, String source,
            long seq, String expectedSha, String expectedDigest, byte[] bytes) throws IOException {
        installLearnerSnapshot(partitionId, source, seq, expectedSha, expectedDigest, bytes, false);
    }

    public synchronized void installLearnerSnapshot(String partitionId, String source,
            long seq, String expectedSha, String expectedDigest, byte[] bytes,
            boolean allowLossyRebase) throws IOException {
        if (bytes == null || bytes.length > 16 * 1024 * 1024
                || !sha256(bytes).equals(expectedSha)) throw new IOException("snapshot hash mismatch");
        String local = "CommonHaDemo" + node;
        com.app.common.partition.PartitionAssignment assignment = DemoControl.read(partitionId);
        if (!assignment.isLearner(local) || !source.equals(assignment.getPrimary())) {
            throw new IOException("snapshot target is not a learner of the source primary");
        }
        DemoDurableJournal original = journal(partitionId);
        synchronized (original) {
            if (original.committedSeq() > seq && !allowLossyRebase) {
                throw new IOException("learner has committed state beyond certified source");
            }
            if (original.committedSeq() == seq && original.isReadyForWrites()
                    && expectedSha.equals(original.committedPrefixSha256())) return;
            Path active = original.path();
            Path evidence = active.getParent().resolve("recovery-evidence");
            Files.createDirectories(evidence);
            String ticket = partitionId + "-" + UUID.randomUUID();
            Path archive = evidence.resolve(ticket + ".original.wal");
            Path staged = evidence.resolve(ticket + ".staged.wal");
            Path proof = evidence.resolve(ticket + ".proof.json");
            String beforeSha = sha256(Files.readAllBytes(active));
            Files.copy(active, archive);
            forceFile(archive);
            String originalSha = sha256(Files.readAllBytes(archive));
            if (!beforeSha.equals(originalSha)) throw new IOException("original WAL archive hash mismatch");
            Files.write(staged, bytes, StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE);
            forceFile(staged);
            long orphanedFrom;
            long orphanedCount;
            try (DemoDurableJournal stagedJournal = new DemoDurableJournal(staged)) {
                orphanedFrom = original.firstOrphanedSeq(stagedJournal);
                orphanedCount = original.orphanedRequestCount(stagedJournal);
                if (allowLossyRebase && orphanedCount > 0
                        && original.lastEpoch() >= assignment.getEpoch()) {
                    throw new IOException("lossy rebase requires a newer fenced assignment epoch");
                }
                if (!stagedJournal.isReadyForWrites() || stagedJournal.committedSeq() != seq
                        || !expectedSha.equals(stagedJournal.committedPrefixSha256())
                        || !expectedDigest.equals(stagedJournal.state().stateDigest())
                        || (!allowLossyRebase && !original.isCommittedPrefixOf(stagedJournal))) {
                    throw new IOException("staged WAL fails replay or committed proof");
                }
            }
            Map<String, Object> record = new LinkedHashMap<String, Object>();
            record.put("partitionId", partitionId);
            record.put("source", source);
            record.put("learner", local);
            record.put("sourceEpoch", assignment.getEpoch());
            record.put("sourceSeq", seq);
            record.put("sourceSha256", expectedSha);
            record.put("originalSha256", originalSha);
            record.put("originalArchive", archive.toString());
            record.put("recoveryMode", allowLossyRebase ? "LOSSY_ASYNC_REBASE" : "CERTIFIED_PREFIX");
            record.put("originalCommittedSeq", original.committedSeq());
            record.put("orphanedFromSeq", orphanedFrom);
            record.put("orphanedThroughSeq", orphanedFrom < 0 ? -1L : original.committedSeq());
            record.put("orphanedCommittedCount", orphanedCount);
            record.put("transaction", ticket);
            Files.write(proof, JsonUtils.Serializer(record).getBytes(StandardCharsets.UTF_8),
                    StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE);
            forceFile(proof);
            forceDirectory(evidence);
            com.app.common.partition.PartitionAssignment fresh = DemoControl.read(partitionId);
            if (!fresh.isLearner(local) || !source.equals(fresh.getPrimary())
                    || fresh.getEpoch() != assignment.getEpoch()
                    || fresh.getAssignmentVersion() != assignment.getAssignmentVersion()) {
                throw new IOException("assignment changed before learner WAL install");
            }
            original.close();
            boolean swapped = false;
            try {
                Files.move(staged, active, StandardCopyOption.ATOMIC_MOVE,
                        StandardCopyOption.REPLACE_EXISTING);
                swapped = true;
                forceDirectory(active.getParent());
            } finally {
                // If the atomic move did not occur, reopen the original. If it
                // did, replay the replacement; any failure remains fail-closed.
                try { journals.put(partitionId, new DemoDurableJournal(active)); }
                catch (IOException reopenFailure) {
                    journals.remove(partitionId);
                    throw reopenFailure;
                }
            }
            if (!swapped) throw new IOException("snapshot swap did not complete");
        }
    }

    /**
     * Explicit async-only recovery after a dirty local replica has been fenced
     * into a new solo-primary epoch. The old full WAL is retained as evidence;
     * only its committed prefix is installed as the writable replacement.
     * ACKs made by the failed former primary beyond that prefix may be lost.
     */
    public synchronized void installAsyncSoloTailRecovery(
            DemoAsyncSoloTailRecoveryManifest manifest) throws IOException {
        manifest.requireCurrent();
        if (!("CommonHaDemo" + node).equals(manifest.node)) {
            throw new IOException("solo recovery target is not local node");
        }
        DemoDurableJournal original = journal(manifest.partition);
        synchronized (original) {
            if (original.isReadyForWrites()) {
                if (original.committedSeq() == manifest.committedSeq
                        && manifest.committedHash.equals(original.committedPrefixSha256())
                        && manifest.stateDigest.equals(original.state().stateDigest())) return;
                throw new IOException("clean journal differs from persisted solo recovery");
            }
            DemoDurableJournal.DirtyTail tail = original.dirtyTail();
            if (original.committedSeq() != manifest.committedSeq
                    || !manifest.committedHash.equals(original.committedPrefixSha256())
                    || !manifest.stateDigest.equals(original.state().stateDigest())
                    || tail == null || tail.pendingSeq != manifest.committedSeq + 1
                    || !manifest.tailHash.equals(tail.sha256)
                    || !manifest.pendingRequestId.equals(tail.pendingRequestId)) {
                throw new IOException("dirty original differs from solo recovery certificate");
            }
            byte[] committed = original.committedPrefixBytes();
            if (!manifest.committedHash.equals(sha256(committed))) {
                throw new IOException("local committed prefix bytes differ from certificate");
            }
            Path active = original.path();
            Path evidence = active.getParent().resolve("recovery-evidence");
            Files.createDirectories(evidence);
            String id = manifest.partition + "-async-solo-"
                    + manifest.ticket.substring(manifest.ticket.lastIndexOf(':') + 1);
            Path archive = evidence.resolve(id + ".original.wal");
            Path staged = evidence.resolve(id + ".staged.wal");
            Path proof = evidence.resolve(id + ".proof.json");
            String originalSha = sha256(Files.readAllBytes(active));
            if (!Files.exists(archive)) {
                Files.copy(active, archive);
                forceFile(archive);
            }
            if (!originalSha.equals(sha256(Files.readAllBytes(archive)))) {
                throw new IOException("original dirty WAL archive changed");
            }
            Files.write(staged, committed, StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);
            forceFile(staged);
            try (DemoDurableJournal candidate = new DemoDurableJournal(staged)) {
                if (!candidate.isReadyForWrites()
                        || candidate.committedSeq() != manifest.committedSeq
                        || !manifest.committedHash.equals(candidate.committedPrefixSha256())
                        || !manifest.stateDigest.equals(candidate.state().stateDigest())
                        || !original.isCommittedPrefixOf(candidate)) {
                    throw new IOException("solo recovery replacement fails physical replay");
                }
            }
            Map<String, Object> certificate = new LinkedHashMap<String, Object>();
            certificate.put("kind", "LOSSY_ASYNC_SOLO_DIRTY_TAIL_RECOVERY");
            certificate.put("partitionId", manifest.partition);
            certificate.put("node", manifest.node);
            certificate.put("ticket", manifest.ticket);
            certificate.put("epoch", manifest.epoch);
            certificate.put("assignmentZkVersion", manifest.assignmentVersion);
            certificate.put("committedSeq", manifest.committedSeq);
            certificate.put("committedPrefixSha256", manifest.committedHash);
            certificate.put("stateDigest", manifest.stateDigest);
            certificate.put("dirtyTailSha256", manifest.tailHash);
            certificate.put("pendingRequestId", manifest.pendingRequestId);
            certificate.put("originalWalSha256", originalSha);
            certificate.put("originalArchive", archive.toString());
            certificate.put("possibleFormerPrimaryAckLoss", true);
            byte[] proofBytes = JsonUtils.Serializer(certificate).getBytes(StandardCharsets.UTF_8);
            if (Files.exists(proof)) {
                if (!java.util.Arrays.equals(proofBytes, Files.readAllBytes(proof))) {
                    throw new IOException("solo recovery evidence certificate changed");
                }
            } else {
                Files.write(proof, proofBytes, StandardOpenOption.CREATE_NEW,
                        StandardOpenOption.WRITE);
                forceFile(proof);
            }
            forceDirectory(evidence);
            DemoFaultHook fault = DemoFaultHook.forRequest(
                    manifest.partition, manifest.pendingRequestId);
            if (fault != null) fault.afterSoloArchive();
            manifest.requireCurrent();
            original.close();
            try {
                Files.move(staged, active, StandardCopyOption.ATOMIC_MOVE,
                        StandardCopyOption.REPLACE_EXISTING);
                forceDirectory(active.getParent());
            } finally {
                try { journals.put(manifest.partition, new DemoDurableJournal(active)); }
                catch (IOException reopenFailure) {
                    journals.remove(manifest.partition);
                    throw reopenFailure;
                }
            }
        }
    }

    /** Install only the already-certified committed prefix during a frozen transaction. */
    public synchronized void installDirtyRecoverySnapshot(DemoDirtyRecoveryManifest manifest,
            byte[] bytes) throws IOException {
        manifest.requireCurrent();
        String partitionId = manifest.partitionId;
        String local = "CommonHaDemo" + node;
        if (!manifest.tailSha256.containsKey(local) || bytes == null
                || bytes.length > 16 * 1024 * 1024
                || !manifest.committedPrefixSha256.equals(sha256(bytes))) {
            throw new IOException("recovery payload or node identity differs from manifest");
        }
        DemoDurableJournal original = journal(partitionId);
        synchronized (original) {
            if (original.committedSeq() != manifest.committedSeq
                    || !manifest.committedPrefixSha256.equals(original.committedPrefixSha256())
                    || !manifest.stateDigest.equals(original.state().stateDigest())) {
                throw new IOException("local committed prefix differs from certified recovery target");
            }
            if (original.isReadyForWrites()) return; // idempotent restart after atomic install
            DemoDurableJournal.DirtyTail tail = original.dirtyTail();
            if (tail == null || tail.pendingSeq != manifest.committedSeq + 1
                    || !manifest.tailSha256.get(local).equals(tail.sha256)) {
                throw new IOException("uncertified or changed original WAL tail");
            }
            Path active = original.path();
            Path evidence = active.getParent().resolve("recovery-evidence");
            Files.createDirectories(evidence);
            String ticket = partitionId + "-" + UUID.randomUUID();
            Path archive = evidence.resolve(ticket + ".original.wal");
            Path staged = evidence.resolve(ticket + ".staged.wal");
            Path proof = evidence.resolve(ticket + ".proof.json");
            String beforeSha = sha256(Files.readAllBytes(active));
            Files.copy(active, archive);
            forceFile(archive);
            String archiveSha = sha256(Files.readAllBytes(archive));
            if (!beforeSha.equals(archiveSha)) throw new IOException("original WAL archive hash mismatch");
            Files.write(staged, bytes, StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE);
            forceFile(staged);
            try (DemoDurableJournal candidate = new DemoDurableJournal(staged)) {
                if (!candidate.isReadyForWrites() || candidate.committedSeq() != manifest.committedSeq
                        || !manifest.committedPrefixSha256.equals(candidate.committedPrefixSha256())
                        || !manifest.stateDigest.equals(candidate.state().stateDigest())) {
                    throw new IOException("recovery replacement fails physical replay");
                }
            }
            Map<String, Object> certificate = new LinkedHashMap<String, Object>();
            certificate.put("kind", "CERTIFIED_DIRTY_TAIL_RECOVERY");
            certificate.put("partitionId", partitionId);
            certificate.put("node", local);
            certificate.put("ticket", manifest.ticket);
            certificate.put("assignmentZkVersion", manifest.assignmentZkVersion);
            certificate.put("epoch", manifest.epoch);
            certificate.put("committedSeq", manifest.committedSeq);
            certificate.put("committedPrefixSha256", manifest.committedPrefixSha256);
            certificate.put("dirtyTailSha256", tail.sha256);
            certificate.put("pendingRequestId", tail.pendingRequestId);
            certificate.put("originalWalSha256", archiveSha);
            certificate.put("originalArchive", archive.toString());
            Files.write(proof, JsonUtils.Serializer(certificate).getBytes(StandardCharsets.UTF_8),
                    StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE);
            forceFile(proof);
            forceDirectory(evidence);
            // The manifest was built from the other two independent physical
            // processes; recheck them and the durable barrier before swap.
            DemoReplicaClient peers = new DemoReplicaClient();
            for (String peer : manifest.tailSha256.keySet()) {
                if (peer.equals(local)) continue;
                Map<String, Object> status = peers.status(peer, partitionId);
                if (!(status.get("committedSeq") instanceof Number)
                        || ((Number) status.get("committedSeq")).longValue() != manifest.committedSeq
                        || !manifest.committedPrefixSha256.equals(status.get("committedPrefixSha256"))
                        || !manifest.stateDigest.equals(status.get("stateDigest"))) {
                    throw new IOException("independent replica committed-prefix proof changed");
                }
            }
            manifest.requireCurrent();
            CertifiedDirtyTailBoundaryGuard.requireRepairBoundary(partitionId,
                    manifest.epoch, DemoControl.read(partitionId).getEpoch(),
                    manifest.assignmentZkVersion, DemoControl.assignmentZkVersion(partitionId),
                    tail.pendingSeq, tail.committedSeq, manifest.committedSeq,
                    true, true, true);
            original.close();
            try {
                Files.move(staged, active, StandardCopyOption.ATOMIC_MOVE,
                        StandardCopyOption.REPLACE_EXISTING);
                forceDirectory(active.getParent());
            } finally {
                try { journals.put(partitionId, new DemoDurableJournal(active)); }
                catch (IOException reopenFailure) {
                    journals.remove(partitionId);
                    throw reopenFailure;
                }
            }
        }
    }

    /** Complete only a certified PREPARE whose exact command is committed by C. */
    public synchronized void installForwardRecovery(DemoForwardRecoveryManifest manifest,
            byte[] sourceWal) throws IOException {
        manifest.requireCurrent();
        if (!("CommonHaDemo" + node).equals(manifest.candidate) || sourceWal == null
                || sourceWal.length > 16 * 1024 * 1024
                || !manifest.targetHash.equals(sha256(sourceWal))) {
            throw new IOException("forward source identity or hash differs from manifest");
        }
        DemoDurableJournal original = journal(manifest.partition);
        synchronized (original) {
            if (original.isReadyForWrites() && original.committedSeq() == manifest.targetSeq
                    && manifest.targetHash.equals(original.committedPrefixSha256())
                    && manifest.targetDigest.equals(original.state().stateDigest())) return;
            DemoDurableJournal.DirtyTail tail = original.dirtyTail();
            DemoStateMachine.Operation pending = original.pendingOperation();
            if (original.committedSeq() != manifest.baseSeq
                    || !manifest.baseHash.equals(original.committedPrefixSha256())
                    || tail == null || tail.pendingSeq != manifest.targetSeq
                    || !manifest.tailHash.equals(tail.sha256)
                    || pending == null || !manifest.requestId.equals(pending.requestId)
                    || manifest.delta != pending.delta) {
                throw new IOException("candidate original PREPARE differs from forward certificate");
            }
            Path active = original.path();
            Path evidence = active.getParent().resolve("recovery-evidence");
            Files.createDirectories(evidence);
            String ticket = manifest.partition + "-forward-" + UUID.randomUUID();
            Path archive = evidence.resolve(ticket + ".original.wal");
            Path staged = evidence.resolve(ticket + ".staged.wal");
            Path proof = evidence.resolve(ticket + ".proof.json");
            String originalHash = sha256(Files.readAllBytes(active));
            Files.copy(active, archive);
            forceFile(archive);
            if (!originalHash.equals(sha256(Files.readAllBytes(archive)))) {
                throw new IOException("forward recovery failed to preserve original WAL");
            }
            Files.write(staged, sourceWal, StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE);
            forceFile(staged);
            try (DemoDurableJournal candidate = new DemoDurableJournal(staged)) {
                DemoDurableJournal.CommittedRequest committed =
                        candidate.committedRequest(manifest.requestId);
                if (!candidate.isReadyForWrites() || candidate.committedSeq() != manifest.targetSeq
                        || !manifest.targetHash.equals(candidate.committedPrefixSha256())
                        || !manifest.targetDigest.equals(candidate.state().stateDigest())
                        || !original.isCommittedPrefixOf(candidate)
                        || committed == null || committed.seq != manifest.targetSeq
                        || committed.delta != manifest.delta) {
                    throw new IOException("forward source fails independent replay or command proof");
                }
            }
            Map<String, Object> record = new LinkedHashMap<String, Object>();
            record.put("kind", "CERTIFIED_FORWARD_COMMIT_RECOVERY");
            record.put("partitionId", manifest.partition);
            record.put("ticket", manifest.ticket);
            record.put("source", manifest.source);
            record.put("candidate", manifest.candidate);
            record.put("baseSeq", manifest.baseSeq);
            record.put("baseHash", manifest.baseHash);
            record.put("pendingTailSha256", manifest.tailHash);
            record.put("originalWalSha256", originalHash);
            record.put("originalArchive", archive.toString());
            record.put("targetSeq", manifest.targetSeq);
            record.put("targetHash", manifest.targetHash);
            record.put("requestId", manifest.requestId);
            Files.write(proof, JsonUtils.Serializer(record).getBytes(StandardCharsets.UTF_8),
                    StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE);
            forceFile(proof);
            forceDirectory(evidence);
            Map<String, Object> source = new DemoReplicaClient().status(manifest.source, manifest.partition);
            if (!Boolean.TRUE.equals(source.get("clean"))
                    || !(source.get("committedSeq") instanceof Number)
                    || ((Number) source.get("committedSeq")).longValue() != manifest.targetSeq
                    || !manifest.targetHash.equals(source.get("committedPrefixSha256"))
                    || !manifest.targetDigest.equals(source.get("stateDigest"))) {
                throw new IOException("independent committed source changed before forward install");
            }
            manifest.requireCurrent();
            original.close();
            try {
                Files.move(staged, active, StandardCopyOption.ATOMIC_MOVE,
                        StandardCopyOption.REPLACE_EXISTING);
                forceDirectory(active.getParent());
            } finally {
                try { journals.put(manifest.partition, new DemoDurableJournal(active)); }
                catch (IOException reopenFailure) {
                    journals.remove(manifest.partition);
                    throw reopenFailure;
                }
            }
        }
    }

    private static void forceFile(Path path) throws IOException {
        try (FileChannel channel = FileChannel.open(path, StandardOpenOption.WRITE)) { channel.force(true); }
    }

    private static void forceDirectory(Path path) throws IOException {
        try (FileChannel channel = FileChannel.open(path, StandardOpenOption.READ)) { channel.force(true); }
    }

    private static String sha256(byte[] bytes) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(bytes);
            StringBuilder result = new StringBuilder(64);
            for (byte item : digest) result.append(String.format("%02x", item & 0xff));
            return result.toString();
        } catch (NoSuchAlgorithmException impossible) {
            throw new IllegalStateException(impossible);
        }
    }

    private void handleStatus(HttpExchange exchange) throws IOException {
        int statusCode = 200;
        Map<String, Object> payload;
        String query = exchange.getRequestURI().getRawQuery();
        String partition = query == null ? "" : query.replace("partitionId=", "");
        if (!"GET".equals(exchange.getRequestMethod()) || !partition.matches("P\\d{3}")
                || !journals.containsKey(partition)) {
            statusCode = 400;
            payload = new LinkedHashMap<String, Object>();
            payload.put("error", "valid GET partitionId=P000..P255 is required");
        } else {
            payload = physicalStatus(partition);
        }
        byte[] body = JsonUtils.Serializer(payload).getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        exchange.sendResponseHeaders(statusCode, body.length);
        try (OutputStream output = exchange.getResponseBody()) { output.write(body); }
    }

    private void handleSnapshot(HttpExchange exchange) throws IOException {
        int code = 200;
        Map<String, Object> payload = new LinkedHashMap<String, Object>();
        try {
            String query = exchange.getRequestURI().getRawQuery();
            String partition = query == null ? "" : query.replace("partitionId=", "");
            if (!"GET".equals(exchange.getRequestMethod()) || !partition.matches("P\\d{3}")) {
                throw new IllegalArgumentException("valid GET partitionId is required");
            }
            DemoDurableJournal journal = journal(partition);
            synchronized (journal) {
                if (!journal.isReadyForWrites()) throw new IllegalStateException("source WAL is not clean");
                payload.put("node", "CommonHaDemo" + node);
                payload.put("partitionId", partition);
                payload.put("committedSeq", journal.committedSeq());
                payload.put("committedPrefixSha256", journal.committedPrefixSha256());
                payload.put("stateDigest", journal.state().stateDigest());
                payload.put("walBase64", Base64.getEncoder().encodeToString(journal.committedPrefixBytes()));
            }
        } catch (IllegalArgumentException malformed) {
            code = 400;
            payload.put("error", malformed.getMessage());
        } catch (Exception unsafe) {
            code = 503;
            payload.put("error", unsafe.getMessage());
        }
        byte[] body = JsonUtils.Serializer(payload).getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        exchange.sendResponseHeaders(code, body.length);
        try (OutputStream output = exchange.getResponseBody()) { output.write(body); }
    }

    private void handleWrite(HttpExchange exchange, boolean commit) throws IOException {
        int code = 200;
        Map<String, Object> response = new LinkedHashMap<String, Object>();
        try {
            if (DemoNettyBridge.enabled()) throw new IOException("legacy HTTP replication disabled in Netty mode");
            if (!"POST".equals(exchange.getRequestMethod())) throw new IllegalArgumentException("POST required");
            byte[] body = readBounded(exchange.getRequestBody());
            @SuppressWarnings("unchecked") Map<String, Object> command = JsonUtils.Deserialize(
                    new String(body, StandardCharsets.UTF_8), Map.class);
            if (command == null) throw new IllegalArgumentException("invalid command");
            String partitionId = requiredString(command, "partitionId");
            String primary = requiredString(command, "primary");
            long epoch = requiredLong(command, "epoch");
            long seq = requiredLong(command, "seq");
            DemoStateMachine.Operation operation = new DemoStateMachine.Operation(
                    requiredString(command, "requestId"), requiredLong(command, "delta"));
            String localNode = "CommonHaDemo" + node;
            DemoControl.requireCurrent(partitionId, epoch, primary, localNode);
            DemoDurableJournal journal = journal(partitionId);
            synchronized (journal) {
                DemoControl.requireCurrent(partitionId, epoch, primary, localNode);
                // Status reads take the same lock. Once the recovery gate is
                // frozen, every earlier replica write has either finished or
                // is visible before a physical certificate can be collected.
                DemoControl.requireControlQuorum(partitionId);
                if (commit) journal.commit(epoch, seq, operation);
                else journal.prepare(epoch, seq, operation);
                DemoControl.requireCurrent(partitionId, epoch, primary, localNode);
                response.put("node", localNode);
                response.put("partitionId", partitionId);
                response.put("epoch", epoch);
                response.put("seq", seq);
                response.put("committedSeq", journal.committedSeq());
                response.put("committedPrefixSha256", journal.committedPrefixSha256());
                response.put("ok", true);
            }
        } catch (IllegalArgumentException malformed) {
            code = 400;
            response.put("ok", false);
            response.put("error", malformed.getMessage());
        } catch (Exception unsafe) {
            code = 503;
            response.put("ok", false);
            response.put("error", unsafe.getClass().getSimpleName() + ": " + unsafe.getMessage());
        }
        byte[] body = JsonUtils.Serializer(response).getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        exchange.sendResponseHeaders(code, body.length);
        try (OutputStream output = exchange.getResponseBody()) { output.write(body); }
    }

    /** Bounded, single-HTTP replication of already-committed primary WAL.
     * Every record retains separate force(true) PREPARE / COMMIT and its own
     * majority-backed control proof. A mid-batch failure leaves an auditable
     * committed prefix or dirty PREPARE; status/recovery handles any retry.
     */
    private void handleCertifiedBatch(HttpExchange exchange) throws IOException {
        int code = 200;
        Map<String, Object> response = new LinkedHashMap<String, Object>();
        try {
            if (DemoNettyBridge.enabled()) throw new IOException("legacy HTTP batch replication disabled in Netty mode");
            if (!"POST".equals(exchange.getRequestMethod())
                    || !"1".equals(System.getenv("DEMO_ASYNC_REPLICATION"))
                    || !"1".equals(System.getenv("DEMO_TWO_NODE_ASYNC"))) {
                throw new IllegalArgumentException("bounded batch only allowed in async A/B Demo");
            }
            @SuppressWarnings("unchecked") Map<String, Object> request = JsonUtils.Deserialize(
                    new String(readBounded(exchange.getRequestBody()), StandardCharsets.UTF_8),
                    Map.class);
            if (request == null) throw new IllegalArgumentException("batch command missing");
            String partition = requiredString(request, "partitionId");
            String primary = requiredString(request, "primary");
            long epoch = requiredLong(request, "epoch");
            Object raw = request.get("records");
            if (!(raw instanceof List) || ((List<?>) raw).isEmpty()
                    || ((List<?>) raw).size() > 8) throw new IllegalArgumentException("batch size 1..8 required");
            List<DemoDurableJournal.CommittedRecord> records =
                    new ArrayList<DemoDurableJournal.CommittedRecord>();
            long lastSeq = -1;
            for (Object item : (List<?>) raw) {
                if (!(item instanceof Map)) throw new IllegalArgumentException("batch item missing");
                @SuppressWarnings("unchecked") Map<String, Object> row = (Map<String, Object>) item;
                long seq = requiredLong(row, "seq");
                if (seq <= 0 || (lastSeq != -1 && seq != lastSeq + 1)) {
                    throw new IllegalArgumentException("batch sequence is not contiguous");
                }
                DemoStateMachine.Operation operation = new DemoStateMachine.Operation(
                        requiredString(row, "requestId"), requiredLong(row, "delta"));
                records.add(new DemoDurableJournal.CommittedRecord(epoch, seq, operation));
                lastSeq = seq;
            }
            String replica = "CommonHaDemo" + node;
            DemoControl.requireCurrent(partition, epoch, primary, replica);
            DemoDurableJournal journal = journal(partition);
            synchronized (journal) {
                if (records.get(0).seq != journal.committedSeq() + 1) {
                    throw new IllegalStateException("batch must begin after current durable prefix");
                }
                for (DemoDurableJournal.CommittedRecord record : records) {
                    DemoControl.requireCurrent(partition, record.epoch, primary, replica);
                    DemoControl.requireControlQuorum(partition);
                    journal.prepare(record.epoch, record.seq, record.operation);
                    DemoControl.requireCurrent(partition, record.epoch, primary, replica);
                    DemoControl.requireControlQuorum(partition);
                    journal.commit(record.epoch, record.seq, record.operation);
                    DemoControl.requireCurrent(partition, record.epoch, primary, replica);
                }
                response.put("node", replica);
                response.put("partitionId", partition);
                response.put("epoch", epoch);
                response.put("committedSeq", journal.committedSeq());
                response.put("committedPrefixSha256", journal.committedPrefixSha256());
                response.put("ok", true);
            }
        } catch (IllegalArgumentException malformed) {
            code = 400;
            response.put("ok", false);
            response.put("error", malformed.getMessage());
        } catch (Exception unsafe) {
            code = 503;
            response.put("ok", false);
            response.put("error", unsafe.getClass().getSimpleName() + ": " + unsafe.getMessage());
        }
        byte[] result = JsonUtils.Serializer(response).getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        exchange.sendResponseHeaders(code, result.length);
        try (OutputStream output = exchange.getResponseBody()) { output.write(result); }
    }

    private void handleRecovery(HttpExchange exchange) throws IOException {
        int code = 200;
        Map<String, Object> response = new LinkedHashMap<String, Object>();
        try {
            if (!"POST".equals(exchange.getRequestMethod())) throw new IllegalArgumentException("POST required");
            @SuppressWarnings("unchecked") Map<String, Object> request = JsonUtils.Deserialize(
                    new String(readBounded(exchange.getRequestBody(), 24 * 1024 * 1024),
                            StandardCharsets.UTF_8), Map.class);
            if (request == null) throw new IllegalArgumentException("recovery request missing");
            String partition = requiredString(request, "partitionId");
            String ticket = requiredString(request, "ticket");
            DemoDirtyRecoveryManifest manifest = DemoDirtyRecoveryManifest.read(partition);
            if (manifest == null || !"PREPARED".equals(manifest.state)
                    || !ticket.equals(manifest.ticket)) throw new IllegalStateException("manifest absent or changed");
            byte[] bytes = Base64.getDecoder().decode(requiredString(request, "walBase64"));
            installDirtyRecoverySnapshot(manifest, bytes);
            response.put("node", "CommonHaDemo" + node);
            response.put("partitionId", partition);
            response.put("ticket", ticket);
            response.put("committedSeq", manifest.committedSeq);
            response.put("committedPrefixSha256", manifest.committedPrefixSha256);
            response.put("ok", true);
        } catch (IllegalArgumentException malformed) {
            code = 400;
            response.put("ok", false);
            response.put("error", malformed.getMessage());
        } catch (Exception unsafe) {
            code = 503;
            response.put("ok", false);
            response.put("error", unsafe.getClass().getSimpleName() + ": " + unsafe.getMessage());
        }
        byte[] body = JsonUtils.Serializer(response).getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        exchange.sendResponseHeaders(code, body.length);
        try (OutputStream output = exchange.getResponseBody()) { output.write(body); }
    }

    private void handleForwardRecovery(HttpExchange exchange) throws IOException {
        int code = 200;
        Map<String, Object> response = new LinkedHashMap<String, Object>();
        try {
            if (!"POST".equals(exchange.getRequestMethod())) throw new IllegalArgumentException("POST required");
            @SuppressWarnings("unchecked") Map<String, Object> request = JsonUtils.Deserialize(
                    new String(readBounded(exchange.getRequestBody(), 24 * 1024 * 1024),
                            StandardCharsets.UTF_8), Map.class);
            if (request == null) throw new IllegalArgumentException("forward request missing");
            String partition = requiredString(request, "partitionId");
            String ticket = requiredString(request, "ticket");
            DemoForwardRecoveryManifest manifest = DemoForwardRecoveryManifest.read(partition);
            if (manifest == null || !"PREPARED".equals(manifest.state)
                    || !ticket.equals(manifest.ticket)
                    || !("CommonHaDemo" + node).equals(manifest.candidate)) {
                throw new IllegalStateException("forward manifest absent or changed");
            }
            byte[] bytes = Base64.getDecoder().decode(requiredString(request, "walBase64"));
            installForwardRecovery(manifest, bytes);
            response.put("node", "CommonHaDemo" + node);
            response.put("partitionId", partition);
            response.put("ticket", ticket);
            response.put("committedSeq", manifest.targetSeq);
            response.put("committedPrefixSha256", manifest.targetHash);
            response.put("ok", true);
        } catch (IllegalArgumentException malformed) {
            code = 400;
            response.put("ok", false);
            response.put("error", malformed.getMessage());
        } catch (Exception unsafe) {
            code = 503;
            response.put("ok", false);
            response.put("error", unsafe.getClass().getSimpleName() + ": " + unsafe.getMessage());
        }
        byte[] body = JsonUtils.Serializer(response).getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        exchange.sendResponseHeaders(code, body.length);
        try (OutputStream output = exchange.getResponseBody()) { output.write(body); }
    }

    private void handleCheckpoint(HttpExchange exchange) throws IOException {
        int code = 200;
        Map<String, Object> response = new LinkedHashMap<String, Object>();
        try {
            if (!"POST".equals(exchange.getRequestMethod())) throw new IllegalArgumentException("POST required");
            @SuppressWarnings("unchecked") Map<String, Object> request = JsonUtils.Deserialize(
                    new String(readBounded(exchange.getRequestBody()), StandardCharsets.UTF_8), Map.class);
            if (request == null) throw new IllegalArgumentException("checkpoint request missing");
            String partition = requiredString(request, "partitionId");
            installCheckpoint(partition, requiredString(request, "ticket"),
                    requiredLong(request, "seq"), requiredString(request, "sourcePrefixSha256"),
                    requiredString(request, "stateDigest"));
            response.putAll(checkpointArchiveProof(partition, requiredString(request, "ticket")));
            response.put("ok", true);
            response.put("node", "CommonHaDemo" + node);
            response.put("partitionId", partition);
            response.put("committedPrefixSha256", journal(partition).committedPrefixSha256());
        } catch (IllegalArgumentException malformed) {
            code = 400;
            response.put("ok", false);
            response.put("error", malformed.getMessage());
        } catch (Exception unsafe) {
            code = 503;
            response.put("ok", false);
            response.put("error", unsafe.getClass().getSimpleName() + ": " + unsafe.getMessage());
        }
        byte[] body = JsonUtils.Serializer(response).getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        exchange.sendResponseHeaders(code, body.length);
        try (OutputStream output = exchange.getResponseBody()) { output.write(body); }
    }

    private void handleArchiveProof(HttpExchange exchange) throws IOException {
        int code = 200;
        Map<String, Object> response = new LinkedHashMap<String, Object>();
        try {
            String query = exchange.getRequestURI().getRawQuery();
            if (!"GET".equals(exchange.getRequestMethod()) || query == null) {
                throw new IllegalArgumentException("GET checkpoint proof required");
            }
            Map<String, String> args = new LinkedHashMap<String, String>();
            for (String part : query.split("&")) {
                String[] pair = part.split("=", 2);
                if (pair.length == 2) args.put(pair[0], java.net.URLDecoder.decode(pair[1], "UTF-8"));
            }
            String partition = args.get("partitionId");
            String ticket = args.get("ticket");
            if (partition == null || !partition.matches("P\\d{3}") || ticket == null) {
                throw new IllegalArgumentException("partitionId and ticket required");
            }
            response.putAll(checkpointArchiveProof(partition, ticket));
            response.put("ok", true);
        } catch (IllegalArgumentException malformed) {
            code = 400;
            response.put("ok", false);
            response.put("error", malformed.getMessage());
        } catch (Exception unsafe) {
            code = 503;
            response.put("ok", false);
            response.put("error", unsafe.getClass().getSimpleName() + ": " + unsafe.getMessage());
        }
        byte[] body = JsonUtils.Serializer(response).getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        exchange.sendResponseHeaders(code, body.length);
        try (OutputStream output = exchange.getResponseBody()) { output.write(body); }
    }

    private void handleCheckpointRollback(HttpExchange exchange) throws IOException {
        int code = 200;
        Map<String, Object> response = new LinkedHashMap<String, Object>();
        try {
            if (!"POST".equals(exchange.getRequestMethod())) throw new IllegalArgumentException("POST required");
            @SuppressWarnings("unchecked") Map<String, Object> request = JsonUtils.Deserialize(
                    new String(readBounded(exchange.getRequestBody()), StandardCharsets.UTF_8), Map.class);
            if (request == null) throw new IllegalArgumentException("rollback request missing");
            String partition = requiredString(request, "partitionId");
            rollbackCheckpoint(partition, requiredString(request, "ticket"),
                    requiredString(request, "sourcePrefixSha256"));
            response.put("ok", true);
            response.put("node", "CommonHaDemo" + node);
            response.put("partitionId", partition);
            response.put("committedPrefixSha256", journal(partition).committedPrefixSha256());
        } catch (IllegalArgumentException malformed) {
            code = 400;
            response.put("ok", false);
            response.put("error", malformed.getMessage());
        } catch (Exception unsafe) {
            code = 503;
            response.put("ok", false);
            response.put("error", unsafe.getClass().getSimpleName() + ": " + unsafe.getMessage());
        }
        byte[] body = JsonUtils.Serializer(response).getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        exchange.sendResponseHeaders(code, body.length);
        try (OutputStream output = exchange.getResponseBody()) { output.write(body); }
    }

    private static byte[] readBounded(InputStream input) throws IOException {
        return readBounded(input, 16384);
    }

    private static byte[] readBounded(InputStream input, int limit) throws IOException {
        java.io.ByteArrayOutputStream bytes = new java.io.ByteArrayOutputStream();
        byte[] block = new byte[4096];
        int size;
        while ((size = input.read(block)) != -1) {
            if (bytes.size() > limit - size) throw new IOException("internal command too large");
            bytes.write(block, 0, size);
        }
        return bytes.toByteArray();
    }

    private static String requiredString(Map<String, Object> values, String key) {
        Object value = values.get(key);
        if (!(value instanceof String) || ((String) value).isEmpty()) {
            throw new IllegalArgumentException(key + " required");
        }
        return (String) value;
    }

    private static long requiredLong(Map<String, Object> values, String key) {
        Object value = values.get(key);
        if (!(value instanceof Number) || ((Number) value).longValue() <= 0) {
            throw new IllegalArgumentException(key + " must be positive");
        }
        return ((Number) value).longValue();
    }

    @Override public synchronized void close() throws IOException {
        if (statusServer != null) {
            statusServer.stop(0);
            statusServer = null;
        }
        IOException error = null;
        for (DemoDurableJournal journal : journals.values()) {
            try { journal.close(); }
            catch (IOException failure) { if (error == null) error = failure; else error.addSuppressed(failure); }
        }
        journals.clear();
        if (error != null) throw error;
    }
}
