package com.app.common.replication;

import java.io.IOException;
import java.util.Objects;
import java.util.Map;

/**
 * Fail-closed CONTROL-plane bridge between node-scoped ZooKeeper CAS and
 * physically verified WAL / CommitIndex / independent custody evidence.
 *
 * This class NEVER reads ZooKeeper from WAL/ACK threads, and it never issues
 * certificates or votes. The supplied verifier MUST actually authenticate
 * original on-disk WAL, signed physical CommitIndex, both independently
 * signed certificate-custody receipts, and old-owner fencing. A test-only
 * callback is not sufficient authority for a production READY transition.
 *
 * The checks here prevent one verified partition, stale SHA, or an
 * unacknowledged STRICT -> ASYNC downgrade being reused for another shard.
 */
public final class CertifiedNodeRecoveryGate implements
        ZkNodeScopedControlPlane.CertifiedRecoveryAuthority,
        ZkNodeScopedControlPlane.CertifiedManifestTransition {
    public interface PhysicalVerifier {
        /** Must verify ZK-epoch retirement AND that prior primary cannot ACK. */
        void requireOldOwnerFenced(
                String partition,long previousEpoch,String previousPrimary,
                long newEpoch,String newPrimary,int newZkVersion)throws Exception;

        /** Returns an authenticated WAL/CommitIndex durable HEAD, not a hint. */
        Head requireCertifiedWalCommitIndex(
                String partition,long previousEpoch,String previousPrimary,
                String previousReplica)throws Exception;

        /** Reads/verifies 2 independent, physical, signed custody certificates. */
        Custody requireDualSignedCustody(
                String partition,long previousEpoch,String previousPrimary,
                String previousReplica)throws Exception;

        /** LOCAL_DURABLE_ASYNC does not guarantee a replicated ACK boundary.
         * Verify the surviving WAL and explicitly accept its RPO exposure.
         * Never report it as QUORUM_DURABLE. */
        void requireAsyncLocalRecovery(
                String partition,long previousEpoch,String previousPrimary,
                long newEpoch,String newPrimary)throws Exception;
    }

    public static final class Head {
        public final String partition,sha256;
        public final long epoch,committedSequence;
        public Head(String partition,long epoch,long committedSequence,
                    String sha256) {
            this.partition=Objects.requireNonNull(partition);
            this.epoch=epoch;
            this.committedSequence=committedSequence;
            this.sha256=Objects.requireNonNull(sha256);
        }
    }
    public static final class Custody {
        public final Head head;
        public final String voterA,voterB,physicalSignerA,physicalSignerB;
        public Custody(Head head,String voterA,String voterB,
                String physicalSignerA,String physicalSignerB){
            this.head=Objects.requireNonNull(head);
            this.voterA=Objects.requireNonNull(voterA);
            this.voterB=Objects.requireNonNull(voterB);
            this.physicalSignerA=Objects.requireNonNull(physicalSignerA);
            this.physicalSignerB=Objects.requireNonNull(physicalSignerB);
        }
    }

    private final PhysicalVerifier verifier;
    public CertifiedNodeRecoveryGate(PhysicalVerifier verifier){
        this.verifier=Objects.requireNonNull(verifier);
    }

    @Override public void requireCertifiedNewEpoch(String node,
        ZkNodeScopedControlPlane.Manifest previous,
        ZkNodeScopedControlPlane.Manifest next,int zkVersion)throws Exception {
        Objects.requireNonNull(node);requireTransition(previous,next,zkVersion,true);
    }
    @Override public void requireCertifiedTransition(String node,
        ZkNodeScopedControlPlane.Manifest previous,
        ZkNodeScopedControlPlane.Manifest next,int zkVersion)throws Exception {
        Objects.requireNonNull(node);requireTransition(previous,next,zkVersion,false);
    }

    private void requireTransition(ZkNodeScopedControlPlane.Manifest old,
            ZkNodeScopedControlPlane.Manifest next,int zkVersion,
            boolean afterSessionLoss)throws Exception {
        if(old==null || next==null || next.generation<=old.generation
                || zkVersion<0)
            throw new IOException("no certified higher manifest generation");
        for(Map.Entry<String,ZkNodeScopedControlPlane.Assignment> entry:
                old.assignments.entrySet()){
            ZkNodeScopedControlPlane.Assignment oldAssignment=entry.getValue();
            NodePartitionGrantTable.Partition prior=oldAssignment.partition;
            ZkNodeScopedControlPlane.Assignment updated=next.assignments.get(prior.id);
            if(updated==null || !updated.ready) {
                // Removing a partition can stop local writes, but it is NOT a
                // physical proof that permits a replacement READY owner.
                continue;
            }
            NodePartitionGrantTable.Partition future=updated.partition;
            if(future.epoch<prior.epoch)
                throw new IOException("recovery rolled partition epoch backward");
            boolean changed=future.epoch!=prior.epoch
                    || !future.primary.equals(prior.primary)
                    || !future.replica.equals(prior.replica)
                    || future.policy!=prior.policy;
            if(!changed && !afterSessionLoss)continue;
            if(future.epoch<=prior.epoch)
                throw new IOException("changed physical assignment reused old Epoch");
            // Changing acknowledged durability is a *separate* authorized
            // policy-cutover transaction, never an implicit failure recovery.
            if(future.policy!=prior.policy)
                throw new IOException("implicit strict/async ACK downgrade or upgrade");
            verifier.requireOldOwnerFenced(prior.id,prior.epoch,prior.primary,
                    future.epoch,future.primary,zkVersion);
            if(prior.policy==DurableWalAckPolicy.STRICT_QUORUM){
                if(prior.replica.isEmpty())
                    throw new IOException("no independent physical WAL replica");
                Head wal=verifier.requireCertifiedWalCommitIndex(
                    prior.id,prior.epoch,prior.primary,prior.replica);
                Custody custody=verifier.requireDualSignedCustody(
                    prior.id,prior.epoch,prior.primary,prior.replica);
                requireMatchingStrictHead(prior,wal,custody);
            } else if(prior.policy==DurableWalAckPolicy.LOCAL_DURABLE_ASYNC){
                verifier.requireAsyncLocalRecovery(prior.id,prior.epoch,
                        prior.primary,future.epoch,future.primary);
            } else throw new IOException("unknown durable ACK policy");
        }
    }

    private static void requireMatchingStrictHead(
            NodePartitionGrantTable.Partition p,Head wal,Custody custody)
            throws IOException {
        if(wal==null || custody==null || custody.head==null)
            throw new IOException("missing physical CommitIndex/Custody");
        if(!p.id.equals(wal.partition) || wal.epoch!=p.epoch
                || wal.committedSequence<0 ||
                !wal.sha256.matches("[0-9a-f]{64}"))
            throw new IOException("uncertified physical WAL CommitIndex head");
        Head attested=custody.head;
        if(!p.id.equals(attested.partition) || attested.epoch!=p.epoch
                || attested.committedSequence!=wal.committedSequence
                || !attested.sha256.equals(wal.sha256))
            throw new IOException("signed physical Custody != CommitIndex head");
        if(!p.primary.equals(custody.voterA)
                || !p.replica.equals(custody.voterB))
            throw new IOException("custody signed by wrong Epoch membership");
        if(custody.physicalSignerA.isEmpty() ||
                custody.physicalSignerB.isEmpty() ||
                custody.physicalSignerA.equals(custody.physicalSignerB))
            throw new IOException("custody has no two independent physical signers");
    }
}
