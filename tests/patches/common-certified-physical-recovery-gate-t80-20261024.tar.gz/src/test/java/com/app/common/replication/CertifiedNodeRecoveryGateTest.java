package com.app.common.replication;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import org.junit.Test;
import static org.junit.Assert.*;

public final class CertifiedNodeRecoveryGateTest {
    private static final String SHA=
       "aabbccddeeff00112233445566778899aabbccddeeff00112233445566778899";
    private static ZkNodeScopedControlPlane.Manifest manifest(
            long generation,long epoch,int num,boolean swapped) {
        Map<String,ZkNodeScopedControlPlane.Assignment> routes=new LinkedHashMap<>();
        for(int i=0;i<num;i++){
            String id=String.format("P%03d",i);
            String primary=(i%2==0)^swapped?"NodeA":"NodeB";
            String replica=primary.equals("NodeA")?"NodeB":"NodeA";
            DurableWalAckPolicy mode=i%2==0
                    ? DurableWalAckPolicy.STRICT_QUORUM
                    : DurableWalAckPolicy.LOCAL_DURABLE_ASYNC;
            routes.put(id,new ZkNodeScopedControlPlane.Assignment(
                new NodePartitionGrantTable.Partition(id,epoch,primary,replica,mode),true));
        }
        return new ZkNodeScopedControlPlane.Manifest(generation,routes);
    }
    static final class VerifiedPhysical implements
            CertifiedNodeRecoveryGate.PhysicalVerifier {
        int fenced,walReads,custodyReads,asyncRecoveries;
        String custodySha=SHA;
        long custodySeq=42L,walSeq=42L;
        String signerA="machine-1",signerB="machine-2";
        boolean wrongMembership;
        boolean fenceDenied;
        @Override public void requireOldOwnerFenced(
                String id,long oldEpoch,String oldPrimary,
                long nextEpoch,String nextPrimary,int version)throws Exception {
            fenced++;
            if(fenceDenied)throw new IOException("old primary still writable");
            if(nextEpoch<=oldEpoch || version<0)
                throw new IOException("epoch or CAS fence wrong");
        }
        @Override public CertifiedNodeRecoveryGate.Head requireCertifiedWalCommitIndex(
                String id,long epoch,String oldPrimary,String oldReplica) {
            walReads++;
            return new CertifiedNodeRecoveryGate.Head(id,epoch,walSeq,SHA);
        }
        @Override public CertifiedNodeRecoveryGate.Custody requireDualSignedCustody(
                String id,long epoch,String oldPrimary,String oldReplica) {
            custodyReads++;
            return new CertifiedNodeRecoveryGate.Custody(
                new CertifiedNodeRecoveryGate.Head(id,epoch,custodySeq,custodySha),
                wrongMembership?"wrong-primary":oldPrimary,oldReplica,
                signerA,signerB);
        }
        @Override public void requireAsyncLocalRecovery(
                String id,long oldEpoch,String oldPrimary,
                long nextEpoch,String nextPrimary) throws Exception{
            asyncRecoveries++;
            if(nextEpoch<=oldEpoch)throw new IOException("async Epoch not fenced");
        }
    }
    interface UnsafeCall {void go()throws Exception;}
    private static void deny(UnsafeCall action,String expected)throws Exception {
        try {action.go();fail("unsafe promotion accepted");}
        catch(IOException failure){
            assertTrue(failure.getMessage(),failure.getMessage().contains(expected));
        }
    }

    @Test public void all256RoutesRequireOwnProofOrExplicitAsyncRecovery()
            throws Exception {
        VerifiedPhysical physical=new VerifiedPhysical();
        CertifiedNodeRecoveryGate gate=new CertifiedNodeRecoveryGate(physical);
        gate.requireCertifiedNewEpoch("NodeA",manifest(1,4,256,false),
            manifest(2,5,256,true),9);
        assertEquals(256,physical.fenced);
        assertEquals(128,physical.walReads);
        assertEquals(128,physical.custodyReads);
        assertEquals(128,physical.asyncRecoveries);
    }
    @Test public void missingDualCustodyOrDifferentWatermarkFails()
            throws Exception {
        VerifiedPhysical physical=new VerifiedPhysical();
        CertifiedNodeRecoveryGate gate=new CertifiedNodeRecoveryGate(physical);
        physical.custodySha=SHA.replace('a','b');
        deny(()->gate.requireCertifiedNewEpoch("NodeA",manifest(1,4,2,false),
            manifest(2,5,2,true),6),"Custody != CommitIndex");
        physical.custodySha=SHA;
        physical.custodySeq=41;
        deny(()->gate.requireCertifiedNewEpoch("NodeA",manifest(1,4,2,false),
            manifest(2,5,2,true),6),"Custody != CommitIndex");
    }
    @Test public void samePhysicalCustodySignerFails()throws Exception {
        VerifiedPhysical physical=new VerifiedPhysical();
        physical.signerB=physical.signerA;
        deny(()->new CertifiedNodeRecoveryGate(physical)
            .requireCertifiedNewEpoch("NodeA",manifest(1,4,2,false),
            manifest(2,5,2,true),6),"two independent");
    }
    @Test public void custodyFromDifferentPriorEpochMembershipRejected()
            throws Exception {
        VerifiedPhysical physical=new VerifiedPhysical();
        physical.wrongMembership=true;
        deny(()->new CertifiedNodeRecoveryGate(physical)
            .requireCertifiedNewEpoch("NodeA",manifest(1,4,2,false),
                manifest(2,5,2,true),6),"wrong Epoch membership");
    }

    @Test public void noPhysicalOldPrimaryFenceFails()throws Exception {
        VerifiedPhysical physical=new VerifiedPhysical();
        physical.fenceDenied=true;
        deny(()->new CertifiedNodeRecoveryGate(physical)
            .requireCertifiedNewEpoch("NodeA",manifest(1,4,2,false),
            manifest(2,5,2,true),6),"old primary");
        assertEquals(0,physical.custodyReads);
    }
    @Test public void unchangedManifestWatchAvoidsRedundantPhysicalReads()
            throws Exception {
        VerifiedPhysical physical=new VerifiedPhysical();
        new CertifiedNodeRecoveryGate(physical).requireCertifiedTransition(
            "NodeA",manifest(1,4,4,false),manifest(2,4,4,false),8);
        assertEquals(0,physical.fenced);
        assertEquals(0,physical.walReads);
    }
    @Test public void oldEpochCannotBeReusedInRoleChange()throws Exception {
        VerifiedPhysical physical=new VerifiedPhysical();
        deny(()->new CertifiedNodeRecoveryGate(physical)
            .requireCertifiedTransition("NodeA",manifest(1,4,2,false),
                manifest(2,4,2,true),8),"reused old Epoch");
    }
    @Test public void implicitStrictToAsyncPolicyDowngradeRejected()
            throws Exception {
        VerifiedPhysical physical=new VerifiedPhysical();
        ZkNodeScopedControlPlane.Manifest initial=manifest(1,4,2,false);
        Map<String,ZkNodeScopedControlPlane.Assignment> modified=
            new LinkedHashMap<>(manifest(2,5,2,true).assignments);
        NodePartitionGrantTable.Partition converted=
            new NodePartitionGrantTable.Partition("P000",5,"NodeB","NodeA",
                    DurableWalAckPolicy.LOCAL_DURABLE_ASYNC);
        modified.put("P000",new ZkNodeScopedControlPlane.Assignment(converted,true));
        deny(()->new CertifiedNodeRecoveryGate(physical)
            .requireCertifiedNewEpoch("NodeA",initial,
                new ZkNodeScopedControlPlane.Manifest(2,modified),8),"downgrade");
    }
    @Test public void recoveringStrictCannotBecomeReadyWithoutPhysicalCertification()
            throws Exception {
        VerifiedPhysical physical=new VerifiedPhysical();
        ZkNodeScopedControlPlane.Manifest genesis=manifest(1,4,2,false);
        Map<String,ZkNodeScopedControlPlane.Assignment> map=
            new LinkedHashMap<>(genesis.assignments);
        map.put("P000",new ZkNodeScopedControlPlane.Assignment(
            genesis.assignments.get("P000").partition,false));
        ZkNodeScopedControlPlane.Manifest recovering=
            new ZkNodeScopedControlPlane.Manifest(1,map);
        new CertifiedNodeRecoveryGate(physical).requireCertifiedTransition(
            "NodeA",recovering,manifest(2,5,2,true),8);
        assertEquals(1,physical.walReads);
    }
}
