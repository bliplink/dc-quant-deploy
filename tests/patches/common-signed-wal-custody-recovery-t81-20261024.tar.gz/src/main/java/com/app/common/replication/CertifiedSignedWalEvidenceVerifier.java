package com.app.common.replication;

import java.io.IOException;
import java.util.Collection;
import java.util.Objects;

/**
 * Business-neutral physical proof adapter for ZkNodeScopedControlPlane.
 *
 * The source MUST load persisted original evidence: signed WAL commit quorum
 * certificate (from verified CommitIndex OR replicated certificate-custody
 * record), independently signed custody install receipts, and the candidate
 * node's fsynced original WAL. It MUST bind RSA members to a previously
 * certified, immutable old-Epoch cluster configuration, not attacker input.
 *
 * A signed WAL quorum alone is NEVER sufficient to establish two custodians.
 * This adapter does no ZK calls on normal WAL/ACK paths. All source calls
 * occur strictly inside rare administrative promotion certification.
 */
public final class CertifiedSignedWalEvidenceVerifier
        implements CertifiedNodeRecoveryGate.PhysicalVerifier {
    public interface Source {
        /** Authenticated ZK-pinned OLD membership + durable RSA identities. */
        DurableWalCommitQuorum.Membership oldMembership(
                String partition,long oldEpoch,String oldPrimary,
                String oldReplica)throws Exception;

        /** Read-only persisted signed quorum commit head. Not an in-memory
         * transport ACK and not a fabricated SHA string. */
        DurableWalCommitQuorum.Certificate persistedCommitHead(
                DurableWalCommitQuorum.Membership old)throws Exception;

        /** The physical recovery candidate's original fsynced WAL prefix. */
        String requireCandidateFsyncedPrefix(
                DurableWalCommitQuorum.Membership old,long seq)throws Exception;

        /** Persisted independent post-fsync custody receipts, signed by
         * OLD voter identities. The source cannot just claim 2 custodians. */
        Collection<DurableWalCustodyQuorum.Receipt> persistedCustodyReceipts(
                DurableWalCommitQuorum.Membership old,
                DurableWalCommitQuorum.Certificate head)throws Exception;

        /** This is NOT a string/lease check. Must prove fenced old writer
         * cannot publish an old-Epoch ACK, including ZK session retirement. */
        void requireOldOwnerIsolated(String partition,long oldEpoch,
                String oldPrimary,long newEpoch,String newPrimary,
                int newZkVersion)throws Exception;

        /** Local mode has explicit nonzero RPO risk and no fake quorum. */
        void requireAsyncRecovery(String partition,long oldEpoch,
                String oldPrimary,long newEpoch,String newPrimary)
                throws Exception;
    }
    private final Source source;
    public CertifiedSignedWalEvidenceVerifier(Source source){
        this.source=Objects.requireNonNull(source);
    }
    @Override public void requireOldOwnerFenced(String partition,long oldEpoch,
            String oldPrimary,long newEpoch,String newPrimary,int version)
            throws Exception {
        source.requireOldOwnerIsolated(partition,oldEpoch,oldPrimary,
                newEpoch,newPrimary,version);
    }
    private DurableWalCommitQuorum.Membership requireMembers(
            String partition,long epoch,String primary,String replica)
            throws Exception {
        if(replica==null || replica.isEmpty())
            throw new IOException("strict quorum needs a replica");
        DurableWalCommitQuorum.Membership m=source.oldMembership(
            partition,epoch,primary,replica);
        if(m==null || !partition.equals(m.partition) || m.epoch!=epoch
                || !primary.equals(m.primary) || m.members.size()!=2
                || !m.members.containsKey(primary)
                || !m.members.containsKey(replica)
                || primary.equals(replica))
            throw new IOException("untrusted old physical RF2 membership");
        return m;
    }
    private DurableWalCommitQuorum.Certificate certifiedHead(
            DurableWalCommitQuorum.Membership members)throws Exception{
        DurableWalCommitQuorum.Certificate persisted=
            source.persistedCommitHead(members);
        if(persisted==null)
            throw new IOException("missing persisted physical CommitIndex head");
        DurableWalCommitQuorum.Certificate verified=DurableWalCommitQuorum.verify(
            members,persisted.committedSequence,
            persisted.commitPrefixSha256,persisted.votes);
        String fsynced=source.requireCandidateFsyncedPrefix(
            members,verified.committedSequence);
        if(!verified.commitPrefixSha256.equals(fsynced))
            throw new IOException("candidate fsynced WAL != certified CommitIndex");
        return verified;
    }
    @Override public CertifiedNodeRecoveryGate.Head requireCertifiedWalCommitIndex(
            String partition,long epoch,String primary,String replica)
            throws Exception {
        DurableWalCommitQuorum.Membership m=requireMembers(
            partition,epoch,primary,replica);
        DurableWalCommitQuorum.Certificate verified=certifiedHead(m);
        return new CertifiedNodeRecoveryGate.Head(partition,epoch,
            verified.committedSequence,verified.commitPrefixSha256);
    }
    @Override public CertifiedNodeRecoveryGate.Custody requireDualSignedCustody(
            String partition,long epoch,String primary,String replica)
            throws Exception {
        DurableWalCommitQuorum.Membership m=requireMembers(
            partition,epoch,primary,replica);
        DurableWalCommitQuorum.Certificate verified=certifiedHead(m);
        Collection<DurableWalCustodyQuorum.Receipt> receipts=
            source.persistedCustodyReceipts(m,verified);
        // This performs the original RSA custody signature, membership,
        // membership digest, sequence, SHA, signer and host independence
        // checks, not just a 2/2-count or a claimed boolean.
        DurableWalCustodyQuorum.CustodiedCertificate custody=
            DurableWalCustodyQuorum.verify(m,verified,receipts);
        if(custody.physicalCustodians!=2
                || custody.sequence!=verified.committedSequence
                || !custody.walPrefixHash.equals(verified.commitPrefixSha256))
            throw new IOException("custody quorum not independently certified");
        return new CertifiedNodeRecoveryGate.Custody(
            new CertifiedNodeRecoveryGate.Head(partition,epoch,
                custody.sequence,custody.walPrefixHash),
            primary,replica,m.members.get(primary).physicalHost,
            m.members.get(replica).physicalHost);
    }
    @Override public void requireAsyncLocalRecovery(String partition,long oldEpoch,
            String oldPrimary,long newEpoch,String newPrimary)throws Exception{
        source.requireAsyncRecovery(partition,oldEpoch,oldPrimary,
            newEpoch,newPrimary);
    }
}
