package com.app.common.replication;

import java.io.*;
import java.security.*;
import java.util.*;

/**
 * Independent RSA receipts for disk-installed quorum commit CERTIFICATE
 * custody, distinct from signed WAL prefix receipts.
 *
 * This MUST be verified before a future strict client's ACK is published.
 * A majority of WAL fsync witnesses does NOT prove a majority of certificate
 * custodians. Recipients must sign only after force() and directory fsync.
 *
 * This proof never grants an epoch lease, PRIMARY, READY or auto-failover.
 */
public final class DurableWalCustodyQuorum {
    private static final String DOMAIN="OTC_COMMON_CERT_CUSTODY_V1";
    private DurableWalCustodyQuorum(){}

    public static final class Receipt {
        public final String node,partition,oldMembershipHash,walPrefixHash;
        public final long oldEpoch,sequence;
        private final byte[] signature;
        private Receipt(String node,String part,String member,String wal,
                long epoch,long seq,byte[] signed){
            this.node=node;partition=part;oldMembershipHash=member;
            walPrefixHash=wal;oldEpoch=epoch;sequence=seq;
            signature=signed.clone();
        }
        public byte[] signature(){return signature.clone();}
        public static Receipt fromWire(String node,String part,String member,
                String wal,long epoch,long seq,byte[] signed){
            if(signed==null || signed.length==0 || signed.length>1024)
                throw new IllegalArgumentException("bad certificate custody signature");
            return new Receipt(node,part,member,wal,epoch,seq,signed);
        }
    }

    public static final class CustodiedCertificate {
        public final long sequence;
        public final String walPrefixHash;
        public final String membershipHash;
        public final int physicalCustodians;
        private CustodiedCertificate(long seq,String hash,String membership,int n) {
            sequence=seq;walPrefixHash=hash;membershipHash=membership;
            physicalCustodians=n;
        }
        public boolean authorizesPromotion(){return false;}
    }

    /** Package-private: only a DurableWalCertificateCustody may sign. */
    static Receipt signVerified(DurableWalCommitQuorum.Membership membership,
            String member,DurableWalCommitQuorum.Certificate installed,
            PrivateKey identityKey)throws Exception {
        if(membership==null || identityKey==null || installed==null
                || !membership.members.containsKey(member))
            throw new IOException("untrusted local custody identity");
        DurableWalCommitQuorum.Certificate verified=DurableWalCommitQuorum.verify(
                membership,installed.committedSequence,
                installed.commitPrefixSha256,installed.votes);
        Signature signing=Signature.getInstance("SHA256withRSA");
        signing.initSign(identityKey);
        signing.update(statement(membership,member,verified));
        return new Receipt(member,membership.partition,membership.digest,
                verified.commitPrefixSha256,membership.epoch,
                verified.committedSequence,signing.sign());
    }

    /** Verified disk-custody quorum is an ACK prerequisite, NOT election. */
    public static CustodiedCertificate verify(
            DurableWalCommitQuorum.Membership membership,
            DurableWalCommitQuorum.Certificate certificate,
            Collection<Receipt> custody)throws Exception {
        if(membership==null || certificate==null || custody==null)
            throw new IOException("missing custody commit boundary");
        DurableWalCommitQuorum.Certificate verified=DurableWalCommitQuorum.verify(
                membership,certificate.committedSequence,
                certificate.commitPrefixSha256,certificate.votes);
        if(custody.size()<membership.majority()
                || custody.size()>membership.members.size())
            throw new IOException("insufficient independent persisted custody voters");
        Set<String> nodes=new HashSet<String>(),hosts=new HashSet<String>();
        for(Receipt receipt:custody){
            // Source WAL quorum is verified ONCE per certificate, not
            // redundantly for every remote physical custody witness.
            requireValidVerifiedReceipt(membership,verified,receipt);
            DurableWalCommitQuorum.Member node=membership.members.get(receipt.node);
            if(!nodes.add(receipt.node) || !hosts.add(node.physicalHost))
                throw new IOException("duplicate physical certificate custodian");
        }
        if(nodes.size()<membership.majority() || hosts.size()<membership.majority())
            throw new IOException("insufficient physically distinct custody proof");
        return new CustodiedCertificate(verified.committedSequence,
                verified.commitPrefixSha256,membership.digest,nodes.size());
    }

    /** Check one real node's signed custody proof; this is NOT a majority ACK. */
    public static void requireValidReceipt(DurableWalCommitQuorum.Membership membership,
            DurableWalCommitQuorum.Certificate certificate,Receipt receipt)throws Exception{
        if(membership==null || certificate==null || receipt==null)
            throw new IOException("missing custody receipt evidence");
        DurableWalCommitQuorum.Certificate proof=DurableWalCommitQuorum.verify(
                membership,certificate.committedSequence,
                certificate.commitPrefixSha256,certificate.votes);
        requireValidVerifiedReceipt(membership,proof,receipt);
    }

    private static void requireValidVerifiedReceipt(
            DurableWalCommitQuorum.Membership membership,
            DurableWalCommitQuorum.Certificate proof,Receipt receipt)throws Exception {
        if(receipt==null)throw new IOException("missing custody witness");
        DurableWalCommitQuorum.Member member=membership.members.get(receipt.node);
        if(member==null || receipt.oldEpoch!=membership.epoch
                || receipt.sequence!=proof.committedSequence
                || !membership.partition.equals(receipt.partition)
                || !membership.digest.equals(receipt.oldMembershipHash)
                || !proof.commitPrefixSha256.equals(receipt.walPrefixHash))
            throw new IOException("forged/stale certificate custodian");
        Signature signature=Signature.getInstance("SHA256withRSA");
        signature.initVerify(member.publicKey);
        signature.update(statement(membership,receipt.node,proof));
        if(!signature.verify(receipt.signature))
            throw new IOException("invalid independent certificate custody RSA");
    }

    private static byte[] statement(DurableWalCommitQuorum.Membership m,String member,
            DurableWalCommitQuorum.Certificate certificate)throws IOException {
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();
        DataOutputStream out=new DataOutputStream(bytes);
        out.writeUTF(DOMAIN);
        out.writeUTF(m.service);out.writeUTF(m.partition);
        out.writeUTF(m.digest);out.writeUTF(member);
        out.writeLong(m.epoch);out.writeLong(certificate.committedSequence);
        out.writeUTF(certificate.commitPrefixSha256);
        out.flush();return bytes.toByteArray();
    }
}
