package com.app.common.replication;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 * Business-neutral WAL commit-quorum receipt verification.
 *
 * This is a new trading COMMIT boundary, NOT the existing recovery source
 * attestation and NEVER, on its own, a leader election/READY authorization.
 * Membership must come from a certified control plane. Each signer must
 * obtain a locally fsynced WAL prefix from its own physical durable storage.
 *
 * Callers must DURABLY publish the resulting certificate before replying
 * QUORUM_DURABLE to a client. This class deliberately does not issue ACKs.
 */
public final class DurableWalCommitQuorum {
    private static final String DOMAIN="OTC_COMMON_WAL_COMMIT_V1";
    private DurableWalCommitQuorum() { }

    public interface LocalDurability {
        /** Require local fsync through seq, then return that exact prefix hash.
         * Must reject a stale/changed epoch and any dirty WAL tail. */
        String requireFsyncedPrefix(long epoch,long seq) throws Exception;
    }

    public static final class Member {
        public final String node;
        public final String physicalHost;
        public final PublicKey publicKey;
        public Member(String node,String physicalHost,PublicKey publicKey) {
            if (!validId(node) || !validId(physicalHost) || publicKey==null
                    || !"RSA".equalsIgnoreCase(publicKey.getAlgorithm()))
                throw new IllegalArgumentException("invalid voter identity or RSA public key");
            this.node=node;
            this.physicalHost=physicalHost;
            this.publicKey=publicKey;
        }
    }

    public static final class Membership {
        public final String service,partition,primary;
        public final long epoch,configurationVersion;
        public final Map<String,Member> members;
        public final String digest;
        public Membership(String service,String partition,String primary,long epoch,
                long configurationVersion,Collection<Member> entries) throws Exception {
            if (!validId(service) || partition==null || !partition.matches("P[0-9]{3}")
                    || !validId(primary) || epoch<=0 || configurationVersion<=0
                    || entries==null || entries.size()<2 || entries.size()>7)
                throw new IllegalArgumentException("invalid RF2-or-more durable data membership");
            Map<String,Member> sorted=new TreeMap<String,Member>();
            Set<String> hosts=new HashSet<String>(), keys=new HashSet<String>();
            for(Member member:entries) {
                if (member==null || sorted.put(member.node,member)!=null
                        || !hosts.add(member.physicalHost)
                        || !keys.add(hash(member.publicKey.getEncoded())))
                    throw new IllegalArgumentException("non-independent physical WAL voters");
            }
            if (!sorted.containsKey(primary))
                throw new IllegalArgumentException("primary not in signed data membership");
            this.service=service;this.partition=partition;this.primary=primary;
            this.epoch=epoch;this.configurationVersion=configurationVersion;
            this.members=Collections.unmodifiableMap(sorted);
            ByteArrayOutputStream bytes=new ByteArrayOutputStream();
            DataOutputStream out=new DataOutputStream(bytes);
            out.writeUTF("OTC_COMMON_MEMBERSHIP_V1");
            out.writeUTF(service);out.writeUTF(partition);out.writeUTF(primary);
            out.writeLong(epoch);out.writeLong(configurationVersion);
            for(Member m:sorted.values()) {
                out.writeUTF(m.node);out.writeUTF(m.physicalHost);
                byte[] encoded=m.publicKey.getEncoded();
                out.writeInt(encoded.length);out.write(encoded);
            }
            out.flush();
            digest=hash(bytes.toByteArray());
        }
        public int majority(){return members.size()/2+1;}
    }

    public static final class Receipt {
        public final String node,partition,commitPrefixSha256,membershipSha256;
        public final long epoch,sequence;
        private final byte[] signed;
        private Receipt(String node,String partition,long epoch,long sequence,
                String prefix,String membershipSha,byte[] signature) {
            this.node=node;this.partition=partition;this.epoch=epoch;
            this.sequence=sequence;this.commitPrefixSha256=prefix;
            this.membershipSha256=membershipSha;this.signed=signature.clone();
        }
        public byte[] signature(){return signed.clone();}
        public static Receipt fromWire(String node,String partition,long epoch,long sequence,
                String prefix,String membershipSha,byte[] signature) {
            if (signature==null || signature.length==0 || signature.length>1024)
                throw new IllegalArgumentException("invalid signed receipt");
            return new Receipt(node,partition,epoch,sequence,prefix,membershipSha,signature);
        }
    }

    public static final class Certificate {
        public final long epoch,committedSequence;
        public final String commitPrefixSha256,membershipSha256;
        public final List<Receipt> votes;
        private Certificate(Membership membership,long seq,String hash,List<Receipt> receipts) {
            epoch=membership.epoch;committedSequence=seq;
            commitPrefixSha256=hash;membershipSha256=membership.digest;
            votes=Collections.unmodifiableList(new ArrayList<Receipt>(receipts));
        }
        /** Do not treat data-quorum durability as permission to become PRIMARY. */
        public boolean authorizesReady(){return false;}
    }

    /** Sign only through the node's own certified fsync barrier. */
    public static Receipt sign(Membership membership,String localNode,long seq,
            LocalDurability local,PrivateKey localPrivateKey) throws Exception {
        if (membership==null || !membership.members.containsKey(localNode)
                || seq<=0 || local==null || localPrivateKey==null)
            throw new IllegalArgumentException("untrusted local WAL signing inputs");
        String prefix=local.requireFsyncedPrefix(membership.epoch,seq);
        if (!validHash(prefix)) throw new IllegalStateException("no fsynced committed WAL hash");
        byte[] payload=statement(membership,localNode,seq,prefix);
        Signature s=Signature.getInstance("SHA256withRSA");
        s.initSign(localPrivateKey);s.update(payload);
        return new Receipt(localNode,membership.partition,membership.epoch,seq,
                prefix,membership.digest,s.sign());
    }

    /** Independently authenticate one pinned member's signed WAL/fsync receipt. */
    public static void requireValidReceipt(Membership membership,Receipt receipt)
            throws Exception {
        if(membership==null || receipt==null
                || !membership.members.containsKey(receipt.node)
                || !membership.partition.equals(receipt.partition)
                || receipt.epoch!=membership.epoch || receipt.sequence<=0
                || !validHash(receipt.commitPrefixSha256)
                || !membership.digest.equals(receipt.membershipSha256))
            throw new IllegalStateException("stale or mismatched WAL batch witness");
        Signature signature=Signature.getInstance("SHA256withRSA");
        signature.initVerify(membership.members.get(receipt.node).publicKey);
        signature.update(statement(membership,receipt.node,
                receipt.sequence,receipt.commitPrefixSha256));
        if(!signature.verify(receipt.signed))
            throw new IllegalStateException("invalid signed WAL batch witness");
    }

    /** Verify independent physical witnesses for the EXACT same WAL boundary. */
    public static Certificate verify(Membership membership,long seq,String prefix,
            Collection<Receipt> receipts) throws Exception {
        if (membership==null || seq<=0 || !validHash(prefix) || receipts==null
                || receipts.size()>membership.members.size())
            throw new IllegalArgumentException("invalid durable quorum candidate");
        Set<String> nodes=new HashSet<String>(), physical=new HashSet<String>();
        List<Receipt> valid=new ArrayList<Receipt>();
        for(Receipt receipt:receipts) {
            if (receipt==null || !membership.members.containsKey(receipt.node)
                    || !membership.partition.equals(receipt.partition)
                    || receipt.epoch!=membership.epoch || receipt.sequence!=seq
                    || !prefix.equals(receipt.commitPrefixSha256)
                    || !membership.digest.equals(receipt.membershipSha256))
                throw new IllegalStateException("inconsistent WAL quorum receipt boundary");
            Member signer=membership.members.get(receipt.node);
            if (!nodes.add(receipt.node) || !physical.add(signer.physicalHost))
                throw new IllegalStateException("duplicate physical quorum witness");
            Signature s=Signature.getInstance("SHA256withRSA");
            s.initVerify(signer.publicKey);
            s.update(statement(membership,receipt.node,seq,prefix));
            if (!s.verify(receipt.signed))
                throw new IllegalStateException("invalid physical quorum witness signature");
            valid.add(receipt);
        }
        if (!nodes.contains(membership.primary) || valid.size()<membership.majority())
            throw new IllegalStateException("insufficient fsynced WAL quorum");
        return new Certificate(membership,seq,prefix,valid);
    }

    private static byte[] statement(Membership m,String node,long seq,String prefix)
            throws Exception {
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();
        DataOutputStream out=new DataOutputStream(bytes);
        out.writeUTF(DOMAIN);out.writeUTF(m.service);out.writeUTF(m.partition);
        out.writeUTF(m.primary);out.writeUTF(node);
        out.writeLong(m.epoch);out.writeLong(m.configurationVersion);
        out.writeUTF(m.digest);out.writeLong(seq);out.writeUTF(prefix);
        out.flush();
        return bytes.toByteArray();
    }
    private static boolean validId(String s){return s!=null && s.matches("[A-Za-z0-9_.-]{1,96}");}
    private static boolean validHash(String s){return s!=null && s.matches("[0-9a-f]{64}");}
    private static String hash(byte[] b)throws Exception {
        byte[] sum=MessageDigest.getInstance("SHA-256").digest(b);
        StringBuilder out=new StringBuilder(64);
        for(byte v:sum) out.append(String.format(java.util.Locale.ROOT,"%02x",v&255));
        return out.toString();
    }
}
