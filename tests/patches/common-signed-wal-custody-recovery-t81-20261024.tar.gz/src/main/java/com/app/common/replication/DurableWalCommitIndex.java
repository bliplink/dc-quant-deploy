package com.app.common.replication;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

/**
 * Business-neutral durable quorum commit-index ledger for a single immutable
 * partition membership/epoch. Commit seq only becomes visible AFTER durable
 * signed receipts are verified, the certificate is fsynced, and its atomic
 * rename and directory entry have been forced to disk.
 *
 * This local ledger is not independently replicated. Loss, deletion or
 * rollback of the whole ledger cannot be detected without an external
 * quorum-signed high-watermark anchor. Never use it for leader promotion.
 */
public final class DurableWalCommitIndex implements AutoCloseable {
    private static final int MAGIC=0x4f544357; // OTCW
    private static final int VERSION=1, MAX_BYTES=32768;
    private static final String GENESIS="GENESIS";
    private final Path directory;
    private final DurableWalCommitQuorum.Membership membership;
    private final FileChannel lockChannel;
    private final FileLock lock;
    private long committedSeq;
    // Loaded solely after a complete on-disk certificate-chain verification.
    // Immutable, safe to hand to peer certificate-custody install protocol.
    private DurableWalCommitQuorum.Certificate highestCertificate;
    private String committedPrefixSha256;
    private String previousCertificateHash=GENESIS;
    private boolean closed;

    public DurableWalCommitIndex(Path directory,
            DurableWalCommitQuorum.Membership membership) throws Exception {
        if(directory==null || membership==null || Files.isSymbolicLink(directory))
            throw new IOException("trusted commit directory and membership required");
        this.directory=directory;
        this.membership=membership;
        Files.createDirectories(directory);
        if(!Files.isDirectory(directory,LinkOption.NOFOLLOW_LINKS))
            throw new IOException("commit directory must not be symbolic link");
        Path lockPath=directory.resolve(".commit-writer.lock");
        if(Files.isSymbolicLink(lockPath))throw new IOException("unsafe commit writer lock");
        lockChannel=FileChannel.open(lockPath,StandardOpenOption.CREATE,StandardOpenOption.WRITE);
        FileLock acquired=null;
        try {
            acquired=lockChannel.tryLock();
            if(acquired==null)throw new IOException("commit writer already running");
            lock=acquired;
            loadAndVerify();
        } catch(Exception fail) {
            if(acquired!=null)acquired.release();
            lockChannel.close();
            throw fail;
        }
    }

    /** Mutations are serialized by this process and an exclusive OS file lock. */
    public synchronized DurableWalCommitQuorum.Certificate certifyAndPersist(
            long seq,String prefixSha256,
            Collection<DurableWalCommitQuorum.Receipt> receipts) throws Exception {
        requireOpen();
        if(seq<=committedSeq)throw new IOException("commit index cannot regress or repeat");
        DurableWalCommitQuorum.Certificate cert=DurableWalCommitQuorum.verify(
                membership,seq,prefixSha256,receipts);
        byte[] record=encode(cert,committedSeq,previousCertificateHash);
        if(record.length>MAX_BYTES)throw new IOException("certificate exceeds fixed maximum size");
        String name=fileName(seq);
        Path target=directory.resolve(name);
        Path pending=directory.resolve(name+".pending");
        if(Files.exists(target,LinkOption.NOFOLLOW_LINKS)
                || Files.exists(pending,LinkOption.NOFOLLOW_LINKS))
            throw new IOException("ambiguous preexisting WAL quorum certificate");
        try(FileChannel file=FileChannel.open(pending,StandardOpenOption.CREATE_NEW,
                StandardOpenOption.WRITE)) {
            ByteBuffer buffer=ByteBuffer.wrap(record);
            while(buffer.hasRemaining())file.write(buffer);
            file.force(true);
        }
        Files.move(pending,target,StandardCopyOption.ATOMIC_MOVE);
        forceDirectory();
        // Only advance in-memory index after durable certificate publication.
        committedSeq=seq;
        highestCertificate=cert;
        committedPrefixSha256=cert.commitPrefixSha256;
        previousCertificateHash=hex(record);
        return cert;
    }

    /**
     * Persist ONE durable high-water certificate for a bounded contiguous
     * batch. Every covered business request may receive a separate client ACK
     * only after the batch certificate is durably published and its own
     * trusted prefix inclusion is checked by the ACK gate.
     *
     * This method never asserts that an unverified individual request fsync
     * is complete and never publishes anything if previous WAL history forked.
     */
    public synchronized DurableWalCommitQuorum.Certificate certifyAndPersistBatch(
            long firstSequence,long lastSequence,String lastPrefixSha256,
            Collection<DurableWalCommitQuorum.Receipt> receipts,
            DurableWalCommitQuorum.LocalDurability trustedWal) throws Exception {
        requireOpen();
        if(firstSequence<=0 || firstSequence!=committedSeq+1
                || lastSequence<firstSequence || lastSequence-firstSequence>=64
                || trustedWal==null || lastPrefixSha256==null)
            throw new IOException("noncontiguous or oversized WAL batch cannot be certified");
        if(committedSeq>0) {
            String old=trustedWal.requireFsyncedPrefix(membership.epoch,committedSeq);
            if(!committedPrefixSha256.equals(old))
                throw new IOException("new WAL batch diverges from committed history");
        }
        String high=trustedWal.requireFsyncedPrefix(membership.epoch,lastSequence);
        if(!lastPrefixSha256.equals(high))
            throw new IOException("new WAL batch missing signed fsynced end");
        return certifyAndPersist(lastSequence,lastPrefixSha256,receipts);
    }

    /** Detect corrupt/unknown/pending files; replay and reverify every signature. */
    private void loadAndVerify()throws Exception {
        TreeMap<Long,Path> ordered=new TreeMap<Long,Path>();
        try(DirectoryStream<Path> all=Files.newDirectoryStream(directory)){
            for(Path file:all){
                String filename=file.getFileName().toString();
                if(".commit-writer.lock".equals(filename))continue;
                if(Files.isSymbolicLink(file)
                        || !Files.isRegularFile(file,LinkOption.NOFOLLOW_LINKS)
                        || !filename.matches("commit-[0-9]{20}\\.bin"))
                    throw new IOException("unknown or pending durable WAL commit evidence");
                long seq;
                try {seq=Long.parseLong(filename.substring(7,27));}
                catch(NumberFormatException invalid){throw new IOException("invalid durable commit index",invalid);}
                if(seq<=0 || ordered.put(seq,file)!=null)
                    throw new IOException("invalid or duplicate committed sequence");
            }
        }
        long prior=0;
        String priorPrefix=null;
        String priorHash=GENESIS;
        for(Map.Entry<Long,Path> item:ordered.entrySet()){
            byte[] record=Files.readAllBytes(item.getValue());
            if(record.length==0 || record.length>MAX_BYTES)
                throw new IOException("invalid durable certificate byte length");
            DataInputStream in=new DataInputStream(new ByteArrayInputStream(record));
            if(in.readInt()!=MAGIC || in.readInt()!=VERSION)
                throw new IOException("unknown WAL quorum certificate version");
            String membershipHash=in.readUTF();
            long epoch=in.readLong(),seq=in.readLong(),previousSeq=in.readLong();
            String walHash=in.readUTF(),previousHash=in.readUTF();
            if(!membership.digest.equals(membershipHash)
                    || epoch!=membership.epoch || seq!=item.getKey()
                    || seq<=prior || previousSeq!=prior
                    || !priorHash.equals(previousHash))
                throw new IOException("WAL commit certificate chain or membership changed");
            int count=in.readInt();
            if(count<membership.majority() || count>membership.members.size())
                throw new IOException("insufficient durable physical receipts");
            List<DurableWalCommitQuorum.Receipt> witnesses=new ArrayList<DurableWalCommitQuorum.Receipt>();
            for(int n=0;n<count;n++){
                String node=in.readUTF(),part=in.readUTF();
                long receiptEpoch=in.readLong(),receiptSeq=in.readLong();
                String receiptWal=in.readUTF(),receiptMembership=in.readUTF();
                int length=in.readInt();
                if(length<=0 || length>1024)
                    throw new IOException("unsafe quorum signature length");
                byte[] signature=new byte[length];
                in.readFully(signature);
                witnesses.add(DurableWalCommitQuorum.Receipt.fromWire(node,part,
                        receiptEpoch,receiptSeq,receiptWal,receiptMembership,signature));
            }
            if(in.read()!=-1)throw new IOException("trailing untrusted WAL quorum evidence");
            DurableWalCommitQuorum.Certificate reconstructed=
                    DurableWalCommitQuorum.verify(membership,seq,walHash,witnesses);
            highestCertificate=reconstructed;
            prior=seq;priorPrefix=walHash;priorHash=hex(record);
        }
        committedSeq=prior;
        committedPrefixSha256=priorPrefix;
        previousCertificateHash=priorHash;
    }

    private byte[] encode(DurableWalCommitQuorum.Certificate certificate,
            long previousSeq,String previousHash)throws IOException {
        ByteArrayOutputStream data=new ByteArrayOutputStream(4096);
        DataOutputStream out=new DataOutputStream(data);
        out.writeInt(MAGIC);out.writeInt(VERSION);
        out.writeUTF(membership.digest);
        out.writeLong(certificate.epoch);
        out.writeLong(certificate.committedSequence);
        out.writeLong(previousSeq);
        out.writeUTF(certificate.commitPrefixSha256);
        out.writeUTF(previousHash);
        out.writeInt(certificate.votes.size());
        for(DurableWalCommitQuorum.Receipt voter:certificate.votes) {
            out.writeUTF(voter.node);out.writeUTF(voter.partition);
            out.writeLong(voter.epoch);out.writeLong(voter.sequence);
            out.writeUTF(voter.commitPrefixSha256);
            out.writeUTF(voter.membershipSha256);
            byte[] signature=voter.signature();
            out.writeInt(signature.length);out.write(signature);
        }
        out.flush();return data.toByteArray();
    }

    private void forceDirectory()throws IOException {
        try(FileChannel dir=FileChannel.open(directory,StandardOpenOption.READ)) {
            dir.force(true);
        }
    }

    private static String fileName(long seq) {
        return String.format(Locale.ROOT,"commit-%020d.bin",seq);
    }

    private static String hex(byte[] bytes)throws Exception {
        byte[] sha=MessageDigest.getInstance("SHA-256").digest(bytes);
        StringBuilder out=new StringBuilder(64);
        for(byte b:sha)out.append(String.format(Locale.ROOT,"%02x",b&255));
        return out.toString();
    }

    private void requireOpen()throws IOException {
        if(closed || !lock.isValid())throw new IOException("durable commit index closed");
    }

    /** Exact disk-certified boundary for gating a client ACK; not a leader grant. */
    public synchronized void requireExactCertified(long epoch,long seq,String walHash)
            throws IOException {
        requireOpen();
        if(epoch!=membership.epoch || seq!=committedSeq || seq<=0
                || walHash==null || !walHash.equals(committedPrefixSha256))
            throw new IOException("no fsynced WAL quorum certificate for exact ACK boundary");
    }

    /**
     * A signed, fsynced WAL high-watermark commits its immutable WAL PREFIX,
     * not just the final request. Permit a covered request only when the
     * locally trusted journal independently attests BOTH the certified end
     * boundary and the exact requested boundary. This is not a recovery or
     * promotion certificate and MUST NOT accept an untrusted wire hash reader.
     *
     * No individual per-request certificate/fsync is needed inside a batch.
     */
    public synchronized void requireCoveredByCertifiedWatermark(
            long epoch,long requestedSeq,String requestedPrefixSha256,
            DurableWalCommitQuorum.LocalDurability trustedWal) throws Exception {
        requireOpen();
        if(epoch!=membership.epoch || requestedSeq<=0
                || requestedSeq>committedSeq || committedSeq<=0
                || requestedPrefixSha256==null
                || !requestedPrefixSha256.matches("[0-9a-f]{64}")
                || trustedWal==null)
            throw new IOException("uncertified cumulative WAL commit boundary");
        // If this trust source only knows a shorter or divergent WAL history,
        // it MUST fail closed. That includes snapshot/restore or an old epoch.
        String end=trustedWal.requireFsyncedPrefix(epoch,committedSeq);
        if(!committedPrefixSha256.equals(end))
            throw new IOException("trusted WAL does not cover certified end hash");
        String prefix=trustedWal.requireFsyncedPrefix(epoch,requestedSeq);
        if(!requestedPrefixSha256.equals(prefix))
            throw new IOException("trusted WAL does not match covered request prefix");
    }

    /** Already verified source certificate from highest fsynced CommitIndex. */
    public synchronized DurableWalCommitQuorum.Certificate verifiedHighestCertificate()
            throws IOException {
        requireOpen();
        if(committedSeq<=0 || highestCertificate==null
                || highestCertificate.committedSequence!=committedSeq
                || !membership.digest.equals(highestCertificate.membershipSha256)
                || !committedPrefixSha256.equals(highestCertificate.commitPrefixSha256))
            throw new IOException("highest durable WAL certificate not available");
        return highestCertificate;
    }

    public synchronized long committedSequence() { return committedSeq; }

    @Override public synchronized void close()throws IOException {
        if(!closed){
            closed=true;
            try { lock.release(); }
            finally {lockChannel.close();}
        }
    }
}
