package com.app.common.replication;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.file.*;
import java.util.*;

/**
 * Durable local custody of the HIGHEST quorum-signed WAL commit certificate.
 *
 * This is a prerequisite for a future cross-epoch promotion protocol, NOT a
 * license to promote. In particular, a primary must not issue QUORUM_DURABLE
 * client ACK until the certificate itself has been durably installed on a
 * majority of distinct physical voters. Merely replicating WAL is not enough.
 *
 * The writer stores one replaceable, fsynced checkpoint per old membership.
 * All fields and voter signatures are reverified on every process restart.
 */
public final class DurableWalCertificateCustody implements AutoCloseable {
    private static final int MAGIC=0x4f544343; // OTCC
    private static final int VERSION=1, MAX_CERT_BYTES=32768;
    private static final String HEAD="head.bin",PENDING="head.pending",LOCK=".custody-writer.lock";

    public interface Authority {
        /** Must recheck the pinned old epoch and assignment; fail closed. */
        void requireOldEpochAuthorized(DurableWalCommitQuorum.Membership old) throws Exception;
    }

    private final DurableWalCommitQuorum.Membership membership;
    private final DurableWalCommitQuorum.LocalDurability localWal;
    private final Authority authority;
    private final Path directory;
    private final FileChannel writerChannel;
    private final FileLock writerLock;
    private DurableWalCommitQuorum.Certificate head;
    private boolean closed;

    public DurableWalCertificateCustody(Path directory,
            DurableWalCommitQuorum.Membership membership,
            DurableWalCommitQuorum.LocalDurability localWal,Authority authority)
            throws Exception {
        if(directory==null || membership==null || localWal==null || authority==null
                || Files.isSymbolicLink(directory))
            throw new IOException("trusted custody directory, WAL and old membership required");
        this.directory=directory;
        this.membership=membership;
        this.localWal=localWal;
        this.authority=authority;
        Files.createDirectories(directory);
        if(!Files.isDirectory(directory,LinkOption.NOFOLLOW_LINKS))
            throw new IOException("unsafe custody directory");
        if(Files.isSymbolicLink(directory.resolve(LOCK)))
            throw new IOException("custody lock symlink refused");
        writerChannel=FileChannel.open(directory.resolve(LOCK),
                StandardOpenOption.WRITE,StandardOpenOption.CREATE);
        FileLock acquired=null;
        try {
            acquired=writerChannel.tryLock();
            if(acquired==null)throw new IOException("another custodian holds the lock");
            writerLock=acquired;
            loadAndVerify();
        }catch(Exception fail){
            if(acquired!=null)acquired.release();
            writerChannel.close();
            throw fail;
        }
    }

    /** Every successful call has physically forced the exact attested head. */
    public synchronized long install(DurableWalCommitQuorum.Certificate proposed)
            throws Exception {
        requireOpen();
        DurableWalCommitQuorum.Certificate proof=verifyCertificate(proposed);
        String localPrefix=localWal.requireFsyncedPrefix(
                membership.epoch,proof.committedSequence);
        if(!proof.commitPrefixSha256.equals(localPrefix))
            throw new IOException("replica WAL diverges from attested quorum commit head");
        authority.requireOldEpochAuthorized(membership);
        if(head!=null) {
            if(proof.committedSequence<head.committedSequence)
                throw new IOException("custody watermark regression");
            if(proof.committedSequence==head.committedSequence) {
                if(!head.commitPrefixSha256.equals(proof.commitPrefixSha256))
                    throw new IOException("forked custody head");
                authority.requireOldEpochAuthorized(membership);
                return proof.committedSequence;
            }
        }
        byte[] encoded=encode(proof);
        if(encoded.length>MAX_CERT_BYTES)
            throw new IOException("certificate exceeds bounded custody frame");
        Path tmp=directory.resolve(PENDING),target=directory.resolve(HEAD);
        if(Files.exists(tmp,LinkOption.NOFOLLOW_LINKS)
                || Files.isSymbolicLink(target))
            throw new IOException("pending or untrusted custody artifact");
        try(FileChannel stream=FileChannel.open(tmp,
                StandardOpenOption.CREATE_NEW,StandardOpenOption.WRITE)) {
            ByteBuffer buffer=ByteBuffer.wrap(encoded);
            while(buffer.hasRemaining())stream.write(buffer);
            stream.force(true);
        }
        // Do NOT publish custody if the old primary already lost its epoch.
        authority.requireOldEpochAuthorized(membership);
        String second=localWal.requireFsyncedPrefix(
                membership.epoch,proof.committedSequence);
        if(!proof.commitPrefixSha256.equals(second))
            throw new IOException("replica WAL changed during custody installation");
        Files.move(tmp,target,StandardCopyOption.ATOMIC_MOVE,
                StandardCopyOption.REPLACE_EXISTING);
        try(FileChannel dir=FileChannel.open(directory,StandardOpenOption.READ)){
            dir.force(true);
        }
        head=proof;
        // Caller must still recheck authority before client ACK.
        authority.requireOldEpochAuthorized(membership);
        return proof.committedSequence;
    }

    /** Read-only and safe after an old primary dies; NEVER grants READY. */
    public synchronized DurableWalCommitQuorum.Certificate highestVerified()
            throws Exception {
        requireOpen();
        if(head==null)return null;
        String actual=localWal.requireFsyncedPrefix(
                membership.epoch,head.committedSequence);
        if(!head.commitPrefixSha256.equals(actual))
            throw new IOException("custodied commit head no longer matches durable WAL");
        return head;
    }

    /** RSA proof is generated only from THIS locally fsynced certificate. */
    public synchronized DurableWalCustodyQuorum.Receipt signInstalled(
            String thisPhysicalNode,java.security.PrivateKey privateKey)throws Exception {
        requireOpen();
        authority.requireOldEpochAuthorized(membership);
        DurableWalCommitQuorum.Certificate installed=highestVerified();
        if(installed==null)throw new IOException("no physically installed custody certificate");
        DurableWalCustodyQuorum.Receipt signed=DurableWalCustodyQuorum.signVerified(
                membership,thisPhysicalNode,installed,privateKey);
        authority.requireOldEpochAuthorized(membership);
        return signed;
    }

    private DurableWalCommitQuorum.Certificate verifyCertificate(
            DurableWalCommitQuorum.Certificate cert)throws Exception {
        if(cert==null || cert.epoch!=membership.epoch
                || !membership.digest.equals(cert.membershipSha256)
                || cert.committedSequence<=0)
            throw new IOException("untrusted or cross-epoch custody certificate");
        return DurableWalCommitQuorum.verify(membership,cert.committedSequence,
                cert.commitPrefixSha256,cert.votes);
    }

    private void loadAndVerify()throws Exception {
        try(DirectoryStream<Path> all=Files.newDirectoryStream(directory)){
            for(Path file:all){
                String name=file.getFileName().toString();
                if(!LOCK.equals(name) && !HEAD.equals(name))
                    throw new IOException("pending or unknown custody file: "+name);
                if(Files.isSymbolicLink(file)
                        || !Files.isRegularFile(file,LinkOption.NOFOLLOW_LINKS))
                    throw new IOException("unsafe custody artifact");
            }
        }
        Path target=directory.resolve(HEAD);
        if(!Files.exists(target,LinkOption.NOFOLLOW_LINKS))return;
        long size=Files.size(target);
        if(size<=0 || size>MAX_CERT_BYTES)
            throw new IOException("invalid custody size");
        try(DataInputStream in=new DataInputStream(
                new ByteArrayInputStream(Files.readAllBytes(target)))) {
            if(in.readInt()!=MAGIC || in.readInt()!=VERSION
                    || !membership.digest.equals(in.readUTF()))
                throw new IOException("custody membership/version mismatch");
            long seq=in.readLong(),epoch=in.readLong();
            String hash=in.readUTF();
            int count=in.readInt();
            if(count<membership.majority() || count>membership.members.size())
                throw new IOException("unverified physical custody votes");
            List<DurableWalCommitQuorum.Receipt> witnesses=
                    new ArrayList<DurableWalCommitQuorum.Receipt>();
            for(int i=0;i<count;i++){
                String node=in.readUTF(),part=in.readUTF();
                long voteEpoch=in.readLong(),voteSeq=in.readLong();
                String voteHash=in.readUTF(),membershipHash=in.readUTF();
                int n=in.readInt();
                if(n<=0 || n>1024)
                    throw new IOException("unbounded signature in custody");
                byte[] sig=new byte[n];
                in.readFully(sig);
                witnesses.add(DurableWalCommitQuorum.Receipt.fromWire(
                        node,part,voteEpoch,voteSeq,voteHash,membershipHash,sig));
            }
            if(epoch!=membership.epoch || in.read()!=-1)
                throw new IOException("custody epoch or trailing data mismatch");
            head=verifyCertificate(DurableWalCommitQuorum.verify(
                    membership,seq,hash,witnesses));
            // Even a valid RSA quorum certificate is unsafe after WAL rollback.
            highestVerified();
        }
    }

    private byte[] encode(DurableWalCommitQuorum.Certificate cert)
            throws IOException {
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();
        DataOutputStream out=new DataOutputStream(bytes);
        out.writeInt(MAGIC);out.writeInt(VERSION);out.writeUTF(membership.digest);
        out.writeLong(cert.committedSequence);out.writeLong(cert.epoch);
        out.writeUTF(cert.commitPrefixSha256);out.writeInt(cert.votes.size());
        for(DurableWalCommitQuorum.Receipt r:cert.votes) {
            out.writeUTF(r.node);out.writeUTF(r.partition);
            out.writeLong(r.epoch);out.writeLong(r.sequence);
            out.writeUTF(r.commitPrefixSha256);out.writeUTF(r.membershipSha256);
            byte[] signed=r.signature();
            out.writeInt(signed.length);out.write(signed);
        }
        out.flush();
        return bytes.toByteArray();
    }

    private void requireOpen()throws IOException {
        if(closed || !writerLock.isValid())
            throw new IOException("custody ledger unavailable");
    }

    @Override public synchronized void close()throws IOException {
        if(closed)return;
        closed=true;
        try { writerLock.release(); } finally { writerChannel.close(); }
    }
}
