package com.app.common.replication;

import java.io.IOException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import org.junit.Test;
import static org.junit.Assert.*;

public final class CertifiedSignedWalEvidenceVerifierTest {
    private static final String HASH=
            "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef";
    private static final class Fixture
            implements CertifiedSignedWalEvidenceVerifier.Source {
        final KeyPair[] keys=new KeyPair[2];
        final DurableWalCommitQuorum.Membership member;
        final DurableWalCommitQuorum.Certificate signed;
        Collection<DurableWalCustodyQuorum.Receipt> custody;
        String localWalHash=HASH;
        int ownerFences;
        Fixture()throws Exception {
            KeyPairGenerator gen=KeyPairGenerator.getInstance("RSA");
            gen.initialize(2048);
            for(int i=0;i<2;i++)keys[i]=gen.generateKeyPair();
            member=new DurableWalCommitQuorum.Membership("TradeSvr",
                "P000","NodeA",7,15,Arrays.asList(
                new DurableWalCommitQuorum.Member("NodeA",
                    "physical-machine-A",keys[0].getPublic()),
                new DurableWalCommitQuorum.Member("NodeB",
                    "physical-machine-B",keys[1].getPublic())));
            DurableWalCommitQuorum.LocalDurability durability=(epoch,seq)->{
                if(epoch!=7 || seq!=2029)throw new IOException("wrong WAL head");
                return HASH;
            };
            DurableWalCommitQuorum.Receipt a=DurableWalCommitQuorum.sign(
                member,"NodeA",2029,durability,keys[0].getPrivate());
            DurableWalCommitQuorum.Receipt b=DurableWalCommitQuorum.sign(
                member,"NodeB",2029,durability,keys[1].getPrivate());
            signed=DurableWalCommitQuorum.verify(member,2029,HASH,
                Arrays.asList(a,b));
            custody=Arrays.asList(
                DurableWalCustodyQuorum.signVerified(member,"NodeA",
                    signed,keys[0].getPrivate()),
                DurableWalCustodyQuorum.signVerified(member,"NodeB",
                    signed,keys[1].getPrivate()));
        }
        @Override public DurableWalCommitQuorum.Membership oldMembership(
                String part,long epoch,String primary,String replica){
            return member;
        }
        @Override public DurableWalCommitQuorum.Certificate persistedCommitHead(
                DurableWalCommitQuorum.Membership m){return signed;}
        @Override public String requireCandidateFsyncedPrefix(
                DurableWalCommitQuorum.Membership m,long seq){
            return localWalHash;
        }
        @Override public Collection<DurableWalCustodyQuorum.Receipt>
                persistedCustodyReceipts(DurableWalCommitQuorum.Membership m,
                DurableWalCommitQuorum.Certificate head){
            return custody;
        }
        @Override public void requireOldOwnerIsolated(String partition,long old,
                String primary,long next,String leader,int version)throws Exception{
            if(version!=8 || next<=old)throw new IOException("old Epoch still valid");
            ownerFences++;
        }
        @Override public void requireAsyncRecovery(String id,long old,
                String primary,long next,String leader)throws Exception {
            throw new IOException("this is a strict-only fixture");
        }
    }
    private static ZkNodeScopedControlPlane.Manifest manifest(
            long generation,long epoch) {
        Map<String,ZkNodeScopedControlPlane.Assignment> routes=new HashMap<>();
        routes.put("P000",new ZkNodeScopedControlPlane.Assignment(
            new NodePartitionGrantTable.Partition("P000",epoch,
                "NodeA","NodeB",DurableWalAckPolicy.STRICT_QUORUM),true));
        return new ZkNodeScopedControlPlane.Manifest(generation,routes);
    }
    private static void denied(Checked work)throws Exception {
        try{work.check();fail("invalid real RSA proof accepted");}
        catch(IOException | IllegalArgumentException expected){}
    }
    interface Checked{void check()throws Exception;}

    @Test public void realRsaWalQuorumAndRealRsaDualCustodyAllowHeadCheck()
            throws Exception {
        Fixture physical=new Fixture();
        CertifiedNodeRecoveryGate gate=new CertifiedNodeRecoveryGate(
            new CertifiedSignedWalEvidenceVerifier(physical));
        gate.requireCertifiedNewEpoch("NodeB",
            manifest(1,7),manifest(2,8),8);
        assertEquals(1,physical.ownerFences);
    }
    @Test public void singleSignedCustodyCannotMasqueradeAsTwoPhysical()
            throws Exception {
        Fixture f=new Fixture();
        f.custody=Arrays.asList(f.custody.iterator().next());
        denied(()->new CertifiedNodeRecoveryGate(
            new CertifiedSignedWalEvidenceVerifier(f))
            .requireCertifiedNewEpoch("NodeB",manifest(1,7),manifest(2,8),8));
    }
    @Test public void wrongWalPrefixRejectsEvenWithValidRsaCustody()
            throws Exception {
        Fixture f=new Fixture();
        f.localWalHash=HASH.replace('a','b');
        denied(()->new CertifiedNodeRecoveryGate(
            new CertifiedSignedWalEvidenceVerifier(f))
            .requireCertifiedNewEpoch("NodeB",manifest(1,7),manifest(2,8),8));
    }
    @Test public void custodyReceiptFromOnlyOneVoterIsNotQuorum()
            throws Exception {
        Fixture f=new Fixture();
        DurableWalCustodyQuorum.Receipt a=f.custody.iterator().next();
        f.custody=Arrays.asList(a,a);
        denied(()->new CertifiedNodeRecoveryGate(
            new CertifiedSignedWalEvidenceVerifier(f))
            .requireCertifiedNewEpoch("NodeB",manifest(1,7),manifest(2,8),8));
    }
}
