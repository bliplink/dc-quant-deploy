package com.app.common.replication;

import org.junit.Test;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import java.util.Collection;
import static org.junit.Assert.*;

public class DurableWalCommitQuorumTest {
    private static final String WAL_HASH=
            "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef";

    private static class Fixture {
        final KeyPair[] key=new KeyPair[3];
        final DurableWalCommitQuorum.Membership membership;
        Fixture() throws Exception {
            KeyPairGenerator gen=KeyPairGenerator.getInstance("RSA");
            gen.initialize(2048);
            for(int i=0;i<3;i++)key[i]=gen.generateKeyPair();
            membership=cluster("OrderSvr",7,13);
        }
        DurableWalCommitQuorum.Membership cluster(String service,long epoch,long config)
                throws Exception {
            return new DurableWalCommitQuorum.Membership(service,"P000","nodeA",epoch,config,
                    Arrays.asList(
                            new DurableWalCommitQuorum.Member("nodeA","host-a",key[0].getPublic()),
                            new DurableWalCommitQuorum.Member("nodeB","host-b",key[1].getPublic()),
                            new DurableWalCommitQuorum.Member("nodeC","host-c",key[2].getPublic())));
        }
        DurableWalCommitQuorum.Receipt receipt(int index)throws Exception {
            String node="node"+(char)('A'+index);
            return DurableWalCommitQuorum.sign(membership,node,15,
                    (epoch,seq)->{
                        if(epoch!=7 || seq!=15)throw new IllegalStateException("not durable");
                        return WAL_HASH;
                    },key[index].getPrivate());
        }
    }

    @Test public void exactTwoOfThreeAllowsBusinessNeutralCommittedBoundary()throws Exception {
        Fixture f=new Fixture();
        DurableWalCommitQuorum.Certificate cert=DurableWalCommitQuorum.verify(
                f.membership,15,WAL_HASH,Arrays.asList(f.receipt(0),f.receipt(1)));
        assertEquals(15,cert.committedSequence);
        assertEquals(2,cert.votes.size());
        assertEquals(7,cert.epoch);
        assertFalse(cert.authorizesReady());
    }

    @Test public void rejectSingleWitnessDuplicatePhysicalAndMissingPrimary()throws Exception {
        Fixture f=new Fixture();
        DurableWalCommitQuorum.Receipt a=f.receipt(0),b=f.receipt(1),c=f.receipt(2);
        rejects(()->DurableWalCommitQuorum.verify(f.membership,15,WAL_HASH,Arrays.asList(a)));
        rejects(()->DurableWalCommitQuorum.verify(f.membership,15,WAL_HASH,Arrays.asList(a,a)));
        rejects(()->DurableWalCommitQuorum.verify(f.membership,15,WAL_HASH,Arrays.asList(b,c)));
    }

    @Test public void rejectForgedSignatureWrongWalPrefixAndMembershipChange()throws Exception {
        Fixture f=new Fixture();
        DurableWalCommitQuorum.Receipt a=f.receipt(0),b=f.receipt(1);
        byte[] fake=b.signature();
        fake[fake.length-1]^=1;
        DurableWalCommitQuorum.Receipt forged=DurableWalCommitQuorum.Receipt.fromWire(
                b.node,b.partition,b.epoch,b.sequence,b.commitPrefixSha256,b.membershipSha256,fake);
        rejects(()->DurableWalCommitQuorum.verify(f.membership,15,WAL_HASH,Arrays.asList(a,forged)));
        String different="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
        rejects(()->DurableWalCommitQuorum.verify(f.membership,15,different,Arrays.asList(a,b)));
        rejects(()->DurableWalCommitQuorum.verify(f.cluster("TradeSvr",7,13),15,WAL_HASH,
                Arrays.asList(a,b)));
        rejects(()->DurableWalCommitQuorum.verify(f.cluster("OrderSvr",8,14),15,WAL_HASH,
                Arrays.asList(a,b)));
    }

    @Test public void signerCannotBypassLocalFsyncOrEpoch()throws Exception {
        Fixture f=new Fixture();
        rejects(()->DurableWalCommitQuorum.sign(f.membership,"nodeA",15,
                (epoch,seq)->{throw new IllegalStateException("fsync incomplete");},
                f.key[0].getPrivate()));
        rejects(()->DurableWalCommitQuorum.sign(f.membership,"nodeA",15,
                (epoch,seq)->"not-a-sha256",f.key[0].getPrivate()));
        rejects(()->DurableWalCommitQuorum.sign(f.membership,"stranger",15,
                (epoch,seq)->WAL_HASH,f.key[0].getPrivate()));
    }

    @Test public void membershipRequiresDistinctPhysicalHostsAndKeys()throws Exception {
        Fixture f=new Fixture();
        rejects(()->new DurableWalCommitQuorum.Membership("OrderSvr","P000","nodeA",7,13,
                Arrays.asList(
                        new DurableWalCommitQuorum.Member("nodeA","host-a",f.key[0].getPublic()),
                        new DurableWalCommitQuorum.Member("nodeB","host-a",f.key[1].getPublic()),
                        new DurableWalCommitQuorum.Member("nodeC","host-c",f.key[2].getPublic()))));
        rejects(()->new DurableWalCommitQuorum.Membership("OrderSvr","P000","nodeA",7,13,
                Arrays.asList(
                        new DurableWalCommitQuorum.Member("nodeA","host-a",f.key[0].getPublic()),
                        new DurableWalCommitQuorum.Member("nodeB","host-b",f.key[0].getPublic()),
                        new DurableWalCommitQuorum.Member("nodeC","host-c",f.key[2].getPublic()))));
    }

    private interface Checked {void apply() throws Exception;}
    private static void rejects(Checked call) throws Exception {
        try {call.apply();fail("must reject uncertified WAL commit quorum");}
        catch(IllegalArgumentException|IllegalStateException expected){}
    }
}
