package com.app.common.replication;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.util.Arrays;
import java.util.List;
import static org.junit.Assert.*;

public class DurableWalCommitIndexTest {
    @Rule public TemporaryFolder temp=new TemporaryFolder();
    private static final String HASH1="0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef";
    private static final String HASH2="abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789";

    private final class Fixture {
        final KeyPair[] keys=new KeyPair[3];
        final DurableWalCommitQuorum.Membership members;
        Fixture()throws Exception {
            KeyPairGenerator gen=KeyPairGenerator.getInstance("RSA");gen.initialize(2048);
            for(int i=0;i<3;i++)keys[i]=gen.generateKeyPair();
            members=new DurableWalCommitQuorum.Membership("OrderSvr","P000",
                    "nodeA",8L,41L,Arrays.asList(
                    new DurableWalCommitQuorum.Member("nodeA","physicalA",keys[0].getPublic()),
                    new DurableWalCommitQuorum.Member("nodeB","physicalB",keys[1].getPublic()),
                    new DurableWalCommitQuorum.Member("nodeC","physicalC",keys[2].getPublic())));
        }
        DurableWalCommitQuorum.Receipt sign(int n,long seq,String prefix)throws Exception {
            return DurableWalCommitQuorum.sign(members,"node"+(char)('A'+n),seq,
                    (epoch,required)->{
                        if(epoch!=8 || required!=seq)throw new IllegalStateException("stale");
                        return prefix;
                    },keys[n].getPrivate());
        }
        List<DurableWalCommitQuorum.Receipt> votes(long seq,String hash)throws Exception {
            return Arrays.asList(sign(0,seq,hash),sign(1,seq,hash));
        }
    }

    @Test public void committedWatermarkAdvancesOnlyAfterDurableAtomicProofAndRestart()
            throws Exception {
        Fixture f=new Fixture();
        Path directory=temp.newFolder("quorum-disk").toPath();
        try(DurableWalCommitIndex ledger=new DurableWalCommitIndex(directory,f.members)) {
            assertEquals(0,ledger.committedSequence());
            DurableWalCommitQuorum.Certificate first=
                    ledger.certifyAndPersist(12,HASH1,f.votes(12,HASH1));
            assertEquals(12,first.committedSequence);
            assertFalse(first.authorizesReady());
            ledger.certifyAndPersist(13,HASH2,f.votes(13,HASH2));
            assertEquals(13,ledger.committedSequence());
            assertEquals(13,ledger.verifiedHighestCertificate().committedSequence);
            assertEquals(HASH2,ledger.verifiedHighestCertificate().commitPrefixSha256);
            assertTrue(Files.isRegularFile(directory.resolve("commit-00000000000000000012.bin")));
            assertTrue(Files.isRegularFile(directory.resolve("commit-00000000000000000013.bin")));
        }
        try(DurableWalCommitIndex restored=new DurableWalCommitIndex(directory,f.members)) {
            assertEquals(13,restored.committedSequence());
            assertEquals(13,restored.verifiedHighestCertificate().committedSequence);
            assertEquals(HASH2,restored.verifiedHighestCertificate().commitPrefixSha256);
            restored.certifyAndPersist(14,HASH2,f.votes(14,HASH2));
            assertEquals(14,restored.committedSequence());
        }
    }

    @Test public void missingDurableQuorumDoesNotCreateCertOrAdvanceIndex()throws Exception {
        Fixture f=new Fixture();
        Path path=temp.newFolder("reject-single").toPath();
        try(DurableWalCommitIndex ledger=new DurableWalCommitIndex(path,f.members)) {
            denied(()->ledger.certifyAndPersist(2,HASH1,Arrays.asList(f.sign(0,2,HASH1))));
            assertEquals(0,ledger.committedSequence());
            assertFalse(Files.exists(path.resolve("commit-00000000000000000002.bin")));
            ledger.certifyAndPersist(2,HASH1,f.votes(2,HASH1));
            denied(()->ledger.certifyAndPersist(2,HASH1,f.votes(2,HASH1)));
            assertEquals(2,ledger.committedSequence());
        }
    }

    @Test public void modifiedCertificateIsNotTrustedAfterRestart()throws Exception {
        Fixture f=new Fixture();
        Path path=temp.newFolder("tampered").toPath();
        try(DurableWalCommitIndex ledger=new DurableWalCommitIndex(path,f.members)) {
            ledger.certifyAndPersist(2,HASH1,f.votes(2,HASH1));
        }
        Path cert=path.resolve("commit-00000000000000000002.bin");
        byte[] tampered=Files.readAllBytes(cert);
        tampered[tampered.length-4]^=3;
        Files.write(cert,tampered);
        denied(()->new DurableWalCommitIndex(path,f.members));
    }

    @Test public void unfinishedPendingCertificateBlocksRestartAndReady()throws Exception {
        Fixture f=new Fixture();
        Path path=temp.newFolder("crashed").toPath();
        try(DurableWalCommitIndex ledger=new DurableWalCommitIndex(path,f.members)) {
            ledger.certifyAndPersist(1,HASH1,f.votes(1,HASH1));
        }
        Files.write(path.resolve("commit-00000000000000000002.bin.pending"),
                new byte[]{1,2,3});
        denied(()->new DurableWalCommitIndex(path,f.members));
    }

    @Test public void alteredMembershipAndDeletedMiddleCertificateFailClosed()throws Exception {
        Fixture f=new Fixture();
        Path path=temp.newFolder("removed-middle").toPath();
        try(DurableWalCommitIndex ledger=new DurableWalCommitIndex(path,f.members)){
            ledger.certifyAndPersist(1,HASH1,f.votes(1,HASH1));
            ledger.certifyAndPersist(2,HASH2,f.votes(2,HASH2));
            ledger.certifyAndPersist(3,HASH1,f.votes(3,HASH1));
        }
        DurableWalCommitQuorum.Membership wrongEpoch =
                new DurableWalCommitQuorum.Membership("OrderSvr","P000","nodeA",9,42,
                        Arrays.asList(
                        new DurableWalCommitQuorum.Member("nodeA","physicalA",f.keys[0].getPublic()),
                        new DurableWalCommitQuorum.Member("nodeB","physicalB",f.keys[1].getPublic()),
                        new DurableWalCommitQuorum.Member("nodeC","physicalC",f.keys[2].getPublic())));
        denied(()->new DurableWalCommitIndex(path,wrongEpoch));
        Files.delete(path.resolve("commit-00000000000000000002.bin"));
        denied(()->new DurableWalCommitIndex(path,f.members));
    }

    interface Checked {void run()throws Exception;}
    private static void denied(Checked action)throws Exception {
        try {action.run();fail("unsafe durable quorum commit ledger accepted");}
        catch(Exception expected) { /* fail closed as expected */ }
    }
}
