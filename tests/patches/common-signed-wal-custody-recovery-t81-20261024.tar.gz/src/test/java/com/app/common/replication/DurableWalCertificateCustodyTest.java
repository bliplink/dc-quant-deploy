package com.app.common.replication;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import java.io.IOException;
import java.nio.file.*;
import java.security.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import static org.junit.Assert.*;

/** Quorum certificate custody durability is distinct from raw WAL fsync. */
public class DurableWalCertificateCustodyTest {
    @Rule public TemporaryFolder files=new TemporaryFolder();
    interface Checked {void run()throws Exception;}
    static void denied(Checked body)throws Exception{
        try{body.run();fail("untrusted durable certificate custody accepted");}
        catch(IOException | IllegalStateException | IllegalArgumentException expected){}
    }
    static class Fixture {
        final KeyPair[] keys=new KeyPair[3];
        final DurableWalCommitQuorum.Membership old;
        final AtomicBoolean authorized=new AtomicBoolean(true);
        volatile long localMax=100;
        volatile String localOverride=null;
        Fixture()throws Exception{
            KeyPairGenerator gen=KeyPairGenerator.getInstance("RSA");
            gen.initialize(2048);
            List<DurableWalCommitQuorum.Member> entries=
                    new ArrayList<DurableWalCommitQuorum.Member>();
            String[] nodes={"CommonHaDemoA","CommonHaDemoB","CommonHaDemoC"};
            for(int i=0;i<keys.length;i++){
                keys[i]=gen.generateKeyPair();
                entries.add(new DurableWalCommitQuorum.Member(nodes[i],
                        "physical-test-host-"+i,keys[i].getPublic()));
            }
            old=new DurableWalCommitQuorum.Membership(
                    "CommonHaDemo","P000",nodes[0],1,1,entries);
        }
        String hash(long seq){
            return String.format(Locale.ROOT,"%064x",seq+42);
        }
        DurableWalCommitQuorum.LocalDurability wal(){
            return (epoch,seq)->{
                if(epoch!=old.epoch || seq<=0 || seq>localMax)
                    throw new IOException("missing or not fsynced local WAL prefix");
                return localOverride==null?hash(seq):localOverride;
            };
        }
        DurableWalCertificateCustody.Authority grant() {
            return m->{
                if(!authorized.get() || !m.digest.equals(old.digest))
                    throw new IOException("old epoch revoked");
            };
        }
        DurableWalCommitQuorum.Certificate cert(long seq)throws Exception{
            List<DurableWalCommitQuorum.Receipt> votes=
                    new ArrayList<DurableWalCommitQuorum.Receipt>();
            votes.add(DurableWalCommitQuorum.sign(
                    old,"CommonHaDemoA",seq,wal(),keys[0].getPrivate()));
            votes.add(DurableWalCommitQuorum.sign(
                    old,"CommonHaDemoB",seq,wal(),keys[1].getPrivate()));
            return DurableWalCommitQuorum.verify(old,seq,hash(seq),votes);
        }
        DurableWalCertificateCustody open(Path path)throws Exception {
            return new DurableWalCertificateCustody(path,old,wal(),grant());
        }
    }

    @Test public void independentBAndCCustodySurviveRestartAndVerifyExactHead()
            throws Exception {
        Fixture f=new Fixture();
        Path b=files.newFolder("custodyB").toPath();
        Path c=files.newFolder("custodyC").toPath();
        DurableWalCommitQuorum.Certificate head=f.cert(55);
        try(DurableWalCertificateCustody one=f.open(b);
            DurableWalCertificateCustody two=f.open(c)) {
            assertEquals(55,one.install(head));
            assertEquals(55,two.install(head));
            assertEquals(f.hash(55),one.highestVerified().commitPrefixSha256);
            assertEquals(f.hash(55),two.highestVerified().commitPrefixSha256);
            assertEquals(55,one.install(head)); // idempotent same proof
        }
        f.authorized.set(false); // old primary dead; proof remains auditable.
        try(DurableWalCertificateCustody one=f.open(b);
            DurableWalCertificateCustody two=f.open(c)) {
            assertEquals(55,one.highestVerified().committedSequence);
            assertEquals(55,two.highestVerified().committedSequence);
            denied(()->one.install(f.cert(56)));
        }
    }

    @Test public void cannotInstallWithoutLocallyFsyncedWalOrCurrentOldEpoch()
            throws Exception {
        Fixture f=new Fixture();
        Path root=files.newFolder("missing-data").toPath();
        DurableWalCommitQuorum.Certificate head=f.cert(50);
        f.localMax=49;
        try(DurableWalCertificateCustody ledger=f.open(root)){
            denied(()->ledger.install(head));
            assertNull(ledger.highestVerified());
            f.localMax=100;f.authorized.set(false);
            denied(()->ledger.install(head));
            assertNull(ledger.highestVerified());
            f.authorized.set(true);
            assertEquals(50,ledger.install(head));
            f.localOverride=String.format(Locale.ROOT,"%064x",999);
            denied(()->ledger.highestVerified());
        }
    }

    @Test public void rollbackTamperAndPendingInstallRefusedAtRestart()throws Exception {
        Fixture f=new Fixture();
        Path root=files.newFolder("tamper").toPath();
        DurableWalCommitQuorum.Certificate proof=f.cert(35);
        try(DurableWalCertificateCustody ledger=f.open(root)){
            assertEquals(35,ledger.install(proof));
            denied(()->ledger.install(f.cert(34)));
        }
        Path head=root.resolve("head.bin");
        byte[] contents=Files.readAllBytes(head);
        contents[contents.length-1]^=1;
        Files.write(head,contents);
        denied(()->{
            try(DurableWalCertificateCustody unexpected=f.open(root)){}
        });
        // Unknown partial temporary file is always fail closed.
        Path separate=files.newFolder("pending").toPath();
        Files.write(separate.resolve("head.pending"),new byte[]{1,2,3});
        denied(()->{
            try(DurableWalCertificateCustody unexpected=f.open(separate)){}
        });
    }

    @Test public void custodyCannotBeFakedBySingleUntrustedPhysicalVoter()
            throws Exception {
        Fixture f=new Fixture();
        Path root=files.newFolder("insufficient").toPath();
        List<DurableWalCommitQuorum.Receipt> one=Collections.singletonList(
                DurableWalCommitQuorum.sign(f.old,"CommonHaDemoA",10,
                        f.wal(),f.keys[0].getPrivate()));
        denied(()->DurableWalCommitQuorum.verify(f.old,10,f.hash(10),one));
        try(DurableWalCertificateCustody custody=f.open(root)){
            assertNull(custody.highestVerified());
        }
    }

    @Test public void twoIndependentDiskCustodiansSignSeparateCertificateCustody()
            throws Exception {
        Fixture f=new Fixture();
        DurableWalCommitQuorum.Certificate certificate=f.cert(83);
        Path b=files.newFolder("signB").toPath();
        Path c=files.newFolder("signC").toPath();
        DurableWalCustodyQuorum.Receipt signedB,signedC;
        try(DurableWalCertificateCustody custodyB=f.open(b);
            DurableWalCertificateCustody custodyC=f.open(c)) {
            custodyB.install(certificate);
            custodyC.install(certificate);
            signedB=custodyB.signInstalled("CommonHaDemoB",f.keys[1].getPrivate());
            signedC=custodyC.signInstalled("CommonHaDemoC",f.keys[2].getPrivate());
            DurableWalCustodyQuorum.CustodiedCertificate agreed=
                    DurableWalCustodyQuorum.verify(f.old,certificate,
                            Arrays.asList(signedB,signedC));
            assertEquals(83,agreed.sequence);
            assertEquals(f.hash(83),agreed.walPrefixHash);
            assertEquals(2,agreed.physicalCustodians);
            assertFalse(agreed.authorizesPromotion());
            denied(()->DurableWalCustodyQuorum.verify(
                    f.old,certificate,Collections.singletonList(signedB)));
            denied(()->DurableWalCustodyQuorum.verify(
                    f.old,certificate,Arrays.asList(signedB,signedB)));
            f.authorized.set(false);
            denied(()->custodyB.signInstalled(
                    "CommonHaDemoB",f.keys[1].getPrivate()));
        }
        // A may be dead: old proof is independently recoverable on B/C.
        try(DurableWalCertificateCustody custodyB=f.open(b);
            DurableWalCertificateCustody custodyC=f.open(c)) {
            assertEquals(83,custodyB.highestVerified().committedSequence);
            assertEquals(83,custodyC.highestVerified().committedSequence);
            assertEquals(2,DurableWalCustodyQuorum.verify(
                    f.old,certificate,Arrays.asList(signedB,signedC)).physicalCustodians);
        }
    }

    @Test public void wrongNodeKeyOldSeqAndUninstalledCustodyCannotPassQuorum()
            throws Exception {
        Fixture f=new Fixture();
        DurableWalCommitQuorum.Certificate cert=f.cert(40);
        Path b=files.newFolder("wrong-key").toPath();
        Path c=files.newFolder("signable").toPath();
        try(DurableWalCertificateCustody one=f.open(b);
            DurableWalCertificateCustody two=f.open(c)) {
            denied(()->one.signInstalled(
                    "CommonHaDemoB",f.keys[1].getPrivate()));
            one.install(cert);
            two.install(cert);
            DurableWalCustodyQuorum.Receipt real=one.signInstalled(
                    "CommonHaDemoB",f.keys[1].getPrivate());
            DurableWalCustodyQuorum.Receipt wrong=two.signInstalled(
                    "CommonHaDemoC",f.keys[1].getPrivate());
            denied(()->DurableWalCustodyQuorum.verify(
                    f.old,cert,Arrays.asList(real,wrong)));
            DurableWalCustodyQuorum.Receipt validC=two.signInstalled(
                    "CommonHaDemoC",f.keys[2].getPrivate());
            DurableWalCommitQuorum.Certificate earlier=f.cert(39);
            denied(()->DurableWalCustodyQuorum.verify(
                    f.old,earlier,Arrays.asList(real,validC)));
        }
    }
    @Test public void boundedHeadDoesNotRollBackAcrossLaterValidUpdate()throws Exception{
        Fixture f=new Fixture();
        Path root=files.newFolder("ascending").toPath();
        DurableWalCommitQuorum.Certificate first=f.cert(60),second=f.cert(72);
        try(DurableWalCertificateCustody custody=f.open(root)){
            assertEquals(60,custody.install(first));
            assertEquals(72,custody.install(second));
            denied(()->custody.install(first));
        }
        try(DurableWalCertificateCustody restored=f.open(root)){
            assertEquals(72,restored.highestVerified().committedSequence);
        }
    }
}
