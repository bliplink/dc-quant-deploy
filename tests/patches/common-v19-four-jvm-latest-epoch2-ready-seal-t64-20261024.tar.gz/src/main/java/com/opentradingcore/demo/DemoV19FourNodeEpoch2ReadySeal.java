package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;
import com.app.common.partition.ZkPartitionFailoverControlPlane;
import com.app.common.replication.*;
import com.app.common.zk.ZookeeperClient;
import com.gateway.connector.utils.JsonUtils;
import java.io.IOException;
import java.nio.file.*;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.*;
import java.util.concurrent.TimeUnit;
import org.I0Itec.zkclient.exception.ZkNodeExistsException;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.data.Stat;

/**
 * T64 live READY publication barrier for the ACTUAL latest Epoch2 seq2 head.
 * Physical A/B and C/D sign independently after fresh replay of their local
 * WAL, Common contiguous index and Common durable custody. A controller ZK
 * lease serializes the signed proposal. This DOES NOT install a client writer,
 * publish READY, or authorize an ACK: it is a checked dependency for those
 * later actions. All nodes are on one Mac (not independent host domains).
 */
final class DemoV19FourNodeEpoch2ReadySeal {
    static final String OP="INTERNAL_EPOCH2_LATEST_READY_SEAL_V1";
    static final String SCOPE="EPOCH2_SEQ2_READY_SEAL_NOT_PUBLISHED_V1";
    static final String PROOFS=DemoV19FourNodeShardCatalog.ROOT+"/epoch2-ready-seals";
    private final String node;
    private final Path root;
    private final PrivateKey key;

    DemoV19FourNodeEpoch2ReadySeal(String node,Path root)throws Exception{
        if(node==null || !node.matches("CommonHaDemo[ABCD]")
                || root==null || !root.isAbsolute())
            throw new IOException("invalid physical new-epoch seal signer");
        this.node=node;this.root=root;
        key=KeyFactory.getInstance("RSA").generatePrivate(
            new PKCS8EncodedKeySpec(Files.readAllBytes(root.resolve(
                ".preflight-identity/local.pk8"))));
    }
    private static String statement(String partition,String voter,String membership,
            String oldSource,String seq2,String state,String nonce) {
        return SCOPE+"|"+partition+"|"+voter+"|epoch=2|zkVersion=1"
            +"|seq=2|member="+membership+"|oldSource="+oldSource
            +"|committed="+seq2+"|state="+state+"|nonce="+nonce
            +"|publishedReady=false|ack=false";
    }
    private static String digest(String text)throws Exception{
        return DemoV19FourNodeGenesisCustody.sha(text.getBytes(
            java.nio.charset.StandardCharsets.UTF_8));
    }
    @SuppressWarnings("unchecked")
    private static Map<String,Object> certified(ZookeeperClient zk,
            PartitionAssignment old) throws Exception {
        DemoV19FourNodeReadyPreflight.requireExactRecoveryAssignment(zk,old);
        DemoV19FourNodeEpoch2Seq2.verifySaved(zk,old);
        DemoV19FourNodeEpoch2Common.verifyProof(zk,old);
        Map<String,Object> cert=JsonUtils.Deserialize(String.valueOf(zk.readData(
            DemoV19FourNodeEpoch2Seq2.PROOFS+"/"+old.getPartitionId())),Map.class);
        Map<String,Object> install=JsonUtils.Deserialize(String.valueOf(zk.readData(
            DemoV19FourNodeEpoch2Install.PROOFS+"/"+old.getPartitionId())),Map.class);
        if(cert==null || install==null || !Objects.equals(
                cert.get("membershipSha256"),
                DemoV19FourNodeEpoch2Install.successorMembership(zk,old).digest)
                || !(cert.get("walSha256") instanceof String)
                || !(cert.get("stateSha256") instanceof String)
                || !(install.get("sourceSha256") instanceof String))
            throw new IOException("not an exact current Common seq2 head");
        Map<String,Object> head=new LinkedHashMap<>();
        head.put("membershipSha256",cert.get("membershipSha256"));
        head.put("sourceSha256",install.get("sourceSha256"));
        head.put("walSha256",cert.get("walSha256"));
        head.put("stateSha256",cert.get("stateSha256"));
        head.put("proofSha256",digest(String.valueOf(
            zk.readData(DemoV19FourNodeEpoch2Seq2.PROOFS+"/"+old.getPartitionId()))));
        return head;
    }
    ReplicationControlResponse handle(ZookeeperClient zk,List<PartitionAssignment> plan,
            DemoV19FourNodeLiveRuntime.HeldWal held,ReplicationControlRequest req) {
        try {
            if(req==null || !OP.equals(req.getOperation())
                    || req.getPayload()==null || req.getPayload().length!=32
                    || !DemoV19FourNodeShardCatalog.SERVICE.equals(
                        req.getServiceName())
                    || !zk.isConnected() || !node.equals(held.node))
                throw new IOException("invalid physical ready seal request");
            String part=req.getPartitionId();
            if(!DemoV19FourNodeSeq1NettyPilot.selected(part))
                throw new IOException("unauthorized ready seal partition");
            PartitionAssignment old=plan.get(Integer.parseInt(part.substring(1)));
            if(!DemoV19FourNodeLiveRuntime.owners(old).contains(node))
                throw new IOException("ready seal voter not current RF2 member");
            DemoDurableJournal source=held.owned.get(part);
            if(source==null)throw new IOException("old primary revoke lock unavailable");
            synchronized(source) {
                Map<String,Object> expected=certified(zk,old);
                String oldSha=(String)expected.get("sourceSha256");
                String seq2Sha=(String)expected.get("walSha256");
                String state=(String)expected.get("stateSha256");
                String member=(String)expected.get("membershipSha256");
                String oldMember=DemoV19FourNodeEpoch2Transition
                    .historicMembership(zk,old).digest;
                Path folder=root.resolve(".pilot-old-epoch-revoked-"+part);
                Path revoke=folder.resolve("head.bin");
                String expectedRevoke=DemoV19FourNodeRemoteRevocation
                    .expectedPayload(old,oldMember,oldSha)+"\n";
                if(Files.isSymbolicLink(folder) || Files.isSymbolicLink(revoke)
                        || !Files.isRegularFile(revoke,LinkOption.NOFOLLOW_LINKS)
                        || !Arrays.equals(Files.readAllBytes(revoke),
                            expectedRevoke.getBytes(java.nio.charset.StandardCharsets.UTF_8)))
                    throw new IOException("old publisher not physically fenced");
                if(source.committedSeq()!=1 || source.lastEpoch()!=1
                        || !source.isReadyForWrites()
                        || !oldSha.equals(source.committedPrefixSha256Through(1)))
                    throw new IOException("old primary journal changed during seal");
                DemoV19FourNodeEpoch2Seq2.verifyLocalAfterRestart(
                    zk,old,node,root);
                DemoV19FourNodeEpoch2Common.verifyLocalAfterRestart(
                    zk,old,node,root);
                Path active=root.resolve(DemoV19FourNodeEpoch2Seq2.dir(part))
                    .resolve("active.wal");
                try(DemoDurableJournal journal=new DemoDurableJournal(active)) {
                    if(!journal.isReadyForWrites() || journal.committedSeq()!=2
                            || journal.lastEpoch()!=2
                            || journal.snapshotSeq()!=1
                            || !oldSha.equals(journal.snapshotSourcePrefix())
                            || !seq2Sha.equals(journal.committedPrefixSha256Through(2))
                            || !state.equals(journal.state().stateDigest()))
                        throw new IOException("physical latest seq2 WAL/state diverged");
                }
                String nonce=DemoV19FourNodeGenesisPreflight.hex(req.getPayload());
                Signature signed=Signature.getInstance("SHA256withRSA");
                signed.initSign(key);
                signed.update(statement(part,node,member,oldSha,seq2Sha,state,nonce)
                    .getBytes(java.nio.charset.StandardCharsets.UTF_8));
                DemoV19FourNodeReadyPreflight.requireExactRecoveryAssignment(zk,old);
                Map<String,Object> out=new LinkedHashMap<>();
                out.put("scope",SCOPE);out.put("partition",part);
                out.put("voter",node);out.put("nonce",nonce);
                out.putAll(expected);
                out.put("ready",false);out.put("clientAck",false);
                out.put("signature",Base64.getEncoder().encodeToString(signed.sign()));
                return ReplicationControlResponse.ok(DemoNettyBridge.json(out));
            }
        } catch(Exception failure){
            return ReplicationControlResponse.error("EPOCH2_LATEST_READY_SEAL_DENIED",
                failure.getClass().getSimpleName()+": "+failure.getMessage());
        }
    }
    static void verify(ZookeeperClient zk,PartitionAssignment old,String voter,
            Map<String,Object> head,String nonce,Object raw)throws Exception {
        if(!(raw instanceof Map))throw new IOException("missing physical ready seal");
        Map<?,?> vote=(Map<?,?>)raw;
        if(!SCOPE.equals(vote.get("scope"))
                || !old.getPartitionId().equals(vote.get("partition"))
                || !voter.equals(vote.get("voter"))
                || !nonce.equals(vote.get("nonce"))
                || !Boolean.FALSE.equals(vote.get("ready"))
                || !Boolean.FALSE.equals(vote.get("clientAck"))
                || !head.get("sourceSha256").equals(vote.get("sourceSha256"))
                || !head.get("walSha256").equals(vote.get("walSha256"))
                || !head.get("stateSha256").equals(vote.get("stateSha256"))
                || !head.get("membershipSha256").equals(vote.get("membershipSha256"))
                || !head.get("proofSha256").equals(vote.get("proofSha256"))
                || !(vote.get("signature") instanceof String))
            throw new IOException("old or cross-group latest-head ready seal");
        Signature s=Signature.getInstance("SHA256withRSA");
        s.initVerify(DemoV19FourNodeGenesisPreflight.pinned(zk,voter));
        s.update(statement(old.getPartitionId(),voter,
                (String)head.get("membershipSha256"),
                (String)head.get("sourceSha256"),
                (String)head.get("walSha256"),
                (String)head.get("stateSha256"),nonce)
            .getBytes(java.nio.charset.StandardCharsets.UTF_8));
        if(!s.verify(Base64.getDecoder().decode((String)vote.get("signature"))))
            throw new IOException("physical latest-head ready seal RSA invalid");
    }
    @SuppressWarnings("unchecked")
    static void verifySaved(ZookeeperClient zk,PartitionAssignment old)throws Exception{
        String path=PROOFS+"/"+old.getPartitionId();
        Stat s=new Stat();Object raw=zk.readData(path,s);
        if(raw==null || s.getVersion()!=0)throw new IOException("ready seal not immutable");
        Map<String,Object> stored=JsonUtils.Deserialize(String.valueOf(raw),Map.class);
        Map<String,Object> head=certified(zk,old);
        if(!SCOPE.equals(stored.get("scope"))
                || !old.getPartitionId().equals(stored.get("partition"))
                || !head.equals(stored.get("head"))
                || !(stored.get("nonce") instanceof String)
                || !(stored.get("votes") instanceof List))
            throw new IOException("not current signed seq2 READY seal");
        List<?> votes=(List<?>)stored.get("votes");
        if(votes.size()!=2)throw new IOException("latest head missing second signer");
        for(int i=0;i<2;i++){
            String voter=DemoV19FourNodeLiveRuntime.owners(old).get(i);
            verify(zk,old,voter,head,(String)stored.get("nonce"),votes.get(i));
        }
    }
    static void sealTwo(ZookeeperClient zk,List<PartitionAssignment> plan)
            throws Exception {
        if(!zk.isConnected())throw new IOException("ZooKeeper data authority lost");
        DemoV19FourNodeShardCatalog.ensurePath(zk,PROOFS);
        try(ZkPartitionFailoverControlPlane controller=
                new ZkPartitionFailoverControlPlane(zk,
                    DemoV19FourNodeShardCatalog.ASSIGNMENTS,
                    "/MDTService",
                    DemoV19FourNodeShardCatalog.ROOT+"/t64-live-ready-seal-lease",
                    "t64-publisher");
            DirectNettyReplicationTransport tcp=new DirectNettyReplicationTransport(
                10000,DirectNettyReplicationServer.DEFAULT_MAX_FRAME_BYTES)){
            if(!controller.tryAcquireLease() || !controller.hasLease())
                throw new IOException("current real control lease not acquired");
            for(String part:new String[]{"P000","P128"}){
                PartitionAssignment old=plan.get(Integer.parseInt(part.substring(1)));
                Map<String,Object> head=certified(zk,old);
                byte[] nonce=new byte[32];new SecureRandom().nextBytes(nonce);
                String challenge=DemoV19FourNodeGenesisPreflight.hex(nonce);
                List<Map<String,Object>> votes=new ArrayList<>();
                for(String voter:DemoV19FourNodeLiveRuntime.owners(old)){
                    if(!controller.hasLease())
                        throw new IOException("controller lease revoked between voters");
                    ReplicationControlResponse response=tcp.control(
                        DemoV19FourNodeLiveRuntime.exactEndpoint(voter),
                        new ReplicationControlRequest(
                            DemoV19FourNodeShardCatalog.SERVICE,OP,part,nonce))
                        .get(8,TimeUnit.SECONDS);
                    if(!response.isSuccess())
                        throw new IOException("latest live voter "+voter+
                            " could not seal: "+response.getCode()+":"+
                            response.getMessage());
                    Map<String,Object> vote=DemoNettyBridge.map(response.getPayload());
                    verify(zk,old,voter,head,challenge,vote);
                    votes.add(vote);
                }
                if(!controller.hasLease())
                    throw new IOException("lost controller lease before durable proof");
                Map<String,Object> persisted=new LinkedHashMap<>();
                persisted.put("scope",SCOPE);persisted.put("partition",part);
                persisted.put("nonce",challenge);
                persisted.put("head",head);
                persisted.put("votes",votes);
                String path=PROOFS+"/"+part;
                if(!zk.exists(path)){
                    try{zk.create(path,JsonUtils.Serializer(persisted),CreateMode.PERSISTENT);}
                    catch(ZkNodeExistsException raced){}
                }
                verifySaved(zk,old);
                if(!controller.hasLease())
                    throw new IOException("lost controller lease after durable proof");
                System.out.println("FOUR_NODE_T64_LATEST_SEQ2_READY_SEAL_PASS partition="+part+
                    " currentHeadSeq=2 signedPhysicalVoters=2"+
                    " twoCommonCustodiesDurable=true controllerLeaseLive=true"+
                    " zkState=RECOVERING publishedReady=false clientAck=false");
            }
        }
    }
}
