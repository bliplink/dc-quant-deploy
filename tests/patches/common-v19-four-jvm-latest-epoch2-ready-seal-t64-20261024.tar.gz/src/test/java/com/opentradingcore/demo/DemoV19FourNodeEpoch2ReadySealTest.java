package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;
import java.io.IOException;
import java.util.*;
import org.junit.Test;
import static org.junit.Assert.*;

/** T64: a stale/latest-head or forged READY authorization must fail closed. */
public final class DemoV19FourNodeEpoch2ReadySealTest {
    private static Map<String,Object> head() {
        Map<String,Object> h=new LinkedHashMap<>();
        h.put("membershipSha256",repeat('a',64));
        h.put("sourceSha256",repeat('b',64));
        h.put("walSha256",repeat('c',64));
        h.put("stateSha256",repeat('d',64));
        h.put("proofSha256",repeat('e',64));
        return h;
    }
    private static String repeat(char c,int n){
        char[] a=new char[n];Arrays.fill(a,c);return new String(a);
    }
    private static Map<String,Object> candidate(String partition,String voter,
            String nonce) {
        Map<String,Object> m=new LinkedHashMap<>(head());
        m.put("scope",DemoV19FourNodeEpoch2ReadySeal.SCOPE);
        m.put("partition",partition);
        m.put("voter",voter);
        m.put("nonce",nonce);
        m.put("signature","not-an-authentic-RSA-signature");
        m.put("ready",false);m.put("clientAck",false);
        return m;
    }
    private static void denied(PartitionAssignment assignment,String voter,
            Map<String,Object> expected,String nonce,Object attempt) throws Exception{
        try {
            // Every malformed case MUST be rejected before any key lookup.
            DemoV19FourNodeEpoch2ReadySeal.verify(null,assignment,voter,
                expected,nonce,attempt);
            fail("unsafe ready-seal authority admitted");
        } catch(IOException expectedDenial){
            assertNotNull(expectedDenial.getMessage());
        }
    }
    @Test public void priorSeq1CannotSignLatestSeq2()throws Exception{
        PartitionAssignment a=DemoV19FourNodeShardCatalog.layout().get(0);
        String voter=a.getReplica();
        Map<String,Object> attempt=candidate(a.getPartitionId(),voter,"0102");
        attempt.put("walSha256",repeat('0',64));
        denied(a,voter,head(),"0102",attempt);
    }
    @Test public void changingPeerNonceOrMembershipFails()throws Exception{
        PartitionAssignment a=DemoV19FourNodeShardCatalog.layout().get(128);
        String voter=a.getPrimary();
        Map<String,Object> attempt=candidate(a.getPartitionId(),voter,"0102");
        denied(a,voter,head(),"different nonce",attempt);
        attempt.put("nonce","different nonce");
        attempt.put("membershipSha256",repeat('f',64));
        denied(a,voter,head(),"different nonce",attempt);
        attempt.put("membershipSha256",repeat('a',64));
        attempt.put("partition","P000");
        denied(a,voter,head(),"different nonce",attempt);
    }
    @Test public void readyOrAckBitForbiddenInPrePublicationSeal() throws Exception{
        PartitionAssignment a=DemoV19FourNodeShardCatalog.layout().get(0);
        String voter=a.getPrimary();
        Map<String,Object> attempt=candidate(a.getPartitionId(),voter,"nonce");
        attempt.put("ready",true);
        denied(a,voter,head(),"nonce",attempt);
        attempt.put("ready",false);
        attempt.put("clientAck",true);
        denied(a,voter,head(),"nonce",attempt);
    }
}
