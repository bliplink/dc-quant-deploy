package com.opentradingcore.demo;

import com.app.common.replication.ReplicationControlRequest;
import com.app.common.replication.ReplicationControlResponse;
import java.nio.file.Paths;
import java.util.*;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Invalid client envelopes must be rejected BEFORE touching ZooKeeper or
 * opening WAL/custody. No READY or ACK can be inferred from a seq number.
 */
public final class DemoV19FourNodeEpoch2StrictAckTest {
    private DemoV19FourNodeEpoch2StrictAck gate(){
        return new DemoV19FourNodeEpoch2StrictAck(
            "CommonHaDemoB",Paths.get("/unavailable"),null,null,null);
    }
    private ReplicationControlResponse send(String part,Map<String,Object> body){
        return gate().handle(new ReplicationControlRequest(
            DemoV19FourNodeShardCatalog.SERVICE,
            DemoV19FourNodeEpoch2StrictAck.OP,part,DemoNettyBridge.json(body)));
    }
    private Map<String,Object> valid(){
        Map<String,Object> command=new LinkedHashMap<>();
        command.put("requestId","T65-CUSTOMER-REQUEST-001");
        command.put("delta",33);
        command.put("epoch",2);
        command.put("sequence",2);
        return command;
    }
    private void refused(ReplicationControlResponse response){
        assertFalse(response.isSuccess());
        assertEquals(DemoV19FourNodeEpoch2StrictAck.CODE,response.getCode());
    }
    @Test public void oldEpochAndUncertifiedSequenceNeverReachStorage(){
        Map<String,Object> req=valid();
        req.put("epoch",1);
        refused(send("P000",req));
        req.put("epoch",2);req.put("sequence",3);
        refused(send("P000",req));
    }
    @Test public void anonymousFractionalOrOversizedAmountCannotEnterAckGate(){
        Map<String,Object> req=valid();
        req.remove("requestId");refused(send("P000",req));
        req.put("requestId","T65-CUSTOMER-REQUEST-001");
        req.put("delta",17.75);refused(send("P000",req));
        req.put("delta",1000001);refused(send("P000",req));
        req.put("delta",33);
        req.put("requestId","x");refused(send("P000",req));
    }
    @Test public void otherPartitionAndEmptyEnvelopeFailClosed(){
        refused(send("P254",valid()));
        refused(send("P999",valid()));
        refused(gate().handle(new ReplicationControlRequest(
            DemoV19FourNodeShardCatalog.SERVICE,
            DemoV19FourNodeEpoch2StrictAck.OP,"P000",new byte[0])));
    }
}
