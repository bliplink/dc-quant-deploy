package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;
import com.app.common.partition.PartitionEpochReadFence;
import com.app.common.partition.ZkPartitionFailoverControlPlane;
import com.app.common.replication.*;
import com.app.common.zk.ZookeeperClient;
import com.gateway.connector.utils.JsonUtils;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import org.apache.zookeeper.data.Stat;

/**
 * T65: connect the existing Common strict client ACK gates to the real
 * four-JVM, two-partition Epoch2 WAL/Custody history.
 *
 * Critically this is NOT a writer and does NOT ACK while ZK RECOVERING.
 * The physical signers and persisted certificates only demonstrate durable
 * quorum, NOT authorization for client-facing trading publication.
 */
final class DemoV19FourNodeEpoch2StrictAck {
    static final String OP="T65_EPOCH2_STRICT_ACK_BOUNDARY_V1";
    static final String CODE="EPOCH2_STRICT_ACK_NOT_READY";
    static final String SCOPE="T65_COMMON_ACK_GATE_WITH_REAL_CUSTODY_NO_READY_V1";
    private final String node;
    private final Path root;
    private final ZookeeperClient zk;
    private final List<PartitionAssignment> sourcePlan;
    private final DemoV19FourNodeLiveRuntime.HeldWal held;

    DemoV19FourNodeEpoch2StrictAck(String node,Path root,ZookeeperClient zk,
            List<PartitionAssignment> sourcePlan,DemoV19FourNodeLiveRuntime.HeldWal held){
        this.node=node;this.root=root;this.zk=zk;this.sourcePlan=sourcePlan;this.held=held;
    }
    private static final class Evidence {
        final DurableWalCommitQuorum.Membership member;
        final DurableWalCommitQuorum.Certificate certificate;
        final List<DurableWalCustodyQuorum.Receipt> custodies;
        final String expectedState,expectedSource;
        Evidence(DurableWalCommitQuorum.Membership member,
                DurableWalCommitQuorum.Certificate certificate,
                List<DurableWalCustodyQuorum.Receipt> custodies,
                String expectedState,String expectedSource){
            this.member=member;this.certificate=certificate;
            this.custodies=custodies;this.expectedState=expectedState;
            this.expectedSource=expectedSource;
        }
    }
    @SuppressWarnings("unchecked")
    private Evidence evidence(PartitionAssignment old)throws Exception{
        String part=old.getPartitionId();
        DemoV19FourNodeEpoch2ReadySeal.verifySaved(zk,old);
        DemoV19FourNodeEpoch2Seq2.verifySaved(zk,old);
        Map<String,Object> signed=JsonUtils.Deserialize(String.valueOf(zk.readData(
            DemoV19FourNodeEpoch2Seq2.PROOFS+"/"+part)),Map.class);
        Map<String,Object> image=JsonUtils.Deserialize(String.valueOf(zk.readData(
            DemoV19FourNodeEpoch2Install.PROOFS+"/"+part)),Map.class);
        DurableWalCommitQuorum.Membership member=
            DemoV19FourNodeEpoch2Install.successorMembership(zk,old);
        List<DurableWalCommitQuorum.Receipt> receipts=
            DemoV19FourNodeSeq1NettyPilot.receiveTwoVotes(signed.get("votes"));
        String sha=(String)signed.get("walSha256");
        DurableWalCommitQuorum.Certificate cert=
            DurableWalCommitQuorum.verify(member,2,sha,receipts);
        List<?> cust=(List<?>)signed.get("custodies");
        if(cust==null || cust.size()!=2)
            throw new IOException("real Common custody quorum absent");
        List<DurableWalCustodyQuorum.Receipt> both=new ArrayList<>();
        for(Object raw:cust)both.add(
            DemoV19FourNodeSeq1NettyPilot.custodyFromWire(raw));
        return new Evidence(member,cert,both,(String)signed.get("stateSha256"),
            (String)image.get("sourceSha256"));
    }
    ReplicationControlResponse handle(ReplicationControlRequest request){
        String part=request==null?null:request.getPartitionId();
        try{
            if(request==null || !OP.equals(request.getOperation())
                    || !DemoV19FourNodeShardCatalog.SERVICE.equals(request.getServiceName())
                    || request.getPayload()==null || request.getPayload().length<25
                    || request.getPayload().length>512
                    || !DemoV19FourNodeSeq1NettyPilot.selected(part))
                throw new IOException("client ACK request outside bounded scope");
            @SuppressWarnings("unchecked")
            Map<String,Object> customer=JsonUtils.Deserialize(new String(
                request.getPayload(),java.nio.charset.StandardCharsets.UTF_8),Map.class);
            if(customer==null || !(customer.get("requestId") instanceof String)
                    || !(customer.get("delta") instanceof Number)
                    || !(customer.get("epoch") instanceof Number)
                    || !(customer.get("sequence") instanceof Number))
                throw new IOException("invalid client request identity/boundary");
            String requestId=(String)customer.get("requestId");
            Number amount=(Number)customer.get("delta");
            if(requestId.length()<6 || requestId.length()>128
                    || amount.longValue()!=amount.doubleValue()
                    || Math.abs(amount.longValue())>1000000
                    || ((Number)customer.get("epoch")).longValue()!=2
                    || ((Number)customer.get("sequence")).longValue()!=2)
                throw new IOException("client command not exact signed Epoch2 seq2");
            PartitionAssignment old=sourcePlan.get(Integer.parseInt(part.substring(1)));
            if(!old.getReplica().equals(node))
                throw new IOException("client ACK requires exact current Epoch2 primary");
            DemoDurableJournal source=held.owned.get(part);
            if(source==null)throw new IOException("old WAL publisher not held");
            synchronized(source) {
                DemoV19FourNodeReadyPreflight.requireExactRecoveryAssignment(zk,old);
                DemoV19FourNodeEpoch2Seq2.verifyLocalAfterRestart(
                    zk,old,node,root);
                Evidence verified=evidence(old);
                String actual;
                Path active=root.resolve(DemoV19FourNodeEpoch2Seq2.dir(part))
                    .resolve("active.wal");
                try(DemoDurableJournal wal=new DemoDurableJournal(active)){
                    if(!wal.isReadyForWrites() || wal.committedSeq()!=2
                            || wal.lastEpoch()!=2 || wal.snapshotSeq()!=1
                            || !verified.expectedSource.equals(wal.snapshotSourcePrefix())
                            || !verified.expectedState.equals(wal.state().stateDigest()))
                        throw new IOException("primary physical WAL state diverged");
                    // Individual ACK must authenticate the client request
                    // *inside* that cumulative WAL prefix, not merely seq2.
                    wal.requireForcedCommitted(2,2,requestId,amount.longValue());
                    actual=wal.committedPrefixSha256Through(2);
                    if(!verified.certificate.commitPrefixSha256.equals(actual))
                        throw new IOException("trusted primary WAL not at certified boundary");
                }
                // First: the ACTUAL existing Common custody client gate, not a
                // separate custom proof. Every response is still NO_ACK.
                DurableWalCertificateCustody.Authority authority=member->{
                    DemoV19FourNodeReadyPreflight.requireExactRecoveryAssignment(zk,old);
                    if(!verified.member.digest.equals(member.digest))
                        throw new IOException("wrong physical custody membership");
                };
                DurableWalCertificateCustodyAckGate.requireDurableBeforeAck(
                    verified.member,verified.certificate,verified.custodies,
                    authority,DemoV19FourNodeEpoch2Seq2.combinedDurability(
                        zk,old,root));
                // Second: the existing Common commit client gate checks the
                // live ZK grant. In RECOVERING it MUST throw, even after 2/2.
                try(DurableWalCommitIndex index=new DurableWalCommitIndex(
                        root.resolve(".pilot-epoch2-common-index-"+part),
                        verified.member);
                    ZkPartitionFailoverControlPlane assignment=
                        new ZkPartitionFailoverControlPlane(zk,
                            DemoV19FourNodeShardCatalog.ASSIGNMENTS,
                            "/MDTService",
                            DemoV19FourNodeShardCatalog.ROOT+
                                "/t65-strict-ack-lease-"+part,node+"-strict-ack")) {
                    PartitionEpochReadFence fence=new PartitionEpochReadFence(
                        zk::isConnected,assignment);
                    DurableWalCommitAckGate.requireDurable(
                        verified.member,index,2,actual,
                        (requestPartition,epoch)->{
                            if(!part.equals(requestPartition) || epoch!=2)
                                throw new IOException("wrong client Epoch2 grant");
                            PartitionEpochReadFence.Ticket ticket=
                                fence.readCurrent(part,node);
                            fence.requireCurrent(ticket);
                        });
                }
                // Do not return a success even if a future Common bug grants
                // ACK without a live writer/lease/source epoch barrier.
                throw new IOException("no atomic source writer/ACK installed");
            }
        }catch(Exception denied){
            return ReplicationControlResponse.error(CODE,
                denied.getClass().getSimpleName()+": "+denied.getMessage());
        }
    }
    static void probeBoth()throws Exception{probe("P000","P128");}
    static void probeOne(String part)throws Exception{
        if(!DemoV19FourNodeSeq1NettyPilot.selected(part))
            throw new IOException("unbounded strict ACK test partition");
        probe(part);
    }
    private static void probe(String... partitions)throws Exception {
        try(DirectNettyReplicationTransport tcp=new DirectNettyReplicationTransport(
                10000,DirectNettyReplicationServer.DEFAULT_MAX_FRAME_BYTES)){
            for(String part:partitions){
                PartitionAssignment old=DemoV19FourNodeShardCatalog.layout()
                    .get(Integer.parseInt(part.substring(1)));
                Map<String,Object> command=new LinkedHashMap<>();
                command.put("requestId",DemoV19FourNodeEpoch2Seq2.requestId(part));
                command.put("delta",DemoV19FourNodeEpoch2Seq2.delta(part));
                command.put("epoch",2);command.put("sequence",2);
                ReplicationControlResponse response=tcp.control(
                    DemoV19FourNodeLiveRuntime.exactEndpoint(old.getReplica()),
                    new ReplicationControlRequest(DemoV19FourNodeShardCatalog.SERVICE,
                        OP,part,DemoNettyBridge.json(command)))
                    .get(8,java.util.concurrent.TimeUnit.SECONDS);
                command.put("requestId","T65-NEVER-WRITTEN-CLIENT-REQUEST");
                ReplicationControlResponse forged=tcp.control(
                    DemoV19FourNodeLiveRuntime.exactEndpoint(old.getReplica()),
                    new ReplicationControlRequest(DemoV19FourNodeShardCatalog.SERVICE,
                        OP,part,DemoNettyBridge.json(command)))
                    .get(8,java.util.concurrent.TimeUnit.SECONDS);
                if(forged.isSuccess() || !CODE.equals(forged.getCode())
                        || !forged.getMessage().contains("local forced WAL command"))
                    throw new IOException("uncommitted client request falsely ACKed");
                command.put("requestId",DemoV19FourNodeEpoch2Seq2.requestId(part));
                command.put("delta",DemoV19FourNodeEpoch2Seq2.delta(part)+1);
                ReplicationControlResponse changedAmount=tcp.control(
                    DemoV19FourNodeLiveRuntime.exactEndpoint(old.getReplica()),
                    new ReplicationControlRequest(DemoV19FourNodeShardCatalog.SERVICE,
                        OP,part,DemoNettyBridge.json(command)))
                    .get(8,java.util.concurrent.TimeUnit.SECONDS);
                if(changedAmount.isSuccess() || !CODE.equals(changedAmount.getCode())
                        || !changedAmount.getMessage().contains("local forced WAL command"))
                    throw new IOException("changed client amount falsely ACKed");
                command.put("delta",DemoV19FourNodeEpoch2Seq2.delta(part));
                command.put("epoch",1);
                ReplicationControlResponse oldEpoch=tcp.control(
                    DemoV19FourNodeLiveRuntime.exactEndpoint(old.getReplica()),
                    new ReplicationControlRequest(DemoV19FourNodeShardCatalog.SERVICE,
                        OP,part,DemoNettyBridge.json(command)))
                    .get(8,java.util.concurrent.TimeUnit.SECONDS);
                if(oldEpoch.isSuccess() || !CODE.equals(oldEpoch.getCode())
                        || !oldEpoch.getMessage().contains("exact signed Epoch2"))
                    throw new IOException("wrong Epoch client request falsely ACKed");
                if(response.isSuccess() || !CODE.equals(response.getCode())
                        || response.getMessage()==null
                        || !response.getMessage().contains("PARTITION_EPOCH_FENCED"))
                    throw new IOException("T65 strict Common ACK gate not fenced: "+
                        response.getCode()+" "+response.getMessage());
                System.out.println("FOUR_NODE_T65_REAL_COMMON_ACK_GATE_DENIAL_PASS"+
                    " partition="+part+" currentSeq=2 realCommonIndex=true"+
                    " exactClientRequestIncluded=true uncommittedClientRequestDenied=true"+
                    " changedDeltaDenied=true oldEpochDenied=true"+
                    " twoSignedPhysicalCustodies=true"+
                    " grantRejectedByPartitionEpochReadFence=true"+
                    " zkState=RECOVERING clientAck=false ready=false");
            }
        }
    }
}
