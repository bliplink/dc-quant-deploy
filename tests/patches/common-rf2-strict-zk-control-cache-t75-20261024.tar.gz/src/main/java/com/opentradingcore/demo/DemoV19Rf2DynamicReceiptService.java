package com.opentradingcore.demo;

import com.app.common.replication.*;
import com.app.common.zk.ZookeeperClient;
import com.gateway.connector.utils.JsonUtils;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.*;
import org.apache.zookeeper.data.Stat;

/** A separately scoped, opt-in signed WAL receipt for proposed RF2 epochs.
 * It NEVER returns a client trade ACK and cannot itself publish READY.
 * Membership/epoch/configuration come only from a versioned, majority-backed
 * ZK assignment, not from the request. Old Epoch1 handler remains unchanged.
 */
final class DemoV19Rf2DynamicReceiptService {
    static final String OPERATION="V19_RF2_DYNAMIC_DURABLE_RECEIPT_V1";
    static final String CAPABILITY_OPERATION="V19_RF2_DYNAMIC_STRICT_WRITER_CAPABILITY_V1";
    private static final String PATH=DemoZkFenceSource.ISOLATED_ROOT
            +"/harness/assignments/P000";
    private final ZookeeperClient zk;
    private final DemoV19Rf2StrictAssignmentCache controlCache;
    private final DemoJournalCatalog journals;
    private final String node;
    private final PrivateKey privateKey;
    private final List<DurableWalCommitQuorum.Member> configured;
    /** One exclusive physically fsynced custody head per exact live epoch
     * and ZK assignment version. Reopening on each ACK replays the whole
     * historical custody file and adds unbounded synchronous CPU/I/O.
     * Any PREPARE -> READY CAS invalidates this cached authority. */
    private DurableWalCertificateCustody cachedCustody;
    private String cachedCustodyKey;

    DemoV19Rf2DynamicReceiptService(ZookeeperClient zk,String node,
            DemoJournalCatalog journals,
            DemoV19Rf2StrictAssignmentCache controlCache)throws Exception {
        if(zk==null || journals==null
                || !("CommonHaDemoA".equals(node) || "CommonHaDemoB".equals(node)))
            throw new IllegalArgumentException("only isolated A/B data signer");
        this.zk=zk;this.node=node;this.journals=journals;
        this.controlCache=controlCache;
        KeyFactory rsa=KeyFactory.getInstance("RSA");
        List<DurableWalCommitQuorum.Member> voters=new ArrayList<>();
        for(char suffix='A';suffix<='B';suffix++){
            String id="CommonHaDemo"+suffix;
            voters.add(new DurableWalCommitQuorum.Member(id,
                    "simulated-single-mac-jvm-"+suffix,
                    rsa.generatePublic(new X509EncodedKeySpec(Files.readAllBytes(
                            Paths.get("/srv/v19/identities",id+".pub.der"))))));
        }
        this.configured=Collections.unmodifiableList(voters);
        this.privateKey=rsa.generatePrivate(new PKCS8EncodedKeySpec(Files.readAllBytes(
                Paths.get("/srv/v19/local-identity/node.pk8"))));
    }

    static final class Plan {
        final long epoch,configVersion,genesisSeq,oldCertifiedSeq;
        final String primary,replica,genesisSha,oldCertifiedSha;
        final boolean preparing;
        Plan(long epoch,long configVersion,long genesisSeq,long oldCertifiedSeq,
                String primary,String replica,String sha,String oldSha,boolean preparing){
            this.epoch=epoch;this.configVersion=configVersion;
            this.genesisSeq=genesisSeq;this.oldCertifiedSeq=oldCertifiedSeq;
            this.primary=primary;this.replica=replica;
            this.genesisSha=sha;this.oldCertifiedSha=oldSha;
            this.preparing=preparing;
        }
    }

    /** Validate trusted ZK content, not caller-supplied body. */
    static Plan requirePlan(Map<String,Object> a)throws IOException {
        if(a==null || !"P000".equals(a.get("partitionId")))
            throw new IOException("wrong RF2 assignment");
        long epoch=number(a,"epoch"),config=number(a,"strictConfigurationVersion"),
             genesis=number(a,"strictGenesisSeq"),
             oldCertified=number(a,"strictOldCertifiedSeq");
        if(epoch<2 || epoch>128 || config<2 || genesis<1 || oldCertified<1
                || genesis<oldCertified)
            throw new IOException("invalid dynamic membership version or Genesis");
        String primary=string(a,"primary");
        if(!"CommonHaDemoA".equals(primary) && !"CommonHaDemoB".equals(primary))
            throw new IOException("invalid strict primary");
        String replica="CommonHaDemoA".equals(primary)?"CommonHaDemoB":"CommonHaDemoA";
        Object peers=a.get("replicas"),learners=a.get("learners");
        if(!(peers instanceof List) || !((List<?>)peers).equals(Collections.singletonList(replica))
                || !(learners instanceof List) || !((List<?>)learners).isEmpty())
            throw new IOException("strict RF2 membership must be exactly two data voters");
        String state=string(a,"state"),policy=string(a,"durabilityPolicy"),
                sha=string(a,"strictGenesisSha256");
        String oldSha=string(a,"strictOldCertifiedSha256");
        if(!sha.matches("[0-9a-f]{64}") || !oldSha.matches("[0-9a-f]{64}"))
            throw new IOException("unsigned Genesis or old ACK hash");
        boolean preparing="RECOVERING".equals(state)
                && "STRICT_REJOIN_GENESIS_PREPARE".equals(policy)
                && Boolean.FALSE.equals(a.get("quorumDurable"))
                && "GENESIS_PENDING".equals(a.get("strictTransition"));
        boolean active="READY".equals(state)
                && "QUORUM_DURABLE".equals(policy)
                && Boolean.TRUE.equals(a.get("quorumDurable"))
                && "GENESIS_CERTIFIED".equals(a.get("strictTransition"));
        if(!preparing && !active)
            throw new IOException("strict epoch signing requires explicit ZK transition");
        return new Plan(epoch,config,genesis,oldCertified,primary,replica,
                sha,oldSha,preparing);
    }
    private static long number(Map<String,Object> m,String field)throws IOException {
        Object v=m.get(field);
        if(!(v instanceof Number))throw new IOException("missing numeric "+field);
        return ((Number)v).longValue();
    }
    private static String string(Map<String,Object> m,String key)throws IOException {
        Object v=m.get(key);if(!(v instanceof String))throw new IOException("missing "+key);
        return (String)v;
    }

    /** A bounded watcher/renewal snapshot is allowed only when an
     * independently current control-plane grant still fences this JVM.
     * No ZK network RPC occurs on the signer/custody hot path in the pilot. */
    private Plan pinnedPlan(Stat stat)throws Exception {
        if(!zk.isConnected())throw new IOException("control quorum unavailable");
        final Plan planned;
        if(controlCache!=null){
            DemoV19Rf2StrictAssignmentCache.Snapshot s=controlCache.current();
            if(s.plan.preparing){
                // PREPARE is a control-plane genesis transaction, never a
                // customer WAL ACK. Keep fresh ZK checks while recovering.
                Object raw=zk.readData(PATH,stat);
                if(raw==null)throw new IOException("strict PREPARE vanished");
                @SuppressWarnings("unchecked") Map<String,Object> values=
                    JsonUtils.Deserialize(String.valueOf(raw),Map.class);
                return requirePlan(values);
            }
            stat.setVersion(s.version);
            planned=s.plan;
            if(node.equals(planned.primary))
                DemoHotpathControl.requireCurrent("P000",planned.epoch,
                    planned.primary,null);
            else if(node.equals(planned.replica))
                DemoHotpathControl.requireReplicaQuorum("P000",planned.epoch,
                    planned.primary,node);
            else throw new IOException("not a member of strict epoch");
        }else{
            Object raw=zk.readData(PATH,stat);
            if(raw==null)throw new IOException("no strict assignment");
            @SuppressWarnings("unchecked") Map<String,Object> map=
                JsonUtils.Deserialize(String.valueOf(raw),Map.class);
            planned=requirePlan(map);
        }
        return planned;
    }

    private Plan current(int requiredVersion,DurableWalCommitQuorum.Membership pinned)
            throws Exception {
        Stat stat=new Stat();
        Plan planned=pinnedPlan(stat);
        if(stat.getVersion()!=requiredVersion)
            throw new IOException("strict membership changed");
        if(planned.epoch!=pinned.epoch
                || planned.configVersion!=pinned.configurationVersion
                || !planned.primary.equals(pinned.primary)
                || !pinned.members.keySet().equals(
                        new java.util.TreeSet<>(Arrays.asList("CommonHaDemoA","CommonHaDemoB")))
                || !zk.isConnected())
            throw new IOException("dynamic membership no longer current");
        return planned;
    }

    /** Capability is only a PREPARE witness that this independent JVM
     * loaded the new strict writer adapter. Never grants client READY.
     */
    ReplicationControlResponse capability(ReplicationControlRequest request){
        try{
            if(request==null || !CAPABILITY_OPERATION.equals(request.getOperation())
                    || !"CommonHaDemo".equals(request.getServiceName())
                    || !"P000".equals(request.getPartitionId())
                    || request.getPayload()==null || request.getPayload().length!=0
                    || !"1".equals(System.getenv("DEMO_V19_RF2_DYNAMIC_STRICT_ACK")))
                throw new IOException("strict writer capability not explicitly installed");
            if(!zk.isConnected())throw new IOException("no ZK quorum");
            Stat stat=new Stat();Object raw=zk.readData(PATH,stat);
            if(raw==null)throw new IOException("missing current strict transition");
            @SuppressWarnings("unchecked") Map<String,Object> map=
                    JsonUtils.Deserialize(String.valueOf(raw),Map.class);
            Plan plan=requirePlan(map);
            if(!plan.preparing)throw new IOException("capability proof only in strict PREPARE");
            Map<String,Object> answer=new LinkedHashMap<>();
            answer.put("node",node);
            answer.put("epoch",plan.epoch);
            answer.put("config",plan.configVersion);
            answer.put("genesisSeq",plan.genesisSeq);
            answer.put("zkVersion",stat.getVersion());
            answer.put("writerInstalled",true);
            return ReplicationControlResponse.ok(DemoNettyBridge.json(answer));
        }catch(Exception e){
            return ReplicationControlResponse.error("STRICT_WRITER_NOT_READY",
                    e.getClass().getSimpleName()+": "+e.getMessage());
        }
    }

    /** New epoch authenticated physical custody. One response proves only
     * ONE independently fsynced certificate; no READY or client ACK.
     * Uses Common's certificate decoder/fsync protocol unchanged.
     */
    static final String CUSTODY_OPERATION="V19_RF2_DYNAMIC_CUSTODY_INSTALL_V1";
    static final String CUSTODY_HEAD_OPERATION="V19_RF2_DYNAMIC_CUSTODY_HEAD_READ_V1";

    /** Reuse the exact, per-JVM exclusive physical custody reader when
     * automatic failover inspects an old strict epoch. Never open the same
     * lock twice or create a new certificate. A read-only verified head
     * grants NO client writes and NO promotion by itself. */
    synchronized DurableWalCommitQuorum.Certificate
            verifiedCachedHead(DurableWalCommitQuorum.Membership expected)
            throws Exception {
        if(expected==null || cachedCustody==null || cachedCustodyKey==null
                || !cachedCustodyKey.startsWith(expected.digest+":")
                || !zk.isConnected())
            return null;
        DurableWalCommitQuorum.Certificate certificate=
            cachedCustody.highestVerified();
        if(certificate==null || certificate.epoch!=expected.epoch
                || !expected.digest.equals(certificate.membershipSha256))
            throw new IOException("cached old custody does not match pinned physical epoch");
        return certificate;
    }

    synchronized ReplicationControlResponse handleCustody(ReplicationControlRequest request) {
        try {
            if(request==null
                    || !(CUSTODY_OPERATION.equals(request.getOperation())
                        || CUSTODY_HEAD_OPERATION.equals(request.getOperation()))
                    || !"CommonHaDemo".equals(request.getServiceName())
                    || !"P000".equals(request.getPartitionId())
                    || request.getPayload()==null
                    || request.getPayload().length>16384)
                throw new IOException("invalid bounded dynamic custody request");
            Stat stat=new Stat();
            Plan plan=pinnedPlan(stat);
            // Valid READY strictly belongs to the currently pinned same
            // configuration. Future certificates are never valid in PREPARE.
            if(!plan.preparing && !zk.isConnected())
                throw new IOException("strict READY requires control quorum");
            boolean readOnlyHead=CUSTODY_HEAD_OPERATION.equals(request.getOperation());
            if(readOnlyHead && request.getPayload().length>256)
                throw new IOException("unbounded custody head request");
            DurableWalCommitQuorum.Membership membership=
                    new DurableWalCommitQuorum.Membership("CommonHaDemo","P000",
                            plan.primary,plan.epoch,plan.configVersion,configured);
            DurableWalCertificateCustody.Authority authority=pinned->{
                Plan still=current(stat.getVersion(),pinned);
                if(still.preparing!=plan.preparing
                        || still.genesisSeq!=plan.genesisSeq
                        || !still.genesisSha.equals(plan.genesisSha)
                        || still.oldCertifiedSeq!=plan.oldCertifiedSeq
                        || !still.oldCertifiedSha.equals(plan.oldCertifiedSha))
                    throw new IOException("physical custody Genesis or epoch changed");
            };
            DurableWalCommitQuorum.LocalDurability walProof=(epoch,seq)->{
                authority.requireOldEpochAuthorized(membership);
                DemoDurableJournal wal=journals.journal("P000");
                synchronized(wal){
                    if(epoch!=plan.epoch || seq<plan.genesisSeq
                            || (plan.preparing && seq!=plan.genesisSeq)
                            || !wal.isReadyForWrites() || wal.committedSeq()<seq
                            || wal.lastEpoch()>epoch
                            || (!plan.preparing && seq>plan.genesisSeq
                                && wal.lastEpoch()!=epoch)
                            || !plan.oldCertifiedSha.equals(
                                wal.committedPrefixSha256Through(plan.oldCertifiedSeq)))
                        throw new IOException("local WAL missing strict old ACK or Genesis");
                    String actual=wal.committedPrefixSha256Through(seq);
                    if(seq==plan.genesisSeq && !plan.genesisSha.equals(actual))
                        throw new IOException("custody WAL Genesis prefix differs");
                    return actual;
                }
            };
            java.nio.file.Path directory=Paths.get("/srv/v19/wal/.strict-custody-epoch-"
                    +plan.epoch+"-config-"+plan.configVersion);
            String authorityKey=membership.digest+":"+stat.getVersion()+":"+
                (plan.preparing?"PREPARE":"READY");
            if(cachedCustody!=null && !authorityKey.equals(cachedCustodyKey)){
                cachedCustody.close();
                cachedCustody=null;
                cachedCustodyKey=null;
            }
            if(cachedCustody==null){
                cachedCustody=new DurableWalCertificateCustody(
                    directory,membership,walProof,authority);
                cachedCustodyKey=authorityKey;
                System.out.println("RF2_DYNAMIC_CUSTODY_REUSED epoch="+plan.epoch+
                    " zkVersion="+stat.getVersion()+" mode="+
                    (plan.preparing?"PREPARE":"READY"));
            }
            DurableWalCertificateCustodyControlHandler handler=
                new DurableWalCertificateCustodyControlHandler(
                    membership,node,privateKey,cachedCustody,authority);
            ReplicationControlRequest commonRequest=new ReplicationControlRequest(
                request.getServiceName(),
                readOnlyHead
                    ? DurableWalCertificateCustodyControlHandler.HEAD_QUERY_OPERATION
                    : DurableWalCertificateCustodyControlHandler.OPERATION,
                request.getPartitionId(),request.getPayload());
            return handler.handle(commonRequest);
        }catch(Exception denied){
            return ReplicationControlResponse.error("RF2_DYNAMIC_CUSTODY_DENIED",
                    denied.getClass().getSimpleName()+": "+denied.getMessage());
        }
    }

    ReplicationControlResponse handle(ReplicationControlRequest req) {
        try {
            if(req==null || !OPERATION.equals(req.getOperation())
                    || !"CommonHaDemo".equals(req.getServiceName())
                    || !"P000".equals(req.getPartitionId())
                    || req.getPayload()==null || req.getPayload().length!=28)
                throw new IOException("invalid bounded dynamic WAL receipt");
            ByteBuffer payload=ByteBuffer.wrap(req.getPayload());
            if(payload.getInt()!=1)throw new IOException("unsupported receipt version");
            long config=payload.getLong(),epoch=payload.getLong(),seq=payload.getLong();
            if(seq<=0)throw new IOException("invalid requested durable sequence");
            Stat stat=new Stat();
            Plan planned=pinnedPlan(stat);
            if(epoch!=planned.epoch || config!=planned.configVersion)
                throw new IOException("stale strict membership/epoch");
            if(planned.preparing && seq!=planned.genesisSeq)
                throw new IOException("unpublished epoch can sign ONLY frozen Genesis");
            if(seq<planned.genesisSeq)
                throw new IOException("cannot promote a prior uncertified tail");
            DurableWalCommitQuorum.Membership membership=new DurableWalCommitQuorum.Membership(
                    "CommonHaDemo","P000",planned.primary,epoch,config,configured);
            // Common validates cryptographic receipt, local fsynced WAL and
            // checks authority on BOTH sides of the signature boundary.
            DurableWalReceiptControlHandler signer=new DurableWalReceiptControlHandler(
                    membership,node,privateKey,(requestedEpoch,requestedSeq)->{
                        Plan still=current(stat.getVersion(),membership);
                        DemoDurableJournal wal=journals.journal("P000");
                        synchronized(wal) {
                            if(!wal.isReadyForWrites() || wal.committedSeq()<requestedSeq
                                    || wal.lastEpoch()>requestedEpoch
                                    || wal.committedSeq()<still.oldCertifiedSeq
                                    || !still.oldCertifiedSha.equals(
                                         wal.committedPrefixSha256Through(still.oldCertifiedSeq))
                                    || (still.preparing && requestedSeq!=still.genesisSeq)
                                    || (!still.preparing && requestedSeq>still.genesisSeq
                                            && wal.lastEpoch()!=requestedEpoch))
                                throw new IOException("no clean local WAL for strict epoch");
                            String hash=wal.committedPrefixSha256Through(requestedSeq);
                            if(requestedSeq==still.genesisSeq
                                    && !still.genesisSha.equals(hash))
                                throw new IOException("local strict Genesis does not match ZK hash");
                            return hash;
                        }
                    },ignored->current(stat.getVersion(),membership));
            return signer.handle(new ReplicationControlRequest(
                    "CommonHaDemo",DurableWalReceiptControlHandler.OPERATION,
                    "P000",req.getPayload()));
        }catch(Exception denied) {
            return ReplicationControlResponse.error("RF2_DYNAMIC_RECEIPT_DENIED",
                    denied.getClass().getSimpleName()+": "+denied.getMessage());
        }
    }
}
