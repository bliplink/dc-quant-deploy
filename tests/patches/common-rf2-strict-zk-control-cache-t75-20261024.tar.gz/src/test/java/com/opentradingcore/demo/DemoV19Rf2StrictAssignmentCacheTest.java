package com.opentradingcore.demo;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.junit.Test;
import static org.junit.Assert.*;

/** V19 STRICT snapshot fence: a stale epoch/version or expired quorum read
 * NEVER authorizes an ACK. Remote signer has an independent copy of this gate. */
public final class DemoV19Rf2StrictAssignmentCacheTest {
    private static final String SHA=
       "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef";
    private static DemoV19Rf2StrictAssignmentCache.Snapshot snapshot(
            int version,String raw,long at){
        DemoV19Rf2DynamicReceiptService.Plan p=
            new DemoV19Rf2DynamicReceiptService.Plan(
                7L,7L,65L,65L,"CommonHaDemoB","CommonHaDemoA",SHA,SHA,false);
        return new DemoV19Rf2StrictAssignmentCache.Snapshot(version,raw,p,at);
    }
    private static void rejected(DemoV19Rf2StrictAssignmentCache.Snapshot s,long at) {
        try {s.valid(at);fail("old ZK control snapshot was still valid");}
        catch(IOException expected){assertTrue(expected.getMessage().contains("expired"));}
    }
    @Test public void ttlMeasuredFromBeforeZkReadNotAfter()throws Exception {
        long first=TimeUnit.SECONDS.toNanos(10);
        DemoV19Rf2StrictAssignmentCache.Snapshot s=snapshot(9,"strict-epoch7",first);
        s.valid(first+DemoV19Rf2StrictAssignmentCache.MAX_AGE_NS-1L);
        rejected(s,first+DemoV19Rf2StrictAssignmentCache.MAX_AGE_NS);
        rejected(s,first-1L); // rollback or monotonic clock regression
    }
    @Test public void rawAndZkVersionMustBothStayIdentical()throws Exception {
        DemoV19Rf2StrictAssignmentCache.Snapshot s=snapshot(9,"strict-epoch7",10L);
        s.same(snapshot(9,"strict-epoch7",11L));
        for(DemoV19Rf2StrictAssignmentCache.Snapshot other:new DemoV19Rf2StrictAssignmentCache.Snapshot[]{
            snapshot(10,"strict-epoch7",10L),
            snapshot(9,"strict-epoch8",10L),
            null
        }){
            try {s.same(other);fail("strict policy change accepted");}
            catch(IOException expected) {assertTrue(expected.getMessage().contains("revoked"));}
        }
    }
}
