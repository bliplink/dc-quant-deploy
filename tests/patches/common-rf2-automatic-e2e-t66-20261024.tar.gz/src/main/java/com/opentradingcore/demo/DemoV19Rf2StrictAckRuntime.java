package com.opentradingcore.demo;

import com.app.common.replication.*;
import com.app.common.zk.ZookeeperClient;
import com.gateway.connector.utils.JsonUtils;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyFactory;
import java.security.spec.X509EncodedKeySpec;
import java.util.*;
import java.util.concurrent.TimeUnit;
import org.apache.zookeeper.data.Stat;

/** Isolated RF2 new-epoch strict write ACK. Never falls back to local ACK
 * if a majority signer, fsynced WAL replica, or custody witness is missing.
 * Caller serializes append+certify by the Demo writer's per-node ACK mutex.
 */
final class DemoV19Rf2StrictAckRuntime {
    private static final String PATH=DemoZkFenceSource.ISOLATED_ROOT
        +"/harness/assignments/P000";
    private final ZookeeperClient zk;
    private final DemoJournalCatalog journals;
    private final DemoAsyncReplicator async;
    private final String node;
    private final DemoV19Rf2DynamicReceiptService localSigner;
    DemoV19Rf2StrictAckRuntime(ZookeeperClient zk,String node,
            DemoJournalCatalog journals,DemoAsyncReplicator async) throws Exception {
        this.zk=Objects.requireNonNull(zk);
        this.node=Objects.requireNonNull(node);
        this.journals=Objects.requireNonNull(journals);
        this.async=Objects.requireNonNull(async);
        // A Netty APPEND handler MUST NOT make a synchronous Netty RPC to
        // its own event loop. Use the EXACT same verified Common RPC handler
        // in-process, and remote Netty only for the independent other voter.
        this.localSigner=new DemoV19Rf2DynamicReceiptService(zk,node,journals);
    }
    DurableWalCommitQuorum.Receipt localSignedReceipt(
            DurableWalCommitQuorum.Membership members,long seq)throws Exception{
        ReplicationControlRequest original=DurableWalReceiptControlHandler.request(members,seq);
        ReplicationControlResponse answer=localSigner.handle(new ReplicationControlRequest(
            original.getServiceName(),DemoV19Rf2DynamicReceiptService.OPERATION,
            original.getPartitionId(),original.getPayload()));
        if(!answer.isSuccess())throw new IOException("local durable receipt denied: "+answer.getMessage());
        DurableWalCommitQuorum.Receipt receipt=
            DurableWalReceiptControlHandler.decodeReceiptPayload(answer.getPayload());
        DurableWalCommitQuorum.requireValidReceipt(members,receipt);
        if(!node.equals(receipt.node))throw new IOException("local physical signer wrong");
        return receipt;
    }
    DurableWalCustodyQuorum.Receipt localInstalledCustody(
            DurableWalCommitQuorum.Membership members,
            DurableWalCommitQuorum.Certificate certificate)throws Exception {
        ReplicationControlRequest original=
            DurableWalCertificateCustodyControlHandler.request(members,certificate);
        ReplicationControlResponse answer=localSigner.handleCustody(new ReplicationControlRequest(
            original.getServiceName(),DemoV19Rf2DynamicReceiptService.CUSTODY_OPERATION,
            original.getPartitionId(),original.getPayload()));
        if(!answer.isSuccess())throw new IOException("local physical custody denied: "+answer.getMessage());
        return DurableWalCertificateCustodyControlHandler.decodeVerified(
            members,certificate,node,answer);
    }
    private static final class Pinned {
        final int version;
        final DemoV19Rf2DynamicReceiptService.Plan plan;
        final String raw;
        Pinned(int version,DemoV19Rf2DynamicReceiptService.Plan plan,String raw){
            this.version=version;this.plan=plan;this.raw=raw;
        }
    }
    private Pinned readActive()throws Exception {
        if(!zk.isConnected())throw new IOException("control quorum unavailable");
        Stat stat=new Stat();
        Object raw=zk.readData(PATH,stat);
        if(raw==null)throw new IOException("no strict assignment");
        @SuppressWarnings("unchecked") Map<String,Object> fields=
            JsonUtils.Deserialize(String.valueOf(raw),Map.class);
        DemoV19Rf2DynamicReceiptService.Plan plan=
            DemoV19Rf2DynamicReceiptService.requirePlan(fields);
        if(plan.preparing || !node.equals(plan.primary))
            throw new IOException("no strict READY primary grant");
        DemoHotpathControl.requireCurrent("P000",plan.epoch,node,null);
        return new Pinned(stat.getVersion(),plan,String.valueOf(raw));
    }
    boolean strictReadyFor(String candidate) {
        if(!node.equals(candidate))return false;
        try{readActive();return true;}
        catch(Exception notReady){return false;}
    }
    private void requireSame(Pinned pinned)throws Exception {
        if(!zk.isConnected())throw new IOException("no ZK majority for strict ACK");
        Stat stat=new Stat();
        Object current=zk.readData(PATH,stat);
        if(current==null || stat.getVersion()!=pinned.version
                || !pinned.raw.equals(String.valueOf(current)))
            throw new IOException("strict ZK assignment changed during commit");
        DemoHotpathControl.requireCurrent("P000",pinned.plan.epoch,node,null);
    }
    private DurableWalCommitQuorum.Membership members(Pinned pinned)throws Exception {
        KeyFactory rsa=KeyFactory.getInstance("RSA");
        List<DurableWalCommitQuorum.Member> voters=new ArrayList<>();
        for(char suffix='A';suffix<='B';suffix++){
            String id="CommonHaDemo"+suffix;
            voters.add(new DurableWalCommitQuorum.Member(
                    id,"simulated-single-mac-jvm-"+suffix,
                    rsa.generatePublic(new X509EncodedKeySpec(Files.readAllBytes(
                        Paths.get("/srv/v19/identities",id+".pub.der"))))));
        }
        return new DurableWalCommitQuorum.Membership(
            "CommonHaDemo","P000",node,pinned.plan.epoch,
            pinned.plan.configVersion,voters);
    }
    /** For new commands refuse to jump past any unacknowledged, dirty WAL.
     * An EXACT same request may retry its already locally fsynced sequence.
     */
    void beforeAppend(String requestId,long delta)throws Exception{
        Pinned pinned=readActive();
        try(DurableWalCommitIndex index=new DurableWalCommitIndex(
                indexDir(pinned.plan),members(pinned))) {
            long certified=index.committedSequence();
            DemoDurableJournal wal=journals.journal("P000");
            synchronized(wal) {
                if(!wal.isReadyForWrites())
                    throw new IOException("unclean strict primary WAL");
                if(certified< pinned.plan.genesisSeq || certified>wal.committedSeq())
                    throw new IOException("strict Genesis not durable");
                if(certified!=wal.committedSeq()) {
                    DemoDurableJournal.CommittedRequest previous=wal.committedRequest(requestId);
                    if(previous==null || previous.seq!=wal.committedSeq() || previous.delta!=delta)
                        throw new IOException("previous WAL tail not strictly ACK certified");
                }
            }
            requireSame(pinned);
        }
    }
    private java.nio.file.Path indexDir(DemoV19Rf2DynamicReceiptService.Plan p) {
        return Paths.get("/srv/v19/wal/.strict-epoch-"+p.epoch+"-config-"+p.configVersion);
    }
    static void requireMatchedRemote(Map<String,Object> remote,String replica,
            long seq,String expectedHash)throws IOException{
        if(remote==null || !replica.equals(remote.get("localNode"))
                || !Boolean.TRUE.equals(remote.get("clean"))
                || !(remote.get("committedSeq") instanceof Number)
                || ((Number)remote.get("committedSeq")).longValue()!=seq
                || !expectedHash.equals(remote.get("committedPrefixSha256")))
            throw new IOException("physical replica WAL not fsynced at exact strict ACK");
    }

    DurableWalCommitAckGate.Confirmed certifyAfterAppend(long epoch,long seq)throws Exception {
        long started=System.nanoTime();
        Pinned pinned=readActive();
        if(pinned.plan.epoch!=epoch || seq<=pinned.plan.genesisSeq)
            throw new IOException("new strict WAL seq not in pinned epoch");
        DemoDurableJournal wal=journals.journal("P000");
        String sha;
        synchronized(wal){
            if(!wal.isReadyForWrites() || wal.lastEpoch()!=epoch || wal.committedSeq()!=seq)
                throw new IOException("strict writer WAL not exact new epoch boundary");
            sha=wal.committedPrefixSha256Through(seq);
        }
        DurableWalCommitQuorum.Membership membership=members(pinned);
        try(DurableWalCommitIndex index=new DurableWalCommitIndex(indexDir(pinned.plan),membership);
            DemoV19TcpClient tcp=new DemoV19TcpClient()){
            long frontier=index.committedSequence();
            if(frontier!=seq && frontier!=seq-1)
                throw new IOException("strict ACK skipped uncertified WAL tail");
            requireSame(pinned);
            if(frontier<seq){
                async.signal("P000");
                long deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(3);
                Exception lag=null;
                while(System.nanoTime()<deadline){
                    requireSame(pinned);
                    try{
                        requireMatchedRemote(tcp.status(pinned.plan.replica),
                            pinned.plan.replica,seq,sha);
                        lag=null;break;
                    }catch(Exception stalled){lag=stalled;}
                    Thread.sleep(25);
                }
                if(lag!=null)throw new IOException("strict remote fsync lag",lag);
                DurableWalCommitQuorum.Receipt a=localSignedReceipt(membership,seq);
                DurableWalCommitQuorum.Receipt b=tcp.signedDynamicReceipt(
                    pinned.plan.replica,membership,seq);
                DurableWalCommitQuorum.verify(membership,seq,sha,Arrays.asList(a,b));
                requireSame(pinned);
                index.certifyAndPersist(seq,sha,Arrays.asList(a,b));
            }
            System.out.println("RF2_STRICT_ACK_STAGE seq="+seq+" phase=certificate elapsedMs="+
                TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-started));
            DurableWalCommitQuorum.Certificate exact=index.verifiedHighestCertificate();
            if(exact==null || exact.committedSequence!=seq
                    || !sha.equals(exact.commitPrefixSha256))
                throw new IOException("strict signed certificate missing from disk");
            DurableWalCustodyQuorum.Receipt local=localInstalledCustody(membership,exact);
            System.out.println("RF2_STRICT_ACK_STAGE seq="+seq+" phase=localCustody elapsedMs="+
                TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-started));
            DurableWalCustodyQuorum.Receipt remote=tcp.installDynamicCustody(
                    pinned.plan.replica,membership,exact);
            System.out.println("RF2_STRICT_ACK_STAGE seq="+seq+" phase=remoteCustody elapsedMs="+
                TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-started));
            requireSame(pinned);
            DurableWalCertificateCustodyAckGate.requireDurableBeforeAck(
                membership,exact,Arrays.asList(local,remote),
                ignored->requireSame(pinned),
                (e,s)->{
                    synchronized(wal){
                        if(e!=epoch || wal.committedSeq()<s || !wal.isReadyForWrites())
                            throw new IOException("local WAL not fsynced for strict ACK");
                        return wal.committedPrefixSha256Through(s);
                    }
                });
            DurableWalCommitAckGate.Confirmed ack=DurableWalCommitAckGate.requireDurable(
                membership,index,seq,sha,
                (partition,e)->requireSame(pinned));
            System.out.println("RF2_STRICT_ACK_STAGE seq="+seq+" phase=finalACK elapsedMs="+
                TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-started));
            return ack;
        }
    }
}
