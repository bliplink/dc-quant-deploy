package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;
import com.app.common.replication.DurableWalCommitQuorum;
import com.app.common.replication.DurableWalCustodyQuorum;
import java.io.IOException;
import java.nio.file.Path;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.util.*;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import static org.junit.Assert.*;

public final class DemoV19FourNodeSeq1NettyPilotTest {
    @Rule public TemporaryFolder temp=new TemporaryFolder();
    interface Unsafe {void run()throws Exception;}
    private static void denies(Unsafe action)throws Exception {
        try{action.run();fail("untrusted seq1 pilot evidence accepted");}
        catch(IOException | IllegalArgumentException | IllegalStateException expected) {}
    }
    private static KeyPair key()throws Exception{
        KeyPairGenerator g=KeyPairGenerator.getInstance("RSA");g.initialize(2048);
        return g.generateKeyPair();
    }
    @Test public void onlyTwoBoundedInternalNonTradingPartitions(){
        assertTrue(DemoV19FourNodeSeq1NettyPilot.selected("P000"));
        assertTrue(DemoV19FourNodeSeq1NettyPilot.selected("P128"));
        for(String p:new String[]{"P001","P127","P129","P255","P256","A","P0000"})
            assertFalse(p,DemoV19FourNodeSeq1NettyPilot.selected(p));
        assertEquals("INTERNAL-NON-TRADING-SEQ1-P000",
            DemoV19FourNodeSeq1NettyPilot.requestId("P000"));
        assertEquals(11,DemoV19FourNodeSeq1NettyPilot.delta("P000"));
        assertEquals(17,DemoV19FourNodeSeq1NettyPilot.delta("P128"));
    }
    @Test public void physicalGenesisMustExistBeforeTheExactInternalSeq1()throws Exception{
        PartitionAssignment a=DemoV19FourNodeShardCatalog.layout().get(0);
        Path path=temp.newFile("P000.wal").toPath();
        try(DemoDurableJournal wal=new DemoDurableJournal(path)){
            denies(()->DemoV19FourNodeSeq1NettyPilot.requireExactPilotWal(wal,a));
            String digest=DemoV19FourNodeGenesisPreflight.exactAssignmentDigest(a);
            wal.installEmptyGenesis(1,"P000",digest);
            DemoV19FourNodeSeq1NettyPilot.requireExactPilotWal(wal,a);
            wal.prepareAndCommitSingleForce(1,1,
                new DemoStateMachine.Operation(
                    DemoV19FourNodeSeq1NettyPilot.requestId("P000"),11));
            DemoV19FourNodeSeq1NettyPilot.requireExactPilotWal(wal,a);
            assertEquals(1,wal.committedSeq());
        }
        try(DemoDurableJournal wal=new DemoDurableJournal(path)){
            DemoV19FourNodeSeq1NettyPilot.requireExactPilotWal(wal,a);
            assertEquals(1,wal.state().distinctRequests());
        }
    }
    @Test public void mismatchedInternalOperationCanNeverBeRepresentedAsPilot()throws Exception{
        PartitionAssignment a=DemoV19FourNodeShardCatalog.layout().get(128);
        Path path=temp.newFile("P128.wal").toPath();
        try(DemoDurableJournal wal=new DemoDurableJournal(path)){
            wal.installEmptyGenesis(1,"P128",
                DemoV19FourNodeGenesisPreflight.exactAssignmentDigest(a));
            wal.prepareAndCommitSingleForce(1,1,
                new DemoStateMachine.Operation("not-the-whitelisted-internal-operation",17));
            denies(()->DemoV19FourNodeSeq1NettyPilot.requireExactPilotWal(wal,a));
        }
    }
    @Test public void duplicateAndIncompleteQuorumVotesAreRejected()throws Exception{
        PartitionAssignment a=DemoV19FourNodeShardCatalog.layout().get(0);
        KeyPair left=key(),right=key();
        DurableWalCommitQuorum.Membership member=new DurableWalCommitQuorum.Membership(
            "CommonHaDemo","P000",a.getPrimary(),1,1,Arrays.asList(
                new DurableWalCommitQuorum.Member(a.getPrimary(),
                    "simulation-a",left.getPublic()),
                new DurableWalCommitQuorum.Member(a.getReplica(),
                    "simulation-b",right.getPublic())));
        String hash="abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789";
        DurableWalCommitQuorum.Receipt aVote=DurableWalCommitQuorum.sign(
            member,a.getPrimary(),1,(epoch,seq)->hash,left.getPrivate());
        DurableWalCommitQuorum.Receipt bVote=DurableWalCommitQuorum.sign(
            member,a.getReplica(),1,(epoch,seq)->hash,right.getPrivate());
        Object encoded=DemoV19FourNodeSeq1NettyPilot.wire(aVote);
        DurableWalCommitQuorum.Receipt decoded=
            DemoV19FourNodeSeq1NettyPilot.fromWire(encoded);
        DurableWalCommitQuorum.requireValidReceipt(member,decoded);
        denies(()->DemoV19FourNodeSeq1NettyPilot.receiveTwoVotes(
            Collections.singletonList(encoded)));
        denies(()->DurableWalCommitQuorum.verify(member,1,hash,
            Arrays.asList(aVote,aVote)));
        assertEquals(2,DemoV19FourNodeSeq1NettyPilot.receiveTwoVotes(
            Arrays.asList(encoded,DemoV19FourNodeSeq1NettyPilot.wire(bVote))).size());
        Map<String,Object> forged=new LinkedHashMap<>(
            DemoV19FourNodeSeq1NettyPilot.wire(aVote));
        forged.put("sha","ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff");
        denies(()->DurableWalCommitQuorum.requireValidReceipt(member,
            DemoV19FourNodeSeq1NettyPilot.fromWire(forged)));
    }
    @Test public void custodyWireIsStillOnlyOneWitnessNotPromotionAuthority()throws Exception {
        byte[] sample=new byte[]{1,2,3,4};
        DurableWalCustodyQuorum.Receipt custody=DurableWalCustodyQuorum.Receipt.fromWire(
            "CommonHaDemoA","P000",
            "abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789",
            "abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789",
            1,1,sample);
        DurableWalCustodyQuorum.Receipt decoded=
            DemoV19FourNodeSeq1NettyPilot.custodyFromWire(
                DemoV19FourNodeSeq1NettyPilot.custodyWire(custody));
        assertEquals("CommonHaDemoA",decoded.node);
        assertEquals(1,decoded.sequence);
        assertArrayEquals(sample,decoded.signature());
        denies(()->DemoV19FourNodeSeq1NettyPilot.custodyFromWire(
            Collections.singletonMap("node","CommonHaDemoA")));
    }
}
