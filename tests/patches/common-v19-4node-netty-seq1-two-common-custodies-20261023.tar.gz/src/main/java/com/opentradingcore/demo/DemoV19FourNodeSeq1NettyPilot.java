package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;
import com.app.common.replication.*;
import com.app.common.zk.ZookeeperClient;
import com.gateway.connector.utils.JsonUtils;
import java.io.*;
import java.nio.file.*;
import java.security.*;
import java.security.spec.*;
import java.util.*;
import java.util.concurrent.TimeUnit;
import org.apache.zookeeper.data.Stat;

/**
 * Explicitly opted-in NON-TRADING two-partition seq1 pilot. Never READY.
 * Only two fixed internal Demo operations, not a public order API.
 * Each of A/B/C/D fsyncs ITS OWN locked partition WAL and independently
 * signs the actual Common DurableWalCommitQuorum receipt. A/B or C/D need
 * to match exact seq/hash and both votes for the primary to fsync a Common
 * DurableWalCommitIndex. No user-order ACK or ZK assignment mutation.
 */
final class DemoV19FourNodeSeq1NettyPilot {
    static final String FSYNC="INTERNAL_SEQ1_FSYNCD_RECEIPT_V1";
    static final String CERTIFY="INTERNAL_SEQ1_COMMON_CERTIFY_V1";
    static final String CUSTODY="INTERNAL_SEQ1_COMMON_CUSTODY_V1";
    static final String OP_SCOPE="INTERNAL_DEMO_NON_TRADING_NO_READY";
    private final String node;
    private final Path root;
    private final PrivateKey key;
    DemoV19FourNodeSeq1NettyPilot(String node,Path walRoot)throws Exception{
        if(node==null || !node.matches("CommonHaDemo[ABCD]"))
            throw new IOException("invalid signer");
        this.node=node;root=walRoot;
        key=KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(
            Files.readAllBytes(root.resolve(".preflight-identity/local.pk8"))));
    }
    static boolean selected(String part){return "P000".equals(part)||"P128".equals(part);}
    static boolean enabled(){
        return "1".equals(System.getenv("DEMO_V19_FOUR_NODE_INTERNAL_SEQ1"));
    }
    static String requestId(String part){return "INTERNAL-NON-TRADING-SEQ1-"+part;}
    static long delta(String part){return "P000".equals(part)?11:17;}
    static void requireExactPilotWal(DemoDurableJournal journal,PartitionAssignment a)
            throws Exception{
        String part=a.getPartitionId();
        String digest=DemoV19FourNodeGenesisPreflight.exactAssignmentDigest(a);
        if(!selected(part) || !journal.isReadyForWrites() || journal.lastEpoch()!=1
                || !journal.hasPhysicalGenesis(1,part,digest))
            throw new IOException("invalid or uninitialized pilot WAL");
        if(journal.committedSeq()==1){
            DemoDurableJournal.CommittedRequest c=journal.committedRequest(requestId(part));
            if(c==null || c.seq!=1 || c.delta!=delta(part)
                    || journal.state().distinctRequests()!=1
                    || journal.state().total()!=delta(part))
                throw new IOException("pilot WAL has unauthorized business request");
        }else if(journal.committedSeq()!=0)
            throw new IOException("pilot WAL sequence beyond one");
    }
    private static String actualGenesisEvidenceHash(ZookeeperClient zk,
            PartitionAssignment a)throws Exception{
        Stat stat=new Stat();
        Object value=zk.readData(DemoV19FourNodeGenesisRecord.EVIDENCE+
            "/"+a.getPartitionId(),stat);
        if(value==null || stat.getVersion()!=0)throw new IOException("missing genesis evidence");
        @SuppressWarnings("unchecked")
        Map<String,Object> doc=JsonUtils.Deserialize(String.valueOf(value),Map.class);
        if(doc==null || !"FSYNC_GENESIS_NO_READY".equals(doc.get("scope"))
                || !(doc.get("nonce") instanceof String)
                || !(doc.get("walPrefixSha256") instanceof String)
                || !(doc.get("receipts") instanceof List))
            throw new IOException("malformed protected Genesis evidence");
        String nonce=(String)doc.get("nonce");
        String physical=(String)doc.get("walPrefixSha256");
        List<?> witnesses=(List<?>)doc.get("receipts");
        if(witnesses.size()!=2)throw new IOException("missing genesis physical vote");
        for(int i=0;i<2;i++){
            if(!(witnesses.get(i) instanceof Map))throw new IOException("bad historical vote");
            String voter=DemoV19FourNodeLiveRuntime.owners(a).get(i);
            String valid=DemoV19FourNodeGenesisRecord.verify(zk,a,voter,nonce,
                ReplicationControlResponse.ok(DemoNettyBridge.json(witnesses.get(i))));
            if(!physical.equals(valid))throw new IOException("genesis WAL fork");
        }
        return DemoV19FourNodeGenesisCustody.sha(
            String.valueOf(value).getBytes(java.nio.charset.StandardCharsets.UTF_8));
    }
    private void requireBootstrap(ZookeeperClient zk,PartitionAssignment a,
            DemoDurableJournal journal)throws Exception{
        DemoV19FourNodeCommonMembership.requireUnchanged(zk,a);
        String evidenceSha=actualGenesisEvidenceHash(zk,a);
        String memberSha=DemoV19FourNodeGenesisPreflight.exactAssignmentDigest(a);
        if(!journal.hasPhysicalGenesis(1,a.getPartitionId(),memberSha))
            throw new IOException("physical initial Genesis missing");
        String genesisHash=journal.committedPrefixSha256Through(0);
        // Existing physically independent bootstrap custody MUST predate
        // this internal test. It cannot be silently created at seq1 stage.
        Path head=root.resolve(".genesis-bootstrap-custody")
            .resolve(a.getPartitionId()).resolve("head.bin");
        if(!Files.isRegularFile(head,LinkOption.NOFOLLOW_LINKS)
                || Files.isSymbolicLink(head))
            throw new IOException("local durable Genesis bootstrap custody absent");
        DemoV19FourNodeGenesisCustody.installLocalHead(root,a,evidenceSha,genesisHash);
    }
    private PartitionAssignment expected(List<PartitionAssignment> plan,String part)
            throws Exception {
        if(!selected(part))throw new IOException("pilot strictly P000 or P128 only");
        PartitionAssignment a=plan.get(Integer.parseInt(part.substring(1)));
        if(!part.equals(a.getPartitionId())
                || !DemoV19FourNodeLiveRuntime.owners(a).contains(node))
            throw new IOException("physical signatory not an assigned buddy");
        return a;
    }
    private DurableWalCommitQuorum.LocalDurability durability(ZookeeperClient zk,
            PartitionAssignment a,DemoDurableJournal journal){
        return (epoch,seq)->{
            DemoV19FourNodeCommonMembership.requireUnchanged(zk,a);
            synchronized(journal){
                requireExactPilotWal(journal,a);
                if(epoch!=1 || seq!=1 || journal.committedSeq()!=1
                        || journal.lastEpoch()!=1)
                    throw new IOException("wrong Common signed seq1 boundary");
                return journal.committedPrefixSha256Through(seq);
            }
        };
    }
    static Map<String,Object> wire(DurableWalCommitQuorum.Receipt r){
        Map<String,Object> x=new LinkedHashMap<>();
        x.put("node",r.node);x.put("partition",r.partition);
        x.put("epoch",r.epoch);x.put("sequence",r.sequence);
        x.put("sha",r.commitPrefixSha256);x.put("membership",r.membershipSha256);
        x.put("signature",Base64.getEncoder().encodeToString(r.signature()));
        return x;
    }
    static DurableWalCommitQuorum.Receipt fromWire(Object raw)throws Exception{
        if(!(raw instanceof Map))throw new IOException("untrusted RSA vote");
        Map<?,?> r=(Map<?,?>)raw;
        Object n=r.get("node"),p=r.get("partition"),h=r.get("sha"),m=r.get("membership");
        Object e=r.get("epoch"),s=r.get("sequence"),sig=r.get("signature");
        if(!(n instanceof String)||!(p instanceof String)||!(h instanceof String)
                ||!(m instanceof String)||!(e instanceof Number)||!(s instanceof Number)
                ||!(sig instanceof String))
            throw new IOException("incomplete RSA signed WAL vote");
        return DurableWalCommitQuorum.Receipt.fromWire((String)n,(String)p,
            ((Number)e).longValue(),((Number)s).longValue(),(String)h,(String)m,
            Base64.getDecoder().decode((String)sig));
    }
    static Map<String,Object> custodyWire(DurableWalCustodyQuorum.Receipt receipt){
        Map<String,Object> out=new LinkedHashMap<>();
        out.put("node",receipt.node);
        out.put("partition",receipt.partition);
        out.put("epoch",receipt.oldEpoch);
        out.put("sequence",receipt.sequence);
        out.put("sha",receipt.walPrefixHash);
        out.put("membership",receipt.oldMembershipHash);
        out.put("signature",Base64.getEncoder().encodeToString(receipt.signature()));
        return out;
    }
    static DurableWalCustodyQuorum.Receipt custodyFromWire(Object raw)throws Exception{
        if(!(raw instanceof Map))throw new IOException("untrusted remote custody receipt");
        Map<?,?> r=(Map<?,?>)raw;
        if(!(r.get("node") instanceof String)
                || !(r.get("partition") instanceof String)
                || !(r.get("membership") instanceof String)
                || !(r.get("sha") instanceof String)
                || !(r.get("epoch") instanceof Number)
                || !(r.get("sequence") instanceof Number)
                || !(r.get("signature") instanceof String))
            throw new IOException("incomplete remote custody receipt");
        return DurableWalCustodyQuorum.Receipt.fromWire(
            (String)r.get("node"),(String)r.get("partition"),
            (String)r.get("membership"),(String)r.get("sha"),
            ((Number)r.get("epoch")).longValue(),
            ((Number)r.get("sequence")).longValue(),
            Base64.getDecoder().decode((String)r.get("signature")));
    }
    static List<DurableWalCommitQuorum.Receipt> receiveTwoVotes(Object raw)
            throws Exception{
        if(!(raw instanceof List)||((List<?>)raw).size()!=2)
            throw new IOException("require exactly two independently signed WAL votes");
        List<DurableWalCommitQuorum.Receipt> out=new ArrayList<>();
        for(Object entry:(List<?>)raw)out.add(fromWire(entry));
        return out;
    }
    ReplicationControlResponse handle(ZookeeperClient zk,List<PartitionAssignment> plan,
            DemoV19FourNodeLiveRuntime.HeldWal held,ReplicationControlRequest req){
        try{
            if(!enabled()||req==null || !node.equals(held.node)
                    || !DemoV19FourNodeShardCatalog.SERVICE.equals(req.getServiceName())
                    || !zk.isConnected())
                throw new IOException("internal isolated seq1 disabled/unauthorized");
            String part=req.getPartitionId();
            PartitionAssignment a=expected(plan,part);
            DemoDurableJournal wal=held.owned.get(part);
            if(wal==null)throw new IOException("physical WAL lock absent");
            DurableWalCommitQuorum.Membership member=
                DemoV19FourNodeCommonMembership.pinned(zk,a);
            if(FSYNC.equals(req.getOperation())){
                if(req.getPayload()==null || req.getPayload().length!=32)
                    throw new IOException("fresh 32-byte pilot challenge required");
                String sha;
                synchronized(wal){
                    requireBootstrap(zk,a,wal);
                    requireExactPilotWal(wal,a);
                    if(wal.committedSeq()==0){
                        wal.prepareAndCommitSingleForce(1,1,
                            new DemoStateMachine.Operation(requestId(part),delta(part)));
                    }
                    sha=durability(zk,a,wal).requireFsyncedPrefix(1,1);
                }
                DurableWalCommitQuorum.Receipt r=DurableWalCommitQuorum.sign(
                    member,node,1,durability(zk,a,wal),key);
                DurableWalCommitQuorum.requireValidReceipt(member,r);
                DemoV19FourNodeCommonMembership.requireUnchanged(zk,a);
                Map<String,Object> result=new LinkedHashMap<>();
                result.put("scope",OP_SCOPE);
                result.put("nonce",DemoV19FourNodeGenesisPreflight.hex(req.getPayload()));
                result.put("vote",wire(r));result.put("walSha256",sha);
                result.put("ready",false);result.put("clientAck",false);
                return ReplicationControlResponse.ok(DemoNettyBridge.json(result));
            }
            if(CERTIFY.equals(req.getOperation())){
                if(!node.equals(a.getPrimary()))
                    throw new IOException("only current assigned primary may certify");
                if(req.getPayload()==null || req.getPayload().length<20
                        || req.getPayload().length>4096)
                    throw new IOException("bounded two-receipt proof required");
                @SuppressWarnings("unchecked")
                Map<String,Object> reqMap=JsonUtils.Deserialize(
                    new String(req.getPayload(),java.nio.charset.StandardCharsets.UTF_8),
                    Map.class);
                if(reqMap==null || !OP_SCOPE.equals(reqMap.get("scope"))
                    || !part.equals(reqMap.get("partition"))
                    || !(reqMap.get("votes") instanceof List)
                    || ((List<?>)reqMap.get("votes")).size()!=2)
                    throw new IOException("invalid Common seq1 quorum publication request");
                List<DurableWalCommitQuorum.Receipt> two=
                    receiveTwoVotes(reqMap.get("votes"));
                String localSha=durability(zk,a,wal).requireFsyncedPrefix(1,1);
                DurableWalCommitQuorum.Certificate valid=
                    DurableWalCommitQuorum.verify(member,1,localSha,two);
                DemoV19FourNodeCommonMembership.requireUnchanged(zk,a);
                Path directory=root.resolve(".pilot-common-commit-index-"+part);
                try(DurableWalCommitIndex index=
                        new DurableWalCommitIndex(directory,member)){
                    if(index.committedSequence()==0)
                        index.certifyAndPersist(1,localSha,two);
                    index.requireExactCertified(1,1,localSha);
                }
                // No ZK promotion. No client success ACK.
                DemoV19FourNodeCommonMembership.requireUnchanged(zk,a);
                Map<String,Object> out=new LinkedHashMap<>();
                out.put("scope",OP_SCOPE);out.put("partition",part);
                out.put("certifiedSeq",valid.committedSequence);
                out.put("sha256",localSha);out.put("quorumVotes",valid.votes.size());
                out.put("ready",false);out.put("clientAck",false);
                return ReplicationControlResponse.ok(DemoNettyBridge.json(out));
            }
            if(CUSTODY.equals(req.getOperation())){
                if(req.getPayload()==null || req.getPayload().length<20
                        || req.getPayload().length>4096)
                    throw new IOException("bounded two-signer custody proof required");
                @SuppressWarnings("unchecked")
                Map<String,Object> input=JsonUtils.Deserialize(
                    new String(req.getPayload(),java.nio.charset.StandardCharsets.UTF_8),
                    Map.class);
                if(input==null || !OP_SCOPE.equals(input.get("scope"))
                        || !part.equals(input.get("partition")))
                    throw new IOException("cross-partition or untrusted custody message");
                List<DurableWalCommitQuorum.Receipt> votes=
                    receiveTwoVotes(input.get("votes"));
                String localSha=durability(zk,a,wal).requireFsyncedPrefix(1,1);
                DurableWalCommitQuorum.Certificate valid=
                    DurableWalCommitQuorum.verify(member,1,localSha,votes);
                if(valid.authorizesReady())
                    throw new IOException("unexpected authorization in Common data certificate");
                Path folder=root.resolve(".pilot-common-custody-"+part);
                DurableWalCertificateCustody.Authority authority=old->{
                    DemoV19FourNodeCommonMembership.requireUnchanged(zk,a);
                    if(!member.digest.equals(old.digest))
                        throw new IOException("custody membership was replaced");
                };
                DurableWalCustodyQuorum.Receipt signed;
                try(DurableWalCertificateCustody store=
                        new DurableWalCertificateCustody(folder,member,
                            durability(zk,a,wal),authority)){
                    if(store.install(valid)!=1)
                        throw new IOException("Common custody failed to fsync seq1");
                    signed=store.signInstalled(node,key);
                    DurableWalCustodyQuorum.requireValidReceipt(member,valid,signed);
                    if(store.highestVerified()==null
                            || store.highestVerified().committedSequence!=1)
                        throw new IOException("Common custody readback failed");
                }
                DemoV19FourNodeCommonMembership.requireUnchanged(zk,a);
                Map<String,Object> accepted=new LinkedHashMap<>();
                accepted.put("scope",OP_SCOPE);
                accepted.put("partition",part);
                accepted.put("custody",custodyWire(signed));
                accepted.put("ready",false);
                accepted.put("clientAck",false);
                return ReplicationControlResponse.ok(DemoNettyBridge.json(accepted));
            }
            throw new IOException("unsupported internal pilot opcode");
        }catch(Exception fail){
            return ReplicationControlResponse.error("NON_TRADING_SEQ1_PILOT_DENIED",
                fail.getClass().getSimpleName()+": "+fail.getMessage());
        }
    }
    static void proveTwoPairs(ZookeeperClient zk,List<PartitionAssignment> plan)
            throws Exception {
        try(DirectNettyReplicationTransport net=new DirectNettyReplicationTransport(
                10000,DirectNettyReplicationServer.DEFAULT_MAX_FRAME_BYTES)){
            for(char c:new char[]{'A','C'}){
                String part=DemoV19FourNodeGenesisPreflight.firstShard(plan,c);
                PartitionAssignment a=plan.get(Integer.parseInt(part.substring(1)));
                DurableWalCommitQuorum.Membership member=
                    DemoV19FourNodeCommonMembership.pinned(zk,a);
                byte[] challenge=new byte[32];new SecureRandom().nextBytes(challenge);
                String nonce=DemoV19FourNodeGenesisPreflight.hex(challenge);
                List<DurableWalCommitQuorum.Receipt> votes=new ArrayList<>();
                String sha=null;
                for(String voter:DemoV19FourNodeLiveRuntime.owners(a)){
                    ReplicationControlResponse reply=net.control(
                        DemoV19FourNodeLiveRuntime.exactEndpoint(voter),
                        new ReplicationControlRequest(
                            DemoV19FourNodeShardCatalog.SERVICE,FSYNC,part,challenge))
                        .get(8,TimeUnit.SECONDS);
                    if(!reply.isSuccess())throw new IOException(
                        "replica seq1 pilot declined: "+voter+" "+reply.getMessage());
                    Map<String,Object> result=DemoNettyBridge.map(reply.getPayload());
                    if(!OP_SCOPE.equals(result.get("scope"))
                        ||!nonce.equals(result.get("nonce"))
                        || !Boolean.FALSE.equals(result.get("ready"))
                        || !Boolean.FALSE.equals(result.get("clientAck")))
                        throw new IOException("untrusted seq1 signer scope");
                    DurableWalCommitQuorum.Receipt r=fromWire(result.get("vote"));
                    if(!voter.equals(r.node))throw new IOException("wrong RSA signer identity");
                    DurableWalCommitQuorum.requireValidReceipt(member,r);
                    if(sha!=null&&!sha.equals(r.commitPrefixSha256))
                        throw new IOException("real 2-node fsynced WAL hash fork");
                    sha=r.commitPrefixSha256;
                    votes.add(r);
                }
                DurableWalCommitQuorum.Certificate cert=
                    DurableWalCommitQuorum.verify(member,1,sha,votes);
                if(cert.authorizesReady())throw new IOException("Common receipt prematurely READY");
                Map<String,Object> commit=new LinkedHashMap<>();
                commit.put("scope",OP_SCOPE);commit.put("partition",part);
                List<Map<String,Object>> encoded=new ArrayList<>();
                for(DurableWalCommitQuorum.Receipt r:votes)encoded.add(wire(r));
                commit.put("votes",encoded);
                ReplicationControlResponse persisted=net.control(
                    DemoV19FourNodeLiveRuntime.exactEndpoint(a.getPrimary()),
                    new ReplicationControlRequest(DemoV19FourNodeShardCatalog.SERVICE,
                        CERTIFY,part,DemoNettyBridge.json(commit))).get(8,TimeUnit.SECONDS);
                if(!persisted.isSuccess())
                    throw new IOException("primary cannot certify Common index: "+
                        persisted.getMessage());
                Map<String,Object> result=DemoNettyBridge.map(persisted.getPayload());
                if(!OP_SCOPE.equals(result.get("scope"))
                    || !Boolean.FALSE.equals(result.get("ready"))
                    || !Boolean.FALSE.equals(result.get("clientAck"))
                    || !part.equals(result.get("partition"))
                    || !(result.get("certifiedSeq") instanceof Number)
                    || ((Number)result.get("certifiedSeq")).longValue()!=1
                    || !sha.equals(result.get("sha256"))
                    || !(result.get("quorumVotes") instanceof Number)
                    || ((Number)result.get("quorumVotes")).intValue()!=2)
                    throw new IOException("incomplete Common 2/2 index result");
                List<DurableWalCustodyQuorum.Receipt> custody=new ArrayList<>();
                for(String custodian:DemoV19FourNodeLiveRuntime.owners(a)){
                    ReplicationControlResponse stored=net.control(
                        DemoV19FourNodeLiveRuntime.exactEndpoint(custodian),
                        new ReplicationControlRequest(DemoV19FourNodeShardCatalog.SERVICE,
                            CUSTODY,part,DemoNettyBridge.json(commit)))
                        .get(8,TimeUnit.SECONDS);
                    if(!stored.isSuccess())
                        throw new IOException("missing remote physical Common custody "+
                            custodian+": "+stored.getMessage());
                    Map<String,Object> receipt=DemoNettyBridge.map(stored.getPayload());
                    if(!OP_SCOPE.equals(receipt.get("scope"))
                            || !part.equals(receipt.get("partition"))
                            || !Boolean.FALSE.equals(receipt.get("ready"))
                            || !Boolean.FALSE.equals(receipt.get("clientAck")))
                        throw new IOException("wrong remote custody scope/permission");
                    DurableWalCustodyQuorum.Receipt physical=
                        custodyFromWire(receipt.get("custody"));
                    if(!custodian.equals(physical.node))
                        throw new IOException("custody signer impersonation");
                    DurableWalCustodyQuorum.requireValidReceipt(member,cert,physical);
                    custody.add(physical);
                }
                DurableWalCustodyQuorum.CustodiedCertificate verified=
                    DurableWalCustodyQuorum.verify(member,cert,custody);
                if(verified.physicalCustodians!=2 || verified.sequence!=1
                        || verified.authorizesPromotion())
                    throw new IOException("incorrect signed Common custody quorum");
                DemoV19FourNodeCommonMembership.requireUnchanged(zk,a);
                System.out.println("FOUR_NODE_NETTY_SEQ1_COMMON_INDEX_PASS partition="+part
                    +" pair="+a.getPrimary()+"/"+a.getReplica()
                    +" physicalNettyWalFsyncs=2 signedCommonReceipts=2"
                    +" commonIndexFsynced=true seq=1 sha256="+sha
                    +" commonCustody=true physicalCommonCustodians=2 ready=false clientAck=false"
                    +" actualOrders=0 singleMacFaultDomain=true");
            }
        }
    }
}
