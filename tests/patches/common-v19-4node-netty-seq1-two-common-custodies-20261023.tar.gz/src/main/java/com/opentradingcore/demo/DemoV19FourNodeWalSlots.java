package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;

/**
 * Isolated v19 4-node pilot: open and independently lock only the 128 owned
 * partition WAL slots on each of the four JVMs.  This is intentionally
 * non-writable PREPARING validation, NOT a Genesis/READY or replication grant.
 */
final class DemoV19FourNodeWalSlots {
    private DemoV19FourNodeWalSlots() {}

    static int initialize(List<PartitionAssignment> assignments,String node,
            Path walRoot) throws IOException {
        DemoV19FourNodeShardCatalog.verifyLayout(assignments,node);
        if(walRoot==null || !walRoot.isAbsolute())
            throw new IllegalArgumentException("isolated physical WAL root required");
        Set<String> owned=new TreeSet<>();
        for(PartitionAssignment a:assignments){
            if(node.equals(a.getPrimary()) || node.equals(a.getReplica()))
                owned.add(a.getPartitionId());
        }
        if(owned.size()!=128)throw new IllegalStateException("exactly 128 owned WALs required");
        Files.createDirectories(walRoot);
        // A shared/cross-wired WAL volume is a failure, not a reason to claim
        // ownership of another partition or delete its existing data.
        try(DirectoryStream<Path> list=Files.newDirectoryStream(walRoot,"P???.wal")){
            for(Path file:list) {
                String filename=file.getFileName().toString();
                String partition=filename.substring(0,filename.length()-4);
                if(!owned.contains(partition))
                    throw new IOException("unexpected foreign partition WAL in data volume: "+file);
            }
        }
        int verified=0;
        for(String part:owned){
            Path file=walRoot.resolve(part+".wal");
            if(Files.isSymbolicLink(file))throw new IOException("WAL symlink forbidden: "+file);
            try(DemoDurableJournal wal=new DemoDurableJournal(file)){
                if(!wal.isReadyForWrites())
                    throw new IOException("catalog WAL is dirty: "+part);
                if(wal.committedSeq()!=0){
                    if(!DemoV19FourNodeSeq1NettyPilot.enabled()
                            || !DemoV19FourNodeSeq1NettyPilot.selected(part))
                        throw new IOException("unexpected nonzero PREPARING WAL: "+part);
                    PartitionAssignment expected=null;
                    for(PartitionAssignment a:assignments)
                        if(part.equals(a.getPartitionId())){expected=a;break;}
                    if(expected==null)throw new IOException("missing exact partition");
                    try{
                        DemoV19FourNodeSeq1NettyPilot.requireExactPilotWal(wal,expected);
                    }catch(Exception bad){throw new IOException(
                        "non-authenticated internal seq1 WAL: "+part,bad);}
                }
                verified++;
            }
        }
        return verified;
    }
}
