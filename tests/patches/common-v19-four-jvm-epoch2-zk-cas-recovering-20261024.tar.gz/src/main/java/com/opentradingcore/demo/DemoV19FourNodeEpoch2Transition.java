package com.opentradingcore.demo;

import com.app.common.partition.*;
import com.app.common.replication.*;
import com.app.common.zk.ZookeeperClient;
import com.gateway.connector.utils.JsonUtils;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import org.apache.zookeeper.data.Stat;

/**
 * Transition EXACTLY the two previously frozen, doubly certified internal
 * demo partitions to epoch2 RECOVERING. Never grants READY or client ACK.
 * Quorum proof comes from old epoch's physical 2/2 revocation and epoch2
 * snapshot candidate 2/2 RSA attestations.
 */
final class DemoV19FourNodeEpoch2Transition {
    private DemoV19FourNodeEpoch2Transition(){}

    static PartitionAssignment recovering(PartitionAssignment original) {
        if(original==null || !DemoV19FourNodeSeq1NettyPilot.selected(
                original.getPartitionId()) || original.getEpoch()!=1
                || !"PREPARING".equals(original.getState()))
            throw new IllegalArgumentException("invalid bounded recovering source");
        PartitionAssignment next=JsonUtils.Deserialize(
            DemoV19FourNodeShardCatalog.encode(original),PartitionAssignment.class);
        next.setPrimary(original.getReplica());
        next.setReplica(original.getPrimary());
        next.setReplicas(Collections.singletonList(original.getPrimary()));
        next.setEpoch(2);
        next.setAssignmentVersion(1);
        next.setState("RECOVERING");
        return next;
    }
    static DurableWalCommitQuorum.Membership historicMembership(
            ZookeeperClient zk,PartitionAssignment original)throws Exception{
        List<DurableWalCommitQuorum.Member> voters=new ArrayList<>();
        for(String node:DemoV19FourNodeLiveRuntime.owners(original))
            voters.add(new DurableWalCommitQuorum.Member(
                node,"same-mac-jvm-"+node,
                DemoV19FourNodeGenesisPreflight.pinned(zk,node)));
        return new DurableWalCommitQuorum.Membership(
            DemoV19FourNodeShardCatalog.SERVICE,original.getPartitionId(),
            original.getPrimary(),1,1,voters);
    }
    @SuppressWarnings("unchecked")
    static Map<String,Object> requireRecoveryProof(ZookeeperClient zk,
            PartitionAssignment original)throws Exception{
        if(zk==null || !zk.isConnected() || original==null
                || !DemoV19FourNodeSeq1NettyPilot.selected(original.getPartitionId()))
            throw new IOException("no bounded connected recovery proof");
        String part=original.getPartitionId();
        DurableWalCommitQuorum.Membership member=historicMembership(zk,original);
        Stat sourceStat=new Stat();
        Object sourceRaw=zk.readData(
            DemoV19FourNodeRemoteRevocation.proofPath(part),sourceStat);
        if(sourceRaw==null||sourceStat.getVersion()!=0)
            throw new IOException("missing immutable old revoke proof");
        Map<String,Object> source=JsonUtils.Deserialize(
            String.valueOf(sourceRaw),Map.class);
        String sha=String.valueOf(source.get("walSha256"));
        if(!member.digest.equals(source.get("membershipSha256"))
                || !sha.matches("[a-f0-9]{64}")
                || !(source.get("nonce") instanceof String)
                || !(source.get("votes") instanceof List)
                || ((List<?>)source.get("votes")).size()!=2)
            throw new IOException("incomplete old source revocation");
        List<?> oldVotes=(List<?>)source.get("votes");
        for(int i=0;i<2;i++){
            if(!(oldVotes.get(i) instanceof Map))
                throw new IOException("invalid old vote");
            DemoV19FourNodeRemoteRevocation.verify(zk,original,
                DemoV19FourNodeLiveRuntime.owners(original).get(i),
                (String)source.get("nonce"),member.digest,sha,
                ReplicationControlResponse.ok(DemoNettyBridge.json(oldVotes.get(i))));
        }
        Stat proofStat=new Stat();
        Object imageRaw=zk.readData(DemoV19FourNodeEpoch2Image.PROOFS+"/"+part,proofStat);
        if(imageRaw==null || proofStat.getVersion()!=0)
            throw new IOException("missing immutable epoch2 image proof");
        Map<String,Object> record=JsonUtils.Deserialize(
            String.valueOf(imageRaw),Map.class);
        String image=String.valueOf(record.get("imageSha256"));
        String head=String.valueOf(record.get("headSha256"));
        String sourceProofSha=DemoV19FourNodeGenesisCustody.sha(
            String.valueOf(sourceRaw).getBytes(java.nio.charset.StandardCharsets.UTF_8));
        if(!DemoV19FourNodeEpoch2Image.SCOPE.equals(record.get("scope"))
                || !part.equals(record.get("partition"))
                || !member.digest.equals(record.get("membershipSha256"))
                || !sha.equals(record.get("walSha256"))
                || !sourceProofSha.equals(record.get("sourceRevokeProofSha256"))
                || !image.matches("[a-f0-9]{64}")
                || !head.matches("[a-f0-9]{64}")
                || !(record.get("nonce") instanceof String)
                || !(record.get("votes") instanceof List)
                || ((List<?>)record.get("votes")).size()!=2)
            throw new IOException("missing certified new epoch candidate");
        List<?> attestations=(List<?>)record.get("votes");
        for(int i=0;i<2;i++){
            if(!(attestations.get(i) instanceof Map))
                throw new IOException("invalid new recovery attestation");
            Map<?,?> fields=(Map<?,?>)attestations.get(i);
            if(!image.equals(fields.get("imageSha256"))
                    || !head.equals(fields.get("headSha256")))
                throw new IOException("forked image candidate signature");
            DemoV19FourNodeEpoch2Image.verify(zk,original,
                DemoV19FourNodeLiveRuntime.owners(original).get(i),
                member.digest,sha,(String)record.get("nonce"),
                ReplicationControlResponse.ok(DemoNettyBridge.json(fields)));
        }
        if(!zk.isConnected())throw new IOException("lost ZK after proof check");
        return record;
    }
    static PartitionAssignment requireAssignment(ZookeeperClient zk,
            PartitionAssignment source,Object actual,int version)throws Exception{
        if(version==0
                && DemoV19FourNodeShardCatalog.encode(source).equals(String.valueOf(actual)))
            return source;
        if(version!=1 || !DemoV19FourNodeSeq1NettyPilot.selected(
                    source.getPartitionId()))
            throw new IOException("untrusted mutation of a catalogue assignment");
        PartitionAssignment next=recovering(source);
        PartitionAssignment decoded=JsonUtils.Deserialize(
            String.valueOf(actual),PartitionAssignment.class);
        if(decoded==null || !DemoV19FourNodeShardCatalog.encode(next).equals(
                DemoV19FourNodeShardCatalog.encode(decoded)))
            throw new IOException("new recovery assignment not exact CAS successor");
        requireRecoveryProof(zk,source);
        if(next.isRoutable() || !"RECOVERING".equals(next.getState()))
            throw new IOException("premature ZK READY");
        return next;
    }
    static void requireLocalImage(ZookeeperClient zk,
            PartitionAssignment source,String node,Path root,
            DemoDurableJournal wal)throws Exception{
        if(!DemoV19FourNodeSeq1NettyPilot.selected(source.getPartitionId()))
            return;
        Stat v=new Stat();
        Object record=zk.readData(DemoV19FourNodeShardCatalog.ASSIGNMENTS+
            "/"+source.getPartitionId(),v);
        PartitionAssignment current=requireAssignment(zk,source,record,v.getVersion());
        if(current.getEpoch()!=2)return;
        Map<String,Object> prepared=requireRecoveryProof(zk,source);
        Path file=root.resolve(DemoV19FourNodeEpoch2Image.imagePath(
            source.getPartitionId())).resolve("candidate.bin");
        if(!Files.isRegularFile(file,LinkOption.NOFOLLOW_LINKS)
            || Files.isSymbolicLink(file)
            || !DemoV19FourNodeLiveRuntime.owners(source).contains(node)
            || wal==null || wal.committedSeq()!=1
            || !prepared.get("walSha256").equals(wal.committedPrefixSha256Through(1))
            || !prepared.get("headSha256").equals(
                DemoV19FourNodeGenesisCustody.sha(Files.readAllBytes(file))))
            throw new IOException("not installed physical new-epoch recovery image");
    }
    static void migrate(ZookeeperClient zk,List<PartitionAssignment> plan)throws Exception{
        for(char owner:new char[]{'A','C'}){
            String part=DemoV19FourNodeGenesisPreflight.firstShard(plan,owner);
            PartitionAssignment old=plan.get(Integer.parseInt(part.substring(1)));
            requireRecoveryProof(zk,old);
            String path=DemoV19FourNodeShardCatalog.ASSIGNMENTS+"/"+part;
            Stat stat=new Stat();
            Object raw=zk.readData(path,stat);
            PartitionAssignment observed=requireAssignment(zk,old,raw,stat.getVersion());
            if(observed.getEpoch()==2){
                System.out.println("FOUR_NODE_EPOCH2_CAS_RECOVERING_PASS partition="+part+
                    " zkVersion=1 idempotent=true ready=false clientAck=false");
                continue;
            }
            PartitionAssignment next=recovering(old);
            try(ZkPartitionFailoverControlPlane controller=
                    new ZkPartitionFailoverControlPlane(zk,
                        DemoV19FourNodeShardCatalog.ASSIGNMENTS,
                        "/MDTService",DemoV19FourNodeShardCatalog.ROOT+
                            "/epoch2-controlled-cas-lease",
                        "isolated-epoch2-recovery-controller")) {
                if(!controller.tryAcquireLease() || !controller.hasLease())
                    throw new IOException("no authentic source controller lease");
                if(!controller.compareAndSet(part,0,next))
                    throw new IOException("old source stat.version CAS rejected");
            }
            Stat after=new Stat();
            Object updated=zk.readData(path,after);
            PartitionAssignment valid=requireAssignment(zk,old,updated,after.getVersion());
            if(valid.getEpoch()!=2 || valid.isRoutable() || after.getVersion()!=1)
                throw new IOException("new recovery authority not durably recorded");
            System.out.println("FOUR_NODE_EPOCH2_CAS_RECOVERING_PASS partition="+part+
                " sourceEpoch=1 newEpoch=2 zkVersion=1 oldPrimary="+old.getPrimary()+
                " recoveringPrimary="+valid.getPrimary()+
                " twoSignedImageProof=true ready=false clientAck=false");
        }
    }
}
