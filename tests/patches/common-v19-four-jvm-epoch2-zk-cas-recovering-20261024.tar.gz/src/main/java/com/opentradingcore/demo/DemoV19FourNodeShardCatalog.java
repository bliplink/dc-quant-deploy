package com.opentradingcore.demo;

import com.app.common.partition.*;
import com.app.common.zk.ZookeeperClient;
import com.gateway.connector.utils.JsonUtils;
import java.util.*;
import java.nio.file.Paths;
import org.I0Itec.zkclient.exception.ZkNodeExistsException;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.data.Stat;

/**
 * Metadata-only, NON-WRITABLE four-data-process placement acceptance pilot.
 * This code does NOT enable WAL/ACK/READY on 256 partitions. It verifies the
 * trusted Common RF2 buddy planner and the real ZK persisted, immutable
 * PREPARING catalog without ever touching the existing P000 v19 test root.
 */
public final class DemoV19FourNodeShardCatalog {
    static final String ROOT="/dc/cluster/commonhademo/v19-four-node-placement-pilot";
    static final String ASSIGNMENTS=ROOT+"/assignments";
    static final String SERVICE="CommonHaDemo";
    static final int PARTITIONS=256;

    private DemoV19FourNodeShardCatalog(){}
    static List<PartitionAssignment> layout(){
        List<ClusterNodeDescriptor> nodes=new ArrayList<>();
        for(char c='A';c<='D';c++){
            ClusterNodeDescriptor node=new ClusterNodeDescriptor();
            node.setServiceName(SERVICE);
            node.setNodeName(SERVICE+c);
            // Logical planner failure-domain labels, not physical machine evidence:
            // all four containers still run inside ONE Mac Docker VM.
            node.setHost("simulated-data-host-"+c);
            node.setState(ClusterNodeLifecycleState.ACTIVE);
            nodes.add(node);
        }
        return PartitionBuddyPlacementPlanner.proposeNew(
            PARTITIONS,1,nodes,Collections.<PartitionAssignment>emptyList());
    }
    static final class Counts {
        final int primary,replica,other;
        Counts(int primary,int replica,int other) {
            this.primary=primary;this.replica=replica;this.other=other;
        }
    }
    static Counts verifyLayout(List<PartitionAssignment> layout,String local){
        if(layout==null || layout.size()!=PARTITIONS
                || local==null || !local.matches("CommonHaDemo[ABCD]"))
            throw new IllegalArgumentException("invalid four-node catalog");
        int primary=0,replica=0,other=0;
        Set<String> unique=new HashSet<>();
        for(int i=0;i<PARTITIONS;i++){
            PartitionAssignment item=layout.get(i);
            String expected=String.format(Locale.ROOT,"P%03d",i);
            if(item==null || !expected.equals(item.getPartitionId())
                    || !unique.add(item.getPartitionId())
                    || item.getEpoch()!=1 || item.getAssignmentVersion()!=0
                    || item.isRoutable() || !"PREPARING".equals(item.getState())
                    || item.replicaNodes().size()!=1 || item.getPrimary().equals(item.getReplica()))
                throw new IllegalStateException("unsafe or modified placement "+expected);
            String lead=item.getPrimary(),follow=item.getReplica();
            int leader=lead.charAt(lead.length()-1)-'A';
            int buddy=follow.charAt(follow.length()-1)-'A';
            if(leader<0 || leader>3 || (leader^1)!=buddy)
                throw new IllegalStateException("not an exact A/B C/D buddy "+expected);
            if(local.equals(lead))primary++;
            else if(local.equals(follow))replica++;
            else other++;
        }
        if(primary!=64 || replica!=64 || other!=128)
            throw new IllegalStateException("node is not balanced 64+64+128: "+local);
        return new Counts(primary,replica,other);
    }
    static String encode(PartitionAssignment assignment){
        return JsonUtils.Serializer(assignment);
    }
    static void assertPersisted(PartitionAssignment expected,String data,int zkVersion){
        if(zkVersion!=0 || !encode(expected).equals(data))
            throw new IllegalStateException("ZK assignment mismatch/modified: "
                    +expected.getPartitionId());
    }
    static void ensurePath(ZookeeperClient zk,String path){
        if(zk.exists(path))return;
        try{zk.create(path,"",CreateMode.PERSISTENT);}
        catch(ZkNodeExistsException racing) {
            if(!zk.exists(path))throw racing;
        }
    }
    static void install(ZookeeperClient zk,List<PartitionAssignment> plan){
        // Evaluate ALL entries before issuing even the first ZK mutation.
        for(char c='A';c<='D';c++)verifyLayout(plan,SERVICE+c);
        for(String path:new String[]{"/dc","/dc/cluster",
                "/dc/cluster/commonhademo",ROOT,ASSIGNMENTS})
            ensurePath(zk,path);
        for(PartitionAssignment expected:plan){
            String path=ASSIGNMENTS+"/"+expected.getPartitionId();
            String value=encode(expected);
            if(!zk.exists(path)){
                try{zk.create(path,value,CreateMode.PERSISTENT);}
                catch(ZkNodeExistsException racing){
                    if(!value.equals(String.valueOf(zk.readData(path))))throw racing;
                }
            } else {
                Stat current=new Stat();
                Object actual=zk.readData(path,current);
                try{
                    DemoV19FourNodeEpoch2Transition.requireAssignment(
                        zk,expected,actual,current.getVersion());
                }catch(Exception invalid){
                    throw new IllegalStateException(
                        "never overwrite unverified recovery assignment: "+path,invalid);
                }
            }
        }
        audit(zk,plan,SERVICE+"A");
    }
    static Counts audit(ZookeeperClient zk,List<PartitionAssignment> plan,String node){
        Counts count=verifyLayout(plan,node);
        if(!zk.isConnected())throw new IllegalStateException("ZK unavailable");
        for(PartitionAssignment expected:plan){
            String path=ASSIGNMENTS+"/"+expected.getPartitionId();
            Stat stat=new Stat();
            Object value=zk.readData(path,stat);
            if(value==null)throw new IllegalStateException("missing ZK assignment: "+path);
            // The ONLY accepted migration is a signed two-voter epoch2
            // RECOVERING v1 record. Every other CAS remains fail closed.
            try{
                DemoV19FourNodeEpoch2Transition.requireAssignment(
                    zk,expected,value,stat.getVersion());
            }catch(Exception invalid){
                throw new IllegalStateException(
                    "untrusted partition recovery publication: "+path,invalid);
            }
        }
        if(!zk.isConnected())throw new IllegalStateException("lost ZK quorum");
        return count;
    }
    public static void main(String[] args) throws Exception {
        if(args.length!=1 || !("--bootstrap".equals(args[0])
                || args[0].matches("--audit=[ABCD]")))
            throw new IllegalArgumentException("isolated four-node --bootstrap or --audit=A|B|C|D only");
        List<PartitionAssignment> plan=layout();
        ZookeeperClient zk=new ZookeeperClient(DemoAssignmentBootstrap.HOSTS,null,null);
        try{
            if("--bootstrap".equals(args[0])){
                install(zk,plan);
                System.out.println("FOUR_NODE_ZK_BOOTSTRAP_PREPARING_OK partitions=256"
                        +" zkWritesInitial=256 ready=0 eachNodePrimary=64"
                        +" eachNodeStandby=64 walReplication=NOT_STARTED");
            } else {
                String id=SERVICE+args[0].charAt(args[0].length()-1);
                Counts c=audit(zk,plan,id);
                int walSlots=0;
                if("1".equals(System.getenv("DEMO_V19_FOUR_NODE_WAL_SLOTS"))){
                    walSlots=DemoV19FourNodeWalSlots.initialize(
                        plan,id,Paths.get("/srv/v19/wal"));
                }
                System.out.println("FOUR_NODE_ZK_AUDIT_PASS node="+id
                        +" primary="+c.primary+" standby="+c.replica
                        +" neither="+c.other+" assignments=256"
                        +" allState=PREPARING ready=0"
                        +" walSlots="+walSlots
                        +" walReplication=NOT_STARTED realTPS=NOT_TESTED");
            }
        }finally{zk.close();}
    }
}
