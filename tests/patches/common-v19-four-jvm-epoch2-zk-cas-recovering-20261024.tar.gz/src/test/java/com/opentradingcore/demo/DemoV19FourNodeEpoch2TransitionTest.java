package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;
import com.gateway.connector.utils.JsonUtils;
import java.util.*;
import org.junit.Test;
import static org.junit.Assert.*;

public final class DemoV19FourNodeEpoch2TransitionTest {
    private static void denies(Runnable cmd){
        try{cmd.run();fail("unverified epoch2 successor accepted");}
        catch(IllegalArgumentException expected){}
    }
    @Test public void swapsExactlyOneBuddyAndKeepsRecoveryNotReady(){
        for(int idx:new int[]{0,128}){
            PartitionAssignment previous=DemoV19FourNodeShardCatalog.layout().get(idx);
            String prior=DemoV19FourNodeShardCatalog.encode(previous);
            PartitionAssignment next=DemoV19FourNodeEpoch2Transition.recovering(previous);
            assertEquals(previous.getPartitionId(),next.getPartitionId());
            assertEquals(previous.getReplica(),next.getPrimary());
            assertEquals(previous.getPrimary(),next.getReplica());
            assertEquals(Collections.singletonList(previous.getPrimary()),
                next.replicaNodes());
            assertEquals(2,next.getEpoch());
            assertEquals(1,next.getAssignmentVersion());
            assertEquals("RECOVERING",next.getState());
            assertFalse(next.isRoutable());
            assertEquals(prior,DemoV19FourNodeShardCatalog.encode(previous));
            assertEquals(previous.getProtocolVersion(),next.getProtocolVersion());
        }
    }
    @Test public void cannotTransitionNormal254PartitionsOrRepeatEpoch(){
        PartitionAssignment normal=DemoV19FourNodeShardCatalog.layout().get(1);
        denies(()->DemoV19FourNodeEpoch2Transition.recovering(normal));
        PartitionAssignment selected=DemoV19FourNodeShardCatalog.layout().get(0);
        selected.setState("READY");
        denies(()->DemoV19FourNodeEpoch2Transition.recovering(selected));
        selected.setState("PREPARING");
        selected.setEpoch(2);
        denies(()->DemoV19FourNodeEpoch2Transition.recovering(selected));
    }
}
