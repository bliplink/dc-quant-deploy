package com.opentradingcore.demo;

import com.app.common.partition.ZkPartitionFailoverControlPlane;
import com.app.common.zk.ZookeeperClient;
import com.gateway.connector.utils.JsonUtils;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyFactory;
import java.security.spec.X509EncodedKeySpec;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import org.I0Itec.zkclient.exception.ZkBadVersionException;
import org.apache.zookeeper.data.Stat;

/**
 * TEST-ONLY explicit two-step ZK strict cutover. Deliberately not wired into
 * any automatic timer: activation requires NEW RSA dual fsync certificate,
 * durable custody, real writer/replica adapters and a separate atomic READY.
 *
 * A successful FREEZE makes the partition non-writable. If preparation cannot
 * complete, it FAILS CLOSED; recovery needs a new fenced transaction (not a
 * blind READY rollback). Do NOT enable on production or active Demo traffic.
 */
final class DemoV19Rf2StrictCutoverCoordinator {
    private static final String PATH=DemoZkFenceSource.ISOLATED_ROOT
            +"/harness/assignments/P000";
    private final ZookeeperClient zk;
    private final ZkPartitionFailoverControlPlane plane;
    private final DemoV19Rf2StrictRejoinPreflight preflight;
    private final String local;
    private int frozenZkVersion=-1;
    private long frozenAtNanos=Long.MIN_VALUE;
    private long oldEpoch=-1;
    private String peer;

    DemoV19Rf2StrictCutoverCoordinator(ZookeeperClient zk,
            ZkPartitionFailoverControlPlane plane,String local) {
        this.zk=Objects.requireNonNull(zk);
        this.plane=Objects.requireNonNull(plane);
        this.local=Objects.requireNonNull(local);
        this.preflight=new DemoV19Rf2StrictRejoinPreflight(zk,plane,local);
    }

    /** Crash restart resumption is safe ONLY for a new-epoch strict PREPARE
     * that has persisted an independently verified local signed Genesis.
     * Resumption grants no client writes and changes no ZK record.
     */
    synchronized boolean resumePreparedGenesis() throws Exception {
        if(!plane.isConnected() || !plane.hasLease() || !plane.isLive(local))
            return false;
        Object raw=zk.readData(PATH);
        if(raw==null)return false;
        @SuppressWarnings("unchecked") Map<String,Object> map=
                JsonUtils.Deserialize(String.valueOf(raw),Map.class);
        DemoV19Rf2DynamicReceiptService.Plan plan;
        try{plan=DemoV19Rf2DynamicReceiptService.requirePlan(map);}
        catch(IOException notStrict){return false;}
        if(!plan.preparing || !local.equals(plan.primary)
                || !plane.isLive(plan.replica))return false;
        KeyFactory rsa=KeyFactory.getInstance("RSA");
        List<com.app.common.replication.DurableWalCommitQuorum.Member> voters=
            new ArrayList<com.app.common.replication.DurableWalCommitQuorum.Member>();
        for(char suffix='A';suffix<='B';suffix++) {
            String id="CommonHaDemo"+suffix;
            voters.add(new com.app.common.replication.DurableWalCommitQuorum.Member(
                id,"simulated-single-mac-jvm-"+suffix,
                rsa.generatePublic(new X509EncodedKeySpec(Files.readAllBytes(
                    Paths.get("/srv/v19/identities",id+".pub.der"))))));
        }
        com.app.common.replication.DurableWalCommitQuorum.Membership membership=
            new com.app.common.replication.DurableWalCommitQuorum.Membership(
                "CommonHaDemo","P000",plan.primary,plan.epoch,plan.configVersion,voters);
        java.nio.file.Path directory=Paths.get("/srv/v19/wal/.strict-epoch-"
            +plan.epoch+"-config-"+plan.configVersion);
        if(!Files.isDirectory(directory))return false;
        try(com.app.common.replication.DurableWalCommitIndex index=
                new com.app.common.replication.DurableWalCommitIndex(directory,membership)){
            com.app.common.replication.DurableWalCommitQuorum.Certificate proof=
                index.verifiedHighestCertificate();
            if(proof==null || proof.committedSequence!=plan.genesisSeq
                    || !plan.genesisSha.equals(proof.commitPrefixSha256))
                throw new IOException("untrusted persisted Genesis after restart");
        }
        System.out.println("V19_RF2_STRICT_GENESIS_RESTART_RESUMED epoch="+plan.epoch
                +" seq="+plan.genesisSeq+" WRITE_DENIED");
        return true;
    }

    /** This CAS, not an in-JVM boolean, is the old writer's write barrier. */
    synchronized boolean freeze() throws Exception {
        if(!plane.isConnected() || !plane.hasLease() || !plane.isLive(local))
            throw new IOException("not the current ZK control lease holder");
        DemoV19Rf2StrictRejoinPreflight.Evidence proof=preflight.once();
        if(!local.equals(proof.primary) || !plane.isLive(proof.learner))
            throw new IOException("untrusted cutover physical owner");
        Stat stat=new Stat();Object raw=zk.readData(PATH,stat);
        if(raw==null)throw new IOException("missing physical Assignment for cutover");
        @SuppressWarnings("unchecked") Map<String,Object> record=
                JsonUtils.Deserialize(String.valueOf(raw),Map.class);
        Map<String,Object> frozen=DemoV19Rf2StrictCutoverPlan.freeze(
                record,proof,stat.getVersion());
        if(!plane.isConnected() || !plane.hasLease()
                || !plane.isLive(local) || !plane.isLive(proof.learner))
            throw new IOException("ZK quorum/lease lost before FREEZE");
        try {zk.writeDataReturnStat(PATH,JsonUtils.Serializer(frozen),stat.getVersion());}
        catch(ZkBadVersionException stale) {return false;}
        frozenAtNanos=System.nanoTime();
        frozenZkVersion=stat.getVersion()+1;
        oldEpoch=proof.epoch;
        peer=proof.learner;
        System.out.println("V19_RF2_STRICT_FREEZE_STAGED epoch="+(oldEpoch+1)
                +" oldEpoch="+oldEpoch+" quorumDurable=false WRITE_DENIED");
        return true;
    }

    /** Post-barrier proof: never use the pre-freeze seq as the new genesis. */
    synchronized boolean prepareGenesis() throws Exception {
        if(frozenZkVersion<0 || oldEpoch<2 || peer==null)
            throw new IOException("no locally observed successful ZK FREEZE CAS");
        long elapsed=System.nanoTime()-frozenAtNanos;
        if(elapsed<TimeUnit.SECONDS.toNanos(6))
            throw new IOException("old grant fence wait not complete");
        if(!plane.isConnected() || !plane.hasLease()
                || !plane.isLive(local) || !plane.isLive(peer))
            throw new IOException("ZK or data membership unavailable");
        Stat stat=new Stat();Object raw=zk.readData(PATH,stat);
        if(raw==null || stat.getVersion()!=frozenZkVersion)
            throw new IOException("frozen assignment advanced; cannot reuse proof");
        @SuppressWarnings("unchecked") Map<String,Object> frozen=
                JsonUtils.Deserialize(String.valueOf(raw),Map.class);
        if(frozen==null || !(frozen.get("epoch") instanceof Number)
                || ((Number)frozen.get("epoch")).longValue()!=oldEpoch+1
                || !local.equals(frozen.get("primary"))
                || !DemoV19Rf2StrictCutoverPlan.FREEZE.equals(
                       frozen.get("durabilityPolicy")))
            throw new IOException("not the current immutable FREEZE record");
        long genesisSeq;
        String genesisSha;
        long historyEpoch;
        try(DemoV19TcpClient tcp=new DemoV19TcpClient()) {
            Map<String,Object> localStatus=tcp.status(local),remoteStatus=tcp.status(peer);
            genesisSeq=requireEqualLong(localStatus,remoteStatus,"committedSeq");
            historyEpoch=requireEqualLong(localStatus,remoteStatus,"lastEpoch");
            if(genesisSeq<1 || !Boolean.TRUE.equals(localStatus.get("clean"))
                    || !Boolean.TRUE.equals(remoteStatus.get("clean"))
                    || !local.equals(localStatus.get("localNode"))
                    || !peer.equals(remoteStatus.get("localNode"))
                    || !Objects.equals(localStatus.get("stateDigest"),remoteStatus.get("stateDigest"))
                    || !Objects.equals(localStatus.get("distinctRequests"),remoteStatus.get("distinctRequests")))
                throw new IOException("physical WAL/deduped business state diverged");
            genesisSha=String.valueOf(localStatus.get("committedPrefixSha256"));
            if(!genesisSha.equals(remoteStatus.get("committedPrefixSha256")))
                throw new IOException("new genesis WAL digest differs");
            long oldSeq=requireLong(frozen,"strictOldCertifiedSeq");
            String oldSha=String.valueOf(frozen.get("strictOldCertifiedSha256"));
            Map<String,Object> old1=tcp.custodyHeadEvidence(local);
            Map<String,Object> old2=tcp.custodyHeadEvidence(peer);
            if(!Boolean.TRUE.equals(old1.get("cryptographicallyVerified"))
                    || !Boolean.TRUE.equals(old2.get("cryptographicallyVerified"))
                    || !Objects.equals(oldSeq,((Number)old1.get("certifiedSeq")).longValue())
                    || !Objects.equals(oldSeq,((Number)old2.get("certifiedSeq")).longValue())
                    || !oldSha.equals(old1.get("certifiedSha256"))
                    || !oldSha.equals(old2.get("certifiedSha256"))
                    || !oldSha.equals(tcp.verifiedPrefixThrough(local,oldSeq))
                    || !oldSha.equals(tcp.verifiedPrefixThrough(peer,oldSeq)))
                throw new IOException("old signed ACK historical prefix missing");
        }
        Map<String,Object> prepared=DemoV19Rf2StrictCutoverPlan.prepare(
                frozen,local,peer,genesisSeq,genesisSha,genesisSha,
                historyEpoch,TimeUnit.NANOSECONDS.toMillis(elapsed));
        if(!plane.isConnected() || !plane.hasLease()
                || !plane.isLive(local) || !plane.isLive(peer))
            throw new IOException("lost quorum/lease after physical proof");
        Stat finalStat=new Stat();Object last=zk.readData(PATH,finalStat);
        if(last==null || finalStat.getVersion()!=stat.getVersion()
                || !Objects.equals(String.valueOf(raw),String.valueOf(last)))
            throw new IOException("assignment changed after physical proof");
        try {zk.writeDataReturnStat(PATH,JsonUtils.Serializer(prepared),stat.getVersion());}
        catch(ZkBadVersionException changed){return false;}
        frozenZkVersion=-1;
        System.out.println("V19_RF2_STRICT_GENESIS_PREPARED epoch="+(oldEpoch+1)
                +" seq="+genesisSeq+" quorumDurable=false WRITE_DENIED");
        return true;
    }
    /** The NEW epoch's independent 2/2 RSA proof is persisted locally.
     * Client traffic stays denied in RECOVERING. Second-custodian durable
     * certificate installation and strict writer activation are still required.
     */
    synchronized long certifyGenesis() throws Exception {
        if(!plane.isConnected() || !plane.hasLease() || !plane.isLive(local))
            throw new IOException("no authorized strict commit-index owner");
        Stat stat=new Stat();Object raw=zk.readData(PATH,stat);
        if(raw==null)throw new IOException("no strict Genesis assignment");
        @SuppressWarnings("unchecked") Map<String,Object> fields=
                JsonUtils.Deserialize(String.valueOf(raw),Map.class);
        DemoV19Rf2DynamicReceiptService.Plan plan=
                DemoV19Rf2DynamicReceiptService.requirePlan(fields);
        if(!plan.preparing || !local.equals(plan.primary)
                || !plane.isLive(plan.replica)
                || !"RECOVERING".equals(fields.get("state")))
            throw new IOException("strict rejoin Genesis not in fenced PREPARE state");
        KeyFactory rsa=KeyFactory.getInstance("RSA");
        List<com.app.common.replication.DurableWalCommitQuorum.Member> voters=
                new ArrayList<com.app.common.replication.DurableWalCommitQuorum.Member>();
        for(char suffix='A';suffix<='B';suffix++) {
            String id="CommonHaDemo"+suffix;
            voters.add(new com.app.common.replication.DurableWalCommitQuorum.Member(
                    id,"simulated-single-mac-jvm-"+suffix,
                    rsa.generatePublic(new X509EncodedKeySpec(Files.readAllBytes(
                            Paths.get("/srv/v19/identities",id+".pub.der"))))));
        }
        com.app.common.replication.DurableWalCommitQuorum.Membership membership=
                new com.app.common.replication.DurableWalCommitQuorum.Membership(
                        "CommonHaDemo","P000",plan.primary,plan.epoch,
                        plan.configVersion,voters);
        try(DemoV19TcpClient tcp=new DemoV19TcpClient()) {
            String oldSha=tcp.verifiedPrefixThrough(local,plan.oldCertifiedSeq);
            if(!plan.oldCertifiedSha.equals(oldSha)
                    || !oldSha.equals(tcp.verifiedPrefixThrough(plan.replica,
                            plan.oldCertifiedSeq))
                    || !plan.genesisSha.equals(tcp.verifiedPrefixThrough(local,
                            plan.genesisSeq))
                    || !plan.genesisSha.equals(tcp.verifiedPrefixThrough(plan.replica,
                            plan.genesisSeq)))
                throw new IOException("physical WAL no longer covers strict Genesis");
            com.app.common.replication.DurableWalCommitQuorum.Receipt first=
                    tcp.signedDynamicReceipt(local,membership,plan.genesisSeq);
            com.app.common.replication.DurableWalCommitQuorum.Receipt second=
                    tcp.signedDynamicReceipt(plan.replica,membership,plan.genesisSeq);
            com.app.common.replication.DurableWalCommitQuorum.verify(membership,
                    plan.genesisSeq,plan.genesisSha,Arrays.asList(first,second));
            Stat afterStat=new Stat();Object after=zk.readData(PATH,afterStat);
            if(after==null || afterStat.getVersion()!=stat.getVersion()
                    || !String.valueOf(after).equals(String.valueOf(raw))
                    || !plane.isConnected() || !plane.hasLease()
                    || !plane.isLive(plan.replica))
                throw new IOException("strict Genesis ZK membership advanced");
            java.nio.file.Path dir=Paths.get("/srv/v19/wal/.strict-epoch-"
                    +plan.epoch+"-config-"+plan.configVersion);
            try(com.app.common.replication.DurableWalCommitIndex index=
                    new com.app.common.replication.DurableWalCommitIndex(dir,membership)) {
                if(index.committedSequence()>0) {
                    com.app.common.replication.DurableWalCommitQuorum.Certificate existing=
                            index.verifiedHighestCertificate();
                    if(existing==null || existing.committedSequence!=plan.genesisSeq
                            || !plan.genesisSha.equals(existing.commitPrefixSha256))
                        throw new IOException("conflicting preexisting strict Epoch certificate");
                } else {
                    index.certifyAndPersist(plan.genesisSeq,plan.genesisSha,
                            Arrays.asList(first,second));
                }
                System.out.println("V19_RF2_STRICT_GENESIS_FSYNCED epoch="+plan.epoch
                        +" seq="+plan.genesisSeq+" twoSignedPhysicalVoters=true"
                        +" clientStrictReady=false certificateCustodyPeer=false");
                return index.committedSequence();
            }
        }
    }

    /** Require independent physically installed certificate copies on A/B.
     * This never writes strict READY or returns any client ACK. It checks
     * physical membership and ZK version before and after dual custody.
     */
    synchronized long custodyGenesis() throws Exception {
        if(!plane.isConnected() || !plane.hasLease() || !plane.isLive(local))
            throw new IOException("no strict custody control authority");
        Stat stat=new Stat();Object raw=zk.readData(PATH,stat);
        if(raw==null)throw new IOException("missing strict custody Assignment");
        @SuppressWarnings("unchecked") Map<String,Object> fields=
                JsonUtils.Deserialize(String.valueOf(raw),Map.class);
        DemoV19Rf2DynamicReceiptService.Plan plan=
                DemoV19Rf2DynamicReceiptService.requirePlan(fields);
        if(!plan.preparing || !local.equals(plan.primary)
                || !plane.isLive(plan.replica))
            throw new IOException("not the pinned frozen strict primary/replica");
        KeyFactory rsa=KeyFactory.getInstance("RSA");
        List<com.app.common.replication.DurableWalCommitQuorum.Member> voters=
                new ArrayList<com.app.common.replication.DurableWalCommitQuorum.Member>();
        for(char suffix='A';suffix<='B';suffix++) {
            String id="CommonHaDemo"+suffix;
            voters.add(new com.app.common.replication.DurableWalCommitQuorum.Member(
                    id,"simulated-single-mac-jvm-"+suffix,
                    rsa.generatePublic(new X509EncodedKeySpec(Files.readAllBytes(
                            Paths.get("/srv/v19/identities",id+".pub.der"))))));
        }
        com.app.common.replication.DurableWalCommitQuorum.Membership membership=
                new com.app.common.replication.DurableWalCommitQuorum.Membership(
                        "CommonHaDemo","P000",plan.primary,plan.epoch,
                        plan.configVersion,voters);
        java.nio.file.Path dir=Paths.get("/srv/v19/wal/.strict-epoch-"
                +plan.epoch+"-config-"+plan.configVersion);
        com.app.common.replication.DurableWalCommitQuorum.Certificate genesis;
        try(com.app.common.replication.DurableWalCommitIndex index=
                new com.app.common.replication.DurableWalCommitIndex(dir,membership)){
            genesis=index.verifiedHighestCertificate();
            if(genesis==null || genesis.committedSequence!=plan.genesisSeq
                    || !plan.genesisSha.equals(genesis.commitPrefixSha256))
                throw new IOException("unpersisted or mismatched strict Genesis");
        }
        try(DemoV19TcpClient tcp=new DemoV19TcpClient()){
            String primaryHash=tcp.verifiedPrefixThrough(local,plan.genesisSeq);
            String replicaHash=tcp.verifiedPrefixThrough(plan.replica,plan.genesisSeq);
            if(!plan.genesisSha.equals(primaryHash)
                    || !plan.genesisSha.equals(replicaHash))
                throw new IOException("physical WAL changed before certificate custody");
            com.app.common.replication.DurableWalCustodyQuorum.Receipt one=
                    tcp.installDynamicCustody(local,membership,genesis);
            com.app.common.replication.DurableWalCustodyQuorum.Receipt two=
                    tcp.installDynamicCustody(plan.replica,membership,genesis);
            com.app.common.replication.DurableWalCustodyQuorum.CustodiedCertificate
                durable=com.app.common.replication.DurableWalCustodyQuorum.verify(
                    membership,genesis,Arrays.asList(one,two));
            Stat afterStat=new Stat();Object after=zk.readData(PATH,afterStat);
            if(after==null || afterStat.getVersion()!=stat.getVersion()
                    || !String.valueOf(after).equals(String.valueOf(raw))
                    || !plane.isConnected() || !plane.hasLease()
                    || !plane.isLive(local) || !plane.isLive(plan.replica))
                throw new IOException("strict custody config changed after two fsyncs");
            System.out.println("V19_RF2_STRICT_GENESIS_DUAL_CUSTODY_FSYNCED epoch="
                +plan.epoch+" seq="+durable.sequence
                +" custodians="+durable.physicalCustodians
                +" clientStrictReady=false certifiedClientAck=false");
            return durable.sequence;
        }
    }

    /** Independent readback of two fsynced custody HEADs, including after
     * process restart; cross-signatures and membership are verified by Common.
     * This is still only evidence, NOT strict client write authorization.
     */
    synchronized long verifyTwoPhysicalCustodyHeads() throws Exception {
        if(!plane.isConnected() || !plane.hasLease() || !plane.isLive(local))
            throw new IOException("no current ZK control authority for readback");
        Stat stat=new Stat();Object raw=zk.readData(PATH,stat);
        if(raw==null)throw new IOException("missing current strict assignment");
        @SuppressWarnings("unchecked") Map<String,Object> fields=
                JsonUtils.Deserialize(String.valueOf(raw),Map.class);
        DemoV19Rf2DynamicReceiptService.Plan plan=
                DemoV19Rf2DynamicReceiptService.requirePlan(fields);
        if(!plan.preparing || !local.equals(plan.primary)
                || !plane.isLive(plan.replica))
            throw new IOException("only frozen strict two-data-node PREPARE may verify custody");
        KeyFactory rsa=KeyFactory.getInstance("RSA");
        List<com.app.common.replication.DurableWalCommitQuorum.Member> voters=
            new ArrayList<com.app.common.replication.DurableWalCommitQuorum.Member>();
        for(char suffix='A';suffix<='B';suffix++) {
            String id="CommonHaDemo"+suffix;
            voters.add(new com.app.common.replication.DurableWalCommitQuorum.Member(
                id,"simulated-single-mac-jvm-"+suffix,
                rsa.generatePublic(new X509EncodedKeySpec(Files.readAllBytes(
                    Paths.get("/srv/v19/identities",id+".pub.der"))))));
        }
        com.app.common.replication.DurableWalCommitQuorum.Membership m=
            new com.app.common.replication.DurableWalCommitQuorum.Membership(
                "CommonHaDemo","P000",plan.primary,plan.epoch,
                plan.configVersion,voters);
        try(DemoV19TcpClient tcp=new DemoV19TcpClient()){
            com.app.common.replication.DurableWalCommitQuorum.Certificate headA=
                tcp.readDynamicCustodyHead(plan.primary,m);
            com.app.common.replication.DurableWalCommitQuorum.Certificate headB=
                tcp.readDynamicCustodyHead(plan.replica,m);
            if(headA.committedSequence!=plan.genesisSeq
                    || headB.committedSequence!=plan.genesisSeq
                    || !plan.genesisSha.equals(headA.commitPrefixSha256)
                    || !plan.genesisSha.equals(headB.commitPrefixSha256)
                    || !headA.membershipSha256.equals(headB.membershipSha256))
                throw new IOException("distinct persisted custody HEADs differ");
            Stat afterStat=new Stat();Object after=zk.readData(PATH,afterStat);
            if(after==null || afterStat.getVersion()!=stat.getVersion()
                    || !String.valueOf(after).equals(String.valueOf(raw))
                    || !plane.isConnected() || !plane.hasLease()
                    || !plane.isLive(plan.replica))
                throw new IOException("ZK mutated across physical custody readback");
            System.out.println("V19_RF2_STRICT_DUAL_CUSTODY_RESTART_VERIFIED epoch="
                +plan.epoch+" seq="+plan.genesisSeq
                +" twoIndependentHeadFiles=true clientStrictReady=false");
            return plan.genesisSeq;
        }
    }

    private static long requireLong(Map<String,Object> obj,String field)throws IOException {
        Object o=obj.get(field);if(!(o instanceof Number))throw new IOException("missing "+field);
        return ((Number)o).longValue();
    }
    private static long requireEqualLong(Map<String,Object> a,
            Map<String,Object> b,String field)throws IOException {
        long l=requireLong(a,field),r=requireLong(b,field);
        if(l!=r)throw new IOException("different physical WAL "+field);
        return l;
    }
}
