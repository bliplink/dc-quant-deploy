package com.opentradingcore.demo;

import java.io.IOException;
import java.util.*;

/**
 * Strict RF2 rejoin is TWO explicitly separate versioned ZK transactions.
 * 1. FREEZE revokes the old degraded writer in a new epoch, but grants no
 *    quorum witness and MUST NOT route new client writes.
 * 2. AFTER old leases have expired, compare both physical fsynced histories;
 *    only then PREPARE the immutable new-epoch Genesis for two RSA witnesses.
 * Neither record makes a partition READY. Without two independently verified
 * persisted witnesses plus the new strict writer adapter, NEVER publish READY.
 */
final class DemoV19Rf2StrictCutoverPlan {
    static final String FREEZE="STRICT_REJOIN_FREEZE_PENDING";
    static final String PREPARE="STRICT_REJOIN_GENESIS_PREPARE";
    static final String GENESIS="GENESIS_PENDING";
    private DemoV19Rf2StrictCutoverPlan() {}

    static Map<String,Object> freeze(Map<String,Object> current,
            DemoV19Rf2StrictRejoinPreflight.Evidence evidence,
            int expectedZkVersion) throws IOException {
        if(current==null || evidence==null
                || !"P000".equals(current.get("partitionId")))
            throw new IOException("cutover P000 evidence missing");
        long epoch=number(current,"epoch");
        long appVersion=number(current,"assignmentVersion");
        if(expectedZkVersion!=evidence.zkVersion || epoch!=evidence.epoch
                || !"READY".equals(current.get("state"))
                || !"AUTO_DEGRADED_LOCAL_DURABLE".equals(current.get("durabilityPolicy"))
                || !Boolean.FALSE.equals(current.get("quorumDurable"))
                || !evidence.primary.equals(current.get("primary"))
                || !Collections.emptyList().equals(current.get("replicas"))
                || !Collections.singletonList(evidence.learner).equals(current.get("learners"))
                || epoch<2 || epoch>=128 || evidence.sequence<evidence.strictGenesisSeq
                || evidence.strictGenesisSeq<1
                || !sha(evidence.prefixSha256) || !sha(evidence.oldCertifiedSha256))
            throw new IOException("not an unchanged certified degraded RF2 assignment");
        Map<String,Object> after=new LinkedHashMap<>(current);
        after.put("state","RECOVERING");
        after.put("epoch",epoch+1);
        after.put("assignmentVersion",appVersion+1);
        after.put("durabilityPolicy",FREEZE);
        after.put("quorumDurable",false);
        after.put("strictTransition","FREEZE_PENDING");
        after.put("strictSourceEpoch",epoch);
        after.put("strictOldCertifiedSeq",evidence.strictGenesisSeq);
        after.put("strictOldCertifiedSha256",evidence.oldCertifiedSha256);
        // Keep a non-signing Learner until a post-fence matched physical proof.
        after.remove("strictConfigurationVersion");
        after.remove("strictGenesisSeq");
        after.remove("strictGenesisSha256");
        after.put("replicas",Collections.emptyList());
        after.put("learners",Collections.singletonList(evidence.learner));
        return after;
    }

    static Map<String,Object> prepare(Map<String,Object> frozen,
            String primary,String learner,long forcedSeq,String forcedSha,
            String learnerSha,long historicalWalEpoch,
            long oldEpochGrantExpiryPassedMs) throws IOException {
        if(frozen==null || primary==null || learner==null)
            throw new IOException("frozen cutover input missing");
        long epoch=number(frozen,"epoch"),sourceEpoch=number(frozen,"strictSourceEpoch");
        long appVersion=number(frozen,"assignmentVersion");
        long oldSeq=number(frozen,"strictOldCertifiedSeq");
        String oldSha=String.valueOf(frozen.get("strictOldCertifiedSha256"));
        if(epoch!=sourceEpoch+1 || epoch<3 || epoch>128 || oldSeq<1
                || !"RECOVERING".equals(frozen.get("state"))
                || !FREEZE.equals(frozen.get("durabilityPolicy"))
                || !"FREEZE_PENDING".equals(frozen.get("strictTransition"))
                || !Boolean.FALSE.equals(frozen.get("quorumDurable"))
                || !primary.equals(frozen.get("primary"))
                || !Arrays.asList("CommonHaDemoA","CommonHaDemoB").contains(primary)
                || !Arrays.asList("CommonHaDemoA","CommonHaDemoB").contains(learner)
                || primary.equals(learner)
                || !Collections.emptyList().equals(frozen.get("replicas"))
                || !Collections.singletonList(learner).equals(frozen.get("learners"))
                || oldEpochGrantExpiryPassedMs<5000L
                || historicalWalEpoch<2 || historicalWalEpoch>sourceEpoch
                || forcedSeq<oldSeq || !sha(forcedSha) || !forcedSha.equals(learnerSha)
                || !sha(oldSha))
            throw new IOException("unsafe recovery: old writer not fenced or WAL mismatch");
        // The caller MUST additionally check old certified prefix on each
        // original WAL and recheck the ZK version in the enclosing CAS.
        Map<String,Object> next=new LinkedHashMap<>(frozen);
        next.put("assignmentVersion",appVersion+1);
        next.put("durabilityPolicy",PREPARE);
        next.put("strictTransition",GENESIS);
        next.put("replicas",Collections.singletonList(learner));
        next.put("learners",Collections.emptyList());
        next.put("strictConfigurationVersion",appVersion+1);
        next.put("strictGenesisSeq",forcedSeq);
        next.put("strictGenesisSha256",forcedSha);
        next.put("quorumDurable",false);
        next.put("state","RECOVERING");
        return next;
    }
    private static long number(Map<String,Object> m,String field)throws IOException {
        Object v=m.get(field);
        if(!(v instanceof Number))throw new IOException("missing numeric "+field);
        return ((Number)v).longValue();
    }
    private static boolean sha(String v){return v!=null && v.matches("[0-9a-f]{64}");}
}
