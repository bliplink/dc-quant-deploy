package com.opentradingcore.demo;

import java.io.IOException;
import java.util.*;
import org.junit.Test;
import static org.junit.Assert.*;

public final class DemoV19Rf2StrictCutoverPlanTest {
    private static final String HASH="0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef";
    private static final String OLD="abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789";
    private Map<String,Object> old(){
        Map<String,Object> a=new LinkedHashMap<>();
        a.put("partitionId","P000");a.put("primary","CommonHaDemoA");
        a.put("replicas",Collections.emptyList());
        a.put("learners",Collections.singletonList("CommonHaDemoB"));
        a.put("epoch",5L);a.put("assignmentVersion",9L);
        a.put("state","READY");a.put("durabilityPolicy","AUTO_DEGRADED_LOCAL_DURABLE");
        a.put("quorumDurable",false);return a;
    }
    private DemoV19Rf2StrictRejoinPreflight.Evidence evidence(){
        return new DemoV19Rf2StrictRejoinPreflight.Evidence(5,17,8,9,
                "CommonHaDemoA","CommonHaDemoB",HASH,"state",OLD);
    }
    private Map<String,Object> freeze()throws IOException {
        return DemoV19Rf2StrictCutoverPlan.freeze(old(),evidence(),9);
    }
    private Map<String,Object> prepare()throws IOException {
        return DemoV19Rf2StrictCutoverPlan.prepare(freeze(),
                "CommonHaDemoA","CommonHaDemoB",17,HASH,HASH,5,5000);
    }
    private void reject(Runnable action){
        try{action.run();fail("unsafe cutover permitted");}
        catch(RuntimeException expected){assertTrue(expected.getCause() instanceof IOException);}
    }
    private static RuntimeException invalid(IOException x){return new RuntimeException(x);}
    @Test public void twoStageNeverPublishesReadyAndAddsExplicitGenesis(){
        try {
            Map<String,Object> frozen=freeze();
            assertEquals("RECOVERING",frozen.get("state"));
            assertEquals(false,frozen.get("quorumDurable"));
            assertEquals("STRICT_REJOIN_FREEZE_PENDING",frozen.get("durabilityPolicy"));
            assertEquals(6L,frozen.get("epoch"));
            assertFalse(frozen.containsKey("strictGenesisSeq"));
            try {DemoV19Rf2DynamicReceiptService.requirePlan(frozen);
                fail("freeze alone must not authorize any durable signatures");
            }catch(IOException denied) { }
            Map<String,Object> prepared=prepare();
            assertEquals("RECOVERING",prepared.get("state"));
            assertEquals(false,prepared.get("quorumDurable"));
            assertEquals(17L,prepared.get("strictGenesisSeq"));
            assertEquals(8L,prepared.get("strictOldCertifiedSeq"));
            assertEquals(HASH,prepared.get("strictGenesisSha256"));
            assertEquals(OLD,prepared.get("strictOldCertifiedSha256"));
            assertEquals(Collections.singletonList("CommonHaDemoB"),prepared.get("replicas"));
            assertTrue(DemoV19Rf2DynamicReceiptService.requirePlan(prepared).preparing);
        }catch(IOException e){throw new AssertionError(e);}
    }
    @Test public void staleVersionAndChangedAssignedPrimaryDenied(){
        reject(()->{try {DemoV19Rf2StrictCutoverPlan.freeze(old(),evidence(),8);}catch(IOException x){throw invalid(x);}});
        Map<String,Object> c=old();c.put("primary","CommonHaDemoB");
        final Map<String,Object> wrongPrimary=c;
        reject(()->{try {DemoV19Rf2StrictCutoverPlan.freeze(wrongPrimary,evidence(),9);}catch(IOException x){throw invalid(x);}});
    }
    @Test public void noPreparationFromUnreadyOrFakeQuorum(){
        Map<String,Object> c=old();c.put("state","RECOVERING");
        final Map<String,Object> notReady=c;
        reject(()->{try {DemoV19Rf2StrictCutoverPlan.freeze(notReady,evidence(),9);}catch(IOException x){throw invalid(x);}});
        c=old();c.put("quorumDurable",true);final Map<String,Object> d=c;
        reject(()->{try {DemoV19Rf2StrictCutoverPlan.freeze(d,evidence(),9);}catch(IOException x){throw invalid(x);}});
    }
    @Test public void noPrematureReadyBeforeOldGrantExpires(){
        reject(()->{try {DemoV19Rf2StrictCutoverPlan.prepare(freeze(),
                "CommonHaDemoA","CommonHaDemoB",17,HASH,HASH,5,4999);}catch(IOException x){throw invalid(x);}});
    }
    @Test public void noGenesisWithDivergedOrMissingWal(){
        reject(()->{try {DemoV19Rf2StrictCutoverPlan.prepare(freeze(),
                "CommonHaDemoA","CommonHaDemoB",17,HASH,OLD,5,5000);}catch(IOException x){throw invalid(x);}});
        reject(()->{try {DemoV19Rf2StrictCutoverPlan.prepare(freeze(),
                "CommonHaDemoA","CommonHaDemoB",7,HASH,HASH,5,5000);}catch(IOException x){throw invalid(x);}});
    }
    @Test public void wrongReplicaOrEpochCannotAcquireNewStrictMembership(){
        reject(()->{try {DemoV19Rf2StrictCutoverPlan.prepare(freeze(),
                "CommonHaDemoA","CommonHaDemoA",17,HASH,HASH,5,5000);}catch(IOException x){throw invalid(x);}});
        reject(()->{try {DemoV19Rf2StrictCutoverPlan.prepare(freeze(),
                "CommonHaDemoA","CommonHaDemoB",17,HASH,HASH,6,5000);}catch(IOException x){throw invalid(x);}});
    }
    @Test public void activeWriterMustStayFrozenAfterPreparation(){
        try {
            Map<String,Object> prepared=prepare();
            assertEquals("RECOVERING",prepared.get("state"));
            assertEquals(false,prepared.get("quorumDurable"));
            assertEquals("GENESIS_PENDING",prepared.get("strictTransition"));
            assertTrue(DemoV19Rf2DynamicReceiptService.requirePlan(prepared).preparing);
        }catch(IOException e){throw new AssertionError(e);}
    }
}
