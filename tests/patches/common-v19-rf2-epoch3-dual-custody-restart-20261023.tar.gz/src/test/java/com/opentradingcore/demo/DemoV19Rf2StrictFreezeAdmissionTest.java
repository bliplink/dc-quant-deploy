package com.opentradingcore.demo;

import java.util.*;
import org.junit.Test;
import static org.junit.Assert.*;

public class DemoV19Rf2StrictFreezeAdmissionTest {
    private Map<String,Object> raw() {
        Map<String,Object> a=new LinkedHashMap<>();
        a.put("state","RECOVERING");a.put("replicas",Collections.emptyList());
        a.put("durabilityPolicy","AUTO_DEGRADED_LOCAL_DURABLE");return a;
    }
    @Test public void oldAutomaticFailoverStillPermitsDegradedReady() {
        assertTrue(DemoV19Rf2AutoStage.mayPublishDegradedFromRecovery(raw()));
    }
    @Test public void strictFreezeMayNotFallBackByAccident() {
        Map<String,Object> a=raw();a.put("durabilityPolicy","STRICT_REJOIN_FREEZE_PENDING");
        a.put("strictTransition","FREEZE_PENDING");
        assertFalse(DemoV19Rf2AutoStage.mayPublishDegradedFromRecovery(a));
    }
    @Test public void pendingGenesisMayNotBeReopenedByOldDegradeThread() {
        Map<String,Object> a=raw();a.put("durabilityPolicy","STRICT_REJOIN_GENESIS_PREPARE");
        a.put("strictTransition","GENESIS_PENDING");
        a.put("replicas",Collections.singletonList("CommonHaDemoB"));
        assertFalse(DemoV19Rf2AutoStage.mayPublishDegradedFromRecovery(a));
    }
    @Test public void unrecognizedPolicyAndReadyAreAlwaysDenied() {
        Map<String,Object> a=raw();a.put("durabilityPolicy","UNKNOWN");
        assertFalse(DemoV19Rf2AutoStage.mayPublishDegradedFromRecovery(a));
        a=raw();a.put("state","READY");
        assertFalse(DemoV19Rf2AutoStage.mayPublishDegradedFromRecovery(a));
    }
}
