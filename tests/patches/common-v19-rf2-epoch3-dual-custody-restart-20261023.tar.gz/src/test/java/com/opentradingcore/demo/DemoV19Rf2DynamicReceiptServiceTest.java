package com.opentradingcore.demo;

import org.junit.Test;
import java.io.IOException;
import java.util.*;
import static org.junit.Assert.*;

public class DemoV19Rf2DynamicReceiptServiceTest {
    private static final String SHA="0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef";
    private static Map<String,Object> preparing() {
        Map<String,Object> a=new LinkedHashMap<>();
        a.put("partitionId","P000");
        a.put("epoch",6);a.put("strictConfigurationVersion",10);
        a.put("strictGenesisSeq",16);
        a.put("strictGenesisSha256",SHA);
        a.put("strictOldCertifiedSeq",8);
        a.put("strictOldCertifiedSha256",SHA);
        a.put("primary","CommonHaDemoA");
        a.put("replicas",Collections.singletonList("CommonHaDemoB"));
        a.put("learners",Collections.emptyList());
        a.put("state","RECOVERING");
        a.put("durabilityPolicy","STRICT_REJOIN_GENESIS_PREPARE");
        a.put("strictTransition","GENESIS_PENDING");
        a.put("quorumDurable",false);
        return a;
    }
    private static void denied(Map<String,Object> map) {
        try {
            DemoV19Rf2DynamicReceiptService.requirePlan(map);
            fail("unverified RF2 plan admitted");
        } catch(IOException expected) { }
    }
    @Test public void noUnfrozenSingleNodeLocalAckMaySignStrictReceipt() {
        Map<String,Object> p=preparing();
        p.put("state","READY");p.put("durabilityPolicy","AUTO_DEGRADED_LOCAL_DURABLE");
        denied(p);
    }
    @Test public void onlyExactTwoMemberGenesisPreparationIsAccepted()throws Exception {
        DemoV19Rf2DynamicReceiptService.Plan p=
                DemoV19Rf2DynamicReceiptService.requirePlan(preparing());
        assertEquals(6,p.epoch);assertEquals(10,p.configVersion);
        assertEquals(16,p.genesisSeq);assertEquals(SHA,p.genesisSha);
        assertEquals(8,p.oldCertifiedSeq);assertEquals(SHA,p.oldCertifiedSha);
        assertEquals("CommonHaDemoA",p.primary);
        assertEquals("CommonHaDemoB",p.replica);assertTrue(p.preparing);
    }
    @Test public void afterVerifiedCutoverActiveMembershipCouldSign()throws Exception {
        Map<String,Object> p=preparing();p.put("state","READY");
        p.put("durabilityPolicy","QUORUM_DURABLE");
        p.put("quorumDurable",true);p.put("strictTransition","GENESIS_CERTIFIED");
        assertFalse(DemoV19Rf2DynamicReceiptService.requirePlan(p).preparing);
    }
    @Test public void rejectMemberAliasAndExtraPeers() {
        Map<String,Object> p=preparing();p.put("replicas",Collections.emptyList());denied(p);
        p=preparing();p.put("replicas",Arrays.asList("CommonHaDemoB","CommonHaDemoC"));denied(p);
        p=preparing();p.put("learners",Collections.singletonList("CommonHaDemoB"));denied(p);
        p=preparing();p.put("primary","CommonHaDemoC");denied(p);
    }
    @Test public void noFutureOrAmbiguousEpochOrGenesis() {
        Map<String,Object> p=preparing();p.put("epoch",0);denied(p);
        p=preparing();p.put("strictConfigurationVersion",0);denied(p);
        p=preparing();p.put("strictGenesisSeq",0);denied(p);
        p=preparing();p.put("strictGenesisSha256","bad");denied(p);
        p=preparing();p.remove("strictGenesisSha256");denied(p);
        p=preparing();p.put("strictOldCertifiedSeq",17);denied(p);
        p=preparing();p.put("strictOldCertifiedSha256","untrusted");denied(p);
        p=preparing();p.remove("strictOldCertifiedSha256");denied(p);
    }
    @Test public void noPrematureQuorumDurableDuringGenesis() {
        Map<String,Object> p=preparing();p.put("quorumDurable",true);denied(p);
        p=preparing();p.put("state","READY");denied(p);
        p=preparing();p.put("strictTransition","GENESIS_CERTIFIED");denied(p);
        p=preparing();p.put("durabilityPolicy","QUORUM_DURABLE");denied(p);
    }
    @Test public void rejectsOtherServiceOrIncompleteStrictActiveContract() {
        Map<String,Object> p=preparing();p.put("partitionId","P001");denied(p);
        p=preparing();p.put("state","READY");
        p.put("durabilityPolicy","QUORUM_DURABLE");
        p.put("strictTransition","GENESIS_CERTIFIED");denied(p);
    }
}
