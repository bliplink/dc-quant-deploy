package com.app.common.replication;

import java.io.IOException;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicLong;

import io.netty.bootstrap.Bootstrap;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.codec.LengthFieldBasedFrameDecoder;
import io.netty.handler.codec.LengthFieldPrepender;

/** Exact-node, long-lived Netty TCP replication transport. */
public final class DirectNettyReplicationTransport implements ReplicationTransport {
    private final EventLoopGroup group;
    private final Bootstrap bootstrap;
    private final int requestTimeoutMillis;
    private final int maxFrameBytes;
    private final AtomicLong requestIds = new AtomicLong(1L);
    private final Map<Long, CompletableFuture<ReplicationAck>> pendingAcks =
            new ConcurrentHashMap<Long, CompletableFuture<ReplicationAck>>();
    private final Map<Long, CompletableFuture<ReplicationControlResponse>> pendingControls =
            new ConcurrentHashMap<Long, CompletableFuture<ReplicationControlResponse>>();
    /** Bounded stripes per physical target; no one-TCP-per-tenant explosion. */
    private static final int PARTITION_REPLICATION_LANES = 8;
    private final Map<String, Channel> channels = new ConcurrentHashMap<String, Channel>();
    private volatile boolean closed;

    public DirectNettyReplicationTransport() {
        this(3000, DirectNettyReplicationServer.DEFAULT_MAX_FRAME_BYTES);
    }

    public DirectNettyReplicationTransport(int requestTimeoutMillis, int maxFrameBytes) {
        if (requestTimeoutMillis <= 0) {
            throw new IllegalArgumentException("requestTimeoutMillis must be positive");
        }
        this.requestTimeoutMillis = requestTimeoutMillis;
        this.maxFrameBytes = maxFrameBytes;
        this.group = new NioEventLoopGroup();
        this.bootstrap = new Bootstrap();
        this.bootstrap.group(group)
                .channel(NioSocketChannel.class)
                .option(ChannelOption.TCP_NODELAY, true)
                .option(ChannelOption.SO_KEEPALIVE, true)
                .handler(new ChannelInitializer<SocketChannel>() {
                    @Override
                    protected void initChannel(SocketChannel channel) {
                        channel.pipeline().addLast(new LengthFieldBasedFrameDecoder(maxFrameBytes, 0, 4, 0, 4));
                        channel.pipeline().addLast(new LengthFieldPrepender(4));
                        channel.pipeline().addLast(new ClientHandler(pendingAcks, pendingControls));
                    }
                });
    }

    @Override
    public CompletableFuture<ReplicationAck> replicate(ReplicationEndpoint endpoint, ReplicationBatch batch) {
        if (closed) {
            CompletableFuture<ReplicationAck> failed = new CompletableFuture<ReplicationAck>();
            failed.completeExceptionally(new IOException("replication transport is closed"));
            return failed;
        }
        final CompletableFuture<ReplicationAck> future = new CompletableFuture<ReplicationAck>();
        final long requestId = requestIds.getAndIncrement();
        pendingAcks.put(requestId, future);

        final Channel channel;
        try {
            channel = channelFor(endpoint, "replica-" +
                    Math.floorMod(batch.getPartitionId().hashCode(),
                            PARTITION_REPLICATION_LANES));
        } catch (Throwable error) {
            pendingAcks.remove(requestId);
            future.completeExceptionally(error);
            return future;
        }

        byte[] encoded = ReplicationCodec.encodeBatch(batch);
        ByteBuf frame = Unpooled.buffer(8 + encoded.length);
        frame.writeLong(requestId);
        frame.writeBytes(encoded);
        channel.writeAndFlush(frame).addListener(new ChannelFutureListener() {
            @Override
            public void operationComplete(ChannelFuture writeFuture) {
                if (!writeFuture.isSuccess()) {
                    CompletableFuture<ReplicationAck> removed = pendingAcks.remove(requestId);
                    if (removed != null) {
                        removed.completeExceptionally(writeFuture.cause());
                    }
                }
            }
        });

        channel.eventLoop().schedule(new Runnable() {
            @Override
            public void run() {
                CompletableFuture<ReplicationAck> removed = pendingAcks.remove(requestId);
                if (removed != null && !removed.isDone()) {
                    removed.completeExceptionally(new TimeoutException("replication ack timeout requestId=" + requestId));
                }
            }
        }, requestTimeoutMillis, TimeUnit.MILLISECONDS);

        return future;
    }

    @Override
    public CompletableFuture<ReplicationControlResponse> control(ReplicationEndpoint endpoint,
            ReplicationControlRequest request) {
        if (closed) {
            CompletableFuture<ReplicationControlResponse> failed =
                    new CompletableFuture<ReplicationControlResponse>();
            failed.completeExceptionally(new IOException("replication transport is closed"));
            return failed;
        }
        if (request == null) throw new IllegalArgumentException("control request is required");

        final CompletableFuture<ReplicationControlResponse> future =
                new CompletableFuture<ReplicationControlResponse>();
        final long requestId = requestIds.getAndIncrement();
        pendingControls.put(requestId, future);

        final Channel channel;
        try {
            // Recovery HEAD/Manifest/DATA never queue behind durability ACKs.
            // Bounded four lanes are enabled ONLY for the isolated RF2 pilot.
            // P000 WAL/ACK mutations remain serialized by the primary writer.
            String lane="recovery-control";
            if("1".equals(System.getenv("DEMO_V19_RF2_CONTROL_LANES"))){
                String op=request.getOperation();
                if("V19_APPEND".equals(op) || "V19_APPEND_GROUP".equals(op))
                    lane="rf2-bounded-write-"+Math.floorMod(requestId,4L);
                else if("V19_STATUS".equals(op))
                    lane="rf2-status-control";
            }
            channel = channelFor(endpoint,lane);
        } catch (Throwable error) {
            pendingControls.remove(requestId);
            future.completeExceptionally(error);
            return future;
        }

        byte[] encoded = ReplicationCodec.encodeControlRequest(request);
        ByteBuf frame = Unpooled.buffer(8 + encoded.length);
        frame.writeLong(requestId);
        frame.writeBytes(encoded);
        channel.writeAndFlush(frame).addListener(new ChannelFutureListener() {
            @Override
            public void operationComplete(ChannelFuture writeFuture) {
                if (!writeFuture.isSuccess()) {
                    CompletableFuture<ReplicationControlResponse> removed = pendingControls.remove(requestId);
                    if (removed != null) removed.completeExceptionally(writeFuture.cause());
                }
            }
        });

        channel.eventLoop().schedule(new Runnable() {
            @Override
            public void run() {
                CompletableFuture<ReplicationControlResponse> removed = pendingControls.remove(requestId);
                if (removed != null && !removed.isDone()) {
                    removed.completeExceptionally(
                            new TimeoutException("replication control timeout requestId=" + requestId));
                }
            }
        }, requestTimeoutMillis, TimeUnit.MILLISECONDS);
        return future;
    }

    private Channel channelFor(ReplicationEndpoint endpoint, String lane) {
        // Stripe affinity retains ordered writes within one logical partition
        // even when 256 logical partitions share the physical replica.
        String key = endpoint.key() + "#" + lane;
        Channel existing = channels.get(key);
        if (existing != null && existing.isActive()) {
            return existing;
        }
        synchronized (channels) {
            existing = channels.get(key);
            if (existing != null && existing.isActive()) {
                return existing;
            }
            if (existing != null) {
                existing.close();
                channels.remove(key);
            }
            Channel connected = bootstrap.connect(endpoint.getHost(), endpoint.getPort()).syncUninterruptibly().channel();
            channels.put(key, connected);
            return connected;
        }
    }

    @Override
    public synchronized void close() {
        if (closed) {
            return;
        }
        closed = true;
        for (Channel channel : channels.values()) {
            try {
                channel.close().syncUninterruptibly();
            } catch (Throwable ignored) {
            }
        }
        channels.clear();
        IOException error = new IOException("replication transport closed");
        for (CompletableFuture<ReplicationAck> future : pendingAcks.values()) {
            future.completeExceptionally(error);
        }
        pendingAcks.clear();
        for (CompletableFuture<ReplicationControlResponse> future : pendingControls.values()) {
            future.completeExceptionally(error);
        }
        pendingControls.clear();
        group.shutdownGracefully().syncUninterruptibly();
    }

    private static final class ClientHandler extends SimpleChannelInboundHandler<ByteBuf> {
        private final Map<Long, CompletableFuture<ReplicationAck>> pendingAcks;
        private final Map<Long, CompletableFuture<ReplicationControlResponse>> pendingControls;

        ClientHandler(Map<Long, CompletableFuture<ReplicationAck>> pendingAcks,
                Map<Long, CompletableFuture<ReplicationControlResponse>> pendingControls) {
            this.pendingAcks = pendingAcks;
            this.pendingControls = pendingControls;
        }

        @Override
        protected void channelRead0(ChannelHandlerContext context, ByteBuf frame) {
            if (frame.readableBytes() < 8) return;
            long requestId = frame.readLong();
            byte[] payload = new byte[frame.readableBytes()];
            frame.readBytes(payload);
            try {
                byte type = ReplicationCodec.frameType(payload);
                if (type == ReplicationCodec.TYPE_CONTROL_RESPONSE) {
                    CompletableFuture<ReplicationControlResponse> future = pendingControls.remove(requestId);
                    if (future != null) future.complete(ReplicationCodec.decodeControlResponse(payload));
                    return;
                }
                if (type == ReplicationCodec.TYPE_ACK) {
                    CompletableFuture<ReplicationAck> future = pendingAcks.remove(requestId);
                    if (future != null) future.complete(ReplicationCodec.decodeAck(payload));
                    return;
                }
                failPending(requestId, new IllegalArgumentException("unexpected replication response type: " + type));
            } catch (Throwable error) {
                failPending(requestId, error);
            }
        }

        private void failPending(long requestId, Throwable error) {
            CompletableFuture<ReplicationAck> ack = pendingAcks.remove(requestId);
            if (ack != null) ack.completeExceptionally(error);
            CompletableFuture<ReplicationControlResponse> control = pendingControls.remove(requestId);
            if (control != null) control.completeExceptionally(error);
        }
    }
}
