package com.opentradingcore.demo;

import com.gateway.connector.utils.JsonUtils;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/**
 * Real Common Netty TCP multi-client stress driver. One simulated client
 * submits one signed-quorum WAL batch (8 writes) to the same P000 shard.
 * DO NOT misrepresent as registered trading tenants or 200 partitions.
 */
public final class DemoV19ConcurrentLoadDriver {
    private static final int LEGACY_GROUP=8;
    static class Result {
        long durationUs;
        String error;
        boolean success;
        int requests;
    }
    public static void main(String[] argv)throws Exception {
        final boolean dynamic="--isolated-rf2-strict".equals(argv[0]);
        final int perGroup=dynamic?32:LEGACY_GROUP;
        if(argv.length!=5 || !("--isolated".equals(argv[0]) || dynamic)
                || !argv[1].matches("[ABC]"))
            throw new IllegalArgumentException(
                "--isolated|--isolated-rf2-strict A|B|C virtualClients maxInFlight batchesPerVirtualClient");
        final int virtualClients=Integer.parseInt(argv[2]);
        final int maxInFlight=Integer.parseInt(argv[3]);
        final int perClient=Integer.parseInt(argv[4]);
        if(virtualClients<1 || virtualClients>200 || maxInFlight<1
                || maxInFlight>32 || perClient<1 || perClient>5
                || virtualClients*perClient>1000)
            throw new IllegalArgumentException("bounded 1..200 clients, concurrency<=32");
        String run="stress-"+Long.toHexString(System.nanoTime());
        ExecutorService pool=Executors.newFixedThreadPool(maxInFlight);
        CompletionService<Result> completion=new ExecutorCompletionService<Result>(pool);
        final int totalGroups=virtualClients*perClient;
        long begin=System.nanoTime();
        try(DemoV19TcpClient tcp=new DemoV19TcpClient(dynamic?12000:3000)) {
            for(int clientIndex=0;clientIndex<virtualClients;clientIndex++) {
                final int client=clientIndex;
                for(int groupIndex=0;groupIndex<perClient;groupIndex++) {
                    final int group=groupIndex;
                    completion.submit(()-> {
                        Result result=new Result();
                        List<Map<String,Object>> commands=new ArrayList<Map<String,Object>>();
                        for(int i=0;i<perGroup;i++){
                            Map<String,Object> command=new LinkedHashMap<String,Object>();
                            command.put("partitionId","P000");
                            command.put("partitionKey","v19-p000-key-123");
                            command.put("requestId",run+"-vc"+client+"-g"+group+"-r"+i);
                            command.put("delta",(long)i+1L);
                            commands.add(command);
                        }
                        long started=System.nanoTime();
                        try {
                            Map<String,Object> ack=tcp.appendGroup("CommonHaDemo"+argv[1],commands);
                            if(!(dynamic?"QUORUM_DURABLE":
                                    "QUORUM_DURABLE_SINGLE_HOST_TEST").equals(
                                    ack.get("durabilityMode"))
                                    || (dynamic && !Boolean.TRUE.equals(ack.get("quorumDurable")))
                                    || ((Number)ack.get("count")).intValue()!=perGroup)
                                throw new IllegalStateException("unverified durable group ACK");
                            Object records=ack.get("requests");
                            if(!(records instanceof List)
                                    || ((List<?>)records).size()!=perGroup)
                                throw new IllegalStateException("missing response records");
                            for(Object item:(List<?>)records) {
                                if(!(item instanceof Map)
                                        || !Integer.valueOf(1).equals(
                                           ((Map<?,?>)item).get("appliedCount")))
                                    throw new IllegalStateException("duplicate/lost application");
                            }
                            result.success=true;
                            result.requests=perGroup;
                        }catch(Exception ex) {
                            result.error=ex.getClass().getSimpleName()+": "+
                                    String.valueOf(ex.getMessage());
                        }finally {
                            result.durationUs=TimeUnit.NANOSECONDS.toMicros(
                                    System.nanoTime()-started);
                        }
                        return result;
                    });
                }
            }
            List<Long> successful=new ArrayList<Long>();
            List<Long> all=new ArrayList<Long>();
            List<String> examples=new ArrayList<String>();
            int good=0,bad=0;
            int peak=0;
            for(int i=0;i<totalGroups;i++) {
                Result response=completion.take().get();
                all.add(response.durationUs);
                if(response.success){good++;successful.add(response.durationUs);}
                else {
                    bad++;
                    if(examples.size()<7)examples.add(response.error);
                }
            }
            double elapsed=(System.nanoTime()-begin)*1e-9;
            Map<String,Object> out=new LinkedHashMap<String,Object>();
            out.put("case",dynamic
                ?"isolated_v19_RF2_epoch3_batched_strict_2of2_quorum"
                :"isolated_v19_single_partition_multi_client_strict_quorum");
            out.put("dataReplicaCount",
                    "1".equals(System.getenv("DEMO_V19_RF2_SHARD_PILOT"))?2:3);
            out.put("physicalFaultDomains","SIMULATED_SINGLE_MAC");
            out.put("virtualClients",virtualClients);
            out.put("maxInFlight",maxInFlight);
            out.put("groupsPerClient",perClient);
            out.put("nettyDeadlineMs",dynamic?12000:3000);
            out.put("walRecordsPerGroup",perGroup);
            out.put("groups",totalGroups);
            out.put("successGroups",good);
            out.put("failedGroups",bad);
            out.put("acknowledgedRequests",good*perGroup);
            out.put("attemptedRequests",totalGroups*perGroup);
            out.put("ackRequestTPS",good*perGroup/elapsed);
            out.put("attemptRequestTPS",totalGroups*perGroup/elapsed);
            out.put("p50SuccessfulMs",percentile(successful,50));
            out.put("p95SuccessfulMs",percentile(successful,95));
            out.put("p99SuccessfulMs",percentile(successful,99));
            out.put("p99AllMs",percentile(all,99));
            out.put("elapsedSec",elapsed);
            out.put("failureExamples",examples);
            System.out.println("V19_CONCURRENT_STRESS "+JsonUtils.Serializer(out));
            if(dynamic && bad>0)
                throw new IllegalStateException("RF2 strict client ACK deadline missed in "+
                        bad+"/"+totalGroups+" groups; measurements above are FAIL");
        }finally {
            pool.shutdownNow();
        }
    }
    private static Object percentile(List<Long> source,int pc) {
        if(source.isEmpty())return null;
        Collections.sort(source);
        return source.get(Math.max(0,
                Math.min(source.size()-1,(int)Math.ceil(source.size()*pc/100.0)-1)))
                /1000.0;
    }
}
