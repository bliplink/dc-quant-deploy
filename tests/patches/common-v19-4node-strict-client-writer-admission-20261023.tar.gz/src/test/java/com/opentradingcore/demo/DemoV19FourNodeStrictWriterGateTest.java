package com.opentradingcore.demo;

import com.app.common.replication.ReplicationControlRequest;
import com.app.common.partition.PartitionEpochReadFence;
import java.io.IOException;
import org.junit.Test;
import static org.junit.Assert.*;

public final class DemoV19FourNodeStrictWriterGateTest {
    private static final String S=DemoV19FourNodeShardCatalog.SERVICE;
    private static final byte[] N=new byte[32];
    private interface Unsafe{void run()throws Exception;}
    private static void denied(Unsafe op)throws Exception{
        try{op.run();fail("malformed strict client request accepted");}
        catch(IOException expected){}
    }
    @Test public void onlyBoundedStrictClientRequestEnvelopeIsAccepted()throws Exception{
        for(String partition:new String[]{"P000","P128","P255"}){
            DemoV19FourNodeStrictWriterGate.validateRequest("CommonHaDemoA",
                new ReplicationControlRequest(S,
                    DemoV19FourNodeStrictWriterGate.OP,partition,N));
        }
        for(String bad:new String[]{"P256","P999","P-01","P00","P0000","","Pxyz"}){
            denied(()->DemoV19FourNodeStrictWriterGate.validateRequest(
                "CommonHaDemoA",new ReplicationControlRequest(S,
                    DemoV19FourNodeStrictWriterGate.OP,bad,N)));
        }
        denied(()->DemoV19FourNodeStrictWriterGate.validateRequest(
            "CommonHaDemoX",new ReplicationControlRequest(S,
                DemoV19FourNodeStrictWriterGate.OP,"P000",N)));
        denied(()->DemoV19FourNodeStrictWriterGate.validateRequest(
            "CommonHaDemoA",new ReplicationControlRequest("OtherService",
                DemoV19FourNodeStrictWriterGate.OP,"P000",N)));
        denied(()->DemoV19FourNodeStrictWriterGate.validateRequest(
            "CommonHaDemoA",new ReplicationControlRequest(S,
                "INTERNAL_SEQ1_FSYNCD_RECEIPT_V1","P000",N)));
        denied(()->DemoV19FourNodeStrictWriterGate.validateRequest(
            "CommonHaDemoA",new ReplicationControlRequest(S,
                DemoV19FourNodeStrictWriterGate.OP,"P000",new byte[8])));
        assertNotEquals("strict client opcode must not overlap internal pilot",
            DemoV19FourNodeStrictWriterGate.OP,DemoV19FourNodeSeq1NettyPilot.FSYNC);
    }
    @Test public void currentCatalogMustNeverPresentItselfAsReadyWriter(){
        for(int index:new int[]{0,128,255}){
            com.app.common.partition.PartitionAssignment a=
                DemoV19FourNodeShardCatalog.layout().get(index);
            assertEquals("PREPARING",a.getState());
            assertFalse(a.isRoutable());
        }
    }
}
