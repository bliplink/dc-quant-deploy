package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;
import com.app.common.partition.PartitionEpochReadFence;
import com.app.common.partition.PartitionFailoverController;
import com.app.common.replication.*;
import com.app.common.zk.ZookeeperClient;
import java.io.IOException;
import java.security.SecureRandom;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * Strict client-writer admission boundary for the isolated four-node demo.
 *
 * This is NOT the earlier INTERNAL_SEQ1_* non-trading pilot. The only public-
 * shaped write opcode is subject to Common's READY/epoch/assignment-version
 * gate and local recovery gate, with an independent controller lease requirement.
 * No actual writer is installed: even if a READY ticket existed this handler
 * explicitly denies rather than creating an order or an ACK. This negative
 * baseline protects all 256 still-PREPARING partitions.
 */
final class DemoV19FourNodeStrictWriterGate {
    static final String OP="STRICT_CLIENT_WRITE_ADMISSION_V1";
    static final String CODE="STRICT_CLIENT_WRITE_NOT_READY";
    private final String node;
    private final ZookeeperClient zk;
    private final PartitionFailoverController.AssignmentStore assignments;
    private final PartitionFailoverController.Guard controller;
    private final PartitionEpochReadFence fence;

    DemoV19FourNodeStrictWriterGate(String node,ZookeeperClient zk,
            PartitionFailoverController.AssignmentStore assignments,
            PartitionFailoverController.Guard controller) {
        if(node==null || !node.matches("CommonHaDemo[ABCD]"))
            throw new IllegalArgumentException("invalid strict admission node");
        this.node=node;
        this.zk=Objects.requireNonNull(zk,"zk");
        this.assignments=Objects.requireNonNull(assignments,"assignments");
        this.controller=Objects.requireNonNull(controller,"controller");
        this.fence=new PartitionEpochReadFence(zk::isConnected,assignments);
    }

    static void validateRequest(String node,ReplicationControlRequest req)
            throws IOException{
        if(node==null || !node.matches("CommonHaDemo[ABCD]")
                || req==null || !OP.equals(req.getOperation())
                || !DemoV19FourNodeShardCatalog.SERVICE.equals(req.getServiceName())
                || req.getPartitionId()==null
                || !req.getPartitionId().matches("P[0-9]{3}")
                || Integer.parseInt(req.getPartitionId().substring(1))>=256
                || req.getPayload()==null || req.getPayload().length!=32)
            throw new IOException("invalid strict client write-admission scope");
    }

    ReplicationControlResponse handle(ReplicationControlRequest req){
        try{
            validateRequest(node,req);
            // The four-node pilot owns only 256 source assignments.
            String part=req.getPartitionId();
            if(!controller.isConnected() || !zk.isConnected())
                throw new IOException("ZooKeeper control quorum not connected");
            PartitionFailoverController.VersionedAssignment snapshot=
                assignments.read(part);
            if(snapshot==null || snapshot.getAssignment()==null)
                throw new IOException("missing physical partition assignment");
            PartitionAssignment a=snapshot.getAssignment();
            if(!DemoV19FourNodeLiveRuntime.owners(a).contains(node))
                throw new IOException("node not a current partition data voter");
            // All 256 source partitions currently PREPARING. This method
            // rejects them before any WAL writer, certificate or user ACK.
            PartitionEpochReadFence.Ticket source=fence.readCurrent(part,node);
            fence.requireCurrent(source);
            if(!controller.hasLease())
                throw new IOException("controller owns no live physical lease");
            // There is no strict 2/2 client writer wired here. Never return
            // success simply because a ticket/lease passed a read check.
            throw new IOException("no strict client writer or atomic fence installed");
        }catch(Exception rejected){
            return ReplicationControlResponse.error(CODE,
                rejected.getClass().getSimpleName()+": "+rejected.getMessage());
        }
    }

    static void proveNoWrite(DirectNettyReplicationTransport client)
            throws Exception{
        List<PartitionAssignment> plan=DemoV19FourNodeShardCatalog.layout();
        SecureRandom random=new SecureRandom();
        for(char initial:new char[]{'A','C'}){
            String part=DemoV19FourNodeGenesisPreflight.firstShard(plan,initial);
            PartitionAssignment a=plan.get(Integer.parseInt(part.substring(1)));
            for(String voter:DemoV19FourNodeLiveRuntime.owners(a)){
                ReplicationControlResponse statusBefore=client.control(
                    DemoV19FourNodeLiveRuntime.exactEndpoint(voter),
                    new ReplicationControlRequest(DemoV19FourNodeShardCatalog.SERVICE,
                        "CATALOG_STATUS_V1",part,new byte[0]))
                    .get(8,TimeUnit.SECONDS);
                if(!statusBefore.isSuccess())
                    throw new IOException("unable to inspect source locked WAL");
                Map<String,Object> before=DemoNettyBridge.map(statusBefore.getPayload());
                byte[] nonce=new byte[32];random.nextBytes(nonce);
                ReplicationControlResponse refused=client.control(
                    DemoV19FourNodeLiveRuntime.exactEndpoint(voter),
                    new ReplicationControlRequest(DemoV19FourNodeShardCatalog.SERVICE,
                        OP,part,nonce)).get(8,TimeUnit.SECONDS);
                if(refused.isSuccess() || !CODE.equals(refused.getCode()))
                    throw new IOException("CRITICAL: PREPARING served strict client write");
                ReplicationControlResponse statusAfter=client.control(
                    DemoV19FourNodeLiveRuntime.exactEndpoint(voter),
                    new ReplicationControlRequest(DemoV19FourNodeShardCatalog.SERVICE,
                        "CATALOG_STATUS_V1",part,new byte[0]))
                    .get(8,TimeUnit.SECONDS);
                if(!statusAfter.isSuccess())throw new IOException("status lost after denial");
                Map<String,Object> after=DemoNettyBridge.map(statusAfter.getPayload());
                for(String key:new String[]{"committedSeq","committedPrefixSha256",
                        "ready","quorumDurable","state"}){
                    if(!Objects.equals(before.get(key),after.get(key)))
                        throw new IOException("strict denied write changed WAL/role: "+key);
                }
                if(!Boolean.FALSE.equals(after.get("ready")) ||
                        !Boolean.FALSE.equals(after.get("quorumDurable")))
                    throw new IOException("strict write handler published false READY");
                System.out.println("FOUR_NODE_STRICT_CLIENT_WRITE_DENIED partition="
                    +part+" node="+voter
                    +" unchangedSeq="+after.get("committedSeq")
                    +" unchangedWalSha="+after.get("committedPrefixSha256")
                    +" realOrderAck=false zkReady=false");
            }
        }
    }
}
