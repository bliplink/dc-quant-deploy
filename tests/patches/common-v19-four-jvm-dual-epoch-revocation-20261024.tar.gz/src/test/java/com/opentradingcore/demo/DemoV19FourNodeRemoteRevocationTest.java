package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;
import java.io.IOException;
import java.nio.file.*;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import static org.junit.Assert.*;

public class DemoV19FourNodeRemoteRevocationTest {
    @Rule public TemporaryFolder temp=new TemporaryFolder();
    private static final PartitionAssignment A=DemoV19FourNodeShardCatalog.layout().get(0);
    private static final String DIGEST="0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef";
    private static final String WAL="abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789";

    interface Attempt {void call()throws Exception;}
    static void denied(Attempt action)throws Exception {
        try{action.call();fail("torn or forked revocation accepted");}
        catch(IOException expected){}
    }
    private static String image(){
        return "PREPARING_SOURCE_EPOCH1_REVOKED_NO_READY|P000|"+
            A.getPrimary()+"|"+A.getReplica()+"|epoch=1|seq=1|member="+
            DIGEST+"|wal="+WAL;
    }
    @Test public void twoIndependentLocalVolumesPersistSameImmutableSourceRevocation()
            throws Exception {
        Path first=temp.newFolder("nodeA").toPath();
        Path second=temp.newFolder("nodeB").toPath();
        String a=DemoV19FourNodeRemoteRevocation.installLocal(first,A,image());
        String b=DemoV19FourNodeRemoteRevocation.installLocal(second,A,image());
        assertEquals(64,a.length());assertEquals(a,b);
        assertArrayEquals(Files.readAllBytes(first.resolve(
            ".pilot-old-epoch-revoked-P000/head.bin")),
            Files.readAllBytes(second.resolve(
            ".pilot-old-epoch-revoked-P000/head.bin")));
        assertEquals(a,DemoV19FourNodeRemoteRevocation.installLocal(first,A,image()));
    }
    @Test public void neverReplaceOldHeadWithNewHashOrCorruptContent()throws Exception{
        Path root=temp.newFolder("one").toPath();
        DemoV19FourNodeRemoteRevocation.installLocal(root,A,image());
        byte[] original=Files.readAllBytes(
            root.resolve(".pilot-old-epoch-revoked-P000/head.bin"));
        denied(()->DemoV19FourNodeRemoteRevocation.installLocal(root,A,
            image().replace(WAL,DIGEST)));
        assertArrayEquals(original,Files.readAllBytes(
            root.resolve(".pilot-old-epoch-revoked-P000/head.bin")));
        Files.write(root.resolve(".pilot-old-epoch-revoked-P000/head.bin"),new byte[]{2});
        denied(()->DemoV19FourNodeRemoteRevocation.installLocal(root,A,image()));
    }
    @Test public void refuseIncompleteOrRedirectedFence()throws Exception {
        Path dir=temp.newFolder("dirty").toPath();
        Path sub=dir.resolve(".pilot-old-epoch-revoked-P000");
        Files.createDirectories(sub);
        Files.write(sub.resolve("head.pending"),new byte[]{1});
        denied(()->DemoV19FourNodeRemoteRevocation.installLocal(dir,A,image()));
        Files.delete(sub.resolve("head.pending"));
        Files.createSymbolicLink(sub.resolve("head.bin"),dir);
        denied(()->DemoV19FourNodeRemoteRevocation.installLocal(dir,A,image()));
    }
    @Test public void oldSourceCannotRegainPermissionWhenPhysicalFenceSurvives()
            throws Exception {
        Path root=temp.newFolder("permanent").toPath();
        DemoV19FourNodeRemoteRevocation.requireLocalOldNotRevoked(root,"P000");
        DemoV19FourNodeRemoteRevocation.installLocal(root,A,image());
        denied(()->DemoV19FourNodeRemoteRevocation.requireLocalOldNotRevoked(
                root,"P000"));
        denied(()->DemoV19FourNodeRemoteRevocation.requireLocalOldNotRevoked(
                root,"P000"));
        // Removal/corruption of the content still leaves a fence directory;
        // never infer restored permission from a missing head.
        Files.delete(root.resolve(".pilot-old-epoch-revoked-P000/head.bin"));
        denied(()->DemoV19FourNodeRemoteRevocation.requireLocalOldNotRevoked(
                root,"P000"));
    }
    @Test public void signedDomainIncludesPartitionVoterAndSourceEpoch()throws Exception{
        assertEquals(DemoV19FourNodeShardCatalog.ROOT+
                "/old-epoch1-revoke-intents/P000",
            DemoV19FourNodeRemoteRevocation.intentPath("P000"));
        assertEquals(DemoV19FourNodeShardCatalog.ROOT+
                "/old-epoch1-revoke-proof/P128",
            DemoV19FourNodeRemoteRevocation.proofPath("P128"));
        denied(()->DemoV19FourNodeRemoteRevocation.installLocal(
            temp.newFolder("cross").toPath(),A,"fake"));
    }
}
