package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;
import java.security.*;
import java.util.List;
import org.junit.Test;
import static org.junit.Assert.*;

public final class DemoV19FourNodeGenesisPreflightTest {
    private static KeyPair newKey()throws Exception{
        KeyPairGenerator generator=KeyPairGenerator.getInstance("RSA");
        generator.initialize(2048);
        return generator.generateKeyPair();
    }
    @Test public void independentRSAProofBoundToExactPartitionAndNonce()throws Exception{
        KeyPair identity=newKey();
        String correct=DemoV19FourNodeGenesisPreflight.statement(
            "P000","CommonHaDemoA","CommonHaDemoA","CommonHaDemoB",0,
            "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
            "11223344");
        String signature=DemoV19FourNodeGenesisPreflight.sign(
            identity.getPrivate(),correct);
        DemoV19FourNodeGenesisPreflight.requireSigned(
            identity.getPublic(),correct,signature);
        String tampered=correct.replace("|P000|","|P001|");
        denied(()->DemoV19FourNodeGenesisPreflight.requireSigned(
            identity.getPublic(),tampered,signature));
        denied(()->DemoV19FourNodeGenesisPreflight.requireSigned(
            identity.getPublic(),correct.replace("|11223344","|55667788"),signature));
    }
    @Test public void signerCannotImpersonateBuddy()throws Exception{
        KeyPair a=newKey(),b=newKey();
        String statement=DemoV19FourNodeGenesisPreflight.statement(
            "P000","CommonHaDemoA","CommonHaDemoA","CommonHaDemoB",0,
            "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
            "aa");
        String sig=DemoV19FourNodeGenesisPreflight.sign(a.getPrivate(),statement);
        denied(()->DemoV19FourNodeGenesisPreflight.requireSigned(
            b.getPublic(),statement,sig));
    }
    @Test public void wrongZKVersionOrRoleInvalidatesPreviousSignature()throws Exception{
        KeyPair a=newKey();
        String wal="e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855";
        String old=DemoV19FourNodeGenesisPreflight.statement(
            "P100","CommonHaDemoC","CommonHaDemoC","CommonHaDemoD",0,wal,"010203");
        String signature=DemoV19FourNodeGenesisPreflight.sign(a.getPrivate(),old);
        String newVersion=DemoV19FourNodeGenesisPreflight.statement(
            "P100","CommonHaDemoC","CommonHaDemoC","CommonHaDemoD",1,wal,"010203");
        denied(()->DemoV19FourNodeGenesisPreflight.requireSigned(
            a.getPublic(),newVersion,signature));
        String wrongBuddy=old.replace("CommonHaDemoD","CommonHaDemoB");
        denied(()->DemoV19FourNodeGenesisPreflight.requireSigned(
            a.getPublic(),wrongBuddy,signature));
    }
    @Test public void deterministicallySelectsOneShardPerPair(){
        List<PartitionAssignment> plan=DemoV19FourNodeShardCatalog.layout();
        String a=DemoV19FourNodeGenesisPreflight.firstShard(plan,'A');
        String c=DemoV19FourNodeGenesisPreflight.firstShard(plan,'C');
        assertNotEquals(a,c);
        assertEquals("CommonHaDemoA",plan.get(Integer.parseInt(a.substring(1))).getPrimary());
        assertEquals("CommonHaDemoC",plan.get(Integer.parseInt(c.substring(1))).getPrimary());
    }
    private interface Attempt {void run()throws Exception;}
    private static void denied(Attempt run)throws Exception {
        try{run.run();fail("accepted forged signed preflight");}
        catch(java.io.IOException expected) {}
    }
}
