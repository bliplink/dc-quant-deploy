package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;
import com.app.common.replication.*;
import com.app.common.zk.ZookeeperClient;
import java.io.*;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.*;
import java.security.*;
import java.security.spec.*;
import java.util.*;
import java.util.concurrent.TimeUnit;
import org.I0Itec.zkclient.exception.ZkNodeExistsException;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.data.Stat;

/**
 * DEMO ONLY: pin four RSA public identities in ZK and obtain per-partition,
 * two-node signed EMPTY WAL attestation BEFORE any Genesis WAL transaction.
 * PRECHECK IS NOT A COMMIT CERTIFICATE, NO READY, NO CLIENT ACK.
 * All four simulated nodes are on the same Mac: not physical fault domains.
 */
final class DemoV19FourNodeGenesisPreflight {
    static final String OP="EMPTY_WAL_PREFLIGHT_V1";
    static final String KEYS=DemoV19FourNodeShardCatalog.ROOT+"/preflight-identities";
    static final String PROOFS=DemoV19FourNodeShardCatalog.ROOT+"/preflight-evidence";
    private static final String DOMAIN="OTC_V19_PREPARING_EMPTY_WAL_V1";
    private static final String HASH_EMPTY="e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855";
    private final String node;
    private final PrivateKey privateKey;
    private final PublicKey publicKey;

    private DemoV19FourNodeGenesisPreflight(String node,PrivateKey key,PublicKey pub){
        this.node=node;privateKey=key;publicKey=pub;
    }
    static DemoV19FourNodeGenesisPreflight open(ZookeeperClient zk,String node,Path root)
            throws Exception {
        if(node==null || !node.matches("CommonHaDemo[ABCD]") || root==null
                || !root.isAbsolute() || !zk.isConnected())
            throw new IOException("isolated exact voter and ZK majority required");
        Path dir=root.resolve(".preflight-identity");
        Files.createDirectories(dir);
        Path pri=dir.resolve("local.pk8"),pub=dir.resolve("local.der");
        if(Files.isSymbolicLink(dir) || Files.isSymbolicLink(pri)
                || Files.isSymbolicLink(pub))
            throw new IOException("unsafe preflight local identity symlink");
        if(!Files.exists(pri) && !Files.exists(pub)){
            KeyPairGenerator gen=KeyPairGenerator.getInstance("RSA");
            gen.initialize(2048,new SecureRandom());
            KeyPair pair=gen.generateKeyPair();
            // One create-once identity; a crash between the two files must
            // fail closed on restart instead of silently changing key identity.
            persistNew(pri,pair.getPrivate().getEncoded());
            persistNew(pub,pair.getPublic().getEncoded());
        }
        if(!Files.isRegularFile(pri) || !Files.isRegularFile(pub))
            throw new IOException("partial preflight identity rejected");
        KeyFactory factory=KeyFactory.getInstance("RSA");
        PrivateKey key=factory.generatePrivate(new PKCS8EncodedKeySpec(Files.readAllBytes(pri)));
        PublicKey publicKey=factory.generatePublic(new X509EncodedKeySpec(Files.readAllBytes(pub)));
        byte[] signedTest="SELF_IDENTITY_TEST".getBytes(java.nio.charset.StandardCharsets.UTF_8);
        Signature sig=Signature.getInstance("SHA256withRSA");
        sig.initSign(key);sig.update(signedTest);byte[] proof=sig.sign();
        sig.initVerify(publicKey);sig.update(signedTest);
        if(!sig.verify(proof))throw new IOException("private/public identity key mismatch");
        DemoV19FourNodeShardCatalog.ensurePath(zk,KEYS);
        String path=KEYS+"/"+node;
        String encoded=Base64.getEncoder().encodeToString(publicKey.getEncoded());
        if(!zk.exists(path)){
            try{zk.create(path,encoded,CreateMode.PERSISTENT);}
            catch(ZkNodeExistsException race) {}
        }
        Stat stat=new Stat();Object existing=zk.readData(path,stat);
        if(existing==null || stat.getVersion()!=0 || !encoded.equals(String.valueOf(existing))
                || !zk.isConnected())throw new IOException("identity cannot change once ZK pinned");
        return new DemoV19FourNodeGenesisPreflight(node,key,publicKey);
    }
    private static void persistNew(Path file,byte[] content)throws Exception{
        try(FileChannel stream=FileChannel.open(file,StandardOpenOption.CREATE_NEW,
                StandardOpenOption.WRITE)){
            ByteBuffer buffer=ByteBuffer.wrap(content);
            while(buffer.hasRemaining())stream.write(buffer);
            stream.force(true);
        }
        try(FileChannel parent=FileChannel.open(file.getParent(),StandardOpenOption.READ)){
            parent.force(true);
        }
    }
    static PublicKey pinned(ZookeeperClient zk,String node)throws Exception{
        if(!zk.isConnected() || node==null || !node.matches("CommonHaDemo[ABCD]"))
            throw new IOException("no authenticated preflight identity");
        Stat stat=new Stat();Object bytes=zk.readData(KEYS+"/"+node,stat);
        if(bytes==null || stat.getVersion()!=0)
            throw new IOException("unpinned or replaced RSA voter");
        byte[] key=Base64.getDecoder().decode(String.valueOf(bytes));
        PublicKey decoded=KeyFactory.getInstance("RSA")
                .generatePublic(new X509EncodedKeySpec(key));
        if(!zk.isConnected())throw new IOException("ZK quorum disappeared");
        return decoded;
    }
    static String statement(String part,String node,String primary,String replica,
            int zkVersion,String walHash,String nonce) {
        return DOMAIN+"|"+part+"|"+node+"|"+primary+"|"+replica+"|"+
                zkVersion+"|0|"+walHash+"|"+nonce;
    }
    static String sign(PrivateKey key,String statement)throws Exception{
        Signature signature=Signature.getInstance("SHA256withRSA");
        signature.initSign(key);
        signature.update(statement.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        return Base64.getEncoder().encodeToString(signature.sign());
    }
    static void requireSigned(PublicKey key,String statement,String signature)
            throws Exception{
        Signature verify=Signature.getInstance("SHA256withRSA");
        verify.initVerify(key);
        verify.update(statement.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        if(!verify.verify(Base64.getDecoder().decode(signature)))
            throw new IOException("preparing WAL attestation signature invalid");
    }
    ReplicationControlResponse handle(ZookeeperClient zk,
            List<PartitionAssignment> assignments,
            DemoV19FourNodeLiveRuntime.HeldWal held,
            ReplicationControlRequest req) {
        try{
            if(req==null || !OP.equals(req.getOperation())
                    || !DemoV19FourNodeShardCatalog.SERVICE.equals(req.getServiceName())
                    || req.getPayload()==null || req.getPayload().length!=32)
                throw new IOException("strictly bounded challenge required");
            String part=req.getPartitionId();
            if(part==null || !part.matches("P(0[0-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])"))
                throw new IOException("out-of-range partition");
            PartitionAssignment a=assignments.get(Integer.parseInt(part.substring(1)));
            if(!part.equals(a.getPartitionId())
                    || !DemoV19FourNodeLiveRuntime.owners(a).contains(node)
                    || !node.equals(held.node))
                throw new IOException("not a pinned physical voter");
            if(!zk.isConnected())throw new IOException("lost majority");
            Stat stat=new Stat();Object raw=zk.readData(
                DemoV19FourNodeShardCatalog.ASSIGNMENTS+"/"+part,stat);
            if(raw==null)throw new IOException("missing assignment");
            DemoV19FourNodeShardCatalog.assertPersisted(
                a,String.valueOf(raw),stat.getVersion());
            DemoDurableJournal journal=held.owned.get(part);
            if(journal==null)throw new IOException("local WAL is not held");
            synchronized(journal){
                if(!journal.isReadyForWrites() || journal.committedSeq()!=0
                        || !HASH_EMPTY.equals(journal.committedPrefixSha256()))
                    throw new IOException("dirty or nonempty preflight WAL");
            }
            String nonce=hex(req.getPayload());
            String text=statement(part,node,a.getPrimary(),a.getReplica(),
                    stat.getVersion(),HASH_EMPTY,nonce);
            String signature=sign(privateKey,text);
            if(!zk.isConnected())throw new IOException("majority lost before signing");
            Stat after=new Stat();
            Object now=zk.readData(DemoV19FourNodeShardCatalog.ASSIGNMENTS+"/"+part,after);
            if(now==null || after.getVersion()!=stat.getVersion()
                    || !String.valueOf(now).equals(String.valueOf(raw)))
                throw new IOException("assignment changed while signing preflight");
            Map<String,Object> answer=new LinkedHashMap<>();
            answer.put("node",node);
            answer.put("partitionId",part);
            answer.put("primary",a.getPrimary());
            answer.put("replica",a.getReplica());
            answer.put("zkVersion",stat.getVersion());
            answer.put("seq",0);
            answer.put("walHash",HASH_EMPTY);
            answer.put("nonce",nonce);
            answer.put("signed",signature);
            return ReplicationControlResponse.ok(DemoNettyBridge.json(answer));
        }catch(Exception refused){
            return ReplicationControlResponse.error("EMPTY_WAL_PREFLIGHT_DENIED",
                refused.getClass().getSimpleName()+": "+refused.getMessage());
        }
    }
    static String hex(byte[] input) {
        StringBuilder b=new StringBuilder(input.length*2);
        for(byte v:input)b.append(String.format(Locale.ROOT,"%02x",v&0xff));
        return b.toString();
    }
    static void verifyResponse(ZookeeperClient zk,PartitionAssignment a,
            String exact,String nonce,ReplicationControlResponse response)
            throws Exception {
        if(response==null || !response.isSuccess())
            throw new IOException("missing preflight peer");
        Map<String,Object> m=DemoNettyBridge.map(response.getPayload());
        if(!exact.equals(m.get("node")) || !a.getPartitionId().equals(m.get("partitionId"))
                || !a.getPrimary().equals(m.get("primary"))
                || !a.getReplica().equals(m.get("replica"))
                || !nonce.equals(m.get("nonce"))
                || !HASH_EMPTY.equals(m.get("walHash"))
                || !(m.get("zkVersion") instanceof Number)
                || ((Number)m.get("zkVersion")).intValue()!=0
                || !(m.get("seq") instanceof Number)
                || ((Number)m.get("seq")).longValue()!=0
                || !(m.get("signed") instanceof String))
            throw new IOException("preflight response misbound to node/partition/version");
        requireSigned(pinned(zk,exact),statement(a.getPartitionId(),exact,
            a.getPrimary(),a.getReplica(),0,HASH_EMPTY,nonce),(String)m.get("signed"));
    }
    static String firstShard(List<PartitionAssignment> plan,char primary) {
        for(PartitionAssignment a:plan)
            if(("CommonHaDemo"+primary).equals(a.getPrimary()))
                return a.getPartitionId();
        throw new IllegalStateException("no shard for primary "+primary);
    }
    private static String assignmentDigest(PartitionAssignment a)throws Exception {
        byte[] source=DemoV19FourNodeShardCatalog.encode(a)
                .getBytes(java.nio.charset.StandardCharsets.UTF_8);
        return hex(MessageDigest.getInstance("SHA-256").digest(source));
    }
    @SuppressWarnings("unchecked")
    private static void validateStoredEvidence(ZookeeperClient zk,
            PartitionAssignment a,Object source,int zookeeperVersion,
            DirectNettyReplicationTransport tcp)throws Exception {
        if(source==null || zookeeperVersion!=0)
            throw new IOException("immutable signed proof is absent or overwritten");
        Map<String,Object> e=com.gateway.connector.utils.JsonUtils
            .Deserialize(String.valueOf(source),Map.class);
        if(e==null || !"PREPARING_ONLY".equals(e.get("scope"))
                || !a.getPartitionId().equals(e.get("partitionId"))
                || !assignmentDigest(a).equals(e.get("assignmentHash"))
                || !(e.get("assignmentVersion") instanceof Number)
                || ((Number)e.get("assignmentVersion")).intValue()!=0
                || !(e.get("nonce") instanceof String)
                || !((String)e.get("nonce")).matches("[0-9a-f]{64}")
                || !(e.get("receipts") instanceof List)
                || ((List<?>)e.get("receipts")).size()!=2)
            throw new IOException("corrupted or promoted PREPARING preflight proof");
        String nonce=(String)e.get("nonce");
        List<?> replies=(List<?>)e.get("receipts");
        List<String> members=DemoV19FourNodeLiveRuntime.owners(a);
        for(int i=0;i<2;i++){
            if(!(replies.get(i) instanceof Map))
                throw new IOException("untrusted signer record");
            Map<String,Object> receipt=(Map<String,Object>)replies.get(i);
            verifyResponse(zk,a,members.get(i),nonce,
                ReplicationControlResponse.ok(DemoNettyBridge.json(receipt)));
            // An immutable signed empty WAL proof does NOT prove the WAL remains
            // empty after restart. Re-query each real Netty/physical fsynced
            // WAL and deny if a replica is unavailable or not pristine.
            ReplicationControlResponse live=tcp.control(
                DemoV19FourNodeLiveRuntime.exactEndpoint(members.get(i)),
                new ReplicationControlRequest(DemoV19FourNodeShardCatalog.SERVICE,
                    "CATALOG_STATUS_V1",a.getPartitionId(),new byte[0]))
                .get(8,TimeUnit.SECONDS);
            if(!live.isSuccess())throw new IOException("signer WAL unavailable");
            DemoV19FourNodeLiveRuntime.assertStatus(
                DemoNettyBridge.map(live.getPayload()),a.getPartitionId(),
                members.get(i),i==0?"PRIMARY_SLOT":"REPLICA_SLOT");
        }
        Stat st=new Stat();Object raw=zk.readData(
            DemoV19FourNodeShardCatalog.ASSIGNMENTS+"/"+a.getPartitionId(),st);
        if(raw==null)throw new IOException("assignment disappeared during proof");
        DemoV19FourNodeShardCatalog.assertPersisted(
            a,String.valueOf(raw),st.getVersion());
        if(!zk.isConnected())throw new IOException("ZK lost after recheck");
    }

    static void runTwoPairPreflight(ZookeeperClient zk,
            List<PartitionAssignment> plan)throws Exception {
        if(!zk.isConnected())throw new IOException("no 3-ZK-majority");
        try(DirectNettyReplicationTransport tcp=new DirectNettyReplicationTransport(10000,
            DirectNettyReplicationServer.DEFAULT_MAX_FRAME_BYTES)){
            for(char lead:new char[]{'A','C'}){
                String partition=firstShard(plan,lead);
                PartitionAssignment a=plan.get(Integer.parseInt(partition.substring(1)));
                Stat version=new Stat();Object current=zk.readData(
                        DemoV19FourNodeShardCatalog.ASSIGNMENTS+"/"+partition,version);
                if(current==null)throw new IOException("missing first shard");
                DemoV19FourNodeShardCatalog.assertPersisted(
                        a,String.valueOf(current),version.getVersion());
                DemoV19FourNodeShardCatalog.ensurePath(zk,PROOFS);
                String evidencePath=PROOFS+"/"+partition;
                if(!zk.exists(evidencePath)){
                    byte[] challenge=new byte[32];new SecureRandom().nextBytes(challenge);
                    String nonce=hex(challenge);
                    Set<String> witnesses=new HashSet<>();
                    List<Map<String,Object>> replies=new ArrayList<>();
                    for(String member:DemoV19FourNodeLiveRuntime.owners(a)){
                        ReplicationControlRequest req=new ReplicationControlRequest(
                            DemoV19FourNodeShardCatalog.SERVICE,OP,partition,challenge);
                        ReplicationControlResponse res=tcp.control(
                            DemoV19FourNodeLiveRuntime.exactEndpoint(member),req)
                            .get(8,TimeUnit.SECONDS);
                        verifyResponse(zk,a,member,nonce,res);
                        replies.add(DemoNettyBridge.map(res.getPayload()));
                        if(!witnesses.add(member))
                            throw new IOException("duplicate signed physical voter");
                    }
                    if(witnesses.size()!=2 || !zk.isConnected())
                        throw new IOException("insufficient independent PREPARING proofs");
                    Stat after=new Stat();Object unchanged=zk.readData(
                        DemoV19FourNodeShardCatalog.ASSIGNMENTS+"/"+partition,after);
                    if(unchanged==null || after.getVersion()!=version.getVersion()
                            || !String.valueOf(unchanged).equals(String.valueOf(current)))
                        throw new IOException("assignment mutated across signer collection");
                    Map<String,Object> signed=new LinkedHashMap<>();
                    signed.put("scope","PREPARING_ONLY");
                    signed.put("partitionId",partition);
                    signed.put("assignmentVersion",0);
                    signed.put("assignmentHash",assignmentDigest(a));
                    signed.put("nonce",nonce);
                    signed.put("receipts",replies);
                    String encoded=com.gateway.connector.utils.JsonUtils.Serializer(signed);
                    try{zk.create(evidencePath,encoded,CreateMode.PERSISTENT);}
                    catch(ZkNodeExistsException racing) {
                        // Another candidate must be validated, not overwritten.
                    }
                }
                Stat proofVersion=new Stat();
                Object stored=zk.readData(evidencePath,proofVersion);
                validateStoredEvidence(zk,a,stored,proofVersion.getVersion(),tcp);
                System.out.println("FOUR_NODE_DUAL_EMPTY_WAL_SIGNED_PREFLIGHT_PASS partition="
                    +partition+" pair="+a.getPrimary()+"/"+a.getReplica()
                    +" physicalJvms=2 zkVersion=0 walSeq=0 committedGenesis=false"
                    +" ready=false clientAck=false persistedSignedZkEvidence=true");
            }
        }
    }
}
