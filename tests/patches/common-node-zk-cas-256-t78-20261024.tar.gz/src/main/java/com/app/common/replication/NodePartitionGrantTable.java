package com.app.common.replication;

import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.LongSupplier;

/**
 * Immutable node-scoped control snapshot shared by STRICT_QUORUM and
 * LOCAL_DURABLE_ASYNC WAL engines.
 *
 * This class has no ZooKeeper dependency. Exactly ONE control-plane verifier
 * authenticates an atomic batch of assignments and a node lease. Replication,
 * business apply, WAL fsync and client ACK use only the published in-memory
 * snapshot. It does not sign a certificate or persist a WAL.
 *
 * SECURITY REQUIREMENTS FOR THE CONTROL-PLANE ADAPTER:
 *  - verify node identity, actual ZK quorum/CAS and fenced old owner;
 *  - verify every partition Epoch and ACK-policy transition;
 *  - never authorize a new owner before every prior grant can no longer
 *    yield a valid ACK (max old TTL + clock uncertainty);
 *  - issue lease expiry from the BEGINNING of the quorum proof, not when
 *    it returns; revoke on session loss/Watch change.
 *
 * A snapshot/permit alone is NOT an ACK: the selected durability engine
 * MUST validate physical WAL/CommitIndex/Custody evidence separately.
 */
public final class NodePartitionGrantTable {
    public interface ControlVerifier {
        /** Called only by control-plane install, NEVER a WAL/ACK thread. */
        void verifyBatch(Batch batch) throws Exception;
    }
    public static final class Partition {
        public final String id,primary,replica;
        public final long epoch;
        public final DurableWalAckPolicy policy;

        public Partition(String id,long epoch,String primary,String replica,
                         DurableWalAckPolicy policy) {
            this.id=required(id,"partition");
            this.primary=required(primary,"primary");
            this.replica=replica==null?"":replica;
            if(epoch<=0 || this.primary.equals(this.replica))
                throw new IllegalArgumentException("invalid physical partition/epoch");
            this.epoch=epoch;
            this.policy=Objects.requireNonNull(policy,"ACK policy");
            if(policy==DurableWalAckPolicy.STRICT_QUORUM && this.replica.isEmpty())
                throw new IllegalArgumentException("strict partition requires a replica");
        }
        private boolean same(Partition other){
            return other!=null && epoch==other.epoch
                && id.equals(other.id) && primary.equals(other.primary)
                && replica.equals(other.replica) && policy==other.policy;
        }
    }
    public static final class Batch {
        public final String nodeId;
        public final long generation,proofStartedNanos,ttlNanos,activationDelayNanos;
        public final Map<String,Partition> partitions;
        private final byte[] quorumProof;

        public Batch(String nodeId,long generation,long proofStartedNanos,
                     long ttlNanos,long activationDelayNanos,
                     Map<String,Partition> partitions,byte[] quorumProof) {
            this.nodeId=required(nodeId,"node");
            if(generation<=0 || proofStartedNanos<0 || ttlNanos<=0
                    || activationDelayNanos<0)
                throw new IllegalArgumentException("bad controller grant");
            this.generation=generation;
            this.proofStartedNanos=proofStartedNanos;
            this.ttlNanos=ttlNanos;
            this.activationDelayNanos=activationDelayNanos;
            if(partitions==null || partitions.isEmpty())
                throw new IllegalArgumentException("empty partition batch");
            Map<String,Partition> copy=new HashMap<>();
            partitions.forEach((key,value)->{
                Objects.requireNonNull(value,"partition record");
                if(!key.equals(value.id))
                    throw new IllegalArgumentException("mismatched partition identity");
                copy.put(key,value);
            });
            this.partitions=Collections.unmodifiableMap(copy);
            this.quorumProof=Objects.requireNonNull(quorumProof,"quorumProof").clone();
            if(this.quorumProof.length==0)
                throw new IllegalArgumentException("missing control quorum evidence");
        }
        public byte[] quorumProof(){return quorumProof.clone();}
    }
    private static final class State {
        final Batch batch;
        final boolean revoked, hardRevoked;
        final long fenceGeneration;
        final Map<String,Long> partitionActivationNanos;
        State(Batch batch,boolean revoked,boolean hardRevoked,
                Map<String,Long> activation,long fenceGeneration){
            this.batch=batch;this.revoked=revoked;this.hardRevoked=hardRevoked;
            this.fenceGeneration=fenceGeneration;
            this.partitionActivationNanos=Collections.unmodifiableMap(
                new HashMap<String,Long>(activation));
        }
    }
    public final class Permit {
        private final State pinned;
        public final Partition partition;
        private final boolean replica;
        private Permit(State pinned,Partition partition,boolean replica){
            this.pinned=pinned;this.partition=partition;this.replica=replica;
        }
        /** Call before WAL append/signing AND immediately before client ACK. */
        public void requireCurrent() throws IOException {
            State now=current.get();
            // Lease renewals replace the physical snapshot but preserve the
            // logical fence generation for the SAME authorized role/Epoch.
            // In-flight WAL operations must survive ordinary heartbeats.
            if(now==null || now.revoked ||
                    now.fenceGeneration!=pinned.fenceGeneration
                    || !partition.same(now.batch.partitions.get(partition.id)))
                throw new IOException("grant revoked or node generation changed");
            unexpired(now.batch);
            Long activatedAt=now.partitionActivationNanos.get(partition.id);
            if(activatedAt==null || monotonicNanos.getAsLong()<activatedAt)
                throw new IOException("new owner retirement fence incomplete");
            if(replica ? !nodeId.equals(partition.replica)
                       : !nodeId.equals(partition.primary))
                throw new IOException("writer role revoked");
        }
        /** Call only after physical durability gate, not in place of it. */
        public void requireAckEvidence(String mode,boolean quorum,boolean dataLoss)
                throws IOException {
            if(replica)throw new IOException("replica cannot acknowledge clients");
            requireCurrent();
            partition.policy.requireAckEvidence(mode,quorum,dataLoss);
            requireCurrent();
        }
    }

    private final String nodeId;
    private final LongSupplier monotonicNanos;
    private final ControlVerifier authority;
    private final int maxPartitions;
    private final long maxLeaseNanos;
    private final AtomicReference<State> current=new AtomicReference<>();
    private long nextFenceGeneration;
    /** Controller-thread-only monotonic watermarks retained even while a
     * shard is excluded from the READY manifest during recovery. A later
     * re-add must advance its Epoch; no ABA disappearance/reappearance. */
    private final Map<String,Partition> highestSeen=new HashMap<>();
    private final Set<String> suspended=new HashSet<>();

    public NodePartitionGrantTable(String nodeId,LongSupplier monotonicNanos,
            ControlVerifier authority,int maxPartitions,long maxLeaseNanos){
        this.nodeId=required(nodeId,"node");
        this.monotonicNanos=Objects.requireNonNull(monotonicNanos);
        this.authority=Objects.requireNonNull(authority);
        if(maxPartitions<1 || maxLeaseNanos<=0)
            throw new IllegalArgumentException("invalid capacity/lease");
        this.maxPartitions=maxPartitions;this.maxLeaseNanos=maxLeaseNanos;
    }
    private static String required(String value,String name){
        if(value==null || value.trim().isEmpty())
            throw new IllegalArgumentException(name+" missing");
        return value;
    }
    private long unexpired(Batch batch)throws IOException {
        long now=monotonicNanos.getAsLong();
        long elapsed=now-batch.proofStartedNanos;
        if(elapsed<0 || elapsed>=batch.ttlNanos)
            throw new IOException("node quorum lease expired");
        return elapsed;
    }

    /**
     * ONE externally proven control event installs up to maxPartitions.
     * Any partial batch is rejected; assignment topology replaces atomically.
     * A revoked/expired generation cannot be resurrected at the same epoch.
     */
    public synchronized void install(Batch batch)throws Exception {
        Objects.requireNonNull(batch,"verified grant");
        // Retirement wait may exceed ONE short node lease. Renewals keep
        // the original per-partition activation deadline until it passes.
        if(!nodeId.equals(batch.nodeId) || batch.partitions.size()>maxPartitions
                || batch.ttlNanos>maxLeaseNanos)
            throw new IOException("invalid node control lease/partition capacity");
        // A slow ZK proof cannot be allowed to borrow time from a later clock.
        unexpired(batch);
        // Trust boundary: verifier MUST consult real ZK CAS/quorum & old fence.
        authority.verifyBatch(batch);
        unexpired(batch);
        State previous=current.get();
        if(previous!=null) {
            Batch old=previous.batch;
            if(batch.generation<old.generation)
                throw new IOException("stale node control generation");
            boolean oldExpired=expired(old);
            if((previous.revoked || oldExpired)
                    && batch.generation<=old.generation)
                throw new IOException("revoked node generation cannot renew");
            if(batch.generation==old.generation) {
                if(!sameTopology(batch.partitions,old.partitions))
                    throw new IOException("topology changed without new generation");
            } else {
                for(Partition next:batch.partitions.values()){
                    Partition prior=old.partitions.get(next.id);
                    if(prior!=null && next.epoch<prior.epoch)
                        throw new IOException("partition epoch rolled backward");
                    if(prior!=null && next.epoch==prior.epoch
                            && !next.same(prior))
                        throw new IOException("policy/owner changed without epoch");
                    // A manifest Watch fences existing permits immediately,
                    // but does not force unrelated healthy partitions to
                    // advance their business Epoch. A lost node session or
                    // expired node grant DOES require every old Epoch to
                    // be retired before it can resume.
                    if(prior!=null && (previous.hardRevoked || oldExpired)
                            && next.epoch<=prior.epoch)
                        throw new IOException("revoked epoch cannot be resurrected");
                }
            }
        }
        // Preserve immutable Epoch floors even when RECOVERING temporarily
        // removes a partition from this node-level READY batch.
        for(Partition next:batch.partitions.values()){
            Partition last=highestSeen.get(next.id);
            if(last!=null && next.epoch<last.epoch)
                throw new IOException("historical partition epoch rolled backward");
            if(last!=null && next.epoch==last.epoch
                    && (!next.same(last) || suspended.contains(next.id)))
                throw new IOException("removed/fenced partition cannot reuse Epoch");
        }
        // Every partition gets its own stable retirement deadline. On
        // unchanged assignment/epoch a node lease refresh carries the old
        // deadline, instead of restarting the outage on every renewal.
        // An independent shard transition does not pause other 255 shards.
        Map<String,Long> activation=new HashMap<>();
        for(Partition next:batch.partitions.values()){
            Long unchanged=null;
            if(previous!=null){
                Partition old=previous.batch.partitions.get(next.id);
                if(next.same(old))
                    unchanged=previous.partitionActivationNanos.get(next.id);
            }
            long ready=unchanged!=null?unchanged.longValue():
                Math.addExact(batch.proofStartedNanos,batch.activationDelayNanos);
            activation.put(next.id,ready);
        }
        boolean sameGrant=previous!=null && !previous.revoked
            && batch.generation==previous.batch.generation
            && sameTopology(batch.partitions,previous.batch.partitions);
        long logicalFence=sameGrant?previous.fenceGeneration:
            ++nextFenceGeneration;
        State installed=new State(batch,false,false,activation,logicalFence);
        current.set(installed);
        // Catch a Watch/session loss that raced the CAS proof between the
        // first verifier invocation and publication of the immutable table.
        // If anything changed, leave the new generation FENCED rather than
        // exposing an unverified candidate to ACK threads.
        try { authority.verifyBatch(batch); }
        catch(Exception revokedAfterInstall){
            current.set(new State(batch,true,true,activation,
                ++nextFenceGeneration));
            throw revokedAfterInstall;
        }
        if(previous!=null){
            for(Partition old:previous.batch.partitions.values())
                if(!batch.partitions.containsKey(old.id))suspended.add(old.id);
        }
        for(Partition next:batch.partitions.values()){
            highestSeen.put(next.id,next);
            suspended.remove(next.id);
        }
    }

    private static boolean sameTopology(Map<String,Partition> a,
                                         Map<String,Partition> b) {
        if(a.size()!=b.size())return false;
        for(Map.Entry<String,Partition> e:a.entrySet())
            if(!e.getValue().same(b.get(e.getKey())))return false;
        return true;
    }
    private boolean expired(Batch b){
        long elapsed=monotonicNanos.getAsLong()-b.proofStartedNanos;
        return elapsed<0 || elapsed>=b.ttlNanos;
    }
    /** Session loss/expiry: ALL old node grants require higher Epoch. */
    public synchronized void revoke() {
        State s=current.get();
        if(s!=null)current.set(new State(s.batch,true,true,
            s.partitionActivationNanos,++nextFenceGeneration));
    }
    /** Assignment Watch: invalidate in-flight permits, but let unchanged
     * partitions retain their Epoch after a new verified node generation.
     * Changed primary/replica/ACK policy still mandates higher Epoch. */
    public synchronized void revokeForManifestChange() {
        State s=current.get();
        if(s!=null)current.set(new State(s.batch,true,s.hardRevoked,
            s.partitionActivationNanos,++nextFenceGeneration));
    }
    public Permit primary(String partition,long epoch,
                          DurableWalAckPolicy policy)throws IOException {
        return permit(partition,epoch,policy,false);
    }
    public Permit replica(String partition,long epoch,
                          DurableWalAckPolicy policy)throws IOException {
        return permit(partition,epoch,policy,true);
    }
    private Permit permit(String id,long epoch,DurableWalAckPolicy policy,
                          boolean replica)throws IOException {
        State s=current.get();
        if(s==null || s.revoked)throw new IOException("control snapshot not READY");
        unexpired(s.batch);
        Partition p=s.batch.partitions.get(id);
        if(p==null || p.epoch!=epoch || p.policy!=policy)
            throw new IOException("stale partition epoch or ACK policy");
        if(!(replica?nodeId.equals(p.replica):nodeId.equals(p.primary)))
            throw new IOException("wrong node for WAL partition");
        Permit permit=new Permit(s,p,replica);
        permit.requireCurrent();
        return permit;
    }
    public int partitionCount(){
        State s=current.get();return s==null?0:s.batch.partitions.size();
    }
    public long generation(){
        State s=current.get();return s==null?0:s.batch.generation;
    }
}
