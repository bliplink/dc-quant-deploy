package com.app.common.replication;

import java.io.IOException;
import java.util.Objects;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Node-scoped cluster CONTROL adapter.
 *
 * One verified renewal transaction supplies all local partition assignments.
 * Watch notifications revoke the old immutable generation immediately and
 * schedule ONE background re-read. No business/WAL/Replica/Custody call
 * reaches the ControlPlane, including STRICT and LOCAL_DURABLE_ASYNC modes.
 *
 * This class does NOT invent a valid ZK proof: the injected ControlPlane
 * must read assignment generation, prove quorum and fence old owners using
 * a durable CAS/lease. NodePartitionGrantTable.ControlVerifier independently
 * checks the proof before install. Timed-out lease is fail-closed.
 */
public final class NodeClusterControlManager implements AutoCloseable {
    public interface ControlPlane {
        /** One authenticated node-scoped control/renewal call, not per shard. */
        NodePartitionGrantTable.Batch renewNodeLease(String node)throws Exception;
    }
    private final String node;
    private final ControlPlane control;
    private final NodePartitionGrantTable grants;
    private final ScheduledExecutorService executor;
    private final long renewIntervalMillis;
    private final AtomicBoolean started=new AtomicBoolean();
    private final AtomicBoolean closed=new AtomicBoolean();
    private volatile long succeeded,failed;
    public NodeClusterControlManager(String node,ControlPlane control,
            NodePartitionGrantTable grants,long renewIntervalMillis) {
        this.node=Objects.requireNonNull(node);
        this.control=Objects.requireNonNull(control);
        this.grants=Objects.requireNonNull(grants);
        if(renewIntervalMillis<10)
            throw new IllegalArgumentException("lease renew interval must be positive");
        this.renewIntervalMillis=renewIntervalMillis;
        executor=Executors.newSingleThreadScheduledExecutor(r->{
            Thread t=new Thread(r,"common-node-control-"+node);
            t.setDaemon(true);
            return t;
        });
    }
    public void start(){
        if(closed.get() || !started.compareAndSet(false,true))
            throw new IllegalStateException("node controller already started/closed");
        executor.scheduleWithFixedDelay(()->refresh(),0,renewIntervalMillis,
                TimeUnit.MILLISECONDS);
    }
    /** Called exclusively by control executor. A lost ZK quorum DOES NOT
     * extend an earlier node lease; it expires locally without further I/O. */
    void refresh(){
        if(closed.get())return;
        try{
            NodePartitionGrantTable.Batch batch=control.renewNodeLease(node);
            if(closed.get())return;
            grants.install(batch);
            succeeded++;
        } catch(Exception noQuorum){
            failed++;
            if(Boolean.getBoolean("common.node.control.debug"))
                noQuorum.printStackTrace(System.err);
            // Never fall back to an unauthenticated local renewal.
            // Existing grant has its own strictly bounded expiry.
        }
    }
    /** ZK Watch signals assignment-generation changes. Invalidate every old
     * permit immediately, but a newly authenticated generation may keep
     * unrelated partitions at their unchanged Epoch. Changed roles and
     * ACK policy still require a higher Epoch. */
    public void onControlChanged(){
        grants.revokeForManifestChange();
        wake();
    }
    /** ZooKeeper session loss requires immediate local fencing. */
    public void onSessionLost(){
        grants.revoke();
    }
    private void wake(){
        if(closed.get() || !started.get())return;
        try {executor.execute(()->refresh());}
        catch(RejectedExecutionException shutdown){}
    }
    public NodePartitionGrantTable.Permit requirePrimary(String partition,long epoch,
            DurableWalAckPolicy mode)throws IOException {
        return grants.primary(partition,epoch,mode);
    }
    public NodePartitionGrantTable.Permit requireReplica(String partition,long epoch,
            DurableWalAckPolicy mode)throws IOException {
        return grants.replica(partition,epoch,mode);
    }
    public int localPartitionCount(){return grants.partitionCount();}
    public long successfulRenewals(){return succeeded;}
    public long failedRenewals(){return failed;}
    @Override public void close(){
        if(closed.compareAndSet(false,true)){
            grants.revoke();
            executor.shutdownNow();
        }
    }
}
