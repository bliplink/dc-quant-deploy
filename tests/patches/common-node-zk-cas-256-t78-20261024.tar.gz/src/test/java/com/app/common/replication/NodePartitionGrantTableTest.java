package com.app.common.replication;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import org.junit.Test;
import static org.junit.Assert.*;

public class NodePartitionGrantTableTest {
    private static final String A="NodeA",B="NodeB";
    private final AtomicLong time=new AtomicLong(100000000000L);
    private final AtomicInteger controlCalls=new AtomicInteger();
    private final NodePartitionGrantTable.ControlVerifier verifier=proof->{
        controlCalls.incrementAndGet();
        if(proof.quorumProof()[0]!=42)
            throw new IOException("invalid authenticated ZK control quorum");
    };
    private NodePartitionGrantTable table(String node) {
        return new NodePartitionGrantTable(node,time::get,verifier,256,1000000000L);
    }
    private Map<String,NodePartitionGrantTable.Partition> partitions(
            int total,long epoch,DurableWalAckPolicy mode,boolean swap) {
        Map<String,NodePartitionGrantTable.Partition> result=new HashMap<>();
        for(int i=0;i<total;i++){
            String id=String.format("P%03d",i);
            String owner=(i%2==0)^swap?A:B,replica=owner.equals(A)?B:A;
            result.put(id,new NodePartitionGrantTable.Partition(id,epoch,owner,
                replica,mode));
        }
        return result;
    }
    private NodePartitionGrantTable.Batch batch(long generation,long epoch,
            DurableWalAckPolicy mode,boolean swap) {
        return new NodePartitionGrantTable.Batch(A,generation,time.get(),
            900000000L,0L,partitions(256,epoch,mode,swap),new byte[]{42});
    }
    private static void denied(Checked runnable,String contains)throws Exception {
        try {runnable.go();fail("invalid grant was allowed");}
        catch(IOException expected){
            assertTrue(expected.getMessage(),expected.getMessage().contains(contains));
        }
    }
    interface Checked {void go()throws Exception;}

    @Test public void exactly256PartitionsOneNodeProofNoZkOnBusinessHotPath()
            throws Exception {
        NodePartitionGrantTable node=table(A);
        node.install(batch(1,1,DurableWalAckPolicy.STRICT_QUORUM,false));
        assertEquals(256,node.partitionCount());
        assertEquals(2,controlCalls.get());
        for(int i=0;i<200000;i++){
            String id=String.format("P%03d",i%256);
            if((i%256)%2==0){
                NodePartitionGrantTable.Permit p=node.primary(
                    id,1,DurableWalAckPolicy.STRICT_QUORUM);
                p.requireAckEvidence("QUORUM_DURABLE",true,false);
            }else{
                NodePartitionGrantTable.Permit p=node.replica(
                    id,1,DurableWalAckPolicy.STRICT_QUORUM);
                p.requireCurrent();
            }
        }
        assertEquals("no controller/ZK probes in business hot path",
                     2,controlCalls.get());
    }

    @Test public void asyncLocalAckHasSameZeroZkRoutingButAdmitsRpoRisk()
            throws Exception {
        NodePartitionGrantTable node=table(A);
        node.install(batch(1,1,DurableWalAckPolicy.LOCAL_DURABLE_ASYNC,false));
        NodePartitionGrantTable.Permit p=node.primary("P000",1,
            DurableWalAckPolicy.LOCAL_DURABLE_ASYNC);
        p.requireAckEvidence("LOCAL_DURABLE_ASYNC",false,true);
        denied(()->p.requireAckEvidence("QUORUM_DURABLE",true,false),
            "EVIDENCE_MISMATCH");
        denied(()->p.requireAckEvidence("LOCAL_DURABLE_ASYNC",false,false),
            "EVIDENCE_MISMATCH");
        denied(()->node.primary("P000",1,DurableWalAckPolicy.STRICT_QUORUM),
            "ACK policy");
        assertEquals(2,controlCalls.get());
    }

    @Test public void sameNodeGenerationCanRenewOnlySameTopology()throws Exception{
        NodePartitionGrantTable t=table(A);
        t.install(batch(1,1,DurableWalAckPolicy.STRICT_QUORUM,false));
        time.addAndGet(100000000L);
        t.install(batch(1,1,DurableWalAckPolicy.STRICT_QUORUM,false));
        assertEquals(4,controlCalls.get());
        denied(()->t.install(batch(1,1,
            DurableWalAckPolicy.LOCAL_DURABLE_ASYNC,false)),"topology");
        denied(()->t.install(batch(1,1,
            DurableWalAckPolicy.STRICT_QUORUM,true)),"topology");
    }

    @Test public void revocationCannotReAuthorizeSameEpochEvenNewGeneration()
            throws Exception {
        NodePartitionGrantTable t=table(A);
        t.install(batch(1,1,DurableWalAckPolicy.STRICT_QUORUM,false));
        NodePartitionGrantTable.Permit old=t.primary("P000",1,
            DurableWalAckPolicy.STRICT_QUORUM);
        t.revoke();
        denied(old::requireCurrent,"revoked");
        denied(()->t.install(batch(1,1,DurableWalAckPolicy.STRICT_QUORUM,false)),
            "revoked");
        denied(()->t.install(batch(2,1,DurableWalAckPolicy.STRICT_QUORUM,false)),
            "revoked epoch");
        time.addAndGet(1000000);
        t.install(batch(2,2,DurableWalAckPolicy.STRICT_QUORUM,true));
        assertEquals(2,t.generation());
        denied(old::requireCurrent,"generation");
        denied(()->t.primary("P000",1,DurableWalAckPolicy.STRICT_QUORUM),
            "stale partition");
        assertNotNull(t.replica("P000",2,DurableWalAckPolicy.STRICT_QUORUM));
    }

    @Test public void expiredNodeLeaseRequiresAuthorizedHigherEpoch()throws Exception{
        NodePartitionGrantTable t=table(A);
        t.install(batch(1,1,DurableWalAckPolicy.LOCAL_DURABLE_ASYNC,false));
        NodePartitionGrantTable.Permit p=t.primary("P000",1,
            DurableWalAckPolicy.LOCAL_DURABLE_ASYNC);
        time.addAndGet(900000000L);
        denied(p::requireCurrent,"expired");
        denied(()->t.install(batch(1,1,
            DurableWalAckPolicy.LOCAL_DURABLE_ASYNC,false)),"revoked");
        denied(()->t.install(batch(2,1,
            DurableWalAckPolicy.LOCAL_DURABLE_ASYNC,false)),"revoked epoch");
        t.install(batch(2,2,DurableWalAckPolicy.LOCAL_DURABLE_ASYNC,false));
        assertEquals(2,t.generation());
    }

    @Test public void newEpochCannotACKBeforeOldWriterRetirementBarrier()
            throws Exception {
        NodePartitionGrantTable t=table(A);
        t.install(new NodePartitionGrantTable.Batch(A,2,time.get(),
            900000000L,300000000L,
            partitions(256,2,DurableWalAckPolicy.STRICT_QUORUM,true),
            new byte[]{42}));
        denied(()->t.replica("P000",2,DurableWalAckPolicy.STRICT_QUORUM),
            "retirement fence");
        time.addAndGet(300000000L);
        t.replica("P000",2,DurableWalAckPolicy.STRICT_QUORUM).requireCurrent();
    }

    @Test public void aSingleShardCutoverDoesNotReblockOther255OnRenewal()
            throws Exception {
        NodePartitionGrantTable table=table(A);
        Map<String,NodePartitionGrantTable.Partition> original=
            partitions(256,1,DurableWalAckPolicy.STRICT_QUORUM,false);
        table.install(new NodePartitionGrantTable.Batch(A,1,time.get(),
            900000000L,250000000L,original,new byte[]{42}));
        denied(()->table.primary("P000",1,DurableWalAckPolicy.STRICT_QUORUM),
            "retirement fence");
        time.addAndGet(250000000L);
        table.primary("P000",1,DurableWalAckPolicy.STRICT_QUORUM).requireCurrent();
        // Refreshing the same node generation MUST NOT restart a 250ms pause.
        table.install(new NodePartitionGrantTable.Batch(A,1,time.get(),
            900000000L,250000000L,original,new byte[]{42}));
        table.primary("P000",1,DurableWalAckPolicy.STRICT_QUORUM).requireCurrent();
        Map<String,NodePartitionGrantTable.Partition> changed=
            new HashMap<>(original);
        changed.put("P000",new NodePartitionGrantTable.Partition(
            "P000",2,B,A,DurableWalAckPolicy.STRICT_QUORUM));
        table.revokeForManifestChange();
        table.install(new NodePartitionGrantTable.Batch(A,2,time.get(),
            900000000L,250000000L,changed,new byte[]{42}));
        // The changed P000 waits for the old primary to retire, P001 stays
        // at original Epoch1 with no interruption, despite a whole-node CAS.
        denied(()->table.replica("P000",2,DurableWalAckPolicy.STRICT_QUORUM),
            "retirement fence");
        table.replica("P001",1,DurableWalAckPolicy.STRICT_QUORUM).requireCurrent();
        time.addAndGet(250000000L);
        table.replica("P000",2,DurableWalAckPolicy.STRICT_QUORUM).requireCurrent();
        table.replica("P001",1,DurableWalAckPolicy.STRICT_QUORUM).requireCurrent();
    }

    @Test public void retirementBarrierLongerThanLeaseCanSpanSeveralRenewals()
            throws Exception {
        NodePartitionGrantTable table=table(A);
        Map<String,NodePartitionGrantTable.Partition> routes=
            partitions(256,2,DurableWalAckPolicy.STRICT_QUORUM,false);
        long began=time.get();
        table.install(new NodePartitionGrantTable.Batch(A,2,began,
            900000000L,1300000000L,routes,new byte[]{42}));
        denied(()->table.primary("P000",2,DurableWalAckPolicy.STRICT_QUORUM),
            "retirement fence");
        time.addAndGet(650000000L);
        table.install(new NodePartitionGrantTable.Batch(A,2,time.get(),
            900000000L,1300000000L,routes,new byte[]{42}));
        denied(()->table.primary("P000",2,DurableWalAckPolicy.STRICT_QUORUM),
            "retirement fence");
        time.addAndGet(650000000L);
        table.install(new NodePartitionGrantTable.Batch(A,2,time.get(),
            900000000L,1300000000L,routes,new byte[]{42}));
        table.primary("P000",2,DurableWalAckPolicy.STRICT_QUORUM).requireCurrent();
        table.replica("P001",2,DurableWalAckPolicy.STRICT_QUORUM).requireCurrent();
    }

    @Test public void disappearingRecoveringPartitionCannotRejoinAtOldEpoch()
            throws Exception {
        NodePartitionGrantTable table=table(A);
        Map<String,NodePartitionGrantTable.Partition> ready=
            partitions(256,1,DurableWalAckPolicy.STRICT_QUORUM,false);
        table.install(new NodePartitionGrantTable.Batch(A,1,time.get(),
            900000000L,0L,ready,new byte[]{42}));
        NodePartitionGrantTable.Permit old=table.primary("P000",1,
            DurableWalAckPolicy.STRICT_QUORUM);
        table.revokeForManifestChange();
        Map<String,NodePartitionGrantTable.Partition> recovering=
            new HashMap<>(ready);
        recovering.remove("P000");
        table.install(new NodePartitionGrantTable.Batch(A,2,time.get(),
            900000000L,0L,recovering,new byte[]{42}));
        denied(old::requireCurrent,"generation");
        table.revokeForManifestChange();
        denied(()->table.install(new NodePartitionGrantTable.Batch(A,3,time.get(),
            900000000L,0L,ready,new byte[]{42})),"removed/fenced");
        Map<String,NodePartitionGrantTable.Partition> healthy=
            new HashMap<>(ready);
        healthy.put("P000",new NodePartitionGrantTable.Partition("P000",2,
            A,B,DurableWalAckPolicy.STRICT_QUORUM));
        table.install(new NodePartitionGrantTable.Batch(A,3,time.get(),
            900000000L,0L,healthy,new byte[]{42}));
        table.primary("P000",2,DurableWalAckPolicy.STRICT_QUORUM).requireCurrent();
        table.primary("P002",1,DurableWalAckPolicy.STRICT_QUORUM).requireCurrent();
    }

    @Test public void watcherRacingFinalVerificationLeavesNoUsablePermit()
            throws Exception {
        java.util.concurrent.atomic.AtomicInteger verified=
            new java.util.concurrent.atomic.AtomicInteger();
        NodePartitionGrantTable table=new NodePartitionGrantTable(A,time::get,
            b->{if(verified.incrementAndGet()==2)
                throw new IOException("Watch fenced CAS at publication");},
            256,900000000L);
        denied(()->table.install(new NodePartitionGrantTable.Batch(A,1,time.get(),
            900000000L,0L,
            partitions(256,1,DurableWalAckPolicy.LOCAL_DURABLE_ASYNC,false),
            new byte[]{42})),"Watch fenced");
        denied(()->table.primary("P000",1,
            DurableWalAckPolicy.LOCAL_DURABLE_ASYNC),"not READY");
    }

    @Test public void originalWalPermitSurvivesNodeHeartbeatButNotZkWatch()
            throws Exception {
        NodePartitionGrantTable table=table(A);
        Map<String,NodePartitionGrantTable.Partition> routes=
            partitions(256,1,DurableWalAckPolicy.STRICT_QUORUM,false);
        table.install(new NodePartitionGrantTable.Batch(A,1,time.get(),
            900000000L,0L,routes,new byte[]{42}));
        NodePartitionGrantTable.Permit inFlight=table.primary("P000",1,
            DurableWalAckPolicy.STRICT_QUORUM);
        time.addAndGet(150000000L);
        table.install(new NodePartitionGrantTable.Batch(A,1,time.get(),
            900000000L,0L,routes,new byte[]{42}));
        inFlight.requireAckEvidence("QUORUM_DURABLE",true,false);
        table.revokeForManifestChange();
        denied(inFlight::requireCurrent,"revoked");
    }

    @Test public void forgedProofInvalidNodeOrTooManyPartitionsFailClosed()
            throws Exception {
        NodePartitionGrantTable t=table(A);
        denied(()->t.install(new NodePartitionGrantTable.Batch(A,1,time.get(),
            900000000L,0L,partitions(256,1,
            DurableWalAckPolicy.STRICT_QUORUM,false),new byte[]{99})),
            "invalid authenticated");
        assertEquals(0,t.partitionCount());
        denied(()->t.install(new NodePartitionGrantTable.Batch(B,1,time.get(),
            900000000L,0L,partitions(256,1,
            DurableWalAckPolicy.STRICT_QUORUM,false),new byte[]{42})),
            "node control");
        denied(()->t.install(new NodePartitionGrantTable.Batch(A,1,time.get(),
            900000000L,0L,partitions(257,1,
            DurableWalAckPolicy.STRICT_QUORUM,false),new byte[]{42})),
            "capacity");
    }

    @Test public void watchInvalidatesInFlightClientBeforeAck()throws Exception{
        NodePartitionGrantTable t=table(A);
        t.install(batch(1,1,DurableWalAckPolicy.LOCAL_DURABLE_ASYNC,false));
        NodePartitionGrantTable.Permit p=t.primary("P000",1,
            DurableWalAckPolicy.LOCAL_DURABLE_ASYNC);
        t.revoke();
        denied(()->p.requireAckEvidence("LOCAL_DURABLE_ASYNC",false,true),
            "revoked");
    }
}
