package com.app.common.replication;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import org.junit.Test;
import static org.junit.Assert.*;

public final class NodeClusterControlManagerTest {
    private final AtomicLong clock=new AtomicLong(1000000000000L);
    private final AtomicInteger renewals=new AtomicInteger();
    private final AtomicInteger verified=new AtomicInteger();
    private long generation=1,epoch=1;
    private boolean quorumAvailable=true;
    private Map<String,NodePartitionGrantTable.Partition> routes(){
        Map<String,NodePartitionGrantTable.Partition> result=new HashMap<>();
        for(int i=0;i<256;i++){
            String id=String.format("P%03d",i);
            boolean own=i%2==0;
            DurableWalAckPolicy policy=i%4<2
                ? DurableWalAckPolicy.STRICT_QUORUM
                : DurableWalAckPolicy.LOCAL_DURABLE_ASYNC;
            result.put(id,new NodePartitionGrantTable.Partition(id,epoch,
                own?"NodeA":"NodeB",own?"NodeB":"NodeA",policy));
        }
        return result;
    }
    private final NodeClusterControlManager.ControlPlane control=node->{
        renewals.incrementAndGet();
        if(!quorumAvailable)throw new IOException("ZooKeeper quorum offline");
        return new NodePartitionGrantTable.Batch(node,generation,clock.get(),
            900000000L,0L,routes(),new byte[]{42});
    };
    private NodePartitionGrantTable table(){
        return new NodePartitionGrantTable("NodeA",clock::get,batch->{
            verified.incrementAndGet();
            if(batch.quorumProof()[0]!=42)throw new IOException("untrusted controller");
        },256,1000000000L);
    }
    interface Checked {void go()throws Exception;}
    private static void denied(Checked job)throws Exception {
        try {job.go();fail("unverified lease accepted");}
        catch(IOException expected) {}
    }

    @Test public void oneAuthenticatedNodeRenewalFor256BothModesAnd200kOperations()
            throws Exception {
        NodePartitionGrantTable state=table();
        NodeClusterControlManager manager=new NodeClusterControlManager("NodeA",
            control,state,300L);
        manager.refresh();
        assertEquals(256,manager.localPartitionCount());
        for(int i=0;i<200000;i++){
            int p=i%256;
            DurableWalAckPolicy policy=p%4<2
                ? DurableWalAckPolicy.STRICT_QUORUM
                : DurableWalAckPolicy.LOCAL_DURABLE_ASYNC;
            String id=String.format("P%03d",p);
            NodePartitionGrantTable.Permit permit=p%2==0
                ? manager.requirePrimary(id,1,policy)
                : manager.requireReplica(id,1,policy);
            if(p%2==0){
                permit.requireAckEvidence(policy.ackDurabilityMode,
                    policy.quorumDurable,
                    policy.possibleDataLossIfPrimaryPermanentlyLost);
            }else permit.requireCurrent();
        }
        assertEquals(1,renewals.get());
        assertEquals(2,verified.get());
        // A node-sized control renewal still does not touch each partition.
        clock.addAndGet(500000000L);
        manager.refresh();
        assertEquals(2,renewals.get());
        assertEquals(4,verified.get());
        manager.close();
    }

    @Test public void watchFencesOldVersionAndRequiresNewEpochAfterCAS()
            throws Exception {
        NodePartitionGrantTable state=table();
        NodeClusterControlManager manager=new NodeClusterControlManager("NodeA",
            control,state,200L);
        manager.refresh();
        NodePartitionGrantTable.Permit old=manager.requirePrimary("P000",1,
            DurableWalAckPolicy.STRICT_QUORUM);
        manager.onControlChanged();
        denied(old::requireCurrent);
        manager.refresh(); // same Epoch cannot defeat Watch revocation
        assertEquals(1,manager.failedRenewals());
        generation=2;epoch=2;
        clock.addAndGet(10000000L);
        manager.refresh();
        manager.requirePrimary("P000",2,
            DurableWalAckPolicy.STRICT_QUORUM).requireCurrent();
        denied(old::requireCurrent);
        assertEquals(2,manager.successfulRenewals());
        manager.close();
    }

    @Test public void controlQuorumLossCannotRenewExpiredLease()
            throws Exception {
        NodePartitionGrantTable state=table();
        NodeClusterControlManager manager=new NodeClusterControlManager("NodeA",
            control,state,100L);
        manager.refresh();
        quorumAvailable=false;
        clock.addAndGet(900000000L);
        manager.refresh();
        assertEquals(1,manager.failedRenewals());
        denied(()->manager.requirePrimary("P000",1,
            DurableWalAckPolicy.STRICT_QUORUM));
        manager.onSessionLost();
        quorumAvailable=true;
        manager.refresh(); // revocation sticky
        denied(()->manager.requirePrimary("P000",1,
            DurableWalAckPolicy.STRICT_QUORUM));
        generation=2;epoch=2;
        clock.addAndGet(1000000L);
        manager.refresh();
        manager.requirePrimary("P000",2,
            DurableWalAckPolicy.STRICT_QUORUM);
        manager.close();
    }
}
