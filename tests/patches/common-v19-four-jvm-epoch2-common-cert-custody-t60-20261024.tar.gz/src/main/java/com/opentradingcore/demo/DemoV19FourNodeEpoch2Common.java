package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;
import com.app.common.replication.*;
import com.app.common.zk.ZookeeperClient;
import com.gateway.connector.utils.JsonUtils;
import java.io.IOException;
import java.nio.file.*;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.*;
import java.util.concurrent.TimeUnit;
import org.I0Itec.zkclient.exception.ZkNodeExistsException;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.data.Stat;

/**
 * Nontrading T60: exactly two epoch2 recovered partitions and independent
 * per-node Common CommitIndex + Common Custody, against the replayable
 * installed snapshot WAL. All ops remain RECOVERING and deny READY / ACK.
 */
final class DemoV19FourNodeEpoch2Common {
    static final String SIGN="INTERNAL_EPOCH2_COMMON_SIGN_V1";
    static final String INDEX="INTERNAL_EPOCH2_COMMON_INDEX_V1";
    static final String CUSTODY="INTERNAL_EPOCH2_COMMON_CUSTODY_V1";
    static final String SCOPE="EPOCH2_COMMON_CERTIFIED_RECOVERING_NO_READY_V1";
    static final String PROOFS=DemoV19FourNodeShardCatalog.ROOT+"/epoch2-common-proofs";

    private final String node;
    private final Path root;
    private final PrivateKey signingKey;
    DemoV19FourNodeEpoch2Common(String node,Path root)throws Exception{
        if(node==null || !node.matches("CommonHaDemo[ABCD]")
                || root==null || !root.isAbsolute())
            throw new IOException("invalid new epoch physical member");
        this.node=node;this.root=root;
        signingKey=KeyFactory.getInstance("RSA").generatePrivate(
            new PKCS8EncodedKeySpec(Files.readAllBytes(
                root.resolve(".preflight-identity/local.pk8"))));
    }

    private static class Context {
        final PartitionAssignment old;
        final DurableWalCommitQuorum.Membership membership;
        final String walSha;
        final Path newWal;
        Context(PartitionAssignment old,DurableWalCommitQuorum.Membership membership,
                String walSha,Path newWal){
            this.old=old;this.membership=membership;this.walSha=walSha;this.newWal=newWal;
        }
    }
    @SuppressWarnings("unchecked")
    static Context requireBound(ZookeeperClient zk,PartitionAssignment old,
            String node,Path walRoot)throws Exception{
        String part=old.getPartitionId();
        if(!zk.isConnected() || !DemoV19FourNodeSeq1NettyPilot.selected(part)
                || !DemoV19FourNodeLiveRuntime.owners(old).contains(node))
            throw new IOException("new epoch inaccessible partition/member");
        Stat stat=new Stat();
        Object raw=zk.readData(DemoV19FourNodeShardCatalog.ASSIGNMENTS+"/"+part,stat);
        PartitionAssignment a=DemoV19FourNodeEpoch2Transition.requireAssignment(
            zk,old,raw,stat.getVersion());
        if(stat.getVersion()!=1 || a.getEpoch()!=2 || a.isRoutable()
                || !"RECOVERING".equals(a.getState()))
            throw new IOException("new epoch no longer safely recovering");
        DemoV19FourNodeEpoch2Install.verifySavedProof(zk,old);
        Map<String,Object> install=JsonUtils.Deserialize(String.valueOf(
            zk.readData(DemoV19FourNodeEpoch2Install.PROOFS+"/"+part)),Map.class);
        String source=(String)install.get("sourceSha256");
        String digest=(String)install.get("stateSha256");
        String sha=(String)install.get("recoveredWalSha256");
        DemoV19FourNodeEpoch2Install.requirePhysicalInstalled(
            walRoot,old,source,digest,sha);
        DurableWalCommitQuorum.Membership membership=
            DemoV19FourNodeEpoch2Install.successorMembership(zk,old);
        if(membership.epoch!=2 || !a.getPrimary().equals(old.getReplica()))
            throw new IOException("new epoch membership not exact successor");
        if(!zk.isConnected())throw new IOException("ZK quorum lost during certification");
        return new Context(old,membership,sha,walRoot.resolve(
            DemoV19FourNodeEpoch2Install.recoveryDir(part)).resolve("recovered.wal"));
    }
    private static DurableWalCommitQuorum.LocalDurability durability(
            ZookeeperClient zk,Context ctx,String voter,Path root) {
        return (epoch,seq)->{
            if(epoch!=2 || seq!=1)
                throw new IOException("wrong epoch2 commit index boundary");
            Context refreshed=requireBound(zk,ctx.old,voter,root);
            if(!ctx.membership.digest.equals(refreshed.membership.digest)
                    || !ctx.walSha.equals(refreshed.walSha))
                throw new IOException("epoch2 membership or WAL changed");
            try(DemoDurableJournal wal=new DemoDurableJournal(ctx.newWal)){
                if(!wal.isReadyForWrites() || wal.lastEpoch()!=2
                        || wal.committedSeq()!=1 || wal.snapshotSeq()!=1)
                    throw new IOException("epoch2 committed snapshot unavailable");
                return wal.committedPrefixSha256Through(1);
            }
        };
    }
    ReplicationControlResponse handle(ZookeeperClient zk,List<PartitionAssignment> plan,
            DemoV19FourNodeLiveRuntime.HeldWal held,ReplicationControlRequest req){
        try{
            if(req==null || !node.equals(held.node)
                    || !DemoV19FourNodeShardCatalog.SERVICE.equals(req.getServiceName())
                    || !zk.isConnected()
                    || !(SIGN.equals(req.getOperation()) || INDEX.equals(req.getOperation())
                        || CUSTODY.equals(req.getOperation()))
                    || !DemoV19FourNodeSeq1NettyPilot.selected(req.getPartitionId()))
                throw new IOException("invalid new epoch Common protocol request");
            String part=req.getPartitionId();
            PartitionAssignment old=plan.get(Integer.parseInt(part.substring(1)));
            DemoDurableJournal original=held.owned.get(part);
            if(original==null)throw new IOException("source WAL not exclusively owned");
            // Freeze is shared with any outstanding old-source transaction.
            synchronized(original){
                Context ctx=requireBound(zk,old,node,root);
                DurableWalCommitQuorum.LocalDurability local=
                    durability(zk,ctx,node,root);
                if(SIGN.equals(req.getOperation())){
                    if(req.getPayload()==null || req.getPayload().length!=32)
                        throw new IOException("sign challenge must be 32 bytes");
                    DurableWalCommitQuorum.Receipt signed=DurableWalCommitQuorum.sign(
                        ctx.membership,node,1,local,signingKey);
                    DurableWalCommitQuorum.requireValidReceipt(ctx.membership,signed);
                    requireBound(zk,old,node,root);
                    Map<String,Object> out=new LinkedHashMap<>();
                    out.put("scope",SCOPE);out.put("partition",part);
                    out.put("nonce",DemoV19FourNodeGenesisPreflight.hex(req.getPayload()));
                    out.put("vote",DemoV19FourNodeSeq1NettyPilot.wire(signed));
                    out.put("ready",false);out.put("clientAck",false);
                    return ReplicationControlResponse.ok(DemoNettyBridge.json(out));
                }
                if(req.getPayload()==null || req.getPayload().length<20
                        || req.getPayload().length>8192)
                    throw new IOException("invalid double-voter Common payload");
                @SuppressWarnings("unchecked")
                Map<String,Object> input=JsonUtils.Deserialize(
                    new String(req.getPayload(),java.nio.charset.StandardCharsets.UTF_8),
                    Map.class);
                if(input==null || !SCOPE.equals(input.get("scope"))
                        || !part.equals(input.get("partition")))
                    throw new IOException("wrong Common Epoch2 scope or partition");
                List<DurableWalCommitQuorum.Receipt> votes=
                    DemoV19FourNodeSeq1NettyPilot.receiveTwoVotes(input.get("votes"));
                DurableWalCommitQuorum.Certificate certificate=DurableWalCommitQuorum.verify(
                    ctx.membership,1,local.requireFsyncedPrefix(2,1),votes);
                if(certificate.authorizesReady())
                    throw new IOException("certified WAL cannot grant READY");
                if(INDEX.equals(req.getOperation())){
                    if(!node.equals(old.getReplica()))
                        throw new IOException("only new primary can persist new index");
                    try(DurableWalCommitIndex index=new DurableWalCommitIndex(
                            root.resolve(".pilot-epoch2-common-index-"+part),
                            ctx.membership)){
                        if(index.committedSequence()==0)
                            index.certifyAndPersist(1,ctx.walSha,votes);
                        index.requireExactCertified(2,1,ctx.walSha);
                    }
                    requireBound(zk,old,node,root);
                    Map<String,Object> result=new LinkedHashMap<>();
                    result.put("scope",SCOPE);result.put("partition",part);
                    result.put("seq",1);result.put("walSha256",ctx.walSha);
                    result.put("votes",2);result.put("ready",false);
                    result.put("clientAck",false);
                    return ReplicationControlResponse.ok(DemoNettyBridge.json(result));
                }
                DurableWalCertificateCustody.Authority authority=historical->{
                    requireBound(zk,old,node,root);
                    if(!ctx.membership.digest.equals(historical.digest))
                        throw new IOException("new Common custody membership changed");
                };
                DurableWalCustodyQuorum.Receipt receipt;
                try(DurableWalCertificateCustody custody=new DurableWalCertificateCustody(
                        root.resolve(".pilot-epoch2-common-custody-"+part),
                        ctx.membership,local,authority)){
                    if(custody.install(certificate)!=1)
                        throw new IOException("new epoch Common custody install denied");
                    receipt=custody.signInstalled(node,signingKey);
                    DurableWalCustodyQuorum.requireValidReceipt(
                        ctx.membership,certificate,receipt);
                    if(custody.highestVerified()==null
                            || custody.highestVerified().committedSequence!=1)
                        throw new IOException("new epoch custody replay denied");
                }
                requireBound(zk,old,node,root);
                Map<String,Object> result=new LinkedHashMap<>();
                result.put("scope",SCOPE);result.put("partition",part);
                result.put("custody",DemoV19FourNodeSeq1NettyPilot.custodyWire(receipt));
                result.put("ready",false);result.put("clientAck",false);
                return ReplicationControlResponse.ok(DemoNettyBridge.json(result));
            }
        }catch(Exception failure){
            return ReplicationControlResponse.error("EPOCH2_COMMON_DENIED",
                failure.getClass().getSimpleName()+": "+failure.getMessage());
        }
    }
    @SuppressWarnings("unchecked")
    static void verifyProof(ZookeeperClient zk,PartitionAssignment old)throws Exception{
        String part=old.getPartitionId(),path=PROOFS+"/"+part;
        Stat stat=new Stat();Object raw=zk.readData(path,stat);
        if(raw==null || stat.getVersion()!=0)
            throw new IOException("missing permanent Epoch2 Common quorum certificate");
        Map<String,Object> doc=JsonUtils.Deserialize(String.valueOf(raw),Map.class);
        DurableWalCommitQuorum.Membership member=
            DemoV19FourNodeEpoch2Install.successorMembership(zk,old);
        Map<String,Object> install=JsonUtils.Deserialize(String.valueOf(
            zk.readData(DemoV19FourNodeEpoch2Install.PROOFS+"/"+part)),Map.class);
        String sha=(String)install.get("recoveredWalSha256");
        if(!SCOPE.equals(doc.get("scope"))
                || !part.equals(doc.get("partition"))
                || !member.digest.equals(doc.get("membershipSha256"))
                || !sha.equals(doc.get("walSha256"))
                || !(doc.get("votes") instanceof List)
                || !(doc.get("custodies") instanceof List))
            throw new IOException("Common epoch2 source/record replaced");
        List<DurableWalCommitQuorum.Receipt> votes=
            DemoV19FourNodeSeq1NettyPilot.receiveTwoVotes(doc.get("votes"));
        DurableWalCommitQuorum.Certificate cert=
            DurableWalCommitQuorum.verify(member,1,sha,votes);
        List<?> rawCustody=(List<?>)doc.get("custodies");
        if(rawCustody.size()!=2)throw new IOException("Common custody not 2/2");
        List<DurableWalCustodyQuorum.Receipt> signed=new ArrayList<>();
        for(Object entry:rawCustody)
            signed.add(DemoV19FourNodeSeq1NettyPilot.custodyFromWire(entry));
        DurableWalCustodyQuorum.CustodiedCertificate durable=
            DurableWalCustodyQuorum.verify(member,cert,signed);
        if(durable.physicalCustodians!=2 || durable.sequence!=1
                || durable.authorizesPromotion() || cert.authorizesReady())
            throw new IOException("new Epoch2 Common certificate cannot grant READY");
    }
    static void verifyLocalAfterRestart(ZookeeperClient zk,
            PartitionAssignment old,String voter,Path root)throws Exception{
        if(!zk.exists(PROOFS+"/"+old.getPartitionId()))return;
        verifyProof(zk,old);
        Context ctx=requireBound(zk,old,voter,root);
        DurableWalCommitQuorum.LocalDurability local=durability(zk,ctx,voter,root);
        DurableWalCertificateCustody.Authority authority=historical->{
            if(!ctx.membership.digest.equals(historical.digest))
                throw new IOException("saved Common quorum has changed");
        };
        try(DurableWalCertificateCustody store=new DurableWalCertificateCustody(
                root.resolve(".pilot-epoch2-common-custody-"+old.getPartitionId()),
                ctx.membership,local,authority)){
            if(store.highestVerified()==null || store.highestVerified().committedSequence!=1)
                throw new IOException("physical Common epoch2 custody missing at restart");
        }
        if(voter.equals(old.getReplica())){
            try(DurableWalCommitIndex index=new DurableWalCommitIndex(
                    root.resolve(".pilot-epoch2-common-index-"+old.getPartitionId()),
                    ctx.membership)){
                index.requireExactCertified(2,1,ctx.walSha);
            }
        }
    }
    static void certifyTwo(ZookeeperClient zk,List<PartitionAssignment> plan)throws Exception{
        if(!zk.isConnected())throw new IOException("three-ZK Common quorum unavailable");
        DemoV19FourNodeShardCatalog.ensurePath(zk,PROOFS);
        try(DirectNettyReplicationTransport net=new DirectNettyReplicationTransport(
                10000,DirectNettyReplicationServer.DEFAULT_MAX_FRAME_BYTES)){
            for(char lead:new char[]{'A','C'}){
                String part=DemoV19FourNodeGenesisPreflight.firstShard(plan,lead);
                PartitionAssignment old=plan.get(Integer.parseInt(part.substring(1)));
                DemoV19FourNodeEpoch2Install.verifySavedProof(zk,old);
                DurableWalCommitQuorum.Membership member=
                    DemoV19FourNodeEpoch2Install.successorMembership(zk,old);
                Map<String,Object> install=JsonUtils.Deserialize(String.valueOf(
                    zk.readData(DemoV19FourNodeEpoch2Install.PROOFS+"/"+part)),Map.class);
                String walSha=(String)install.get("recoveredWalSha256");
                byte[] challenge=new byte[32];new SecureRandom().nextBytes(challenge);
                String nonce=DemoV19FourNodeGenesisPreflight.hex(challenge);
                List<DurableWalCommitQuorum.Receipt> signed=new ArrayList<>();
                List<Map<String,Object>> votes=new ArrayList<>();
                for(String voter:DemoV19FourNodeLiveRuntime.owners(old)){
                    ReplicationControlResponse reply=net.control(
                        DemoV19FourNodeLiveRuntime.exactEndpoint(voter),
                        new ReplicationControlRequest(DemoV19FourNodeShardCatalog.SERVICE,
                            SIGN,part,challenge)).get(8,TimeUnit.SECONDS);
                    if(!reply.isSuccess())throw new IOException("new epoch Common signer missing: "+
                        voter+" "+reply.getMessage());
                    Map<String,Object> body=DemoNettyBridge.map(reply.getPayload());
                    if(!SCOPE.equals(body.get("scope"))
                            || !nonce.equals(body.get("nonce"))
                            || !Boolean.FALSE.equals(body.get("ready"))
                            || !Boolean.FALSE.equals(body.get("clientAck")))
                        throw new IOException("not a current signed common vote");
                    DurableWalCommitQuorum.Receipt receipt=
                        DemoV19FourNodeSeq1NettyPilot.fromWire(body.get("vote"));
                    if(!voter.equals(receipt.node)
                            || !walSha.equals(receipt.commitPrefixSha256))
                        throw new IOException("Common new source or signer fork");
                    DurableWalCommitQuorum.requireValidReceipt(member,receipt);
                    signed.add(receipt);
                    votes.add(DemoV19FourNodeSeq1NettyPilot.wire(receipt));
                }
                DurableWalCommitQuorum.Certificate certificate=
                    DurableWalCommitQuorum.verify(member,1,walSha,signed);
                Map<String,Object> message=new LinkedHashMap<>();
                message.put("scope",SCOPE);message.put("partition",part);
                message.put("votes",votes);
                ReplicationControlResponse stored=net.control(
                    DemoV19FourNodeLiveRuntime.exactEndpoint(old.getReplica()),
                    new ReplicationControlRequest(DemoV19FourNodeShardCatalog.SERVICE,
                        INDEX,part,DemoNettyBridge.json(message))).get(8,TimeUnit.SECONDS);
                if(!stored.isSuccess())
                    throw new IOException("new Epoch2 primary cannot persist CommitIndex: "+
                        stored.getMessage());
                Map<String,Object> recorded=DemoNettyBridge.map(stored.getPayload());
                if(!SCOPE.equals(recorded.get("scope"))
                        || !Boolean.FALSE.equals(recorded.get("ready"))
                        || !walSha.equals(recorded.get("walSha256")))
                    throw new IOException("new Epoch2 Common CommitIndex incomplete");
                List<DurableWalCustodyQuorum.Receipt> custody=new ArrayList<>();
                List<Map<String,Object>> wireCustody=new ArrayList<>();
                for(String custodian:DemoV19FourNodeLiveRuntime.owners(old)){
                    ReplicationControlResponse response=net.control(
                        DemoV19FourNodeLiveRuntime.exactEndpoint(custodian),
                        new ReplicationControlRequest(DemoV19FourNodeShardCatalog.SERVICE,
                            CUSTODY,part,DemoNettyBridge.json(message))).get(8,TimeUnit.SECONDS);
                    if(!response.isSuccess())
                        throw new IOException("new Common custody missing "+custodian+
                            ": "+response.getMessage());
                    Map<String,Object> body=DemoNettyBridge.map(response.getPayload());
                    if(!SCOPE.equals(body.get("scope"))
                            || !Boolean.FALSE.equals(body.get("ready"))
                            || !Boolean.FALSE.equals(body.get("clientAck")))
                        throw new IOException("unexpected recovered Common custody reply");
                    DurableWalCustodyQuorum.Receipt receipt=
                        DemoV19FourNodeSeq1NettyPilot.custodyFromWire(body.get("custody"));
                    if(!custodian.equals(receipt.node))
                        throw new IOException("wrong new Epoch Common custodian");
                    DurableWalCustodyQuorum.requireValidReceipt(member,certificate,receipt);
                    custody.add(receipt);wireCustody.add(
                        DemoV19FourNodeSeq1NettyPilot.custodyWire(receipt));
                }
                DurableWalCustodyQuorum.CustodiedCertificate checked=
                    DurableWalCustodyQuorum.verify(member,certificate,custody);
                if(checked.physicalCustodians!=2 || checked.sequence!=1
                        || checked.authorizesPromotion())
                    throw new IOException("Common epoch2 custody has insufficient voters");
                Map<String,Object> durable=new LinkedHashMap<>();
                durable.put("scope",SCOPE);durable.put("partition",part);
                durable.put("membershipSha256",member.digest);
                durable.put("walSha256",walSha);
                durable.put("votes",votes);durable.put("custodies",wireCustody);
                String path=PROOFS+"/"+part;
                if(!zk.exists(path)){
                    try{zk.create(path,JsonUtils.Serializer(durable),CreateMode.PERSISTENT);}
                    catch(ZkNodeExistsException raced){}
                }
                verifyProof(zk,old);
                System.out.println("FOUR_NODE_EPOCH2_COMMON_CERT_CUSTODY_PASS partition="+part+
                    " newPrimary="+old.getReplica()+" epoch=2 seq=1"+
                    " commonIndexFsynced=true commonReceipts=2 commonCustodies=2"+
                    " physicalRecoveredWalSha="+walSha+" ready=false clientAck=false");
            }
        }
    }
}