package com.opentradingcore.demo;

import com.app.common.replication.*;
import com.app.common.zk.ZookeeperClient;
import com.gateway.connector.utils.JsonUtils;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyFactory;
import java.security.spec.X509EncodedKeySpec;
import java.util.*;
import java.util.concurrent.TimeUnit;
import org.apache.zookeeper.data.Stat;

/** Isolated RF2 new-epoch strict write ACK. Never falls back to local ACK
 * if a majority signer, fsynced WAL replica, or custody witness is missing.
 * Caller serializes append+certify by the Demo writer's per-node ACK mutex.
 */
final class DemoV19Rf2StrictAckRuntime {
    private static final String PATH=DemoZkFenceSource.ISOLATED_ROOT
        +"/harness/assignments/P000";
    private final ZookeeperClient zk;
    private final DemoJournalCatalog journals;
    private final DemoAsyncReplicator async;
    private final String node;
    private final DemoV19Rf2DynamicReceiptService localSigner;
    /** One long-lived exact-node Netty client for all consecutive strict
     * ACK certificates. A new client per WAL append incurred the default
     * 2-second graceful EventLoop shutdown quiet-period EVERY request.
     * Current assignment and signatures are still verified for EVERY write. */
    private final DemoV19TcpClient tcp=new DemoV19TcpClient();
    /** A single exclusive durable writer owns this Common CommitIndex until
     * the authenticated Epoch/configuration changes. Opening it on EVERY
     * request replays every historical RSA certificate and grows O(N^2).
     * Never share across different epochs or signed memberships. */
    private DurableWalCommitIndex activeIndex;
    private String activeIndexIdentity;
    /** Parsed RSA voter keys are immutable for a pinned ZK configuration.
     * Re-reading and parsing both DER files for beforeAppend AND certify
     * costs disk/ASN.1 work per business command. Revoke cache whenever
     * ZK assignment version, epoch, config or authenticated primary changes. */
    private DurableWalCommitQuorum.Membership cachedMembers;
    private String cachedMembersIdentity;
    private synchronized DurableWalCommitIndex indexFor(Pinned pinned,
            DurableWalCommitQuorum.Membership membership)throws Exception {
        String key=pinned.plan.epoch+":"+pinned.plan.configVersion+":"+
            membership.digest;
        if(activeIndex!=null && !key.equals(activeIndexIdentity)){
            activeIndex.close();
            activeIndex=null;
            activeIndexIdentity=null;
        }
        if(activeIndex==null){
            activeIndex=new DurableWalCommitIndex(indexDir(pinned.plan),membership);
            activeIndexIdentity=key;
            System.out.println("RF2_STRICT_INDEX_REUSED_WRITER_STARTED epoch="+
                pinned.plan.epoch+" config="+pinned.plan.configVersion);
        }
        return activeIndex;
    }
    DemoV19Rf2StrictAckRuntime(ZookeeperClient zk,String node,
            DemoJournalCatalog journals,DemoAsyncReplicator async,
            DemoV19Rf2DynamicReceiptService sharedSigner) throws Exception {
        this.zk=Objects.requireNonNull(zk);
        this.node=Objects.requireNonNull(node);
        this.journals=Objects.requireNonNull(journals);
        this.async=Objects.requireNonNull(async);
        // A Netty APPEND handler MUST NOT make a synchronous Netty RPC to
        // its own event loop. Use the EXACT same verified Common RPC handler
        // in-process, and remote Netty only for the independent other voter.
        // Reuse the SAME local handler as the server's Netty receipt path.
        // Two separate cached physical Custody instances on the same node
        // would contend for a java.nio FileLock and falsely deny customer ACK.
        this.localSigner=Objects.requireNonNull(sharedSigner,
            "one shared custody signer per physical JVM");
    }
    DurableWalCommitQuorum.Receipt localSignedReceipt(
            DurableWalCommitQuorum.Membership members,long seq)throws Exception{
        ReplicationControlRequest original=DurableWalReceiptControlHandler.request(members,seq);
        ReplicationControlResponse answer=localSigner.handle(new ReplicationControlRequest(
            original.getServiceName(),DemoV19Rf2DynamicReceiptService.OPERATION,
            original.getPartitionId(),original.getPayload()));
        if(!answer.isSuccess())throw new IOException("local durable receipt denied: "+answer.getMessage());
        DurableWalCommitQuorum.Receipt receipt=
            DurableWalReceiptControlHandler.decodeReceiptPayload(answer.getPayload());
        DurableWalCommitQuorum.requireValidReceipt(members,receipt);
        if(!node.equals(receipt.node))throw new IOException("local physical signer wrong");
        return receipt;
    }
    DurableWalCustodyQuorum.Receipt localInstalledCustody(
            DurableWalCommitQuorum.Membership members,
            DurableWalCommitQuorum.Certificate certificate)throws Exception {
        ReplicationControlRequest original=
            DurableWalCertificateCustodyControlHandler.request(members,certificate);
        ReplicationControlResponse answer=localSigner.handleCustody(new ReplicationControlRequest(
            original.getServiceName(),DemoV19Rf2DynamicReceiptService.CUSTODY_OPERATION,
            original.getPartitionId(),original.getPayload()));
        if(!answer.isSuccess())throw new IOException("local physical custody denied: "+answer.getMessage());
        return DurableWalCertificateCustodyControlHandler.decodeVerified(
            members,certificate,node,answer);
    }
    private static final class Pinned {
        final int version;
        final DemoV19Rf2DynamicReceiptService.Plan plan;
        final String raw;
        Pinned(int version,DemoV19Rf2DynamicReceiptService.Plan plan,String raw){
            this.version=version;this.plan=plan;this.raw=raw;
        }
    }
    private Pinned readActive()throws Exception {
        if(!zk.isConnected())throw new IOException("control quorum unavailable");
        Stat stat=new Stat();
        Object raw=zk.readData(PATH,stat);
        if(raw==null)throw new IOException("no strict assignment");
        @SuppressWarnings("unchecked") Map<String,Object> fields=
            JsonUtils.Deserialize(String.valueOf(raw),Map.class);
        DemoV19Rf2DynamicReceiptService.Plan plan=
            DemoV19Rf2DynamicReceiptService.requirePlan(fields);
        if(plan.preparing || !node.equals(plan.primary))
            throw new IOException("no strict READY primary grant");
        DemoHotpathControl.requireCurrent("P000",plan.epoch,node,null);
        return new Pinned(stat.getVersion(),plan,String.valueOf(raw));
    }
    boolean strictReadyFor(String candidate) {
        if(!node.equals(candidate))return false;
        try{readActive();return true;}
        catch(Exception notReady){return false;}
    }
    private void requireSame(Pinned pinned)throws Exception {
        if(!zk.isConnected())throw new IOException("no ZK majority for strict ACK");
        Stat stat=new Stat();
        Object current=zk.readData(PATH,stat);
        if(current==null || stat.getVersion()!=pinned.version
                || !pinned.raw.equals(String.valueOf(current)))
            throw new IOException("strict ZK assignment changed during commit");
        DemoHotpathControl.requireCurrent("P000",pinned.plan.epoch,node,null);
    }
    private synchronized DurableWalCommitQuorum.Membership members(Pinned pinned)throws Exception {
        String key=pinned.version+":"+pinned.plan.epoch+":"+
            pinned.plan.configVersion+":"+pinned.plan.primary;
        if(cachedMembers!=null && key.equals(cachedMembersIdentity))
            return cachedMembers;
        KeyFactory rsa=KeyFactory.getInstance("RSA");
        List<DurableWalCommitQuorum.Member> voters=new ArrayList<>();
        for(char suffix='A';suffix<='B';suffix++){
            String id="CommonHaDemo"+suffix;
            voters.add(new DurableWalCommitQuorum.Member(
                    id,"simulated-single-mac-jvm-"+suffix,
                    rsa.generatePublic(new X509EncodedKeySpec(Files.readAllBytes(
                        Paths.get("/srv/v19/identities",id+".pub.der"))))));
        }
        DurableWalCommitQuorum.Membership built=
            new DurableWalCommitQuorum.Membership(
                "CommonHaDemo","P000",node,pinned.plan.epoch,
                pinned.plan.configVersion,voters);
        cachedMembers=built;
        cachedMembersIdentity=key;
        return built;
    }
    /** Fast *intermediate* fence; does not authorize an ACK. Every strict
     * request still starts with a fresh ZK assignment and ends with fresh
     * version/CAS reads in BOTH Common durable ACK gates, plus the remote
     * signer and both physical Custody authority checks. Never substitute
     * this for the final ZK authorization or physical durable witnesses. */
    private void requireSameLocal(Pinned pinned)throws Exception {
        if(!DemoHotpathControl.enabled("P000")) {
            requireSame(pinned);
            return;
        }
        if(!zk.isConnected())throw new IOException("lost ZK quorum in strict preparation");
        DemoHotpathControl.requireCurrent("P000",pinned.plan.epoch,node,null);
    }
    /** For new commands refuse to jump past any unacknowledged, dirty WAL.
     * An EXACT same request may retry its already locally fsynced sequence.
     */
    void beforeAppend(String requestId,long delta)throws Exception{
        Pinned pinned=readActive();
        DurableWalCommitIndex index=indexFor(pinned,members(pinned));
        {
            long certified=index.committedSequence();
            DemoDurableJournal wal=journals.journal("P000");
            synchronized(wal) {
                if(!wal.isReadyForWrites())
                    throw new IOException("unclean strict primary WAL");
                if(certified< pinned.plan.genesisSeq || certified>wal.committedSeq())
                    throw new IOException("strict Genesis not durable");
                if(certified!=wal.committedSeq()) {
                    DemoDurableJournal.CommittedRequest previous=wal.committedRequest(requestId);
                    if(previous==null || previous.seq!=wal.committedSeq() || previous.delta!=delta)
                        throw new IOException("previous WAL tail not strictly ACK certified");
                }
            }
            requireSameLocal(pinned);
        }
    }
    private java.nio.file.Path indexDir(DemoV19Rf2DynamicReceiptService.Plan p) {
        return Paths.get("/srv/v19/wal/.strict-epoch-"+p.epoch+"-config-"+p.configVersion);
    }
    static void requireMatchedRemote(Map<String,Object> remote,String replica,
            long seq,String expectedHash)throws IOException{
        if(remote==null || !replica.equals(remote.get("localNode"))
                || !Boolean.TRUE.equals(remote.get("clean"))
                || !(remote.get("committedSeq") instanceof Number)
                || ((Number)remote.get("committedSeq")).longValue()!=seq
                || !expectedHash.equals(remote.get("committedPrefixSha256")))
            throw new IOException("physical replica WAL not fsynced at exact strict ACK");
    }

    DurableWalCommitAckGate.Confirmed certifyAfterAppend(long epoch,long seq)throws Exception {
        return certifyAfterAppend(epoch,seq,seq);
    }
    /** One signed/custodied high-water certificate for a contiguous forced
     * WAL batch. Individual request ACKs still use the Common covered gate.
     * No gaps, no mixed epoch, and never a local-only "quorum" ACK. */
    DurableWalCommitAckGate.Confirmed certifyAfterAppend(
            long epoch,long first,long seq)throws Exception {
        if(first<1 || first>seq || seq-first>=32)
            throw new IOException("unbounded strict client WAL batch");
        long started=System.nanoTime();
        Pinned pinned=readActive();
        if(pinned.plan.epoch!=epoch || seq<=pinned.plan.genesisSeq)
            throw new IOException("new strict WAL seq not in pinned epoch");
        DemoDurableJournal wal=journals.journal("P000");
        String sha;
        synchronized(wal){
            if(!wal.isReadyForWrites() || wal.lastEpoch()!=epoch || wal.committedSeq()!=seq)
                throw new IOException("strict writer WAL not exact new epoch boundary");
            sha=wal.committedPrefixSha256Through(seq);
        }
        DurableWalCommitQuorum.Membership membership=members(pinned);
        {
            DurableWalCommitIndex index=indexFor(pinned,membership);
            long frontier=index.committedSequence();
            if(frontier!=seq && frontier!=first-1)
                throw new IOException("strict ACK skipped uncertified WAL tail");
            requireSameLocal(pinned);
            if(frontier<seq){
                async.signal("P000");
                long deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(3);
                Exception lag=null;
                while(System.nanoTime()<deadline){
                    requireSameLocal(pinned);
                    try{
                        requireMatchedRemote(tcp.status(pinned.plan.replica),
                            pinned.plan.replica,seq,sha);
                        lag=null;break;
                    }catch(Exception stalled){lag=stalled;}
                    Thread.sleep(25);
                }
                if(lag!=null)throw new IOException("strict remote fsync lag",lag);
                DurableWalCommitQuorum.Receipt a=localSignedReceipt(membership,seq);
                DurableWalCommitQuorum.Receipt b=tcp.signedDynamicReceipt(
                    pinned.plan.replica,membership,seq);
                DurableWalCommitQuorum.verify(membership,seq,sha,Arrays.asList(a,b));
                requireSame(pinned);
                if(first==seq)
                    index.certifyAndPersist(seq,sha,Arrays.asList(a,b));
                else
                    index.certifyAndPersistBatch(first,seq,sha,Arrays.asList(a,b),
                        (e,s)->{
                            synchronized(wal){
                                if(e!=epoch || !wal.isReadyForWrites()
                                        || wal.committedSeq()<s)
                                    throw new IOException("batch WAL durability not established");
                                return wal.committedPrefixSha256Through(s);
                            }
                        });
            }
            System.out.println("RF2_STRICT_ACK_STAGE seq="+seq+" phase=certificate elapsedMs="+
                TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-started));
            DurableWalCommitQuorum.Certificate exact=index.verifiedHighestCertificate();
            if(exact==null || exact.committedSequence!=seq
                    || !sha.equals(exact.commitPrefixSha256))
                throw new IOException("strict signed certificate missing from disk");
            DurableWalCustodyQuorum.Receipt local=localInstalledCustody(membership,exact);
            System.out.println("RF2_STRICT_ACK_STAGE seq="+seq+" phase=localCustody elapsedMs="+
                TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-started));
            DurableWalCustodyQuorum.Receipt remote=tcp.installDynamicCustody(
                    pinned.plan.replica,membership,exact);
            System.out.println("RF2_STRICT_ACK_STAGE seq="+seq+" phase=remoteCustody elapsedMs="+
                TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-started));
            requireSame(pinned);
            DurableWalCertificateCustodyAckGate.requireDurableBeforeAck(
                membership,exact,Arrays.asList(local,remote),
                ignored->requireSame(pinned),
                (e,s)->{
                    synchronized(wal){
                        if(e!=epoch || wal.committedSeq()<s || !wal.isReadyForWrites())
                            throw new IOException("local WAL not fsynced for strict ACK");
                        return wal.committedPrefixSha256Through(s);
                    }
                });
            DurableWalCommitAckGate.Confirmed ack=DurableWalCommitAckGate.requireDurable(
                membership,index,seq,sha,
                (partition,e)->requireSame(pinned));
            System.out.println("RF2_STRICT_ACK_STAGE seq="+seq+" phase=finalACK elapsedMs="+
                TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-started));
            return ack;
        }
    }

    /** One Common high-water covered gate plus exact forced identity for
     * every individual group entry. This is equivalent to per-entry prefix
     * inclusion but avoids 8 x majority ZK read and 8 x certified-end SHA.
     * The caller owns the per-partition ACK mutex throughout. */
    void requireCoveredCommands(long epoch,long first,
            List<DemoStateMachine.Operation> commands)throws Exception {
        if(commands==null || commands.isEmpty() || commands.size()>32)
            throw new IOException("invalid strict ACK covered request count");
        Pinned pinned=readActive();
        if(pinned.plan.epoch!=epoch)
            throw new IOException("strict grant changed before covered ACK");
        DemoDurableJournal wal=journals.journal("P000");
        DurableWalCommitQuorum.Membership membership=members(pinned);
        long last=first+commands.size()-1;
        String lastPrefix;
        // Both checks require the same immutable fsynced WAL and current
        // runtime grant. A corrupt/mismatched requestId or amount must NEVER
        // be ACKed by a cumulative certificate for another request.
        synchronized(wal){
            if(!wal.isReadyForWrites() || wal.lastEpoch()!=epoch
                    || wal.committedSeq()<last)
                throw new IOException("strict batch head not durably forced");
            for(int i=0;i<commands.size();i++){
                DemoStateMachine.Operation op=commands.get(i);
                wal.requireForcedCommitted(epoch,first+i,op.requestId,op.delta);
            }
            lastPrefix=wal.committedPrefixSha256Through(last);
        }
        DurableWalCommitIndex index=indexFor(pinned,membership);
        {
            DurableWalCommitAckGate.Confirmed covered=
                DurableWalCommitAckGate.requireDurableCovered(
                    membership,index,last,lastPrefix,
                    (e,s)->{
                        synchronized(wal){
                            if(e!=epoch || !wal.isReadyForWrites()
                                    || wal.committedSeq()<s)
                                throw new IOException("covered WAL not forced");
                            return wal.committedPrefixSha256Through(s);
                        }
                    },
                    (part,e)->requireSame(pinned));
            if(covered.sequence!=last || !lastPrefix.equals(covered.prefixSha256))
                throw new IOException("strict high-water group inclusion failed");
            requireSame(pinned);
        }
    }
}
