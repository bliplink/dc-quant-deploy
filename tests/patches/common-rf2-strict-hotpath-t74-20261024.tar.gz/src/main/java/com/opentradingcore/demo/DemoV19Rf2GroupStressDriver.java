package com.opentradingcore.demo;

import com.gateway.connector.utils.JsonUtils;
import java.util.*;
import java.util.concurrent.*;

/** Explicit RF2 strict Netty GROUP performance; reports actual WAL ACKs.
 * Not comparable to one-RPC-per-WAL TPS. A group is confirmed only AFTER
 * a signed high-water CommitIndex and TWO independent physical Custodies. */
public final class DemoV19Rf2GroupStressDriver {
    private static Double percentile(List<Long> ms,int pc){
        if(ms.isEmpty())return null;
        Collections.sort(ms);
        return ms.get(Math.min(ms.size()-1,
            Math.max(0,(int)Math.ceil(ms.size()*pc/100.0)-1)))/1000.0;
    }
    public static void main(String[] argv)throws Exception {
        if(argv.length!=5 || !"--isolated".equals(argv[0])
                || !argv[1].matches("[AB]"))
            throw new IllegalArgumentException("--isolated A|B batches workers groupSize");
        final int batches=Integer.parseInt(argv[2]);
        final int workers=Integer.parseInt(argv[3]);
        final int size=Integer.parseInt(argv[4]);
        if(batches<1 || batches>200 || workers<1 || workers>8
                || size<2 || size>32)
            throw new IllegalArgumentException("strict: batches 1..200 workers<=8 group 2..32");
        final String node="CommonHaDemo"+argv[1];
        final String unique="t74group-"+Long.toHexString(System.nanoTime())+"-";
        ExecutorService executor=Executors.newFixedThreadPool(workers);
        CompletionService<Object[]> responses=new ExecutorCompletionService<>(executor);
        try(DemoV19TcpClient client=new DemoV19TcpClient(12000)) {
            long startSeq=((Number)client.status(node).get("committedSeq")).longValue();
            long start=System.nanoTime();
            for(int batch=0;batch<batches;batch++){
                final int id=batch;
                responses.submit(()->{
                    List<Map<String,Object>> commands=new ArrayList<>();
                    for(int i=0;i<size;i++){
                        Map<String,Object> command=new LinkedHashMap<>();
                        command.put("partitionId","P000");
                        command.put("partitionKey","v19-p000-key-123");
                        command.put("requestId",unique+id+"-"+i);
                        command.put("delta",1L);
                        commands.add(command);
                    }
                    long begin=System.nanoTime();
                    String failure=null;
                    try{
                        Map<String,Object> result=client.appendGroup(node,commands);
                        if(!"QUORUM_DURABLE".equals(result.get("durabilityMode"))
                                || !Boolean.TRUE.equals(result.get("quorumDurable"))
                                || !Boolean.FALSE.equals(result.get(
                                    "possibleDataLossIfPrimaryPermanentlyLost"))
                                || !Integer.valueOf(0).equals(((Number)result.get("code")).intValue())
                                || ((Number)result.get("count")).intValue()!=size
                                || !(result.get("requests") instanceof List)
                                || ((List<?>)result.get("requests")).size()!=size)
                            failure="incorrect strict group ACK evidence: "+result;
                    }catch(Exception exception){
                        failure=exception.getClass().getSimpleName()+": "+exception.getMessage();
                    }
                    return new Object[]{TimeUnit.NANOSECONDS.toMicros(
                        System.nanoTime()-begin),failure};
                });
            }
            int accepted=0;
            List<Long> successfulLatency=new ArrayList<>();
            List<String> examples=new ArrayList<>();
            for(int i=0;i<batches;i++){
                Object[] result=responses.take().get();
                if(result[1]==null){
                    accepted++;
                    successfulLatency.add((Long)result[0]);
                } else if(examples.size()<5)examples.add((String)result[1]);
            }
            double elapsed=(System.nanoTime()-start)/1e9;
            long endSeq=((Number)client.status(node).get("committedSeq")).longValue();
            Map<String,Object> metrics=new LinkedHashMap<>();
            metrics.put("case","Common_RF2_STRICT_real_Netty_bounded_WAL_group");
            metrics.put("groups",batches);
            metrics.put("groupSize",size);
            metrics.put("workers",workers);
            metrics.put("acceptedGroups",accepted);
            metrics.put("acceptedWalAcks",accepted*size);
            metrics.put("failedGroups",batches-accepted);
            metrics.put("walAckTps",accepted*size/elapsed);
            metrics.put("groupAckTps",accepted/elapsed);
            metrics.put("p50GroupAckMs",percentile(successfulLatency,50));
            metrics.put("p95GroupAckMs",percentile(successfulLatency,95));
            metrics.put("p99GroupAckMs",percentile(successfulLatency,99));
            metrics.put("startSeq",startSeq);
            metrics.put("endSeq",endSeq);
            metrics.put("physicalSeqDelta",endSeq-startSeq);
            metrics.put("failures",examples);
            metrics.put("limit","one physical Mac; batch=one group RPC, NOT one RPC per WAL");
            System.out.println("T74_STRICT_GROUP_ACK_STRESS "+JsonUtils.Serializer(metrics));
            if(accepted!=batches || endSeq-startSeq!=batches*size)
                throw new IllegalStateException("Strict quorum group not fully ACKed");
        } finally {executor.shutdownNow();}
    }
}