package com.opentradingcore.demo;

import com.gateway.connector.utils.JsonUtils;
import java.util.*;
import java.util.concurrent.*;

/** Bounded real Netty RF2 strict-vs-solo client-write stress.
 * Counts ACKs, not synthetic requests or business orders.
 * Mixed modes are NOT interchangeable: solo ACK has RPO risk.
 */
public final class DemoV19Rf2StressDriver {
    private static final class Outcome {
        final long latencyUs;
        final String failure;
        Outcome(long latencyUs,String failure){this.latencyUs=latencyUs;this.failure=failure;}
    }
    private static Double percentile(List<Long> values, int pc) {
        if(values.isEmpty())return null;
        Collections.sort(values);
        return values.get(Math.min(values.size()-1,
            Math.max(0,(int)Math.ceil(values.size()*pc/100.0)-1)))/1000.0;
    }
    public static void main(String[] args)throws Exception {
        if(args.length!=5 || !"--isolated".equals(args[0])
                || !args[1].matches("[AB]"))
            throw new IllegalArgumentException("--isolated A|B count workers strict|solo|local");
        final int count=Integer.parseInt(args[2]);
        final int workers=Integer.parseInt(args[3]);
        final String mode=args[4];
        if(count<1 || count>1600 || workers<1 || workers>16
                || !("strict".equals(mode) || "solo".equals(mode)
                     || "local".equals(mode)))
            throw new IllegalArgumentException("bounded strict|solo|local 1..1600 count workers<=16");
        final String node="CommonHaDemo"+args[1];
        final String expected="strict".equals(mode)?"QUORUM_DURABLE":
            "solo".equals(mode)?"AUTO_DEGRADED_LOCAL_DURABLE":"LOCAL_DURABLE_ASYNC";
        ExecutorService pool=Executors.newFixedThreadPool(workers);
        CompletionService<Outcome> queue=new ExecutorCompletionService<>(pool);
        String prefix="t67-rf2-"+mode+"-"+Long.toHexString(System.nanoTime())+"-";
        // Identical per-request transport deadline for BOTH ACK policies:
        // compare actual single-operation client ACK, never an 8/32 WAL group.
        try(DemoV19TcpClient tcp=new DemoV19TcpClient(12000)){
            Map<String,Object> before=tcp.status(node);
            final long beginSeq=((Number)before.get("committedSeq")).longValue();
            long started=System.nanoTime();
            for(int i=0;i<count;i++){
                final int n=i;
                queue.submit(()->{
                    Map<String,Object> command=new LinkedHashMap<>();
                    command.put("partitionId","P000");
                    command.put("partitionKey","v19-p000-key-123");
                    command.put("requestId",prefix+n);
                    command.put("delta",1L);
                    long begin=System.nanoTime();
                    String fail=null;
                    try{
                        Map<String,Object> ack=tcp.append(node,command);
                        if(!expected.equals(ack.get("durabilityMode"))
                                || ((Number)ack.get("code")).intValue()!=0
                                || ((Number)ack.get("appliedCount")).intValue()!=1)
                            fail="not an ACK of expected durability "+ack;
                        if(fail==null && "strict".equals(mode)
                                && (!Boolean.TRUE.equals(ack.get("quorumDurable"))
                                    || !Boolean.FALSE.equals(
                                        ack.get("possibleDataLossIfPrimaryPermanentlyLost"))))
                            fail="strict ACK without exact 2/2 durable semantics";
                        if(fail==null && ("solo".equals(mode) || "local".equals(mode))
                                && (!Boolean.FALSE.equals(ack.get("quorumDurable"))
                                    || !Boolean.TRUE.equals(
                                        ack.get("possibleDataLossIfPrimaryPermanentlyLost"))))
                            fail="unsafe solo ACK: missing explicit RPO-risk classification";
                    }catch(Exception ex){
                        fail=ex.getClass().getSimpleName()+": "+ex.getMessage();
                    }
                    return new Outcome(
                        TimeUnit.NANOSECONDS.toMicros(System.nanoTime()-begin),fail);
                });
            }
            List<Long> successes=new ArrayList<>(),all=new ArrayList<>();
            List<String> examples=new ArrayList<>();
            int accepted=0,failed=0;
            for(int i=0;i<count;i++){
                Outcome r=queue.take().get();
                all.add(r.latencyUs);
                if(r.failure==null){accepted++;successes.add(r.latencyUs);}
                else {failed++;if(examples.size()<6)examples.add(r.failure);}
            }
            double elapsed=(System.nanoTime()-started)*1e-9;
            Map<String,Object> after=null;
            int statusTimeouts=0;
            String statusError=null;
            // A status RPC might time out during a heavy final ACK backlog.
            // Keep the completed client ACK metrics independent of STATUS.
            for(int retry=0;retry<4 && after==null;retry++){
                try{after=tcp.status(node);}
                catch(Exception e){
                    statusTimeouts++;
                    statusError=e.getClass().getSimpleName()+": "+e.getMessage();
                    Thread.sleep(750);
                }
            }
            long endSeq=after==null?-1L:
                ((Number)after.get("committedSeq")).longValue();
            Map<String,Object> result=new LinkedHashMap<>();
            result.put("case","Common_RF2_one_shard_real_Netty_ACK");
            result.put("node",node);result.put("durabilityMode",expected);
            result.put("virtualClients",count);result.put("workers",workers);
            result.put("nettyDeadlineMs",12000);
            result.put("attemptedWrites",count);result.put("acknowledgedWrites",accepted);
            result.put("failedOrTimedOut",failed);
            result.put("ackWriteTPS",accepted/elapsed);
            result.put("attemptWriteTPS",count/elapsed);
            result.put("p50AcknowledgedMs",percentile(successes,50));
            result.put("p95AcknowledgedMs",percentile(successes,95));
            result.put("p99AcknowledgedMs",percentile(successes,99));
            result.put("p99AllMs",percentile(all,99));
            result.put("elapsedSec",elapsed);
            result.put("startSeq",beginSeq);result.put("endSeq",endSeq);
            result.put("sequenceDelta",endSeq<0?null:endSeq-beginSeq);
            result.put("statusTimeouts",statusTimeouts);
            result.put("lastStatusError",statusError);
            result.put("failureExamples",examples);
            result.put("warning","one physical Mac, simulated clients, not tenant/order TPS");
            System.out.println("T67_RF2_SINGLE_ACK_STRESS "+JsonUtils.Serializer(result));
            // A client timeout may follow a durable commit. NEVER silently
            // classify those as successful client ACKs or lost business data.
            if(failed!=0 || endSeq-beginSeq!=count)
                throw new IllegalStateException("RF2 ACK failures="+failed+
                    " physical WAL delta="+(endSeq-beginSeq)+" expected="+count);
        } finally {
            pool.shutdownNow();
        }
    }
}
