package com.opentradingcore.demo;

import com.app.common.zk.ZookeeperClient;
import org.apache.zookeeper.CreateMode;

/** One explicit ACK-policy selector for the isolated RF2 Common pilot.
 * This is a STARTUP policy for a newly bootstrapped ZK assignment, NOT a
 * runtime grant or an online mode transition. A different policy on the
 * same durable ZK ensemble must fail closed rather than weaken prior ACKs.
 * Production requires an authenticated epoch CAS + old-writer revocation.
 */
final class DemoV19AckPolicy {
    private static final String ROOT=DemoZkFenceSource.ISOLATED_ROOT
            +"/harness/ack-policy";
    enum Mode { STRICT_QUORUM, LOCAL_DURABLE_ASYNC }
    final Mode mode;
    private DemoV19AckPolicy(Mode mode){this.mode=mode;}
    static DemoV19AckPolicy fromEnvironment(){
        String value=System.getenv("DEMO_V19_ACK_POLICY");
        if(value==null || value.trim().isEmpty())return null; // legacy test configs
        if(!value.equals(value.trim()))
            throw new IllegalArgumentException("ACK policy has whitespace");
        try {return new DemoV19AckPolicy(Mode.valueOf(value));}
        catch(IllegalArgumentException invalid){
            throw new IllegalArgumentException(
                "unknown DEMO_V19_ACK_POLICY; use STRICT_QUORUM or LOCAL_DURABLE_ASYNC");
        }
    }
    boolean strict(){return mode==Mode.STRICT_QUORUM;}
    boolean local(){return mode==Mode.LOCAL_DURABLE_ASYNC;}
    /** Called ONLY by the bootstrapping process after the ZK root exists. */
    void bootstrap(ZookeeperClient zk){
        if(!zk.exists(ROOT)) {
            try {zk.create(ROOT,mode.name(),CreateMode.PERSISTENT);}
            catch(org.I0Itec.zkclient.exception.ZkNodeExistsException concurrent){}
        }
        requireCurrent(zk);
    }
    /** Prevent changing durability on the same assignment by a restart/env flip.
     * Independent epoch transition with proof is deliberately not exposed. */
    void requireCurrent(ZookeeperClient zk){
        if(!zk.exists(ROOT) || !mode.name().equals(zk.readData(ROOT)))
            throw new IllegalStateException(
                "ACK_POLICY_CHANGE_REQUIRES_AUTHORIZED_EPOCH_CUTOVER: configured="+
                mode+" zk="+(zk.exists(ROOT)?zk.readData(ROOT):"MISSING"));
    }
}
