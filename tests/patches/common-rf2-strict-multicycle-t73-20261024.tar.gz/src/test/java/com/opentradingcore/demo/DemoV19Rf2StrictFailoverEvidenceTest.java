package com.opentradingcore.demo;

import org.junit.Test;
import static org.junit.Assert.*;

public final class DemoV19Rf2StrictFailoverEvidenceTest {
    private static final String SHA=
        "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef";
    private static DemoV19Rf2StrictFailoverEvidence.Proof known(){
        return new DemoV19Rf2StrictFailoverEvidence.Proof(5,11,65,
            "CommonHaDemoA",SHA);
    }
    @Test public void exactPreCasOldCustodyHeadMayBeReusedOnlyWithoutNewGrant() {
        assertTrue(DemoV19Rf2StrictFailoverEvidence.exactPreCasOldCustodyHead(
            known(),5,11,"CommonHaDemoA",65,SHA));
        assertFalse(DemoV19Rf2StrictFailoverEvidence.exactPreCasOldCustodyHead(
            null,5,11,"CommonHaDemoA",65,SHA));
        assertFalse(DemoV19Rf2StrictFailoverEvidence.exactPreCasOldCustodyHead(
            known(),4,11,"CommonHaDemoA",65,SHA));
        assertFalse(DemoV19Rf2StrictFailoverEvidence.exactPreCasOldCustodyHead(
            known(),5,12,"CommonHaDemoA",65,SHA));
        assertFalse(DemoV19Rf2StrictFailoverEvidence.exactPreCasOldCustodyHead(
            known(),5,11,"CommonHaDemoB",65,SHA));
        assertFalse(DemoV19Rf2StrictFailoverEvidence.exactPreCasOldCustodyHead(
            known(),5,11,"CommonHaDemoA",66,SHA));
        assertFalse(DemoV19Rf2StrictFailoverEvidence.exactPreCasOldCustodyHead(
            known(),5,11,"CommonHaDemoA",65,
            "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }
}