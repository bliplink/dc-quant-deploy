package com.opentradingcore.demo;

import com.app.common.partition.PartitionReadinessGuard;
import com.app.common.zk.ZookeeperClient;
import org.apache.zookeeper.CreateMode;

import java.nio.file.Paths;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * P000-only, physically isolated v19 integration harness.
 * Real ZK 3-server ensemble + two independent JVMs/WAL volumes + real Netty.
 * NOT an Order/Trade service and NOT a substitute for full fault auditing.
 */
public final class DemoV19ClusterHarness {
    private static final String ROOT = DemoZkFenceSource.ISOLATED_ROOT + "/harness";
    private static final String ASSIGN = ROOT + "/assignments";
    private static final String GATES = ROOT + "/gates";
    private static final String P = "P000";

    private DemoV19ClusterHarness() {}

    public static void main(String[] args) throws Exception {
        if (args.length != 1) throw new IllegalArgumentException("--bootstrap or --node=A|B|C");
        if ("--bootstrap".equals(args[0])) { bootstrap(); return; }
        if (!args[0].matches("--node=[ABC]")) throw new IllegalArgumentException("node A|B|C");
        if ("--node=C".equals(args[0])
                && !"1".equals(System.getenv("DEMO_V19_THREE_DATA_NODES")))
            throw new IllegalStateException("C requires a dedicated three-data-node ensemble");
        String suffix = args[0].substring("--node=".length());
        String node = "CommonHaDemo" + suffix;
        ZookeeperClient zk = new ZookeeperClient(DemoAssignmentBootstrap.HOSTS, null, null);
        final DemoV19AckPolicy ackPolicy=DemoV19AckPolicy.fromEnvironment();
        if(ackPolicy!=null) {
            ackPolicy.requireCurrent(zk);
            System.out.println("COMMON_V19_ACK_POLICY_STARTUP policy="+ackPolicy.mode+
                " liveSwitch=false zkBootstrapPinned=true");
        }
        DemoZkLeaseController controller = new DemoZkLeaseController(
                zk, GATES, ASSIGN, node, 2200L, 300L, 450L);
        DemoJournalCatalog catalog = new DemoJournalCatalog(suffix,
                Paths.get("/srv/v19/wal"));
        DemoAsyncReplicator async = new DemoAsyncReplicator(
                node, catalog, new DemoReplicaClient());
        // Independent pilot-only retry: lost signals while a Replica is
        // offline must not stall WAL catch-up until the next user order.
        java.util.concurrent.ScheduledExecutorService retry =
                Executors.newSingleThreadScheduledExecutor(task -> {
                    Thread thread = new Thread(task, "v19-replica-retry-" + suffix);
                    thread.setDaemon(true);
                    return thread;
                });
        DemoPrimaryWriter writer = new DemoPrimaryWriter(
                node, catalog, new DemoReplicaClient(), async);
        if(ackPolicy!=null)writer.useAckPolicy(ackPolicy);
        final boolean strictSelected=ackPolicy==null || ackPolicy.strict();
        if(ackPolicy!=null && strictSelected && !DemoV19DurableRuntime.enabled())
            throw new IllegalStateException("STRICT_QUORUM requires real configured RF2 quorum");
        DemoV19DurableRuntime durable = strictSelected && DemoV19DurableRuntime.enabled()
                ? new DemoV19DurableRuntime(node,catalog,async) : null;
        if(durable!=null) {
            writer.useExperimentalQuorum(durable);
            async.useSignedBatchProofs(durable);
        }
        final DemoV19Rf2DynamicReceiptService dynamicReceipt=
                strictSelected &&
                "1".equals(System.getenv("DEMO_V19_RF2_DYNAMIC_RECEIPT_PILOT"))
                ? new DemoV19Rf2DynamicReceiptService(zk,node,catalog) : null;
        if(strictSelected &&
                "1".equals(System.getenv("DEMO_V19_RF2_DYNAMIC_STRICT_ACK"))){
            if(dynamicReceipt==null)
                throw new IllegalStateException("strict ACK needs the same dynamic custody signer");
            writer.useDynamicStrictAck(
                new DemoV19Rf2StrictAckRuntime(
                    zk,node,catalog,async,dynamicReceipt));
        }
        final DemoV19Rf2AutoStage autoStage=strictSelected &&
                DemoV19Rf2AutoStage.enabled()
                ? new DemoV19Rf2AutoStage(
                    zk,node,durable,catalog,dynamicReceipt) : null;
        DemoV19TcpService v19Tcp = new DemoV19TcpService(durable,node,catalog,
                writer,async,controller,dynamicReceipt);
        com.app.common.replication.DirectNettyReplicationServer replica =
                DemoNettyBridge.server(suffix, catalog, v19Tcp::control, durable);
        try {
            if (!"netty".equals(System.getenv("DEMO_REPLICATION_TRANSPORT"))
                    || !"1".equals(System.getenv("DEMO_ASYNC_REPLICATION"))
                    || !"1".equals(System.getenv("DEMO_TWO_NODE_ASYNC"))
                    || !"1".equals(System.getenv("DEMO_V19_DEDICATED_ENSEMBLE")))
                throw new IllegalStateException("v19 isolated test flags missing");
            controller.track(P);
            DemoHotpathControl.installPilot(controller.grantCache());
            System.setProperty("demo.v19.hotpath.enabled", "true");
            System.setProperty("demo.ack.fullDigest", "false");
            replica.start();
            controller.start();
            if (autoStage!=null) autoStage.start();
            retry.scheduleWithFixedDelay(() -> {
                try {
                    // Epoch1/2-only retry silently stranded new Epoch3+
                    // WAL on restart. This is a low-rate P000 control nudge;
                    // the async sender still checks exact per-record ZK fences.
                    // Exactly one cached grant-view lookup, not a linear
                    // scan through every historical Epoch on every tick.
                    long currentEpoch=controller.grantCache().view(P).epoch;
                    if(controller.permits(P,currentEpoch))async.signal(P);
                } catch (RuntimeException notReady) {
                    // Data-plane refuses grants before READY.
                }
            }, 1L, 1L, TimeUnit.SECONDS);
            // v19 has one Netty TCP listener per node for commands, state
            // inspection and WAL replication. No HTTP server is started.
            Thread ready = new Thread(() -> {
                while (!Thread.currentThread().isInterrupted()) {
                    try {
                        boolean writableGrant=false;
                        long currentEpoch=controller.grantCache().view(P).epoch;
                        if(currentEpoch>0 && currentEpoch<=DemoV19Rf2EpochLimits.MAX_EPOCH
                                && controller.permits(P,currentEpoch)
                                && catalog.journal(P).isReadyForWrites()) {
                            PartitionReadinessGuard.markReady(node,P,currentEpoch);
                            writableGrant=true;
                        }
                        // Expired/revoked ZK grants must immediately clear any
                        // previous READY bit, even without an exception.
                        if (!writableGrant) PartitionReadinessGuard.revoke(node, P);
                        Thread.sleep(35L);
                    } catch (InterruptedException stop) {
                        Thread.currentThread().interrupt();
                    } catch (RuntimeException ignored) {
                        PartitionReadinessGuard.revoke(node, P);
                    }
                }
            }, "v19-readiness-" + suffix);
            ready.setDaemon(true);
            ready.start();
            System.out.println("V19_CLUSTER_HARNESS_STARTED node=" + node
                    + " tcp=" + ("A".equals(suffix) ? 35411
                            : "B".equals(suffix) ? 35412 : 35413)
                    + " wal=/srv/v19/wal root=" + ROOT);
            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                ready.interrupt();
                retry.shutdownNow(); async.close();
                if(autoStage!=null)autoStage.close();
                controller.close(); zk.close();
                replica.close();
                try {if(durable!=null)durable.close();}catch(Exception e){e.printStackTrace();}
                try { catalog.close(); } catch (Exception e) { e.printStackTrace(); }
            }));
            new java.util.concurrent.CountDownLatch(1).await();
        } catch (Throwable failure) {
            retry.shutdownNow(); async.close();
            if(autoStage!=null)autoStage.close();
            controller.close(); zk.close();
            replica.close(); catalog.close();
            try {if(durable!=null)durable.close();}catch(Exception close) {failure.addSuppressed(close);}
            throw failure;
        }
    }

    private static void bootstrap() {
        ZookeeperClient zk = new ZookeeperClient(DemoAssignmentBootstrap.HOSTS, null, null);
        try {
            for (String root : new String[]{"/dc", "/dc/cluster", "/dc/cluster/commonhademo",
                    DemoZkFenceSource.ISOLATED_ROOT, ROOT, ASSIGN, GATES}) {
                if (!zk.exists(root)) zk.create(root, "", CreateMode.PERSISTENT);
            }
            DemoV19AckPolicy policy=DemoV19AckPolicy.fromEnvironment();
            if(policy!=null)policy.bootstrap(zk);
            String assignment = ASSIGN + "/" + P;
            if (!zk.exists(assignment))
                zk.create(assignment, encodeAssignment(1, "CommonHaDemoA"),
                        CreateMode.PERSISTENT);
            else if (!encodeAssignment(1, "CommonHaDemoA").equals(zk.readData(assignment)))
                throw new IllegalStateException("existing v19 assignment differs, refuse overwrite");
            String gate = GATES + "/" + P;
            if (!zk.exists(gate)) zk.create(gate, "0|-|OPEN", CreateMode.PERSISTENT);
            System.out.println("V19_CLUSTER_BOOTSTRAP_OK root=" + ROOT);
        } finally { zk.close(); }
    }

    /** Only used by an explicit isolated test operator after checking durable WALs. */
    static String encodeAssignment(long epoch, String owner) {
        String replica = "CommonHaDemoA".equals(owner)
                ? "CommonHaDemoB" : "CommonHaDemoA";
        String members = "\"" + replica + "\"";
        if ("1".equals(System.getenv("DEMO_V19_THREE_DATA_NODES"))) {
            String secondReplica = "CommonHaDemoC".equals(owner)
                    ? "CommonHaDemoB" : "CommonHaDemoC";
            if (!replica.equals(secondReplica)) members += ",\"" + secondReplica + "\"";
        }
        return "{\"partitionId\":\"P000\",\"epoch\":" + epoch
                + ",\"assignmentVersion\":" + epoch + ",\"protocolVersion\":1,"
                + "\"primary\":\"" + owner + "\","
                + "\"replica\":\"" + replica + "\",\"replicas\":["
                + members + "],\"learners\":[],\"state\":\"READY\"}";
    }

}
