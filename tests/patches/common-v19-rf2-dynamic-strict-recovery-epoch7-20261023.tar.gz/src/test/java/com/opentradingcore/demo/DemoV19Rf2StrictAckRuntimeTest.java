package com.opentradingcore.demo;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import org.junit.Test;
import static org.junit.Assert.*;

/** Network-less negative proof tests. Docker tests exercise real durable ACK. */
public class DemoV19Rf2StrictAckRuntimeTest {
    private final String sha="0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef";
    private Map<String,Object> physical(long seq){
        Map<String,Object> map=new LinkedHashMap<>();
        map.put("localNode","CommonHaDemoA");
        map.put("clean",true);
        map.put("committedSeq",seq);
        map.put("committedPrefixSha256",sha);
        return map;
    }
    private void denied(Map<String,Object> status,long seq,String expected){
        try{
            DemoV19Rf2StrictAckRuntime.requireMatchedRemote(
                status,"CommonHaDemoA",seq,expected);
            fail("unsafe WAL evidence admitted");
        }catch(IOException expectedRefusal) { }
    }
    @Test public void acceptsOnlyExactCleanDurableReplica()throws Exception {
        DemoV19Rf2StrictAckRuntime.requireMatchedRemote(physical(10),
            "CommonHaDemoA",10,sha);
    }
    @Test public void rejectsReplicaLagAndAhead() {
        denied(physical(9),10,sha);
        denied(physical(11),10,sha);
    }
    @Test public void rejectsForkEvenAtSameSequence() {
        denied(physical(10),10,
            "abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789");
    }
    @Test public void rejectsIdentitySpoofingAndDirtyTail(){
        Map<String,Object> m=physical(10);
        m.put("localNode","CommonHaDemoB");denied(m,10,sha);
        m=physical(10);m.put("clean",false);denied(m,10,sha);
    }
    @Test public void rejectsIncompleteRemoteStatus(){
        Map<String,Object> m=physical(10);
        m.remove("committedPrefixSha256");denied(m,10,sha);
        m=physical(10);m.remove("committedSeq");denied(m,10,sha);
        denied(null,10,sha);
    }
}
