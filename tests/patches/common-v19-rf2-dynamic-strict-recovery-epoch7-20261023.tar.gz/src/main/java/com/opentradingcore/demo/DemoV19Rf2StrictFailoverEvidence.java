package com.opentradingcore.demo;

import com.app.common.replication.*;
import com.app.common.zk.ZookeeperClient;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyFactory;
import java.security.spec.X509EncodedKeySpec;
import java.util.*;

/** Promotion from a strict 2/2 group into a new locally durable epoch:
 * a survivor MUST own a cryptographically verified physical custody head
 * from the immediately previous strict RF2 membership. This is NOT election.
 */
final class DemoV19Rf2StrictFailoverEvidence {
    private final ZookeeperClient zk;
    private final DemoJournalCatalog journals;
    DemoV19Rf2StrictFailoverEvidence(ZookeeperClient zk,DemoJournalCatalog journals){
        this.zk=Objects.requireNonNull(zk);this.journals=Objects.requireNonNull(journals);
    }
    static final class Proof {
        final long epoch,config,seq;
        final String primary,sha;
        Proof(long e,long c,long s,String p,String h){
            epoch=e;config=c;seq=s;primary=p;sha=h;
        }
    }
    Proof fromStrictReady(Map<String,Object> original,String candidate)throws Exception {
        DemoV19Rf2DynamicReceiptService.Plan plan=
            DemoV19Rf2DynamicReceiptService.requirePlan(original);
        if(plan.preparing || !candidate.equals(plan.primary)
                && !candidate.equals(plan.replica))
            throw new IOException("candidate outside prior strict RF2 data members");
        return verifiedHead(plan.epoch,plan.configVersion,
            plan.primary,candidate,plan.genesisSeq,plan.genesisSha);
    }
    Proof fromStaged(Map<String,Object> staged,String candidate)throws Exception{
        if(staged==null || !candidate.equals(staged.get("primary"))
                || !"RECOVERING".equals(staged.get("state"))
                || !"AUTO_DEGRADED_LOCAL_DURABLE".equals(staged.get("durabilityPolicy"))
                || !Boolean.FALSE.equals(staged.get("quorumDurable")))
            throw new IOException("wrong candidate or strict staged transition");
        long oldEpoch=number(staged,"strictRecoveryOldEpoch"),
             config=number(staged,"strictRecoveryConfigVersion"),
             certifiedSeq=number(staged,"strictRecoveryCertifiedSeq");
        String oldPrimary=String.valueOf(staged.get("strictRecoveryOldPrimary")),
               expectedSha=String.valueOf(staged.get("strictRecoveryCertifiedSha"));
        if(number(staged,"epoch")!=oldEpoch+1
                || !Collections.emptyList().equals(staged.get("replicas"))
                || staged.get("strictTransition")!=null
                || !expectedSha.matches("[0-9a-f]{64}"))
            throw new IOException("recovery proof cannot authorize new epoch");
        Proof actual=verifiedHead(oldEpoch,config,oldPrimary,candidate,certifiedSeq,expectedSha);
        if(actual.seq!=certifiedSeq || !actual.sha.equals(expectedSha))
            throw new IOException("recovering WAL proof drift");
        return actual;
    }
    private static long number(Map<String,Object> r,String key)throws IOException {
        Object o=r.get(key);
        if(!(o instanceof Number))throw new IOException("missing "+key);
        return ((Number)o).longValue();
    }
    private Proof verifiedHead(long epoch,long config,String oldPrimary,
            String candidate,long minimumSeq,String minimumSha)throws Exception {
        if(!zk.isConnected() || epoch<2 || config<2 || minimumSeq<1
                || !minimumSha.matches("[0-9a-f]{64}"))
            throw new IOException("old strict membership or quorum invalid");
        if(!("CommonHaDemoA".equals(candidate) || "CommonHaDemoB".equals(candidate))
                || !("CommonHaDemoA".equals(oldPrimary)
                     || "CommonHaDemoB".equals(oldPrimary)))
            throw new IOException("unrecognized physical member");
        KeyFactory factory=KeyFactory.getInstance("RSA");
        List<DurableWalCommitQuorum.Member> voters=new ArrayList<>();
        for(char suffix='A';suffix<='B';suffix++){
            String member="CommonHaDemo"+suffix;
            voters.add(new DurableWalCommitQuorum.Member(member,
                "simulated-single-mac-jvm-"+suffix,
                factory.generatePublic(new X509EncodedKeySpec(Files.readAllBytes(
                    Paths.get("/srv/v19/identities",member+".pub.der"))))));
        }
        DurableWalCommitQuorum.Membership m=new DurableWalCommitQuorum.Membership(
            "CommonHaDemo","P000",oldPrimary,epoch,config,voters);
        DemoDurableJournal wal=journals.journal("P000");
        synchronized(wal){
            if(!wal.isReadyForWrites() || wal.committedSeq()<minimumSeq
                    || !minimumSha.equals(wal.committedPrefixSha256Through(minimumSeq)))
                throw new IOException("candidate WAL lacks old certified strict boundary");
        }
        DurableWalCommitQuorum.LocalDurability walProof=(askedEpoch,seq)->{
            synchronized(wal){
                if(!wal.isReadyForWrites() || askedEpoch!=epoch
                        || wal.lastEpoch()>epoch || wal.committedSeq()<seq)
                    throw new IOException("candidate WAL not clean or missing strict head");
                return wal.committedPrefixSha256Through(seq);
            }
        };
        DurableWalCertificateCustody.Authority auth=ignored->{
            if(!zk.isConnected())throw new IOException("lost ZK control quorum");
        };
        java.nio.file.Path dir=Paths.get("/srv/v19/wal/.strict-custody-epoch-"
            +epoch+"-config-"+config);
        try(DurableWalCertificateCustody custody=new DurableWalCertificateCustody(
                dir,m,walProof,auth)) {
            DurableWalCommitQuorum.Certificate head=custody.highestVerified();
            if(head==null || head.committedSequence<minimumSeq
                    || (head.committedSequence==minimumSeq
                        && !minimumSha.equals(head.commitPrefixSha256)))
                throw new IOException("candidate lacks last signed strict custody head");
            // Every real strict client ACK was gated by custody of BOTH members.
            // This exact recovered physical head is therefore a safe local base.
            return new Proof(epoch,config,head.committedSequence,
                oldPrimary,head.commitPrefixSha256);
        }
    }
}
