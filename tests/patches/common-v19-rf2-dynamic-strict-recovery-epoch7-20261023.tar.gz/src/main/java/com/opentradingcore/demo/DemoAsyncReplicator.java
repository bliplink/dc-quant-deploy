package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;

import java.io.IOException;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/** Opt-in, best-effort copier of already-fsynced primary WAL records. */
public final class DemoAsyncReplicator implements AutoCloseable {
    private static final int MAX_RECORDS_PER_PASS = 128;
    private static final int MAX_CERTIFIED_BATCH = 8;
    private static final int REPLICATION_WORKERS = 16;
    // Foreground append signals remain immediate; only redundant idle verification
    // gets a bounded retry interval. A committed WAL backlog is never deferred.
    static final long MAX_IDLE_PROOF_NANOS = TimeUnit.SECONDS.toNanos(24);
    private final String node;
    private final DemoJournalCatalog journals;
    private final DemoReplicaClient client;
    private final ScheduledExecutorService workers = Executors.newScheduledThreadPool(
            REPLICATION_WORKERS, runnable -> {
        Thread thread = new Thread(runnable, "demo-async-replica");
        thread.setDaemon(true);
        return thread;
    });
    private final Map<String, AtomicBoolean> queued = new ConcurrentHashMap<String, AtomicBoolean>();
    private final Map<String, Map<String, Long>> watermarks =
            new ConcurrentHashMap<String, Map<String, Long>>();
    private final Map<String, String> unsafe = new ConcurrentHashMap<String, String>();
    private final Map<String, Long> quietProofAt = new ConcurrentHashMap<String, Long>();
    private final AtomicLong skippedIdleProbes = new AtomicLong();
    private final Map<String, Long> lastErrorLog = new ConcurrentHashMap<String, Long>();
    private final AtomicInteger sweepCursor = new AtomicInteger();
    private volatile boolean closed;
    private volatile DemoV19DurableRuntime signedBatchProofs;
    void useSignedBatchProofs(DemoV19DurableRuntime verifier) {
        this.signedBatchProofs=verifier;
    }

    // Diagnostics do not alter ACK eligibility, epoch checks, quorum proofs or WAL bytes.
    private final Map<String, AtomicLong> stageNanos = new ConcurrentHashMap<String, AtomicLong>();
    private final Map<String, AtomicLong> stageCounts = new ConcurrentHashMap<String, AtomicLong>();
    private final AtomicLong replicatedRecords = new AtomicLong();
    private final AtomicLong failedPasses = new AtomicLong();
    private final AtomicLong observedLag = new AtomicLong();
    private final AtomicLong maxLag = new AtomicLong();
    private final AtomicInteger activePasses = new AtomicInteger();

    private void record(String stage, long started) {
        stageNanos.computeIfAbsent(stage, key -> new AtomicLong()).addAndGet(
                Math.max(0, System.nanoTime() - started));
        stageCounts.computeIfAbsent(stage, key -> new AtomicLong()).incrementAndGet();
    }

    /** Lightweight read-only replication diagnostics, never a quorum receipt. */
    Map<String,Object> stageMetrics() {
        Map<String,Object> result=new java.util.LinkedHashMap<String,Object>();
        result.put("replicatedRecords",replicatedRecords.get());
        result.put("failedPasses",failedPasses.get());
        result.put("currentLag",observedLag.get());
        result.put("maxLag",maxLag.get());
        result.put("activePasses",activePasses.get());
        Map<String,Object> averages=new java.util.LinkedHashMap<String,Object>();
        for(String stage:new String[]{"assignment","statusRpc","prefixProof",
                "epochAndGate","prepareRpc","commitRpc","commitHash","batchRpc","batchHash"}) {
            long count=stageCounts.getOrDefault(stage,new AtomicLong()).get();
            long nanos=stageNanos.getOrDefault(stage,new AtomicLong()).get();
            Map<String,Long> metric=new java.util.LinkedHashMap<String,Long>();
            metric.put("samples",count);
            metric.put("avgUs",count==0?0L:nanos/count/1000);
            averages.put(stage,metric);
        }
        result.put("stages",averages);
        return result;
    }

    private void printMetrics() {
        if (closed) return;
        StringBuilder lines = new StringBuilder("DEMO_ASYNC_STAGE_METRICS node=").append(node)
                .append(" records=").append(replicatedRecords.get())
                .append(" quietProbeSkips=").append(skippedIdleProbes.get())
                .append(" failedPasses=").append(failedPasses.get())
                .append(" activePasses=").append(activePasses.get())
                .append(" currentLag=").append(observedLag.get())
                .append(" maxLag=").append(maxLag.get());
        for (String stage : new String[]{"assignment", "statusRpc", "prefixProof", "epochAndGate",
                "prepareRpc", "commitRpc", "commitHash", "batchRpc", "batchHash"}) {
            long count = stageCounts.getOrDefault(stage, new AtomicLong()).get();
            long nanos = stageNanos.getOrDefault(stage, new AtomicLong()).get();
            lines.append(' ').append(stage).append("Count=").append(count)
                    .append(' ').append(stage).append("AvgUs=")
                    .append(count == 0 ? 0 : nanos / count / 1000);
        }
        System.out.println(lines.toString());
    }

    public DemoAsyncReplicator(String node, DemoJournalCatalog journals, DemoReplicaClient client) {
        this.node = node;
        this.journals = journals;
        this.client = client;
    }

    public void start() {
        workers.scheduleWithFixedDelay(this::printMetrics, 15, 15, TimeUnit.SECONDS);
        workers.scheduleWithFixedDelay(() -> {
            for (int count = 0; count < 32; count++) {
                String partition = String.format("P%03d", sweepCursor.getAndIncrement() % 256);
                try {
                    if (node.equals(DemoControl.read(partition).getPrimary())) signal(partition);
                } catch (RuntimeException unavailable) {
                    // The next sweep retries; no readiness is inferred from this scan.
                }
            }
        }, 0, 2, TimeUnit.SECONDS);
    }

    public void signal(String partition) {
        if (closed) return;
        AtomicBoolean flag = queued.computeIfAbsent(partition, key -> new AtomicBoolean());
        if (flag.compareAndSet(false, true)) workers.execute(() -> {
            boolean more = false;
            try {
                activePasses.incrementAndGet();
                more = replicate(partition);
            } catch (Exception failure) {
                failedPasses.incrementAndGet();
                long now = System.nanoTime();
                Long previous = lastErrorLog.putIfAbsent(partition, now);
                if (previous == null || now - previous > TimeUnit.SECONDS.toNanos(60)) {
                    lastErrorLog.put(partition, now);
                    System.err.println("DEMO_ASYNC_REPLICATION_DELAYED partition=" + partition
                            + " reason=" + failure);
                }
            } finally {
                activePasses.decrementAndGet();
                flag.set(false);
                // Signals arriving during this pass are coalesced. A busy
                // partition must drain its durable WAL backlog immediately;
                // waiting for the 256-partition sweep after every 128 records
                // makes replication slower than even modest foreground load.
                if (more && !closed) signal(partition);
            }
        });
    }

    public long replicatedSeq(String partition, Iterable<String> replicas) {
        Map<String, Long> known = watermarks.get(partition);
        long minimum = Long.MAX_VALUE;
        int count = 0;
        for (String replica : replicas) {
            minimum = Math.min(minimum, known == null ? 0L : known.getOrDefault(replica, 0L));
            count++;
        }
        return count == 0 ? 0L : minimum;
    }

    public boolean hasDivergence(String partition) { return unsafe.containsKey(partition); }

    private boolean replicate(String partition) throws IOException {
        Map<String, Long> previousWatermarks = watermarks.get(partition);
        Long lastProof = quietProofAt.get(partition);
        long wallNanos = System.nanoTime();
        // Does not assert readiness or issue a write. Revalidate all known
        // replicas after a short bounded period, even without new transactions.
        // New committed WAL seq immediately invalidates the skip and enforces
        // the complete epoch/quorum/freeze + prepare/commit + hash chain below.
        if (shouldSkipIdleVerification(previousWatermarks, journals.journal(partition).committedSeq(),
                lastProof == null ? 0L : lastProof, wallNanos, unsafe.containsKey(partition))) {
            skippedIdleProbes.incrementAndGet();
            return false;
        }
        long stageStart = System.nanoTime();
        PartitionAssignment assignment;
        try { assignment = DemoHotpathControl.read(partition); }
        finally { record("assignment", stageStart); }
        if (!assignment.isRoutable() || !node.equals(assignment.getPrimary())) return false;
        DemoDurableJournal journal = journals.journal(partition);
        IOException delayed = null;
        for (String replica : assignment.replicaNodes()) {
            if (closed) return false;
            try {
            Map<String,Object> status=null;
            // Optional Common-signed, exact-prefix status hint; never a new
            // durable ACK. Any epoch/dirty WAL/fork/restart must fail closed
            // or fall back to the old complete STATUS recovery flow.
            DemoV19DurableRuntime verifier=signedBatchProofs;
            if("1".equals(System.getenv("DEMO_V19_SIGNED_BATCH_ACK_PILOT"))
                    && verifier!=null && "P000".equals(partition)
                    && !unsafe.containsKey(partition)) {
                try {
                    com.app.common.replication.DurableWalCommitQuorum.Receipt hinted=
                            verifier.freshReplicaStart(replica,journal);
                    if(hinted!=null) {
                        DemoDurableJournal.CommittedRecord pending=
                                journal.committedRecord(hinted.sequence+1);
                        if(pending==null || DemoFaultHook.forRequest(partition,
                                pending.operation.requestId)==null) {
                            status=new java.util.LinkedHashMap<String,Object>();
                            status.put("committedSeq",hinted.sequence);
                            status.put("committedPrefixSha256",hinted.commitPrefixSha256);
                            status.put("clean",Boolean.TRUE);
                        }
                    }
                } catch(Exception rejected) {
                    throw new IOException("signed status hint invalid; stop replication",rejected);
                }
            }
            if(status==null) {
                stageStart=System.nanoTime();
                try {status=client.status(replica,partition);}
                finally {record("statusRpc",stageStart);}
            }
            long remoteSeq = number(status.get("committedSeq"));
            long localSeq = journal.committedSeq();
            if (remoteSeq > localSeq) {
                divergence(partition, "replica ahead of primary: " + replica);
                return false;
            }
            String expected;
            long prefixStart = System.nanoTime();
            try { expected = journal.committedPrefixSha256Through(remoteSeq); }
            catch (IOException missingSnapshot) {
                // A snapshot transfer, not replay from sequence one, is required.
                throw new IOException("replica needs certified snapshot: " + replica, missingSnapshot);
            }
            record("prefixProof", prefixStart);
            if (!expected.equals(status.get("committedPrefixSha256"))) {
                divergence(partition, "replica committed prefix differs: " + replica);
                return false;
            }
            if (!Boolean.TRUE.equals(status.get("clean"))) {
                Object evidence = status.get("dirtyTail");
                DemoDurableJournal.CommittedRecord next = journal.committedRecord(remoteSeq + 1);
                if (!(evidence instanceof Map) || next == null
                        || !equalNumber(remoteSeq + 1, ((Map<?, ?>) evidence).get("pendingSeq"))
                        || !next.operation.requestId.equals(((Map<?, ?>) evidence).get("pendingRequestId"))) {
                    divergence(partition, "uncertified replica tail: " + replica);
                    return false;
                }
            }
            watermarks.computeIfAbsent(partition, key -> new ConcurrentHashMap<String, Long>())
                    .put(replica, remoteSeq);
            long lag = Math.max(0L, localSeq - remoteSeq);
            observedLag.set(lag);
            maxLag.accumulateAndGet(lag, Math::max);
            long limit = Math.min(localSeq, remoteSeq + MAX_RECORDS_PER_PASS);
            for (long seq = remoteSeq + 1; seq <= limit; seq++) {
                DemoDurableJournal.CommittedRecord record = journal.committedRecord(seq);
                if (record == null) throw new IOException("committed WAL tail unavailable at " + seq);
                // Fault-injected sequences MUST retain the legacy two-call
                // prepare/commit boundary so a crash can be injected between
                // their individual physical WAL forces.
                if (DemoFaultHook.forRequest(partition, record.operation.requestId) == null) {
                    List<DemoDurableJournal.CommittedRecord> batch =
                            new ArrayList<DemoDurableJournal.CommittedRecord>();
                    for (long candidate = seq; candidate <= limit
                            && batch.size() < MAX_CERTIFIED_BATCH; candidate++) {
                        DemoDurableJournal.CommittedRecord next = journal.committedRecord(candidate);
                        if (next == null || next.epoch != record.epoch
                                || DemoFaultHook.forRequest(partition, next.operation.requestId) != null) {
                            break;
                        }
                        batch.add(next);
                    }
                    if (!batch.isEmpty()) {
                        // No optimization around the epoch, freeze or quorum
                        // proof: validate EACH WAL frame before transport.
                        for (DemoDurableJournal.CommittedRecord item : batch) {
                            stageStart = System.nanoTime();
                            try {
                                DemoHotpathControl.requireAsyncSend(
                                        partition, item.epoch, node, replica);
                            } finally { record("epochAndGate", stageStart); }
                        }
                        long endSeq = batch.get(batch.size() - 1).seq;
                        stageStart = System.nanoTime();
                        Map<String, Object> committed;
                        try { committed = client.sendBatch(replica, partition, node, record.epoch, batch); }
                        finally { record("batchRpc", stageStart); }
                        stageStart = System.nanoTime();
                        String hash;
                        try { hash = journal.committedPrefixSha256Through(endSeq); }
                        finally { record("batchHash", stageStart); }
                        if("1".equals(System.getenv("DEMO_V19_SIGNED_BATCH_ACK_PILOT"))) {
                            DemoV19DurableRuntime signedVerifier=signedBatchProofs;
                            Object response=committed.get("signedBatchAck");
                            if(signedVerifier==null || !(response instanceof com.app.common.replication.ReplicationAck))
                                throw new IOException("signed fsync batch ACK is required");
                            try {
                                com.app.common.replication.DurableWalCommitQuorum.Receipt signed=
                                        signedVerifier.verifySignedBatchAck(
                                                (com.app.common.replication.ReplicationAck)response,
                                                replica,hash);
                                committed.put("committedPrefixSha256",signed.commitPrefixSha256);
                                signedVerifier.rememberSignedBatch(replica,signed);
                            } catch(Exception unsafe) {
                                throw new IOException("independent signed batch ACK verification failed",unsafe);
                            }
                        }
                        if (!hash.equals(committed.get("committedPrefixSha256"))) {
                            divergence(partition, "replica certified batch hash differs: " + replica);
                            return false;
                        }
                        replicatedRecords.addAndGet(batch.size());
                        observedLag.set(Math.max(0L, journal.committedSeq() - endSeq));
                        watermarks.get(partition).put(replica, endSeq);
                        seq = endSeq; // for-loop resumes at next distinct WAL sequence
                        continue;
                    }
                }
                stageStart = System.nanoTime();
                try {
                DemoHotpathControl.requireAsyncSend(
                        partition, record.epoch, node, replica);
                } finally { record("epochAndGate", stageStart); }
                stageStart = System.nanoTime();
                try { client.send(replica, "prepare", partition, node,
                        record.epoch, seq, record.operation); }
                finally { record("prepareRpc", stageStart); }
                DemoFaultHook fault = DemoFaultHook.forRequest(partition, record.operation.requestId);
                if (fault != null) fault.afterAsyncPrepare();
                stageStart = System.nanoTime();
                Map<String, Object> committed;
                try { committed = client.send(replica, "commit", partition, node,
                        record.epoch, seq, record.operation); }
                finally { record("commitRpc", stageStart); }
                stageStart = System.nanoTime();
                String hash;
                try { hash = journal.committedPrefixSha256Through(seq); }
                finally { record("commitHash", stageStart); }
                if (!hash.equals(committed.get("committedPrefixSha256"))) {
                    divergence(partition, "replica commit hash differs: " + replica);
                    return false;
                }
                replicatedRecords.incrementAndGet();
                observedLag.set(Math.max(0L, journal.committedSeq() - seq));
                watermarks.get(partition).put(replica, seq);
            }
            } catch (IOException unavailable) {
                if(signedBatchProofs!=null)
                    signedBatchProofs.invalidateReplicaStart(replica);
                // One down replica must not prevent the other from receiving
                // its own ordered, durable copy.
                delayed = unavailable;
            }
        }
        if (delayed != null) throw delayed;
        unsafe.remove(partition);
        quietProofAt.put(partition, System.nanoTime());
        Map<String, Long> known = watermarks.get(partition);
        long latest = journal.committedSeq();
        for (String replica : assignment.replicaNodes()) {
            if (known == null || known.getOrDefault(replica, 0L) < latest) return true;
        }
        return false;
    }

    // Package-private to support deterministic tests without ZooKeeper or HTTP.
    static boolean shouldSkipIdleVerification(Map<String, Long> known, long localSeq,
            long verifiedAt, long now, boolean unsafe) {
        if (unsafe || known == null || known.isEmpty() || verifiedAt <= 0
                || now < verifiedAt || now - verifiedAt >= MAX_IDLE_PROOF_NANOS) return false;
        for (Long sequence : known.values()) {
            if (sequence == null || sequence.longValue() < localSeq) return false;
        }
        return true;
    }

    private void divergence(String partition, String reason) {
        String previous = unsafe.put(partition, reason);
        if (!reason.equals(previous)) {
            System.err.println("DEMO_ASYNC_DIVERGENCE partition=" + partition + " reason=" + reason);
        }
    }

    private static long number(Object value) throws IOException {
        if (!(value instanceof Number)) throw new IOException("replica sequence missing");
        return ((Number) value).longValue();
    }

    private static boolean equalNumber(long expected, Object value) {
        return value instanceof Number && ((Number) value).longValue() == expected;
    }

    @Override public void close() {
        closed = true;
        workers.shutdownNow();
    }
}
