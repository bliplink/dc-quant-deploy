package com.opentradingcore.demo;

import com.app.common.replication.*;
import java.io.IOException;
import java.util.Collections;
import java.util.Map;
import java.util.LinkedHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/** Persistent binary Netty TCP client for v19 test operations; no HTTP. */
public final class DemoV19TcpClient implements AutoCloseable {
    private final DirectNettyReplicationTransport transport =
            new DirectNettyReplicationTransport();

    public Map<String,Object> status(String node) throws Exception {
        return request(node, DemoV19TcpService.STATUS,
                Collections.<String,Object>emptyMap());
    }

    /** Read-only, cryptographically verified old-epoch persisted proof.
     * Never promotes a node, grants an epoch, or treats one head as complete.
     */
    public Map<String,Object> custodyHeadEvidence(String node) throws Exception {
        java.security.KeyFactory keys=java.security.KeyFactory.getInstance("RSA");
        java.util.List<DurableWalCommitQuorum.Member> participants=
                new java.util.ArrayList<DurableWalCommitQuorum.Member>();
        char last="1".equals(System.getenv("DEMO_V19_RF2_SHARD_PILOT"))?'B':'C';
        for(char suffix='A';suffix<=last;suffix++){
            String id="CommonHaDemo"+suffix;
            byte[] encoded=java.nio.file.Files.readAllBytes(java.nio.file.Paths.get(
                    "/srv/v19/identities",id+".pub.der"));
            participants.add(new DurableWalCommitQuorum.Member(id,
                    "simulated-single-mac-jvm-"+suffix,keys.generatePublic(
                            new java.security.spec.X509EncodedKeySpec(encoded))));
        }
        DurableWalCommitQuorum.Membership pinned=new DurableWalCommitQuorum.Membership(
                "CommonHaDemo","P000","CommonHaDemoA",1,1,participants);
        ReplicationControlResponse raw=transport.control(DemoNettyBridge.endpoint(node),
                DurableWalCertificateCustodyControlHandler.headQueryRequest(pinned))
                .get(8,TimeUnit.SECONDS);
        DurableWalCommitQuorum.Certificate cert=
                DurableWalCertificateCustodyControlHandler.decodeHeadEvidence(pinned,raw);
        Map<String,Object> result=new LinkedHashMap<String,Object>();
        result.put("partitionId","P000");
        result.put("sourceNode",node);
        result.put("oldEpoch",cert.epoch);
        result.put("certifiedSeq",cert.committedSequence);
        result.put("certifiedSha256",cert.commitPrefixSha256);
        result.put("oldWalVoterCount",cert.votes.size());
        result.put("cryptographicallyVerified",true);
        result.put("authorizesPromotion",false);
        return result;
    }

    public Map<String,Object> append(String node, Map<String,Object> command) throws Exception {
        return request(node, DemoV19TcpService.APPEND, command);
    }
    public Map<String,Object> appendGroup(String node,
            java.util.List<Map<String,Object>> commands) throws Exception {
        Map<String,Object> payload=new LinkedHashMap<String,Object>();
        payload.put("commands",commands);
        return request(node,DemoV19TcpService.APPEND_GROUP,payload);
    }


    void requireDynamicStrictWriterCapability(String target,long epoch,
            long config,long genesis,int zkVersion)throws Exception{
        com.app.common.replication.ReplicationControlRequest request=
            new com.app.common.replication.ReplicationControlRequest(
                "CommonHaDemo",
                DemoV19Rf2DynamicReceiptService.CAPABILITY_OPERATION,
                "P000",new byte[0]);
        com.app.common.replication.ReplicationControlResponse response=
            transport.control(DemoNettyBridge.endpoint(target),request)
                .get(8,TimeUnit.SECONDS);
        if(!response.isSuccess())
            throw new IOException("no strict writer on "+target+": "+response.getMessage());
        Map<String,Object> proof=DemoNettyBridge.map(response.getPayload());
        if(!target.equals(proof.get("node"))
                || !Boolean.TRUE.equals(proof.get("writerInstalled"))
                || !(proof.get("epoch") instanceof Number)
                || ((Number)proof.get("epoch")).longValue()!=epoch
                || !(proof.get("config") instanceof Number)
                || ((Number)proof.get("config")).longValue()!=config
                || !(proof.get("genesisSeq") instanceof Number)
                || ((Number)proof.get("genesisSeq")).longValue()!=genesis
                || !(proof.get("zkVersion") instanceof Number)
                || ((Number)proof.get("zkVersion")).intValue()!=zkVersion)
            throw new IOException("strict writer capability wrong identity/config/epoch");
    }

    /** Verify this peer really restarted with the persisted new-epoch
     * authenticated custody HEAD. Never treats head as authorization to write.
     */
    com.app.common.replication.DurableWalCommitQuorum.Certificate
    readDynamicCustodyHead(String target,
            com.app.common.replication.DurableWalCommitQuorum.Membership members)
            throws Exception {
        com.app.common.replication.ReplicationControlRequest original=
            com.app.common.replication.DurableWalCertificateCustodyControlHandler
                .headQueryRequest(members);
        com.app.common.replication.ReplicationControlRequest request=
            new com.app.common.replication.ReplicationControlRequest(
                original.getServiceName(),
                DemoV19Rf2DynamicReceiptService.CUSTODY_HEAD_OPERATION,
                original.getPartitionId(),original.getPayload());
        com.app.common.replication.ReplicationControlResponse response=
                transport.control(DemoNettyBridge.endpoint(target),request)
                    .get(8,TimeUnit.SECONDS);
        return com.app.common.replication.DurableWalCertificateCustodyControlHandler
                .decodeHeadEvidence(members,response);
    }

    /** Install a verified NEW epoch certificate into an independent JVM WAL
     * directory using Common's unchanged bounded signed-custody protocol. */
    com.app.common.replication.DurableWalCustodyQuorum.Receipt
    installDynamicCustody(String target,
            com.app.common.replication.DurableWalCommitQuorum.Membership members,
            com.app.common.replication.DurableWalCommitQuorum.Certificate cert)
            throws Exception {
        com.app.common.replication.ReplicationControlRequest original=
            com.app.common.replication.DurableWalCertificateCustodyControlHandler
                .request(members,cert);
        com.app.common.replication.ReplicationControlRequest request=
            new com.app.common.replication.ReplicationControlRequest(
                original.getServiceName(),
                DemoV19Rf2DynamicReceiptService.CUSTODY_OPERATION,
                original.getPartitionId(),original.getPayload());
        com.app.common.replication.ReplicationControlResponse response=
                transport.control(DemoNettyBridge.endpoint(target),request)
                    .get(8,TimeUnit.SECONDS);
        if(!response.isSuccess())
            throw new IOException("dynamic custody "+target+" denied: "+response.getMessage());
        return com.app.common.replication.DurableWalCertificateCustodyControlHandler
                .decodeVerified(members,cert,target,response);
    }

    /** One independently RSA-signed fsynced receipt, no client ACK. */
    com.app.common.replication.DurableWalCommitQuorum.Receipt signedDynamicReceipt(
            String target,com.app.common.replication.DurableWalCommitQuorum.Membership pinned,
            long seq) throws Exception {
        com.app.common.replication.ReplicationControlRequest original=
                com.app.common.replication.DurableWalReceiptControlHandler.request(pinned,seq);
        com.app.common.replication.ReplicationControlRequest request=
                new com.app.common.replication.ReplicationControlRequest(
                        original.getServiceName(),
                        DemoV19Rf2DynamicReceiptService.OPERATION,
                        original.getPartitionId(),original.getPayload());
        com.app.common.replication.ReplicationControlResponse response=transport.control(
                DemoNettyBridge.endpoint(target),request).get(8,TimeUnit.SECONDS);
        com.app.common.replication.DurableWalCommitQuorum.Receipt receipt=
                com.app.common.replication.DurableWalReceiptControlHandler.decodeReceipt(response);
        com.app.common.replication.DurableWalCommitQuorum.requireValidReceipt(pinned,receipt);
        if(!target.equals(receipt.node) || receipt.sequence!=seq
                || receipt.epoch!=pinned.epoch)
            throw new IOException("RF2 receipt physical source/seq mismatch");
        return receipt;
    }

    /** Exact fsynced historical WAL prefix from the addressed independent JVM.
     * Unlike a STATUS top hash this binds the old ACK certificate to real data.
     */
    String verifiedPrefixThrough(String node,long seq)throws Exception {
        if(seq<1 || !node.matches("CommonHaDemo[AB]"))
            throw new IOException("invalid bounded historical WAL query");
        Map<String,Object> args=new LinkedHashMap<String,Object>();args.put("seq",seq);
        Map<String,Object> result=request(node,"HASH_THROUGH",args);
        if(!node.equals(result.get("node"))
                || !(result.get("committedSeq") instanceof Number)
                || ((Number)result.get("committedSeq")).longValue()!=seq
                || !(result.get("committedPrefixSha256") instanceof String)
                || !((String)result.get("committedPrefixSha256")).matches("[0-9a-f]{64}"))
            throw new IOException("old certified WAL physical identity or prefix mismatch");
        return (String)result.get("committedPrefixSha256");
    }

    /** Probe dynamic signer on the REAL isolated Netty socket; a sole receipt
     * is never a quorum certificate and NEVER authorizes a client trade ACK.
     */
    public boolean probeDynamicReceipt(String target,long epoch,long config,long seq)
            throws Exception {
        java.nio.ByteBuffer raw=java.nio.ByteBuffer.allocate(28);
        raw.putInt(1);raw.putLong(config);raw.putLong(epoch);raw.putLong(seq);
        ReplicationControlRequest command=new ReplicationControlRequest(
                "CommonHaDemo",DemoV19Rf2DynamicReceiptService.OPERATION,
                "P000",raw.array());
        ReplicationControlResponse response=transport.control(
                DemoNettyBridge.endpoint(target),command).get(8,TimeUnit.SECONDS);
        if (!response.isSuccess()) {
            System.out.println("V19_RF2_DYNAMIC_RECEIPT_DENIED target="+target
                    +" reason="+response.getMessage());
            return false;
        }
        DurableWalCommitQuorum.Receipt receipt=
                DurableWalReceiptControlHandler.decodeReceiptPayload(response.getPayload());
        if(!target.equals(receipt.node) || receipt.epoch!=epoch
                || receipt.sequence!=seq)
            throw new IOException("dynamic receipt source or epoch mismatched");
        System.out.println("V19_RF2_DYNAMIC_RECEIPT_ONE_VOTE_ONLY target="+target
                +" epoch="+epoch+" seq="+seq+" walSha="+receipt.commitPrefixSha256
                +" clientQuorumAck=false");
        return true;
    }

    /** Return a completely verified WAL byte image, but never install it. */
    DemoV19TcpSnapshotReceiver.Image snapshot(String node) throws Exception {
        return DemoV19TcpSnapshotReceiver.fetch(
                (operation, args) -> request(node, operation, args), node);
    }

    private Map<String,Object> request(String node, String operation, Object payload)
            throws Exception {
        if (node == null || !node.matches("CommonHaDemo[ABC]"))
            throw new IllegalArgumentException("only isolated A/B/C");
        ReplicationEndpoint target = DemoNettyBridge.endpoint(node);
        ReplicationControlRequest request = new ReplicationControlRequest(
                "CommonHaDemo", operation, "P000", DemoNettyBridge.json(payload));
        final ReplicationControlResponse response;
        try {
            response = transport.control(target, request).get(8L, TimeUnit.SECONDS);
        } catch (ExecutionException | TimeoutException ex) {
            throw new IOException("v19 TCP " + operation + " could not complete", ex);
        }
        if (!response.isSuccess())
            throw new IOException("v19 TCP " + operation + " denied: "
                    + response.getMessage());
        Map<String,Object> decoded = DemoNettyBridge.map(response.getPayload());
        if (!"P000".equals(decoded.get("partitionId")))
            throw new IOException("wrong TCP partition response");
        if (DemoV19TcpService.STATUS.equals(operation)) {
            if (!node.substring(node.length()-1).equals(decoded.get("node")))
                throw new IOException("wrong TCP physical WAL node");
        }
        return decoded;
    }

    @Override public void close() { transport.close(); }

    /** One-shot v19 internal TCP diagnostics (used by CLI & fault tests). */
    public static void main(String[] args) throws Exception {
        if (args.length < 3 || !"--isolated".equals(args[0]))
            throw new IllegalArgumentException("--isolated status|snapshot|append A|B|C [requestId delta]");
        String node = "CommonHaDemo" + args[2];
        try (DemoV19TcpClient client = new DemoV19TcpClient()) {
            Map<String,Object> data;
            if ("dynamic-receipt".equals(args[1]) && args.length == 6) {
                client.probeDynamicReceipt(node,Long.parseLong(args[3]),
                        Long.parseLong(args[4]),Long.parseLong(args[5]));
                return;
            }
            if ("custody-head".equals(args[1]) && args.length == 3) {
                data = client.custodyHeadEvidence(node);
            } else if ("status".equals(args[1]) && args.length == 3) {
                data = client.status(node);
            } else if ("snapshot".equals(args[1]) && args.length == 3) {
                DemoV19TcpSnapshotReceiver.Image image = client.snapshot(node);
                java.nio.file.Path staged = java.nio.file.Files.createTempFile("v19-tcp-snapshot-", ".wal");
                try {
                    java.nio.file.Files.write(staged, image.bytes);
                    try (DemoDurableJournal verified = new DemoDurableJournal(staged)) {
                        if (!verified.isReadyForWrites() || verified.committedSeq() != image.committedSeq
                                || !image.sha256.equals(verified.committedPrefixSha256())
                                || !image.stateDigest.equals(verified.state().stateDigest()))
                            throw new java.io.IOException("received TCP WAL fails independent replay check");
                        data = new LinkedHashMap<String,Object>();
                        data.put("partitionId", "P000");
                        data.put("sourceNode", node);
                        data.put("committedSeq", image.committedSeq);
                        data.put("epoch", image.epoch);
                        data.put("bytes", image.bytes.length);
                        data.put("committedPrefixSha256", image.sha256);
                        data.put("replayedStateDigest", verified.state().stateDigest());
                        data.put("verified", true);
                    }
                } finally { java.nio.file.Files.deleteIfExists(staged); }
            } else if("batch".equals(args[1]) && args.length == 5) {
                int count=Integer.parseInt(args[4]);
                if(count<=0 || count>8)
                    throw new IllegalArgumentException("bounded group 1..8");
                java.util.List<Map<String,Object>> commands=
                        new java.util.ArrayList<Map<String,Object>>();
                for(int i=0;i<count;i++) {
                    Map<String,Object> command=new LinkedHashMap<String,Object>();
                    command.put("partitionId","P000");
                    command.put("partitionKey","v19-p000-key-123");
                    command.put("requestId",args[3]+"-"+(i+1));
                    command.put("delta",i+1);
                    commands.add(command);
                }
                data=client.appendGroup(node,commands);
            } else if ("append".equals(args[1]) && args.length == 5) {
                Map<String,Object> command = new LinkedHashMap<String,Object>();
                command.put("partitionId", "P000");
                command.put("partitionKey", "v19-p000-key-123");
                command.put("requestId", args[3]);
                command.put("delta", Long.parseLong(args[4]));
                data = client.append(node, command);
            } else {
                throw new IllegalArgumentException("unrecognized v19 test TCP operation");
            }
            System.out.println("V19_TCP_" + args[1].toUpperCase()
                    + " " + com.gateway.connector.utils.JsonUtils.Serializer(data));
        }
    }
}
