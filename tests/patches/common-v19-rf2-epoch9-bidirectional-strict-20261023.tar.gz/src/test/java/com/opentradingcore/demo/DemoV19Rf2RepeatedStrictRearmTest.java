package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;
import java.util.Collections;
import org.junit.Test;
import static org.junit.Assert.*;

/** No completed strict Epoch may be replayed as a new strict rejoin. */
public final class DemoV19Rf2RepeatedStrictRearmTest {
    private static PartitionAssignment degraded(int epoch,String primary,String learner) {
        PartitionAssignment a=new PartitionAssignment();
        a.setPartitionId("P000");
        a.setEpoch(epoch);
        a.setPrimary(primary);
        a.setState("READY");
        a.setReplicas(Collections.<String>emptyList());
        a.setLearners(Collections.singletonList(learner));
        return a;
    }
    @Test public void newSoloEpochCanSafelyRearmAfterLastStrictActivation(){
        assertTrue(DemoV19Rf2AutoStage.mayRearmStrictCycle(
            degraded(6,"CommonHaDemoB","CommonHaDemoA"),"CommonHaDemoB",5));
    }
    @Test public void sameOrOlderEpochMustNeverRearm(){
        assertFalse(DemoV19Rf2AutoStage.mayRearmStrictCycle(
            degraded(5,"CommonHaDemoB","CommonHaDemoA"),"CommonHaDemoB",5));
        assertFalse(DemoV19Rf2AutoStage.mayRearmStrictCycle(
            degraded(4,"CommonHaDemoB","CommonHaDemoA"),"CommonHaDemoB",5));
    }
    @Test public void onlyActualCurrentSoloPrimaryCanRearm(){
        assertFalse(DemoV19Rf2AutoStage.mayRearmStrictCycle(
            degraded(6,"CommonHaDemoB","CommonHaDemoA"),"CommonHaDemoA",5));
        PartitionAssignment strict=degraded(6,"CommonHaDemoB","CommonHaDemoA");
        strict.setReplicas(Collections.singletonList("CommonHaDemoA"));
        strict.setLearners(Collections.<String>emptyList());
        assertFalse(DemoV19Rf2AutoStage.mayRearmStrictCycle(
            strict,"CommonHaDemoB",5));
    }
    @Test public void notReadyOrNoDistinctLearnerMustNotRearm(){
        PartitionAssignment recovering=degraded(6,"CommonHaDemoB","CommonHaDemoA");
        recovering.setState("RECOVERING");
        assertFalse(DemoV19Rf2AutoStage.mayRearmStrictCycle(
            recovering,"CommonHaDemoB",5));
        assertFalse(DemoV19Rf2AutoStage.mayRearmStrictCycle(
            degraded(6,"CommonHaDemoB","CommonHaDemoB"),"CommonHaDemoB",5));
    }
    @Test public void boundedDemoStillRejectsBeyondLastSupportedEpoch(){
        assertFalse(DemoV19Rf2AutoStage.mayRearmStrictCycle(
            degraded(128,"CommonHaDemoB","CommonHaDemoA"),"CommonHaDemoB",127));
    }
}
