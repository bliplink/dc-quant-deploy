package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;
import com.app.common.replication.*;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/**
 * Explicit opt-in, SINGLE HOST experimental demonstration adapter.
 * All correctness/crypto/commit-index/ACK rules are implemented in Common.
 * No business-specific commit algorithm or new network protocol here.
 *
 * Docker JVMs are separate, but live on one Docker VM. Never advertise the
 * result as physically independent fault-domain QUORUM_DURABLE production.
 */
final class DemoV19DurableRuntime implements AutoCloseable {
    private final String node;
    private final DemoJournalCatalog journals;
    private final DemoAsyncReplicator async;
    private final DurableWalCommitQuorum.Membership membership;
    private final DurableWalReceiptControlHandler signedTcp;
    private final DurableWalCommitIndex committed;
    private final DirectNettyReplicationTransport transport;
    private final PrivateKey localKey;
    private final boolean custodyEnabled;
    private final DurableWalCertificateCustody certificateCustody;
    private final DurableWalCertificateCustodyControlHandler custodyTcp;
    private volatile long confirmedCustodySeq;

    static boolean enabled() {
        if(!"1".equals(System.getenv("DEMO_V19_COMMON_QUORUM_TEST")))return false;
        boolean rf3="1".equals(System.getenv("DEMO_V19_THREE_DATA_NODES"));
        boolean rf2="1".equals(System.getenv("DEMO_V19_RF2_SHARD_PILOT"));
        // A mixed RF2/RF3 control image is unsafe: require exactly one pilot.
        return rf3!=rf2;
    }

    DemoV19DurableRuntime(String localNode,DemoJournalCatalog catalogs,
            DemoAsyncReplicator async) throws Exception {
        if(!enabled() || !"1".equals(System.getenv("DEMO_V19_SINGLE_HOST_QUORUM_TEST")))
            throw new IOException("v19 quorum test requires explicit isolated single-host opt-in");
        this.node=localNode;
        this.journals=catalogs;
        this.async=async;
        KeyFactory factory=KeyFactory.getInstance("RSA");
        String root="/srv/v19/identities";
        List<DurableWalCommitQuorum.Member> configured=new ArrayList<DurableWalCommitQuorum.Member>();
        char lastDataNode="1".equals(System.getenv("DEMO_V19_RF2_SHARD_PILOT"))
                ? 'B':'C';
        for(char ch='A';ch<=lastDataNode;ch++) {
            String id="CommonHaDemo"+ch;
            byte[] encoded=Files.readAllBytes(Paths.get(root,id+".pub.der"));
            PublicKey pub=factory.generatePublic(new X509EncodedKeySpec(encoded));
            // SIMULATED fault domain labels, not three different machines.
            configured.add(new DurableWalCommitQuorum.Member(id,
                    "simulated-single-mac-jvm-"+ch,pub));
        }
        byte[] secret=Files.readAllBytes(Paths.get("/srv/v19/local-identity/node.pk8"));
        this.localKey=factory.generatePrivate(new PKCS8EncodedKeySpec(secret));
        this.membership=new DurableWalCommitQuorum.Membership("CommonHaDemo",
                "P000","CommonHaDemoA",1,1,configured);
        // Only a replication START HINT, not an ACK or a new epoch grant.
        this.verifiedReplicaStart=new DurableWalVerifiedPrefixCache(
                membership,TimeUnit.SECONDS.toNanos(2));
        this.signedTcp=new DurableWalReceiptControlHandler(membership,node,localKey,
                (epoch,seq)->{
                    DemoDurableJournal wal=journals.journal("P000");
                    synchronized(wal) {
                        if(!wal.isReadyForWrites() || wal.lastEpoch()!=epoch
                                || wal.committedSeq()<seq)
                            throw new IOException("local fsynced WAL prefix not available");
                        return wal.committedPrefixSha256Through(seq);
                    }
                },this::requireGrant);
        this.committed="CommonHaDemoA".equals(node)
                ? new DurableWalCommitIndex(Paths.get("/srv/v19/wal/.quorum-commit-index"),membership)
                : null;
        this.custodyEnabled="1".equals(System.getenv("DEMO_V19_CUSTODY_ACK_PILOT"));
        if(custodyEnabled) {
            this.certificateCustody=new DurableWalCertificateCustody(
                    Paths.get("/srv/v19/wal/.cert-custody"),membership,
                    (askedEpoch,askedSeq)->{
                        // Atomic Learner WAL replacement reopens the journal. Never
                        // retain the pre-install (now closed) journal reference.
                        DemoDurableJournal wal=catalogs.journal("P000");
                        synchronized(wal){
                            // Historical signed head remains readable when a
                            // safely fenced NEW epoch has appended more WAL.
                            // The exact historical SHA binds askedSeq to the
                            // old certificate. Installation still needs its
                            // old membership authorization, so this DOES NOT
                            // permit signing new records under the old epoch.
                            if(!wal.isReadyForWrites() || wal.lastEpoch()<askedEpoch
                                    || wal.committedSeq()<askedSeq)
                                throw new IOException("local custody WAL prefix not fsynced");
                            return wal.committedPrefixSha256Through(askedSeq);
                        }
                    },this::requireGrant);
            this.custodyTcp=new DurableWalCertificateCustodyControlHandler(
                    membership,node,localKey,certificateCustody,this::requireGrant);
        } else {
            this.certificateCustody=null;
            this.custodyTcp=null;
        }
        this.transport=new DirectNettyReplicationTransport(1800,
                DirectNettyReplicationServer.DEFAULT_MAX_FRAME_BYTES);
    }

    private List<String> designatedDataPeers() {
        List<String> selected=new ArrayList<String>();
        for(String member:membership.members.keySet())
            if(!member.equals(membership.primary))selected.add(member);
        return selected;
    }

    private final DurableWalVerifiedPrefixCache verifiedReplicaStart;

    /** Use a very recent RSA-verified physical WAL prefix to avoid STATUS RTT. */
    DurableWalCommitQuorum.Receipt freshReplicaStart(
            String replica,DemoDurableJournal local)throws Exception {
        requireGrant(membership);
        DurableWalCommitQuorum.Receipt receipt=verifiedReplicaStart.fresh(
                replica,System.nanoTime(),(epoch,seq)->{
                    synchronized(local) {
                        if(!local.isReadyForWrites() || local.lastEpoch()!=epoch
                                || seq>local.committedSeq())
                            throw new IOException("unsafe trusted local WAL starting prefix");
                        return local.committedPrefixSha256Through(seq);
                    }
                });
        requireGrant(membership);
        return receipt;
    }

    void invalidateReplicaStart(String replica) {verifiedReplicaStart.invalidate(replica);}

    private final java.util.concurrent.ConcurrentHashMap<String,
            DurableWalCommitQuorum.Receipt> recentSignedBatches =
            new java.util.concurrent.ConcurrentHashMap<String,
                    DurableWalCommitQuorum.Receipt>();

    /** Called only after replica's durable WAL group force/commit and gate. */
    ReplicationAck signedBatchAck(ReplicationAck committedBatch)throws Exception {
        if(committedBatch==null || !committedBatch.isSuccess())
            throw new IOException("cannot sign a failed or uncommitted batch");
        requireGrant(membership);
        ReplicationControlResponse signed=signedTcp.handle(
                DurableWalReceiptControlHandler.request(membership,
                        committedBatch.getReplicatedSeq()));
        DurableWalCommitQuorum.Receipt witness=
                DurableWalReceiptControlHandler.decodeReceipt(signed);
        requireGrant(membership);
        return DurableWalBatchAckProof.attach(committedBatch,witness);
    }

    /** Verify pinned physical identity/signature and durable boundary. */
    DurableWalCommitQuorum.Receipt verifySignedBatchAck(
            ReplicationAck ack,String replica,String expectedHash)throws Exception {
        requireGrant(membership);
        DurableWalCommitQuorum.Receipt witness=DurableWalBatchAckProof.read(
                ack,membership,replica,expectedHash);
        if(witness==null)throw new IOException("replica did not provide signed fsync batch ACK");
        requireGrant(membership);
        return witness;
    }

    void rememberSignedBatch(String replica,DurableWalCommitQuorum.Receipt receipt)
            throws Exception {
        if(replica!=null && receipt!=null) {
            verifiedReplicaStart.remember(receipt,System.nanoTime());
            recentSignedBatches.compute(replica,(id,prior)->
                    prior==null || prior.sequence<receipt.sequence?receipt:prior);
        }
    }

    ReplicationControlResponse control(ReplicationControlRequest request) {
        if(request!=null &&
                (DurableWalCertificateCustodyControlHandler.OPERATION
                        .equals(request.getOperation())
                 || DurableWalCertificateCustodyControlHandler.HEAD_QUERY_OPERATION
                        .equals(request.getOperation())))
            return custodyTcp==null
                    ? ReplicationControlResponse.error("CUSTODY_DISABLED","pilot not active")
                    : custodyTcp.handle(request);
        return signedTcp.handle(request);
    }

    private void requireGrant(DurableWalCommitQuorum.Membership expected) throws Exception {
        PartitionAssignment assignment=DemoHotpathControl.read("P000");
        if(assignment.getEpoch()!=expected.epoch
                || !assignment.isRoutable()
                || !expected.primary.equals(assignment.getPrimary())
                || !expected.members.containsKey(node)
                || !(node.equals(expected.primary) || assignment.isReplica(node)))
            throw new IOException("quorum signer does not have current assigned membership");
        DemoHotpathControl.requireCurrent("P000",expected.epoch,expected.primary,
                node.equals(expected.primary)?null:node);
        if(node.equals(expected.primary)) {
            DemoHotpathControl.requireWritableQuorum("P000",expected.epoch,node);
        } else {
            DemoHotpathControl.requireReplicaQuorum("P000",expected.epoch,
                    expected.primary,node);
        }
    }

    /** Strict opt-in custody: do not ACK a persisted WAL certificate until
     *  local and remote physical custodians fsync the certificate itself. */
    private synchronized void requireCustodiedCommit(long requestedSeq)throws Exception {
        if(!custodyEnabled)return;
        if(committed==null || certificateCustody==null)
            throw new IOException("custody strict ACK must run on real primary");
        requireGrant(membership);
        DurableWalCommitQuorum.Certificate exact=committed.verifiedHighestCertificate();
        if(exact.committedSequence<requestedSeq)
            throw new IOException("requested sequence exceeds durable certificate head");
        if(confirmedCustodySeq>=exact.committedSequence) {
            DurableWalCommitQuorum.Certificate local=certificateCustody.highestVerified();
            if(local==null || local.committedSequence<exact.committedSequence)
                throw new IOException("cached custody advanced beyond real disk proof");
            requireGrant(membership);
            return;
        }
        DurableWalCustodyQuorum.Receipt own;
        long custodyLocalStart=System.nanoTime();
        try {
            certificateCustody.install(exact);
            own=certificateCustody.signInstalled(node,localKey);
        } finally {
            DemoV19PerfCounters.recordCustodyLocal(
                    System.nanoTime()-custodyLocalStart);
        }
        Exception lastFailure=null;
        long until=System.nanoTime()+TimeUnit.MILLISECONDS.toNanos(1300);
        while(System.nanoTime()<until){
            requireGrant(membership);
            List<DurableWalCustodyQuorum.Receipt> receipts=
                    new ArrayList<DurableWalCustodyQuorum.Receipt>();
            receipts.add(own);
            for(String peer:designatedDataPeers()){
                Future<ReplicationControlResponse> pending=null;
                long custodyRemoteStart=System.nanoTime();
                try {
                    pending=transport.control(DemoNettyBridge.endpoint(peer),
                        DurableWalCertificateCustodyControlHandler.request(
                                membership,exact));
                    ReplicationControlResponse response=pending.get(320,TimeUnit.MILLISECONDS);
                    receipts.add(DurableWalCertificateCustodyControlHandler.decodeVerified(
                            membership,exact,peer,response));
                }catch(Exception fail){lastFailure=fail;}
                finally{
                    DemoV19PerfCounters.recordCustodyPeer(
                            System.nanoTime()-custodyRemoteStart);
                    if(pending!=null && !pending.isDone())pending.cancel(true);
                }
                if(receipts.size()>=membership.majority())break;
            }
            if(receipts.size()>=membership.majority()){
                DemoDurableJournal wal=journals.journal("P000");
                DurableWalCertificateCustodyAckGate.requireDurableBeforeAck(
                    membership,exact,receipts,this::requireGrant,
                    (epoch,seq)->{
                        synchronized(wal){
                            if(!wal.isReadyForWrites() || wal.lastEpoch()!=epoch
                                    || wal.committedSeq()<seq)
                                throw new IOException("strict custody lacks fsynced primary WAL");
                            return wal.committedPrefixSha256Through(seq);
                        }
                    });
                confirmedCustodySeq=exact.committedSequence;
                requireGrant(membership);
                return;
            }
            Thread.sleep(10);
        }
        throw new IOException("majority physical certificate custody missing"
                +(lastFailure==null?"":": "+lastFailure.getMessage()));
    }

    /** Returns only AFTER 2 distinct signed, locally fsynced votes & disk cert. */
    DurableWalCommitAckGate.Confirmed certify(long epoch,long seq) throws Exception {
        if(committed==null || !node.equals(membership.primary))
            throw new IOException("non-primary cannot sign client durable ACK");
        requireGrant(membership);
        DemoDurableJournal local=journals.journal("P000");        long localStageStart=System.nanoTime();

        String hash;
        synchronized(local) {
            if(!local.isReadyForWrites() || local.committedSeq()<seq
                    || local.lastEpoch()!=epoch)
                throw new IOException("local WAL boundary not fsynced");
            hash=local.committedPrefixSha256Through(seq);
        }
        // Idempotent retry after lost TCP ACK: never attempt to overwrite
        // a previously durable certificate for exactly the same boundary.
        if(committed.committedSequence()==seq) {
            requireCustodiedCommit(seq);
            return DurableWalCommitAckGate.requireDurable(membership,committed,
                    seq,hash,(part,currentEpoch)->requireGrant(membership));
        }
        if(committed.committedSequence()>seq) {
            requireCustodiedCommit(seq);
            // Newer cumulative high-water certificates authenticate the
            // immutable fsynced WAL prefix containing this old request.
            // This is NOT an unbounded seq>= shortcut: Common rechecks the
            // signed end hash and exact historical request prefix plus grant.
            DurableWalCommitQuorum.LocalDurability trusted=(candidateEpoch,requested)->{
                synchronized(local) {
                    if(!local.isReadyForWrites() || local.lastEpoch()!=candidateEpoch
                            || local.committedSeq()<requested)
                        throw new IOException("historical ACK WAL prefix is not trusted");
                    return local.committedPrefixSha256Through(requested);
                }
            };
            return DurableWalCommitAckGate.requireDurableCovered(
                    membership,committed,seq,hash,trusted,
                    (part,currentEpoch)->requireGrant(membership));
        }
        DurableWalCommitQuorum.Receipt own=DurableWalCommitQuorum.sign(
                membership,node,seq,(askedEpoch,askedSeq)->{
                    synchronized(local) {
                        if(!local.isReadyForWrites() || local.lastEpoch()!=askedEpoch
                                || local.committedSeq()<askedSeq)
                            throw new IOException("local WAL became unsafe during ACK");
                        return local.committedPrefixSha256Through(askedSeq);
                    }
                },localKey);
        DemoV19PerfCounters.recordQuorumLocal(System.nanoTime()-localStageStart);
        // Default Common Netty command RPC times out at 3000 ms; a local
        // quorum wait must expire well BEFORE that upper-layer deadline.
        // Keep sufficient slack for certificate fsync and an explicit 503.
        final long proofWaitMillis=1800L;
        long until=System.nanoTime()+TimeUnit.MILLISECONDS.toNanos(proofWaitMillis);
        List<String> peers=designatedDataPeers();
        Exception last=null;
        long waitStageStart=System.nanoTime();
        while(System.nanoTime()<until) {
            requireGrant(membership);
            async.signal("P000");
            List<DurableWalCommitQuorum.Receipt> valid=new ArrayList<DurableWalCommitQuorum.Receipt>();
            valid.add(own);
            for(String peer:peers) {
                Future<ReplicationControlResponse> pending=null;
                try {
                    pending=transport.control(DemoNettyBridge.endpoint(peer),
                            DurableWalReceiptControlHandler.request(membership,seq));
                    ReplicationControlResponse reply=pending.get(320,TimeUnit.MILLISECONDS);
                    DurableWalCommitQuorum.Receipt receipt=
                            DurableWalReceiptControlHandler.decodeReceipt(reply);
                    if(hash.equals(receipt.commitPrefixSha256))valid.add(receipt);
                    else throw new IOException("replica signed a divergent WAL prefix");
                } catch(Exception e) {
                    last=e;
                } finally {
                    if(pending!=null && !pending.isDone())pending.cancel(true);
                }
                if(valid.size()>=membership.majority())break;
            }
            if(valid.size()>=membership.majority()) {
                requireGrant(membership);
                // All cryptographic validation and fsync reside in Common.
                DemoV19PerfCounters.recordQuorumWait(System.nanoTime()-waitStageStart);
                long certStageStart=System.nanoTime();
                committed.certifyAndPersist(seq,hash,valid);
                requireCustodiedCommit(seq);
                DurableWalCommitAckGate.Confirmed confirmed =
                        DurableWalCommitAckGate.requireDurable(membership,committed,
                                seq,hash,(part,currentEpoch)->requireGrant(membership));
                DemoV19PerfCounters.recordQuorumCert(System.nanoTime()-certStageStart);
                return confirmed;
            }
            // Low-latency availability probe only; never replaces verified
            // signed, fsynced WAL proof. Bound total wait above at 1800ms.
            // The former 75ms delay dominated the isolated 10TPS ACK path.
            Thread.sleep(10L);
        }
        throw new IOException("no independent-TCP-replica quorum WAL certificate within 1800ms"
                +(last==null?"":": "+last.getMessage()));
    }

    /**
     * Actual test-only batched WAL: one signed high-water mark, one majority
     * certificate fsync for all contiguous requests. No client gets ACK until
     * the certificate is durable and EACH prefix is validated by Common.
     */
    DurableWalCommitAckGate.Confirmed certifyBatch(
            long epoch,long first,long last) throws Exception {
        if(!"1".equals(System.getenv("DEMO_V19_GROUP_FORCE_PILOT"))
                || committed==null || !node.equals(membership.primary))
            throw new IOException("group certified ACK experiment disabled");
        requireGrant(membership);
        DemoDurableJournal local=journals.journal("P000");
        DurableWalCommitQuorum.LocalDurability trusted=(askedEpoch,askedSeq)->{
            synchronized(local) {
                if(!local.isReadyForWrites() || local.lastEpoch()!=askedEpoch
                        || local.committedSeq()<askedSeq)
                    throw new IOException("WAL group missing fsynced prefix");
                return local.committedPrefixSha256Through(askedSeq);
            }
        };
        String high=trusted.requireFsyncedPrefix(epoch,last);
        long certified=committed.committedSequence();
        if(certified>=last) {
            requireCustodiedCommit(last);
            return DurableWalCommitAckGate.requireDurableCovered(
                    membership,committed,last,high,trusted,
                    (p,e)->requireGrant(membership));
        }
        if(first!=certified+1 || last<first || last-first>=64)
            throw new IOException("uncertified WAL gap or batch beyond Common bound");
        DurableWalCommitQuorum.Receipt own=DurableWalCommitQuorum.sign(
                membership,node,last,trusted,localKey);
        long end=System.nanoTime()+TimeUnit.MILLISECONDS.toNanos(1800);
        Exception prior=null;
        while(System.nanoTime()<end) {
            requireGrant(membership);
            async.signal("P000");
            List<DurableWalCommitQuorum.Receipt> votes=
                    new ArrayList<DurableWalCommitQuorum.Receipt>();
            votes.add(own);
            for(String peer:designatedDataPeers()) {
                DurableWalCommitQuorum.Receipt cached=recentSignedBatches.get(peer);
                if("1".equals(System.getenv("DEMO_V19_SIGNED_BATCH_ACK_PILOT"))
                        && cached!=null && cached.sequence==last
                        && high.equals(cached.commitPrefixSha256)) {
                    DurableWalCommitQuorum.requireValidReceipt(membership,cached);
                    requireGrant(membership);
                    votes.add(cached);
                    if(votes.size()>=membership.majority())break;
                    continue;
                }
                Future<ReplicationControlResponse> pending=null;
                try {
                    pending=transport.control(DemoNettyBridge.endpoint(peer),
                            DurableWalReceiptControlHandler.request(membership,last));
                    DurableWalCommitQuorum.Receipt witness=
                            DurableWalReceiptControlHandler.decodeReceipt(
                                    pending.get(320,TimeUnit.MILLISECONDS));
                    if(high.equals(witness.commitPrefixSha256))votes.add(witness);
                    else throw new IOException("divergent batch WAL prefix");
                } catch(Exception absent) {
                    prior=absent;
                } finally {
                    if(pending!=null && !pending.isDone())pending.cancel(true);
                }
                if(votes.size()>=membership.majority())break;
            }
            if(votes.size()>=membership.majority()) {
                requireGrant(membership);
                committed.certifyAndPersistBatch(first,last,high,votes,trusted);
                requireCustodiedCommit(last);
                return DurableWalCommitAckGate.requireDurableCovered(
                        membership,committed,last,high,trusted,
                        (part,currentEpoch)->requireGrant(membership));
            }
            Thread.sleep(10L);
        }
        throw new IOException("no signed batch WAL quorum in 1800ms"
                +(prior==null?"":": "+prior.getMessage()));
    }

    /**
     * Single-fenced-epoch recovery of already fsynced WAL with a quorum
     * certification gap. The Common planner limits a pass to 64 contiguous
     * records; the ordinary Common certifyBatch still demands independent
     * signed 2/3 physical WAL witnesses, one fsynced CommitIndex cert and
     * a fresh Primary grant. Never creates an ACK or appends NEW WAL here.
     */
    long certifyNextPendingPrefix(long epoch) throws Exception {
        if(committed==null || !node.equals(membership.primary))
            throw new IOException("not authorized to advance quorum commit index");
        requireGrant(membership);
        DemoDurableJournal wal=journals.journal("P000");
        com.app.common.replication.DurableWalQuorumBacklog.Range next=
                com.app.common.replication.DurableWalQuorumBacklog.nextCertifiedRange(
                        committed.committedSequence(),wal.committedSeq());
        if(next==null)return committed.committedSequence();
        // Each independent witness must sign this exact, already-fsynced
        // chunk before the Common ledger is allowed to advance its index.
        certifyBatch(epoch,next.first,next.last);
        return committed.committedSequence();
    }

    void requireFreshWriteAdmission(long epoch,DemoDurableJournal journal)
            throws Exception {
        if(committed==null)throw new IOException("missing trusted Common CommitIndex");
        long seen=committed.committedSequence();
        if(journal.committedSeq()!=seen)
            certifyNextPendingPrefix(epoch);
        // Strict fail-closed: one signed 64-record repair step may not cover
        // the whole pending tail, so deny NEW requests until fully certified.
        com.app.common.replication.DurableWalQuorumBacklog
                .requireNoUncertifiedTail(
                        committed.committedSequence(),journal.committedSeq());
    }

    long certifiedSequence() throws Exception {
        if(committed==null)throw new IOException("quorum CommitIndex not enabled");
        requireGrant(membership);
        return committed.committedSequence();
    }

    DurableWalCommitAckGate.Confirmed certifyCovered(
            long epoch,long seq) throws Exception {
        requireGrant(membership);
        DemoDurableJournal local=journals.journal("P000");
        DurableWalCommitQuorum.LocalDurability trusted=(askedEpoch,askedSeq)->{
            synchronized(local) {
                if(!local.isReadyForWrites() || local.lastEpoch()!=askedEpoch
                        || local.committedSeq()<askedSeq)
                    throw new IOException("requested group prefix not fsynced");
                return local.committedPrefixSha256Through(askedSeq);
            }
        };
        String prefix=trusted.requireFsyncedPrefix(epoch,seq);
        requireCustodiedCommit(seq);
        return DurableWalCommitAckGate.requireDurableCovered(
                membership,committed,seq,prefix,trusted,
                (partition,currentEpoch)->requireGrant(membership));
    }

    /** Old RF2 survivor proof for non-routable new-epoch staging only. */
    void requireCertifiedOldRf2Survivor(PartitionAssignment old) throws Exception {
        if (!custodyEnabled || certificateCustody==null || old==null
                || !node.equals(old.getReplica())
                || !membership.primary.equals(old.getPrimary())
                || old.getEpoch()!=membership.epoch || old.replicaNodes().size()!=1)
            throw new IOException("not the exact old RF2 custodian");
        DurableWalCommitQuorum.Certificate proof=certificateCustody.highestVerified();
        if (proof==null || proof.committedSequence<1)
            throw new IOException("missing authenticated old ACK certificate");
        DemoDurableJournal journal=journals.journal(old.getPartitionId());
        synchronized(journal) {
            if (!journal.isReadyForWrites() || journal.lastEpoch()!=old.getEpoch()
                    || journal.committedSeq()<proof.committedSequence)
                throw new IOException("survivor WAL missing certified ACK prefix");
            if (!proof.commitPrefixSha256.equals(
                    journal.committedPrefixSha256Through(proof.committedSequence)))
                throw new IOException("survivor WAL differs from certified old ACK prefix");
        }
    }

    /** Safe lower bound for async RF2 role reversal: the new claimant owns
     * the old quorum-certified prefix. The newer local-only tail may lag B;
     * such loss is EXPLICITLY allowed only by AUTO_DEGRADED_LOCAL_DURABLE.
     * This is NOT a two-replica quorum commit certificate or proof of RPO=0.
     */
    long requireSafeEpoch3OldLearner(PartitionAssignment old) throws Exception {
        if (!custodyEnabled || certificateCustody==null || old==null
                || !("CommonHaDemoA".equals(node) || "CommonHaDemoB".equals(node))
                || old.getEpoch()<2 || old.getEpoch()>=DemoV19Rf2EpochLimits.MAX_EPOCH
                || node.equals(old.getPrimary())
                || !"READY".equals(old.getState())
                || !old.replicaNodes().isEmpty() || !old.isLearner(node))
            throw new IOException("not eligible old RF2 learner");
        DurableWalCommitQuorum.Certificate certified=certificateCustody.highestVerified();
        if (certified==null || certified.epoch!=1 || certified.committedSequence<1)
            throw new IOException("no old strict RF2 majority certificate");
        DemoDurableJournal wal=journals.journal("P000");
        synchronized(wal) {
            if (!wal.isReadyForWrites() || wal.lastEpoch()<2
                    || wal.committedSeq()<certified.committedSequence
                    || !certified.commitPrefixSha256.equals(
                            wal.committedPrefixSha256Through(certified.committedSequence)))
                throw new IOException("candidate cannot preserve old quorum ACK prefix");
            return wal.committedSeq();
        }
    }

    long requireSafeEpoch3Staged(PartitionAssignment staged) throws Exception {
        if (staged==null || staged.getEpoch()<3 || staged.getEpoch()>DemoV19Rf2EpochLimits.MAX_EPOCH
                || !node.equals(staged.getPrimary())
                || !"RECOVERING".equals(staged.getState())
                || staged.replicaNodes().size()!=0
                || staged.getLearners().size()!=1
                || node.equals(staged.getLearners().get(0))
                || !("CommonHaDemoA".equals(staged.getLearners().get(0))
                    || "CommonHaDemoB".equals(staged.getLearners().get(0))))
            throw new IOException("epoch3 staged candidate not the selected data owner");
        DurableWalCommitQuorum.Certificate head=certificateCustody==null
                ?null:certificateCustody.highestVerified();
        if (head==null || head.epoch!=1 || head.committedSequence<1)
            throw new IOException("missing old quorum-certified ACK base");
        DemoDurableJournal wal=journals.journal("P000");
        synchronized(wal) {
            if (!wal.isReadyForWrites() || wal.lastEpoch()<2
                    || wal.committedSeq()<head.committedSequence
                    || !head.commitPrefixSha256.equals(
                            wal.committedPrefixSha256Through(head.committedSequence)))
                throw new IOException("epoch3 local history cannot preserve old confirmed ACK");
            return wal.committedSeq();
        }
    }

    /** The old 2/2 ACK frontier becomes the local-durable degraded genesis.
     * Exact WAL equality rejects uncertified tails instead of inventing ACKs.
     */
    long requireSafeDegradedEpoch2Genesis(PartitionAssignment recovering) throws Exception {
        if (!custodyEnabled || certificateCustody==null || recovering==null
                || !node.equals(recovering.getPrimary())
                || recovering.getEpoch()!=membership.epoch+1
                || !"RECOVERING".equals(recovering.getState())
                || !recovering.replicaNodes().isEmpty()
                || recovering.getLearners().size()!=1
                || !membership.primary.equals(recovering.getLearners().get(0)))
            throw new IOException("not certified old RF2 survivor in new epoch");
        DurableWalCommitQuorum.Certificate head=certificateCustody.highestVerified();
        if (head==null || head.committedSequence<1)
            throw new IOException("missing authenticated old 2/2 ACK head");
        DemoDurableJournal journal=journals.journal("P000");
        synchronized(journal) {
            if (!journal.isReadyForWrites() || journal.lastEpoch()!=membership.epoch
                    || journal.committedSeq()!=head.committedSequence)
                throw new IOException("uncertified physical WAL tail or epoch mismatch");
            String actual=journal.committedPrefixSha256Through(head.committedSequence);
            if (!head.commitPrefixSha256.equals(actual))
                throw new IOException("old quorum certificate not covered by survivor WAL");
        }
        return head.committedSequence;
    }

    @Override public void close() throws Exception {
        try {transport.close();}
        finally {
            try {if(committed!=null)committed.close();}
            finally {if(certificateCustody!=null)certificateCustody.close();}
        }
    }
}
