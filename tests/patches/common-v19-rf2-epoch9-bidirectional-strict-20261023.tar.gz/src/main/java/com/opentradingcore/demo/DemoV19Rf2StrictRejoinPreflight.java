package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;
import com.app.common.partition.PartitionFailoverController;
import com.app.common.partition.ZkPartitionFailoverControlPlane;
import com.app.common.zk.ZookeeperClient;
import com.gateway.connector.utils.JsonUtils;
import java.io.IOException;
import java.util.Map;
import java.util.Objects;
import org.apache.zookeeper.data.Stat;

/**
 * A real, READ-ONLY preflight for restoring RF2 strict replication.
 * Uses independent JVM TCP status and old RSA quorum certificates, then
 * rechecks physical ZooKeeper Assignment version. A matching pair is only a
 * candidate: writes can advance after this method returns. In particular it
 * never advertises READY/2-of-2, never changes the ZK membership, and NEVER
 * converts a local ACK into a dual durable ACK.
 */
final class DemoV19Rf2StrictRejoinPreflight {
    private static final String PATH=DemoZkFenceSource.ISOLATED_ROOT
            +"/harness/assignments/P000";
    private final ZookeeperClient zk;
    private final ZkPartitionFailoverControlPlane plane;
    private final String local;

    DemoV19Rf2StrictRejoinPreflight(ZookeeperClient zk,
            ZkPartitionFailoverControlPlane plane,String local) {
        this.zk=Objects.requireNonNull(zk);
        this.plane=Objects.requireNonNull(plane);
        this.local=Objects.requireNonNull(local);
    }

    static final class Evidence {
        final long epoch,sequence,strictGenesisSeq,zkVersion;
        final String primary,learner,prefixSha256,stateDigest,oldCertifiedSha256;
        Evidence(long epoch,long sequence,long strictGenesisSeq,long zkVersion,
                String primary,String learner,String hash,String stateDigest,
                String oldCertifiedSha256) {
            this.epoch=epoch;this.sequence=sequence;
            this.strictGenesisSeq=strictGenesisSeq;this.zkVersion=zkVersion;
            this.primary=primary;this.learner=learner;
            this.prefixSha256=hash;this.stateDigest=stateDigest;
            this.oldCertifiedSha256=oldCertifiedSha256;
        }
        String summary(){return "epoch="+epoch+" seq="+sequence+" sha="+prefixSha256
            +" zkVersion="+zkVersion+" primary="+primary+" learner="+learner;}
    }

    Evidence once() throws Exception {
        if (!plane.isConnected()) throw new IOException("ZK quorum disconnected");
        PartitionFailoverController.VersionedAssignment pinned=plane.read("P000");
        if (pinned==null) throw new IOException("ZK assignment unavailable");
        PartitionAssignment a=pinned.getAssignment();
        String primary=a.getPrimary();
        if (!local.equals(primary) || !a.isRoutable() || a.getEpoch()<2
                || a.getEpoch()>=DemoV19Rf2EpochLimits.MAX_EPOCH || !a.replicaNodes().isEmpty()
                || a.getLearners().size()!=1)
            throw new IOException("current primary must have one learner and no replica: "+a+" local="+local);
        String learner=a.getLearners().get(0);
        if (primary.equals(learner) || !plane.isLive(primary) || !plane.isLive(learner))
            throw new IOException("distinct live physical peers required");
        Stat initial=new Stat();
        Object raw=zk.readData(PATH,initial);
        requireDegradedAssignment(raw,a);
        if(initial.getVersion()!=pinned.getVersion())
            throw new IOException("assignment advanced during read");

        Evidence proposed;
        try (DemoV19TcpClient tcp=new DemoV19TcpClient()) {
            Map<String,Object> first=tcp.status(primary);
            Map<String,Object> second=tcp.status(learner);
            Map<String,Object> firstProof=tcp.custodyHeadEvidence(primary);
            Map<String,Object> secondProof=tcp.custodyHeadEvidence(learner);
            proposed=compare(a,learner,pinned.getVersion(),first,second,
                    firstProof,secondProof);
        }
        if (!plane.isConnected() || !plane.isLive(primary) || !plane.isLive(learner))
            throw new IOException("ZK member disappeared after physical proof");
        PartitionFailoverController.VersionedAssignment after=plane.read("P000");
        if(after==null || after.getVersion()!=pinned.getVersion()
                || after.getAssignment().getEpoch()!=a.getEpoch()
                || !primary.equals(after.getAssignment().getPrimary())
                || !after.getAssignment().getLearners().equals(a.getLearners()))
            throw new IOException("assignment changed after physical proof");
        Stat finalStat=new Stat();
        requireDegradedAssignment(zk.readData(PATH,finalStat),a);
        if(finalStat.getVersion()!=initial.getVersion() || !plane.isConnected())
            throw new IOException("ZK durability policy changed during physical proof");
        return proposed;
    }

    private static void requireDegradedAssignment(Object raw,PartitionAssignment a)
            throws IOException {
        if(raw==null) throw new IOException("missing persisted durability policy");
        @SuppressWarnings("unchecked") Map<String,Object> v=JsonUtils.Deserialize(
                String.valueOf(raw),Map.class);
        if(v==null || !"AUTO_DEGRADED_LOCAL_DURABLE".equals(v.get("durabilityPolicy"))
                || !Boolean.FALSE.equals(v.get("quorumDurable"))
                || !a.getPrimary().equals(v.get("primary"))
                || number(v,"epoch")!=a.getEpoch()
                || !"READY".equals(v.get("state")))
            throw new IOException("degraded contract is not currently published");
    }

    static Evidence compare(PartitionAssignment a,String learner,int version,
            Map<String,Object> primary,Map<String,Object> replica,
            Map<String,Object> primaryOld,Map<String,Object> replicaOld)
            throws IOException {
        if(a==null || primary==null || replica==null || primaryOld==null
                || replicaOld==null || !"P000".equals(a.getPartitionId())
                || !a.isRoutable() || !a.isLearner(learner)
                || !a.replicaNodes().isEmpty() || a.getEpoch()<2)
            throw new IOException("not an admissible recovering RF2 group");
        if (!a.getPrimary().equals(primary.get("localNode"))
                || !learner.equals(replica.get("localNode"))
                || !a.getPrimary().equals(primaryOld.get("sourceNode"))
                || !learner.equals(replicaOld.get("sourceNode")))
            throw new IOException("TCP proof source does not match expected physical identity");
        if (!Boolean.TRUE.equals(primary.get("clean"))
                || !Boolean.TRUE.equals(replica.get("clean"))
                || !"P000".equals(primary.get("partitionId"))
                || !"P000".equals(replica.get("partitionId"))
                || number(primary,"committedSeq")<1
                || number(primary,"committedSeq")!=number(replica,"committedSeq")
                || number(primary,"lastEpoch")<2
                || number(primary,"lastEpoch")>a.getEpoch()
                || number(primary,"lastEpoch")!=number(replica,"lastEpoch")
                || !equalHash(primary.get("committedPrefixSha256"),
                        replica.get("committedPrefixSha256"))
                || !Objects.equals(primary.get("stateDigest"),replica.get("stateDigest"))
                || !Objects.equals(primary.get("distinctRequests"),replica.get("distinctRequests")))
            throw new IOException("physical WAL or replayed business state mismatch");
        if (!Boolean.TRUE.equals(primaryOld.get("cryptographicallyVerified"))
                || !Boolean.TRUE.equals(replicaOld.get("cryptographicallyVerified"))
                || number(primaryOld,"oldEpoch")!=1 || number(replicaOld,"oldEpoch")!=1
                || number(primaryOld,"oldWalVoterCount")!=2
                || number(replicaOld,"oldWalVoterCount")!=2
                || number(primaryOld,"certifiedSeq")<1
                || number(primaryOld,"certifiedSeq")!=number(replicaOld,"certifiedSeq")
                || number(primaryOld,"certifiedSeq")>number(primary,"committedSeq")
                || !equalHash(primaryOld.get("certifiedSha256"),
                        replicaOld.get("certifiedSha256")))
            throw new IOException("old strict RF2 quorum certificate not corroborated");
        return new Evidence(a.getEpoch(),number(primary,"committedSeq"),
                number(primaryOld,"certifiedSeq"),version,a.getPrimary(),learner,
                String.valueOf(primary.get("committedPrefixSha256")),
                String.valueOf(primary.get("stateDigest")),
                String.valueOf(primaryOld.get("certifiedSha256")));
    }
    private static long number(Map<String,Object> row,String key)throws IOException {
        Object v=row.get(key);
        if(!(v instanceof Number))throw new IOException("missing number "+key);
        return ((Number)v).longValue();
    }
    private static boolean equalHash(Object left,Object right) {
        return left instanceof String && right instanceof String
                && ((String)left).matches("[0-9a-f]{64}") && left.equals(right);
    }
}
