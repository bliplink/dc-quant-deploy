package com.opentradingcore.demo;

/** Bounded isolated RF2 pilot epoch range. One source of truth for WAL,
 * failover, learner promotion, readiness and repeat strict rejoin.
 * The production Common state machine has its own independent policies.
 */
final class DemoV19Rf2EpochLimits {
    static final long MAX_EPOCH=128;
    private DemoV19Rf2EpochLimits(){}
}
