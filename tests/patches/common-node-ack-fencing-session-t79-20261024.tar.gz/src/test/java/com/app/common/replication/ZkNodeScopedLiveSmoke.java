package com.app.common.replication;

import com.app.common.zk.ZookeeperClient;
import java.util.LinkedHashMap;
import java.util.Map;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.data.Stat;

/**
 * Run manually inside the isolated Docker JVM's 3-ZK test network.
 * This exercises real ZK reads/CAS/watches but NOT business WAL, nor
 * certified automatic physical failover. The transition in this smoke is a
 * TEST OPERATOR manifest CAS and must never be labeled automated HA.
 */
public final class ZkNodeScopedLiveSmoke {
    private static final String ROOT="/dc/cluster/t79-node-control-ephemeral-session";
    private static final String MANIFEST=ROOT+"/manifest";
    private static final String HOSTS=
        "otc-ha-zk1:2181,otc-ha-zk2:2181,otc-ha-zk3:2181";
    private static Map<String,ZkNodeScopedControlPlane.Assignment> initial(){
        Map<String,ZkNodeScopedControlPlane.Assignment> partitions=
            new LinkedHashMap<>();
        for(int i=0;i<256;i++){
            String id=String.format("P%03d",i);
            boolean primaryA=(i%2==0);
            DurableWalAckPolicy policy=i%4<2
                ?DurableWalAckPolicy.STRICT_QUORUM
                :DurableWalAckPolicy.LOCAL_DURABLE_ASYNC;
            partitions.put(id,new ZkNodeScopedControlPlane.Assignment(
                new NodePartitionGrantTable.Partition(id,1,
                    primaryA?"NodeA":"NodeB",
                    primaryA?"NodeB":"NodeA",policy),true));
        }
        return partitions;
    }
    private static void ensure(ZookeeperClient c,String path){
        if(!c.exists(path))
            c.create(path,"",CreateMode.PERSISTENT);
    }
    private static void waitReady(NodeClusterControlManager controller,
            String id,long epoch,DurableWalAckPolicy policy,boolean primary)
            throws Exception{
        long until=System.nanoTime()+5000000000L;
        while(System.nanoTime()<until){
            try{
                NodePartitionGrantTable.Permit permit=primary
                    ?controller.requirePrimary(id,epoch,policy)
                    :controller.requireReplica(id,epoch,policy);
                permit.requireCurrent();return;
            }catch(Exception noGrant){Thread.sleep(80);}
        }
        throw new IllegalStateException("physical ZooKeeper grant did not become READY "+
            id+" epoch="+epoch+" nodeRolePrimary="+primary);
    }
    private static void mustReject(NodeClusterControlManager manager,
            String id,long epoch,DurableWalAckPolicy policy,boolean primary)
            throws Exception{
        try{
            if(primary)manager.requirePrimary(id,epoch,policy).requireCurrent();
            else manager.requireReplica(id,epoch,policy).requireCurrent();
        }catch(java.io.IOException denied){return;}
        throw new IllegalStateException("OLD OR UNRETIRED ZK GRANT LEAKED "+
            id+" epoch="+epoch);
    }
    /** Separate fresh ZK path for real 2/3 quorum-loss fail-closed injection.
     * A shell operator must SIGSTOP/stop TWO isolated ZK containers AFTER
     * READY prints. The test never claims automatic Epoch recovery. */
    private static void quorumOutage()throws Exception {
        final String root=ROOT+"-outage",path=root+"/manifest";
        try(ZookeeperClientResource adminClient=new ZookeeperClientResource(HOSTS);
            ZookeeperClientResource dataClient=new ZookeeperClientResource(HOSTS)){
            ZookeeperClient admin=adminClient.client;
            ensure(admin,"/dc");ensure(admin,"/dc/cluster");
            ensure(admin,root);ensure(admin,root+"/leases");
            ZkNodeScopedControlPlane.Manifest genesis=
                new ZkNodeScopedControlPlane.Manifest(1,initial());
            if(!admin.exists(path))
                admin.create(path,genesis.encode(),CreateMode.PERSISTENT);
            if(!genesis.encode().equals(String.valueOf(admin.readData(path))))
                throw new IllegalStateException("existing ZK outage fixture changed");
            ZkNodeScopedControlPlane source=new ZkNodeScopedControlPlane(
                dataClient.client,"NodeA",path,root+"/leases/NodeA",
                "t78-quorum-outage-a",1200,0);
            NodePartitionGrantTable grants=source.newGrantTable();
            try(NodeClusterControlManager manager=new NodeClusterControlManager(
                    "NodeA",source,grants,250)){
                source.attach(manager);manager.start();
                waitReady(manager,"P000",1,DurableWalAckPolicy.STRICT_QUORUM,true);
                waitReady(manager,"P002",1,DurableWalAckPolicy.LOCAL_DURABLE_ASYNC,true);
                System.out.println("T78_QUORUM_OUTAGE_READY_256");
                System.out.flush();
                Thread.sleep(9500L);
                mustReject(manager,"P000",1,DurableWalAckPolicy.STRICT_QUORUM,true);
                mustReject(manager,"P002",1,DurableWalAckPolicy.LOCAL_DURABLE_ASYNC,true);
                System.out.println("T78_QUORUM_OUTAGE_BOTH_ACK_MODES_FAIL_CLOSED"+
                    " 256routes="+manager.localPartitionCount()+
                    " successfulControlRenewals="+manager.successfulRenewals()+
                    " failedControlRenewals="+manager.failedRenewals());
                System.out.flush();
            }finally{source.close();}
        }
    }
    public static void main(String[] argv)throws Exception{
        if(argv.length==1 && "--quorum-outage".equals(argv[0])){
            quorumOutage();return;
        }
        if(argv.length!=0)throw new IllegalArgumentException("no parameters");
        try(ZookeeperClientResource coordinator=new ZookeeperClientResource(HOSTS);
            ZookeeperClientResource clientA=new ZookeeperClientResource(HOSTS);
            ZookeeperClientResource clientB=new ZookeeperClientResource(HOSTS)){
            ZookeeperClient admin=coordinator.client;
            ensure(admin,"/dc");ensure(admin,"/dc/cluster");ensure(admin,ROOT);
            ensure(admin,ROOT+"/leases");
            ZkNodeScopedControlPlane.Manifest genesis=
                new ZkNodeScopedControlPlane.Manifest(1,initial());
            if(!admin.exists(MANIFEST))
                admin.create(MANIFEST,genesis.encode(),CreateMode.PERSISTENT);
            Stat existingStat=new Stat();
            Object existing=admin.readData(MANIFEST,existingStat);
            if(!genesis.encode().equals(String.valueOf(existing)))
                throw new IllegalStateException("refuse existing altered test manifest");
            final long ttl=1500,retire=1900; // > old TTL + safety margin
            ZkNodeScopedControlPlane sourceA=new ZkNodeScopedControlPlane(
                clientA.client,"NodeA",MANIFEST,ROOT+"/leases/NodeA",
                "t78-smoke-session-a",ttl,retire);
            ZkNodeScopedControlPlane sourceB=new ZkNodeScopedControlPlane(
                clientB.client,"NodeB",MANIFEST,ROOT+"/leases/NodeB",
                "t78-smoke-session-b",ttl,retire);
            // Test-only operator authorization for a manual ZK CAS.
            // NOT evidence of automatic signed WAL/Custody failover.
            ZkNodeScopedControlPlane.CertifiedManifestTransition testCutover=
                (node,previous,next,version)->{
                    if(previous.generation!=1 || next.generation!=2
                        || next.assignments.get("P000").partition.epoch!=2)
                        throw new java.io.IOException("unverified test cutover");
                };
            sourceA.useCertifiedManifestTransitions(testCutover);
            sourceB.useCertifiedManifestTransitions(testCutover);
            NodePartitionGrantTable gA=sourceA.newGrantTable(),gB=sourceB.newGrantTable();
            try(NodeClusterControlManager mA=new NodeClusterControlManager(
                    "NodeA",sourceA,gA,300);
                NodeClusterControlManager mB=new NodeClusterControlManager(
                    "NodeB",sourceB,gB,300)){
                sourceA.attach(mA);sourceB.attach(mB);
                mA.start();mB.start();
                waitReady(mA,"P000",1,DurableWalAckPolicy.STRICT_QUORUM,true);
                waitReady(mB,"P000",1,DurableWalAckPolicy.STRICT_QUORUM,false);
                waitReady(mA,"P002",1,DurableWalAckPolicy.LOCAL_DURABLE_ASYNC,true);
                gA.primary("P000",1,DurableWalAckPolicy.STRICT_QUORUM)
                    .requireAckEvidence("QUORUM_DURABLE",true,false);
                gA.primary("P002",1,DurableWalAckPolicy.LOCAL_DURABLE_ASYNC)
                    .requireAckEvidence("LOCAL_DURABLE_ASYNC",false,true);
                if(mA.localPartitionCount()!=256 || mB.localPartitionCount()!=256)
                    throw new IllegalStateException("real ZK node scope not 256");
                System.out.println("T78_REAL_ZK_NODE_256_BOTH_MODES_READY "+
                    "nodeA="+mA.localPartitionCount()+" nodeB="+mB.localPartitionCount()+
                    " renewA="+mA.successfulRenewals()+
                    " renewB="+mB.successfulRenewals()+
                    " manifestReadsA="+sourceA.manifestZkReads()+
                    " manifestReadsB="+sourceB.manifestZkReads()+
                    " nodeLeaseCasA="+sourceA.leaseQuorumCasWrites()+
                    " nodeLeaseCasB="+sourceB.leaseQuorumCasWrites());
                Map<String,ZkNodeScopedControlPlane.Assignment> changed=
                    new LinkedHashMap<>(initial());
                changed.put("P000",new ZkNodeScopedControlPlane.Assignment(
                    new NodePartitionGrantTable.Partition("P000",2,"NodeB",
                        "NodeA",DurableWalAckPolicy.STRICT_QUORUM),true));
                ZkNodeScopedControlPlane.Manifest next=
                    new ZkNodeScopedControlPlane.Manifest(2,changed);
                // Only to validate the ZK/watch/CAS adapter, not an
                // authorized automatic failover or production cutover.
                admin.writeDataReturnStat(MANIFEST,next.encode(),existingStat.getVersion());
                Thread.sleep(300); // asynchronous ZK Watch delivery
                mustReject(mA,"P000",1,DurableWalAckPolicy.STRICT_QUORUM,true);
                mustReject(mB,"P000",2,DurableWalAckPolicy.STRICT_QUORUM,true);
                // P001 is unaffected by P000 role swap; no extra Epoch.
                waitReady(mA,"P001",1,DurableWalAckPolicy.STRICT_QUORUM,false);
                waitReady(mB,"P001",1,DurableWalAckPolicy.STRICT_QUORUM,true);
                System.out.println("T78_REAL_ZK_UNRELATED_255_NO_EPOCH_BUMP");
                waitReady(mB,"P000",2,DurableWalAckPolicy.STRICT_QUORUM,true);
                waitReady(mA,"P000",2,DurableWalAckPolicy.STRICT_QUORUM,false);
                Stat leaseA=new Stat(),leaseB=new Stat();
                admin.readData(ROOT+"/leases/NodeA",leaseA);
                admin.readData(ROOT+"/leases/NodeB",leaseB);
                System.out.println("T78_REAL_ZK_NODE_CAS_WATCH_ROLE_CHANGE_PASS "+
                    "manifestGeneration=2 onlyP000Epoch=2 unaffectedP001Epoch=1 "+
                    "leaseVersionA="+leaseA.getVersion()+
                    " leaseVersionB="+leaseB.getVersion()+
                    " manifestReadsA="+sourceA.manifestZkReads()+
                    " manifestReadsB="+sourceB.manifestZkReads()+
                    " nodeLeaseCasA="+sourceA.leaseQuorumCasWrites()+
                    " nodeLeaseCasB="+sourceB.leaseQuorumCasWrites());
            }finally{sourceA.close();sourceB.close();}
        }
    }
    private static class ZookeeperClientResource implements AutoCloseable {
        final ZookeeperClient client;
        ZookeeperClientResource(String hosts){
            this.client=new ZookeeperClient(hosts,null,null);
        }
        @Override public void close(){client.close();}
    }
}
