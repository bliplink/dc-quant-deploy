package com.app.common.replication;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import org.junit.Test;
import static org.junit.Assert.*;

public final class ZkNodeScopedControlPlaneTest {
    private static final String MANIFEST="/test/cluster/manifest";
    private static final String LEASE="/test/cluster/leases/NodeA";
    static class FakeOps implements ZkNodeScopedControlPlane.Ops {
        final Map<String,ZkNodeScopedControlPlane.Value> data=new LinkedHashMap<>();
        int readCalls,manifestReads,writeCasCalls,ephemeralCreates;
        boolean connected=true,failCas,mutateDuringCas,rotateSessionAfterCas;
        long physicalSession=0x123456789L;
        Runnable changed=()->{},disconnected=()->{};
        @Override public synchronized boolean connected(){return connected;}
        @Override public synchronized long sessionId(){
            return connected?physicalSession:-1L;
        }
        @Override public synchronized ZkNodeScopedControlPlane.Value read(String path){
            readCalls++;
            if(MANIFEST.equals(path))manifestReads++;
            return data.get(path);
        }
        @Override public synchronized boolean createEphemeral(String path,String owner){
            ephemeralCreates++;
            if(data.containsKey(path))return false;
            data.put(path,new ZkNodeScopedControlPlane.Value(owner,0,
                physicalSession));
            return true;
        }
        @Override public synchronized ZkNodeScopedControlPlane.Value compareAndSet(
                String path,int version,String owner){
            writeCasCalls++;
            if(!connected||failCas)return null;
            ZkNodeScopedControlPlane.Value old=data.get(path);
            if(old==null || old.version!=version)return null;
            if(mutateDuringCas){
                mutateDuringCas=false;
                ZkNodeScopedControlPlane.Manifest next=manifest(2,1,false);
                data.put(MANIFEST,new ZkNodeScopedControlPlane.Value(
                    next.encode(),data.get(MANIFEST).version+1));
                changed.run();
            }
            ZkNodeScopedControlPlane.Value done=
                new ZkNodeScopedControlPlane.Value(owner,version+1,
                    old.ephemeralOwner);
            data.put(path,done);
            if(rotateSessionAfterCas){
                rotateSessionAfterCas=false;
                physicalSession++;
            }
            return done;
        }
        @Override public void watchManifest(String path,Runnable onChange){
            changed=onChange;
        }
        @Override public void watchDisconnect(Runnable onDisconnect){
            disconnected=onDisconnect;
        }
        synchronized void publish(ZkNodeScopedControlPlane.Manifest m){
            int next=data.containsKey(MANIFEST)?data.get(MANIFEST).version+1:0;
            data.put(MANIFEST,new ZkNodeScopedControlPlane.Value(m.encode(),next));
            changed.run();
        }
        synchronized void disconnect(){
            connected=false;disconnected.run();
        }
    }
    private static ZkNodeScopedControlPlane.Manifest manifest(long gen,long epoch,
            boolean swapFirst){
        Map<String,ZkNodeScopedControlPlane.Assignment> p=new LinkedHashMap<>();
        for(int i=0;i<256;i++){
            String id=String.format("P%03d",i);
            boolean primaryA=i%2==0;
            if(swapFirst && i==0)primaryA=false;
            DurableWalAckPolicy policy=i%4<2
                ? DurableWalAckPolicy.STRICT_QUORUM
                : DurableWalAckPolicy.LOCAL_DURABLE_ASYNC;
            p.put(id,new ZkNodeScopedControlPlane.Assignment(
                new NodePartitionGrantTable.Partition(id,epoch,
                    primaryA?"NodeA":"NodeB",primaryA?"NodeB":"NodeA",policy),
                true));
        }
        return new ZkNodeScopedControlPlane.Manifest(gen,p);
    }
    private static void denied(Checked task)throws Exception {
        try{task.go();fail("expected fail closed");}
        catch(IOException expected){}
    }
    private interface Checked {void go()throws Exception;}
    private static final class Fixture {
        final FakeOps ops=new FakeOps();
        final ZkNodeScopedControlPlane source;
        final NodePartitionGrantTable grants;
        final NodeClusterControlManager manager;
        Fixture(long leaseMillis){
            ops.publish(manifest(1,1,false));
            source=new ZkNodeScopedControlPlane(ops,"NodeA",MANIFEST,LEASE,
                "session-001",leaseMillis,0);
            grants=source.newGrantTable();
            manager=new NodeClusterControlManager("NodeA",source,grants,500);
            source.attach(manager);
        }
    }

    @Test public void oneQuorumLeaseCASAuthorizes256RoutesAnd100kBusinessOps()
            throws Exception {
        Fixture f=new Fixture(1000);
        f.manager.refresh();
        assertEquals(256,f.manager.localPartitionCount());
        assertEquals(1,f.ops.writeCasCalls);
        assertEquals(1,f.ops.ephemeralCreates);
        int reads=f.ops.readCalls;
        for(int i=0;i<100000;i++){
            int n=i%256;
            String p=String.format("P%03d",n);
            DurableWalAckPolicy mode=n%4<2
                ? DurableWalAckPolicy.STRICT_QUORUM
                : DurableWalAckPolicy.LOCAL_DURABLE_ASYNC;
            NodePartitionGrantTable.Permit permit=n%2==0
                ?f.manager.requirePrimary(p,1,mode)
                :f.manager.requireReplica(p,1,mode);
            permit.requireCurrent();
            if(n%2==0)permit.requireAckEvidence(mode.ackDurabilityMode,
                mode.quorumDurable,mode.possibleDataLossIfPrimaryPermanentlyLost);
        }
        assertEquals(reads,f.ops.readCalls);
        assertEquals(1,f.ops.writeCasCalls);
        int readManifestCount=f.ops.manifestReads;
        f.manager.refresh();
        assertEquals(2,f.ops.writeCasCalls);
        assertEquals(readManifestCount,f.ops.manifestReads);
        assertEquals(256,f.manager.localPartitionCount());
        f.manager.close();
    }

    @Test public void validRenewalCannotInvalidateInflightAckBeforeTableInstall()
            throws Exception {
        Fixture f=new Fixture(1200);
        f.manager.refresh();
        NodePartitionGrantTable.Permit strict=f.manager.requirePrimary("P000",1,
            DurableWalAckPolicy.STRICT_QUORUM);
        NodePartitionGrantTable.Permit async=f.manager.requirePrimary("P002",1,
            DurableWalAckPolicy.LOCAL_DURABLE_ASYNC);
        // The control thread has completed its next real majority CAS,
        // but has NOT yet atomically published the new grant table state.
        // A hotpath ACK must remain valid throughout a normal heartbeat.
        NodePartitionGrantTable.Batch refreshed=f.source.renewNodeLease("NodeA");
        strict.requireAckEvidence("QUORUM_DURABLE",true,false);
        async.requireAckEvidence("LOCAL_DURABLE_ASYNC",false,true);
        f.grants.install(refreshed);
        strict.requireAckEvidence("QUORUM_DURABLE",true,false);
        async.requireAckEvidence("LOCAL_DURABLE_ASYNC",false,true);
        assertEquals(2,f.ops.writeCasCalls);
        f.manager.close();
    }

    @Test public void manifestOnePartitionRoleChangeOnlyBumpsItsEpoch()
            throws Exception{
        Fixture f=new Fixture(1200);
        // Isolated test authority only; actual deployment requires real
        // signed dual-Custody/CommitIndex cutover proof.
        f.source.useCertifiedManifestTransitions((node,prev,next,zkVersion)->{
            if(prev.generation>=next.generation)
                throw new IOException("bad manifest transition");
        });
        f.manager.refresh();
        NodePartitionGrantTable.Permit old=f.manager.requirePrimary("P000",1,
            DurableWalAckPolicy.STRICT_QUORUM);
        // Only P000 changes owner and advances Epoch; 255 peers keep Epoch1.
        Map<String,ZkNodeScopedControlPlane.Assignment> next=
            new LinkedHashMap<>(manifest(1,1,false).assignments);
        next.put("P000",new ZkNodeScopedControlPlane.Assignment(
            new NodePartitionGrantTable.Partition("P000",2,
                "NodeB","NodeA",DurableWalAckPolicy.STRICT_QUORUM),true));
        f.ops.publish(new ZkNodeScopedControlPlane.Manifest(2,next));
        denied(old::requireCurrent);
        f.manager.refresh();
        f.manager.requireReplica("P000",2,
            DurableWalAckPolicy.STRICT_QUORUM).requireCurrent();
        f.manager.requireReplica("P001",1,
            DurableWalAckPolicy.STRICT_QUORUM).requireCurrent();
        denied(()->f.manager.requirePrimary("P000",1,
            DurableWalAckPolicy.STRICT_QUORUM));
        assertEquals(2,f.ops.writeCasCalls);
        f.manager.close();
    }

    @Test public void changedManifestWithoutCertifiedCutoverMustFailClosed()
            throws Exception {
        Fixture f=new Fixture(1200);
        f.manager.refresh();
        f.ops.publish(manifest(2,2,true));
        f.manager.refresh();
        assertEquals(1,f.manager.failedRenewals());
        denied(()->f.manager.requireReplica("P000",2,
            DurableWalAckPolicy.STRICT_QUORUM));
        f.manager.close();
    }

    @Test public void identicalLeaseTokenCannotStealAnotherZkSession()throws Exception{
        Fixture f=new Fixture(1500);
        f.ops.data.put(LEASE,new ZkNodeScopedControlPlane.Value(
            "session-001",0,0x666666L));
        f.manager.refresh();
        assertEquals(1,f.manager.failedRenewals());
        assertEquals(0,f.ops.writeCasCalls);
        denied(()->f.manager.requirePrimary("P000",1,
            DurableWalAckPolicy.STRICT_QUORUM));
        f.manager.close();
    }

    @Test public void persistentNodeLeaseIsNotEphemeralOwner()throws Exception{
        Fixture f=new Fixture(1500);
        f.ops.data.put(LEASE,new ZkNodeScopedControlPlane.Value(
            "session-001",0,0));
        f.manager.refresh();
        assertEquals(1,f.manager.failedRenewals());
        denied(()->f.manager.requirePrimary("P002",1,
            DurableWalAckPolicy.LOCAL_DURABLE_ASYNC));
        f.manager.close();
    }

    @Test public void ZkSessionRotatedDuringLeaseCASRejectsOldClient()throws Exception{
        Fixture f=new Fixture(1500);
        f.ops.rotateSessionAfterCas=true;
        f.manager.refresh();
        assertEquals(1,f.manager.failedRenewals());
        denied(()->f.manager.requirePrimary("P000",1,
            DurableWalAckPolicy.STRICT_QUORUM));
        f.manager.close();
    }

    @Test public void noMajorityCASNoGrantEvenIfLocalZkReadSucceeds()
            throws Exception {
        Fixture f=new Fixture(1200);
        f.ops.failCas=true;
        f.manager.refresh();
        assertEquals(1,f.manager.failedRenewals());
        denied(()->f.manager.requirePrimary("P000",1,
            DurableWalAckPolicy.STRICT_QUORUM));
        f.manager.close();
    }

    @Test public void manifestWatchArrivingDuringCASFencesInFlightResult()
            throws Exception {
        Fixture f=new Fixture(1200);
        f.manager.refresh();
        f.ops.mutateDuringCas=true;
        f.manager.refresh();
        assertEquals(1,f.manager.failedRenewals());
        denied(()->f.manager.requirePrimary("P000",1,
            DurableWalAckPolicy.STRICT_QUORUM));
        f.manager.close();
    }

    @Test public void sessionLossNeverAllowsOldEpochAfterQuorumReconnect()
            throws Exception {
        Fixture f=new Fixture(150);
        f.manager.refresh();
        f.ops.disconnect();
        denied(()->f.manager.requirePrimary("P000",1,
            DurableWalAckPolicy.STRICT_QUORUM));
        f.ops.connected=true;
        f.manager.refresh();
        assertEquals(1,f.manager.failedRenewals());
        denied(()->f.manager.requirePrimary("P000",1,
            DurableWalAckPolicy.STRICT_QUORUM));
        f.manager.close();
    }

    @Test public void newEpochRequiresRealExternalCustodyAuthorizationAndLeaseRetirement()
            throws Exception {
        Fixture f=new Fixture(150);
        f.manager.refresh();
        f.ops.disconnect();
        f.ops.connected=true;
        f.ops.publish(manifest(2,2,false));
        f.manager.refresh();
        assertEquals(1,f.manager.failedRenewals());
        final AtomicInteger attest=new AtomicInteger();
        f.source.useCertifiedRecovery((node,before,after,zkVersion)->{
            assertEquals("NodeA",node);
            assertEquals(1,before.generation);
            assertEquals(2,after.generation);
            attest.incrementAndGet();
        });
        // Since T77 hard-revoked the old full node lease, the new generation
        // must pass its actual retirement window before any new ACK is valid.
        f.manager.refresh();
        assertEquals(0,attest.get());
        Thread.sleep(390);
        f.manager.refresh();
        assertEquals(1,attest.get());
        f.manager.requirePrimary("P000",2,
            DurableWalAckPolicy.STRICT_QUORUM).requireCurrent();
        denied(()->f.manager.requirePrimary("P000",1,
            DurableWalAckPolicy.STRICT_QUORUM));
        f.manager.close();
    }

    @Test public void strictAndAsyncCannotBeRelabelledAtAck()throws Exception{
        Fixture f=new Fixture(1500);
        f.manager.refresh();
        NodePartitionGrantTable.Permit strict=f.manager.requirePrimary("P000",1,
            DurableWalAckPolicy.STRICT_QUORUM);
        strict.requireAckEvidence("QUORUM_DURABLE",true,false);
        denied(()->strict.requireAckEvidence("LOCAL_DURABLE_ASYNC",false,true));
        NodePartitionGrantTable.Permit async=f.manager.requirePrimary("P002",1,
            DurableWalAckPolicy.LOCAL_DURABLE_ASYNC);
        async.requireAckEvidence("LOCAL_DURABLE_ASYNC",false,true);
        denied(()->async.requireAckEvidence("QUORUM_DURABLE",true,false));
        f.manager.close();
    }

    @Test public void invalidManifestOrDuplicateFailsClosed()throws Exception{
        denied(()->ZkNodeScopedControlPlane.Manifest.parse("NPC1|1\nP000|1|A|B|STRICT_QUORUM|READY\nP000|1|A|B|STRICT_QUORUM|READY"));
        denied(()->ZkNodeScopedControlPlane.Manifest.parse("NPC1|1\nP000|1|A|B|UNKNOWN|READY"));
        denied(()->ZkNodeScopedControlPlane.Manifest.parse("NPC1|1\nP000|1|A|B|STRICT_QUORUM|WRITING"));
        assertEquals(256,ZkNodeScopedControlPlane.Manifest.parse(
            manifest(9,3,true).encode()).assignments.size());
    }
}
