package com.app.common.replication;

import com.app.common.zk.ZookeeperClient;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.data.Stat;

/**
 * Physical ZK 3-process regression: two distinct ZooKeeper sessions with the
 * SAME node identity and textual token. Only the actual EPHEMERAL creator
 * is authorized to CAS-renew and ACK. Strict and local-async both fail closed
 * on the impostor. Does NOT simulate business WAL/failover.
 */
public final class ZkNodeDuplicateSessionSmoke {
    private static final String HOSTS =
        "otc-ha-zk1:2181,otc-ha-zk2:2181,otc-ha-zk3:2181";
    private static final String ROOT="/dc/cluster/t79-duplicate-physical-session";
    private static void ensure(ZookeeperClient zk,String path) {
        if(!zk.exists(path))zk.create(path,"",CreateMode.PERSISTENT);
    }
    private static ZkNodeScopedControlPlane.Manifest genesis(){
        Map<String,ZkNodeScopedControlPlane.Assignment> assignments=
            new LinkedHashMap<>();
        for(int i=0;i<256;i++){
            String id=String.format("P%03d",i);
            DurableWalAckPolicy mode=i%4<2
                ?DurableWalAckPolicy.STRICT_QUORUM
                :DurableWalAckPolicy.LOCAL_DURABLE_ASYNC;
            String leader=i%2==0?"NodeA":"NodeB";
            String buddy=i%2==0?"NodeB":"NodeA";
            assignments.put(id,new ZkNodeScopedControlPlane.Assignment(
                new NodePartitionGrantTable.Partition(id,1,leader,buddy,mode),true));
        }
        return new ZkNodeScopedControlPlane.Manifest(1,assignments);
    }
    private static void deny(NodeClusterControlManager controller,String partition,
            DurableWalAckPolicy mode)throws Exception{
        try{
            controller.requirePrimary(partition,1,mode).requireAckEvidence(
                mode.ackDurabilityMode,mode.quorumDurable,
                mode.possibleDataLossIfPrimaryPermanentlyLost);
            throw new IllegalStateException("FOREIGN_ZK_SESSION_WAS_AUTHORIZED");
        }catch(IOException expected){}
    }
    public static void main(String[] args)throws Exception {
        if(args.length!=0)throw new IllegalArgumentException("no args");
        ZookeeperClient admin=new ZookeeperClient(HOSTS,null,null);
        ZookeeperClient real=new ZookeeperClient(HOSTS,null,null);
        ZookeeperClient impostor=new ZookeeperClient(HOSTS,null,null);
        try{
            ensure(admin,"/dc");ensure(admin,"/dc/cluster");ensure(admin,ROOT);
            ensure(admin,ROOT+"/leases");
            String manifest=ROOT+"/manifest";
            String lease=ROOT+"/leases/NodeA";
            if(!admin.exists(manifest))
                admin.create(manifest,genesis().encode(),CreateMode.PERSISTENT);
            ZkNodeScopedControlPlane owner=new ZkNodeScopedControlPlane(real,
                "NodeA",manifest,lease,"same-session-token",1500,0);
            ZkNodeScopedControlPlane rival=new ZkNodeScopedControlPlane(impostor,
                "NodeA",manifest,lease,"same-session-token",1500,0);
            try(NodeClusterControlManager a=new NodeClusterControlManager(
                    "NodeA",owner,owner.newGrantTable(),300);
                NodeClusterControlManager b=new NodeClusterControlManager(
                    "NodeA",rival,rival.newGrantTable(),300)){
                owner.attach(a);rival.attach(b);
                a.refresh();
                a.requirePrimary("P000",1,DurableWalAckPolicy.STRICT_QUORUM)
                    .requireAckEvidence("QUORUM_DURABLE",true,false);
                a.requirePrimary("P002",1,DurableWalAckPolicy.LOCAL_DURABLE_ASYNC)
                    .requireAckEvidence("LOCAL_DURABLE_ASYNC",false,true);
                Stat first=new Stat();admin.readData(lease,first);
                if(first.getEphemeralOwner()!=real.activeSessionId()
                        || real.activeSessionId()==impostor.activeSessionId())
                    throw new IllegalStateException("physical sessions not distinct");
                b.refresh();
                if(b.successfulRenewals()!=0L || b.failedRenewals()!=1L)
                    throw new IllegalStateException("session impostor renewed same token");
                deny(b,"P000",DurableWalAckPolicy.STRICT_QUORUM);
                deny(b,"P002",DurableWalAckPolicy.LOCAL_DURABLE_ASYNC);
                Stat after=new Stat();admin.readData(lease,after);
                if(after.getVersion()!=first.getVersion()
                        || after.getEphemeralOwner()!=first.getEphemeralOwner())
                    throw new IllegalStateException("impostor altered original lease");
                a.requirePrimary("P000",1,DurableWalAckPolicy.STRICT_QUORUM)
                    .requireAckEvidence("QUORUM_DURABLE",true,false);
                System.out.println("T79_REAL_TWO_ZK_SESSIONS_IDENTICAL_TOKEN"+
                    " FOREIGN_EPHEMERAL_OWNER_DENIED strict=true async=true"+
                    " ownerUnchanged=true originalCAS="+a.successfulRenewals()+
                    " impostorCAS="+b.successfulRenewals()+
                    " partitionRoutes=256");
            }finally{owner.close();rival.close();}
        }finally{impostor.close();real.close();admin.close();}
    }
}
