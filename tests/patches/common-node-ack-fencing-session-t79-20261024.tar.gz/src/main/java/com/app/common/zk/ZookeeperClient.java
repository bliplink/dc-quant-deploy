package com.app.common.zk;

import java.nio.charset.Charset;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.I0Itec.zkclient.IZkChildListener;
import org.I0Itec.zkclient.IZkDataListener;
import org.I0Itec.zkclient.IZkStateListener;
import org.I0Itec.zkclient.ZkClient;
import org.I0Itec.zkclient.ZkConnection;
import org.I0Itec.zkclient.exception.ZkMarshallingError;
import org.I0Itec.zkclient.serialize.ZkSerializer;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.ZooKeeper;
import org.apache.zookeeper.Watcher.Event.KeeperState;
import org.apache.zookeeper.data.Stat;

import com.app.common.utils.StringUtil;
import com.mysql.jdbc.StringUtils;

import lombok.extern.slf4j.Slf4j;
@Slf4j
public class ZookeeperClient {
	static final String SESSION_TIMEOUT_PROPERTY = "dc.zookeeper.sessionTimeoutMs";
	static final String SESSION_TIMEOUT_ENV = "DC_ZOOKEEPER_SESSION_TIMEOUT_MS";
	static final String CONNECTION_TIMEOUT_PROPERTY = "dc.zookeeper.connectionTimeoutMs";
	static final String CONNECTION_TIMEOUT_ENV = "DC_ZOOKEEPER_CONNECTION_TIMEOUT_MS";
	static final int DEFAULT_SESSION_TIMEOUT_MS = 120000;
	static final int DEFAULT_CONNECTION_TIMEOUT_MS = 60000;
	static final int MIN_TIMEOUT_MS = 1000;
	static final int MAX_TIMEOUT_MS = 600000;
	private ZkClient zk = null;;
	private final ZkConnection zkConnection;
	private IEventListener eventlistener = null;
	private volatile boolean connected = false;
	private volatile KeeperState lastKeeperState = KeeperState.Disconnected;

	public IEventListener getEventlistener() {
		return eventlistener;
	}

	public void setEventlistener(IEventListener eventlistener) {
		this.eventlistener = eventlistener;
	}

	/**
	 * True only when the session can participate in writable control-plane
	 * decisions. ZooKeeper ConnectedReadOnly can serve stale reads, but must not
	 * authorize MD publication, leader leases or partition promotion.
	 */
	public boolean isConnected() {
		// ZkClient may connect before its state listener is subscribed. The
		// cached KeeperState then misses the first SyncConnected event, making
		// an active writable session appear permanently disconnected.
		// Check the underlying ZooKeeper state on every control-plane decision;
		// CONNECTEDREADONLY must never authorize a lease or promotion.
		return isWritableZooKeeperState(zkConnection.getZookeeperState());
	}
	/** Current ZooKeeper session ID for checking EPHEMERAL lease ownership.
	 * A matching user-supplied string is not proof of session ownership. */
	public long activeSessionId() {
		ZooKeeper session=zkConnection.getZookeeper();
		return session!=null && isConnected() ? session.getSessionId() : -1L;
	}


	static boolean isWritableZooKeeperState(ZooKeeper.States state) {
		return state == ZooKeeper.States.CONNECTED;
	}

	static boolean isWritableKeeperState(KeeperState state) {
		return state == KeeperState.SyncConnected;
	}

	static boolean isWritableAfterInitialConnect(boolean waitResult, KeeperState observedState) {
		return waitResult && isWritableKeeperState(observedState);
	}

	private void onEvent(int code) {
		if (eventlistener != null) {
			eventlistener.onEvent(code);
		}
	}

	public class zkSerializer implements ZkSerializer {
		@Override
		public Object deserialize(byte[] bytes) throws ZkMarshallingError {
			return new String(bytes, Charset.forName("UTF-8"));
		}

		@Override
		public byte[] serialize(Object serializable) throws ZkMarshallingError {
			return ((String) serializable).getBytes(Charset.forName("UTF-8"));
		}
	}

	public ZookeeperClient(String hosts, String username, String password) {
		int sessionTimeoutMs = resolveTimeoutMillis(SESSION_TIMEOUT_PROPERTY, SESSION_TIMEOUT_ENV,
				DEFAULT_SESSION_TIMEOUT_MS, MIN_TIMEOUT_MS, MAX_TIMEOUT_MS);
		int connectionTimeoutMs = resolveTimeoutMillis(CONNECTION_TIMEOUT_PROPERTY, CONNECTION_TIMEOUT_ENV,
				DEFAULT_CONNECTION_TIMEOUT_MS, MIN_TIMEOUT_MS, MAX_TIMEOUT_MS);
		zkConnection = new ZkConnection(hosts, sessionTimeoutMs);
		zk = new ZkClient(zkConnection, connectionTimeoutMs);
		log.info("ZookeeperClient hosts ->{} username -> {} sessionTimeoutMs -> {} connectionTimeoutMs -> {}",
				hosts, username, sessionTimeoutMs, connectionTimeoutMs);
		if (StringUtil.isNotBlank(username) || StringUtil.isNotBlank(password)) {
			zk.addAuthInfo("digest", (username + ":" + password).getBytes());
		}
		zk.setZkSerializer(new zkSerializer());
		IZkStateListener listener = new IZkStateListener() {

			@Override
			public void handleStateChanged(KeeperState state) throws Exception {
				lastKeeperState = state;
				connected = isWritableKeeperState(state);
				if (state == KeeperState.Disconnected || state == KeeperState.ConnectedReadOnly) {
					log.warn("ZookeeperClient hosts ->{} WRITABLE_CONTROL_PLANE_UNAVAILABLE state:{}", hosts, state);
					onEvent(IEventListener.CONNECTION_CLOSED);
				}
				if (state == KeeperState.SyncConnected) {
					log.info("ZookeeperClient hosts ->{} CONNECTION_SUCCESS",hosts);
					onEvent(IEventListener.CONNECTION_SUCCESS);
				}
			}

			@Override
			public void handleSessionEstablishmentError(Throwable error) throws Exception {
				// TODO Auto-generated method stub
				System.err.println("handleSessionEstablishmentError"+error);
			}

			@Override
			public void handleNewSession() throws Exception {
				// A new session alone is not a writable quorum connection.
				// Only the subsequent SyncConnected state event grants authority.
				connected = isWritableKeeperState(lastKeeperState);
			}
		};
		zk.subscribeStateChanges(listener);
		boolean connectedToAnyServer = zk.waitUntilConnected(1, TimeUnit.SECONDS);
		connected = connectedToAnyServer && isWritableZooKeeperState(zkConnection.getZookeeperState());
	}

	static int resolveTimeoutMillis(String propertyName, String envName, int defaultValue,
			int minValue, int maxValue) {
		String configured = System.getProperty(propertyName);
		if (StringUtil.isBlank(configured)) {
			configured = System.getenv(envName);
		}
		if (StringUtil.isBlank(configured)) {
			return defaultValue;
		}
		try {
			int value = Integer.parseInt(configured.trim());
			if (value < minValue || value > maxValue) {
				log.warn("Ignoring out-of-range ZooKeeper timeout {}={} allowed=[{},{}], using default {}",
						propertyName, configured, minValue, maxValue, defaultValue);
				return defaultValue;
			}
			return value;
		} catch (NumberFormatException e) {
			log.warn("Ignoring invalid ZooKeeper timeout {}={}, using default {}", propertyName, configured,
					defaultValue);
			return defaultValue;
		}
	}

	public void subscribeStateChanges(IZkStateListener listener) {
		zk.subscribeStateChanges(listener);
	}

	public void subscribeDataChanges(String path, IZkDataListener listener) {
		zk.subscribeDataChanges(path, listener);
	}

	public void subscribeChildChanges(String path, IZkChildListener listener) {
		zk.subscribeChildChanges(path, listener);
	}

	public boolean exists(String path) {
		try {
			return zk.exists(path);
		} catch (Exception e) {
			return false;
		}
	}

	public List<String> getChildren(String path) {
		return zk.getChildren(path);
	}

	public String create(final String path, Object data, final CreateMode mode) {
		return zk.create(path, data, mode);
	}

	public Object readData(String path) {
		try {
			return zk.readData(path);
			} catch (Exception e) {
			return "";
		}
		
	}

	public Object readData(String path, Stat stat) {
		return zk.readData(path, stat);
	}

	public void writeData(String path, Object object) {
		zk.writeData(path, object);
	}

	public void writeData(String path, Object object, int expectedVersion) {
		zk.writeData(path, object, expectedVersion);
	}

	public Stat writeDataReturnStat(String path, Object object, int expectedVersion) {
		return zk.writeDataReturnStat(path, object, expectedVersion);
	}

	public boolean delete(String path) {
		try {
			return zk.delete(path);
		} catch (Exception e) {
			return false;
		}
	}

	public void close() {
		zk.close();
	}

	public void writeData2(String path, String data) {
		String[] paths = path.split("/");
		String pathTmp = "";
		for (String str : paths) {
			if (!StringUtils.isNullOrEmpty(str)) {
				pathTmp = pathTmp + "/" + str;
				String dataTmp = "";
				if (pathTmp.equals(path)) {
					dataTmp = data;
				}
				if (!exists(pathTmp)) {
					create(pathTmp, dataTmp, CreateMode.PERSISTENT);
				} else if (!StringUtils.isNullOrEmpty(dataTmp)) {
					writeData(pathTmp, data);
				}
			}
		}
	}
}
