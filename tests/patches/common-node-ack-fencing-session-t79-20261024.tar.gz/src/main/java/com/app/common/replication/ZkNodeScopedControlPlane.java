package com.app.common.replication;

import com.app.common.zk.ZookeeperClient;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.atomic.AtomicLong;
import org.I0Itec.zkclient.IZkDataListener;
import org.I0Itec.zkclient.IZkStateListener;
import org.I0Itec.zkclient.exception.ZkBadVersionException;
import org.I0Itec.zkclient.exception.ZkNodeExistsException;
import org.I0Itec.zkclient.exception.ZkNoNodeException;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.data.Stat;

/**
 * Real node-level ZooKeeper control-plane adapter for NodeClusterControlManager.
 *
 * All 256 assignments live in ONE versioned, ACL-protected manifest ZNode.
 * Per node, each renewal reads the same manifest and CAS-writes only ONE
 * session-owned ephemeral lease. A successful CAS requires a connected ZK
 * quorum; a read, Watch, or local cache alone cannot renew grant authority.
 *
 * This is a control protocol, NOT a takeover-certification algorithm. The
 * external recovery coordinator MUST authenticate old WAL/CommitIndex/dual
 * Custody, fence previous owners and enforce the full old-lease retirement
 * window BEFORE publishing a higher-Epoch manifest via its own authorized CAS.
 * ZK ACLs MUST prevent data nodes from editing the manifest.
 */
public final class ZkNodeScopedControlPlane implements
        NodeClusterControlManager.ControlPlane, AutoCloseable {

    public interface Ops {
        boolean connected();
        long sessionId();
        Value read(String path) throws Exception;
        boolean createEphemeral(String path,String value)throws Exception;
        Value compareAndSet(String path,int version,String value)throws Exception;
        void watchManifest(String path,Runnable changed);
        void watchDisconnect(Runnable disconnected);
    }
    public static final class Value {
        public final String data;
        public final int version;
        public final long ephemeralOwner;
        public Value(String data,int version){this(data,version,0L);}
        public Value(String data,int version,long owner){
            this.data=data;this.version=version;this.ephemeralOwner=owner;
        }
    }
    private static final class ClientOps implements Ops {
        private final ZookeeperClient client;
        ClientOps(ZookeeperClient client){this.client=Objects.requireNonNull(client);}
        @Override public boolean connected(){return client.isConnected();}
        @Override public long sessionId(){return client.activeSessionId();}
        @Override public Value read(String path)throws Exception {
            try{
                Stat stat=new Stat();
                Object obj=client.readData(path,stat);
                if(obj==null)return null;
                return new Value(String.valueOf(obj),stat.getVersion(),
                    stat.getEphemeralOwner());
            }catch(ZkNoNodeException notCreated){
                // The Common ZookeeperClient readData(path, Stat) throws on
                // missing ephemeral nodes; only this exact absence is
                // eligible for a CAS-verified lease create.
                return null;
            }
        }
        @Override public boolean createEphemeral(String path,String data)throws Exception{
            try{client.create(path,data,CreateMode.EPHEMERAL);return true;}
            catch(ZkNodeExistsException occupied){return false;}
        }
        @Override public Value compareAndSet(String path,int version,String data)
                throws Exception{
            try{
                Stat done=client.writeDataReturnStat(path,data,version);
                return new Value(data,done.getVersion(),done.getEphemeralOwner());
            }catch(ZkBadVersionException fenced){return null;}
        }
        @Override public void watchManifest(String path,Runnable changed) {
            client.subscribeDataChanges(path,new IZkDataListener(){
                @Override public void handleDataChange(String p,Object value) {
                    changed.run();
                }
                @Override public void handleDataDeleted(String p) {changed.run();}
            });
        }
        @Override public void watchDisconnect(Runnable disconnected){
            client.subscribeStateChanges(new IZkStateListener(){
                @Override public void handleStateChanged(Watcher.Event.KeeperState state){
                    if(state!=Watcher.Event.KeeperState.SyncConnected)
                        disconnected.run();
                }
                @Override public void handleNewSession(){disconnected.run();}
                @Override public void handleSessionEstablishmentError(Throwable reason){
                    disconnected.run();
                }
            });
        }
    }

    /** Canonical per-partition record. RECOVERING never grants customer IO. */
    public static final class Assignment {
        public final NodePartitionGrantTable.Partition partition;
        public final boolean ready;
        public Assignment(NodePartitionGrantTable.Partition partition,boolean ready){
            this.partition=Objects.requireNonNull(partition);
            this.ready=ready;
        }
    }
    /** Atomic generation, NOT 256 independently mutable ZooKeeper records. */
    public static final class Manifest {
        public final long generation;
        public final Map<String,Assignment> assignments;
        public Manifest(long generation,Map<String,Assignment> assignments){
            if(generation<1 || assignments==null || assignments.isEmpty()
                    || assignments.size()>256)
                throw new IllegalArgumentException("invalid node partition manifest");
            Map<String,Assignment> copy=new LinkedHashMap<>();
            assignments.forEach((id,assignment)->{
                Objects.requireNonNull(assignment);
                if(!id.equals(assignment.partition.id))
                    throw new IllegalArgumentException("partition key mismatch");
                copy.put(id,assignment);
            });
            this.generation=generation;
            this.assignments=Collections.unmodifiableMap(copy);
        }
        public String encode(){
            StringBuilder builder=new StringBuilder("NPC1|").append(generation);
            List<String> ids=new ArrayList<>(assignments.keySet());
            Collections.sort(ids);
            for(String id:ids){
                Assignment a=assignments.get(id);
                NodePartitionGrantTable.Partition p=a.partition;
                builder.append('\n').append(p.id).append('|').append(p.epoch)
                    .append('|').append(p.primary).append('|').append(p.replica)
                    .append('|').append(p.policy.name()).append('|')
                    .append(a.ready?"READY":"RECOVERING");
            }
            return builder.toString();
        }
        public static Manifest parse(String raw)throws IOException{
            if(raw==null || raw.length()>128000)
                throw new IOException("node assignment manifest too large/missing");
            String[] lines=raw.split("\\n",-1);
            if(lines.length<2 || lines.length>257
                    || !lines[0].matches("NPC1\\|[1-9][0-9]*"))
                throw new IOException("bad node manifest header");
            long gen=positive(lines[0].substring(5));
            Map<String,Assignment> assignments=new LinkedHashMap<>();
            for(int i=1;i<lines.length;i++){
                String[] fields=lines[i].split("\\|",-1);
                if(fields.length!=6 || !identifier(fields[0])
                        || !identifier(fields[2])
                        || !(fields[3].isEmpty() || identifier(fields[3])))
                    throw new IOException("malformed manifest partition line "+i);
                long epoch=positive(fields[1]);
                final DurableWalAckPolicy mode;
                try{mode=DurableWalAckPolicy.parse(fields[4]);}
                catch(IllegalArgumentException invalid){throw new IOException(invalid);}
                if(!"READY".equals(fields[5]) && !"RECOVERING".equals(fields[5]))
                    throw new IOException("unknown partition publication state");
                NodePartitionGrantTable.Partition p;
                try{p=new NodePartitionGrantTable.Partition(fields[0],epoch,
                    fields[2],fields[3],mode);}
                catch(IllegalArgumentException invalid){throw new IOException(invalid);}
                if(assignments.put(p.id,new Assignment(p,"READY".equals(fields[5])))!=null)
                    throw new IOException("duplicate manifest partition");
            }
            Manifest m=new Manifest(gen,assignments);
            if(!m.encode().equals(raw))
                throw new IOException("noncanonical node manifest encoding");
            return m;
        }
        private static long positive(String raw)throws IOException {
            try{long value=Long.parseLong(raw);if(value>0)return value;}
            catch(NumberFormatException invalid){}
            throw new IOException("invalid Epoch/generation");
        }
        private static boolean identifier(String id) {
            return id!=null && id.matches("[A-Za-z0-9_.-]{1,96}");
        }
    }

    /** Real recovery coordinator must authenticate original physical WAL,
     * certified CommitIndex, independent dual Custody and old-owner fencing.
     * Without this service session reauthorization remains deliberately off. */
    public interface CertifiedRecoveryAuthority {
        void requireCertifiedNewEpoch(String node,Manifest previous,
            Manifest next,int newZkVersion)throws Exception;
    }
    /** Every normal live assignment generation change also requires a
     * certified transition. Do not trust a changed ZK manifest as evidence
     * that the old writer has already been isolated. */
    public interface CertifiedManifestTransition {
        void requireCertifiedTransition(String node,Manifest previous,
            Manifest next,int newZkVersion)throws Exception;
    }
    private static final class CachedManifest {
        final Value persisted;
        final Manifest parsed;
        final long watchGeneration;
        CachedManifest(Value value,Manifest m,long generation){
            persisted=value;parsed=m;watchGeneration=generation;
        }
    }
    private static final class VerifiedWindow {
        final NodePartitionGrantTable.Batch earlier,latest;
        final long watchedGeneration;
        VerifiedWindow(NodePartitionGrantTable.Batch earlier,
                       NodePartitionGrantTable.Batch latest,long generation){
            this.earlier=earlier;this.latest=latest;
            this.watchedGeneration=generation;
        }
    }
    private final Ops ops;
    private final String node,manifestPath,leasePath,ownerToken;
    private final long ttlNanos,activationDelayNanos;
    // The previous lease certificate remains valid DURING the next CAS->
    // immutable-table-install handoff, but only for the identical Watch
    // generation. This prevents a 300ms heartbeat from spuriously rejecting
    // otherwise certified in-flight WAL while Watch revocation stays atomic.
    private final AtomicReference<VerifiedWindow> verified=new AtomicReference<>();
    private final AtomicLong changeGeneration=new AtomicLong();
    private final AtomicLong manifestZkReads=new AtomicLong();
    private final AtomicLong leaseQuorumCasWrites=new AtomicLong();
    private volatile Manifest lastTrustedManifest;
    private volatile CachedManifest cachedManifest;
    private volatile CertifiedManifestTransition transitionAuthority;
    private volatile boolean closed;
    private volatile boolean sessionRevoked;
    private volatile long lastSessionLossNanos;
    private volatile CertifiedRecoveryAuthority recoveryAuthority;
    private volatile NodeClusterControlManager manager;

    public ZkNodeScopedControlPlane(ZookeeperClient client,String node,
            String manifestPath,String leasePath,String ownerToken,
            long ttlMillis,long activationDelayMillis){
        this(new ClientOps(client),node,manifestPath,leasePath,ownerToken,
            ttlMillis,activationDelayMillis);
    }
    /** Mockable Ops for deterministically testing quorum/CAS semantics. */
    public ZkNodeScopedControlPlane(Ops ops,String node,String manifestPath,
            String leasePath,String ownerToken,long ttlMillis,
            long activationDelayMillis){
        this.ops=Objects.requireNonNull(ops);
        this.node=identifier(node);
        this.manifestPath=path(manifestPath);
        this.leasePath=path(leasePath);
        this.ownerToken=identifier(ownerToken);
        if(ttlMillis<100 || ttlMillis>30000
                || activationDelayMillis<0 || activationDelayMillis>120000)
            throw new IllegalArgumentException("invalid node lease");
        this.ttlNanos=TimeUnit.MILLISECONDS.toNanos(ttlMillis);
        this.activationDelayNanos=TimeUnit.MILLISECONDS.toNanos(
            activationDelayMillis);
    }
    private static String identifier(String text){
        if(!Manifest.identifier(text))
            throw new IllegalArgumentException("bad ZK node/owner identifier");
        return text;
    }
    private static String path(String text){
        if(text==null || !text.matches("/(?:[A-Za-z0-9_.-]+/)*[A-Za-z0-9_.-]+"))
            throw new IllegalArgumentException("invalid ZK control ZNode path");
        return text;
    }

    /** Diagnostics count ONLY adapter-originated control operations; these
     * counters do not estimate background ZooKeeper client heartbeats. */
    public long manifestZkReads(){return manifestZkReads.get();}
    public long leaseQuorumCasWrites(){return leaseQuorumCasWrites.get();}

    /** Table is private to this adapter: no caller can fake a CAS receipt. */
    public NodePartitionGrantTable newGrantTable(){
        return new NodePartitionGrantTable(node,System::nanoTime,batch->{
            VerifiedWindow snapshot=verified.get();
            if(snapshot==null || batch!=snapshot.latest
                    || snapshot.watchedGeneration!=changeGeneration.get()
                    || closed || sessionRevoked || !ops.connected())
                throw new IOException("unverified node quorum CAS certificate");
        },batch->{
            // ZERO ZooKeeper calls. Watch clears the entire window BEFORE
            // queued grant-manager revoke. Ordinary lease renewals allow the
            // immediately previous certificate until the next table install.
            VerifiedWindow snapshot=verified.get();
            if(snapshot==null ||
                    (batch!=snapshot.latest && batch!=snapshot.earlier)
                    || snapshot.watchedGeneration!=changeGeneration.get()
                    || closed || sessionRevoked)
                throw new IOException("cluster control certificate locally revoked");
        },256,ttlNanos);
    }
    /** Hooks control watchers; do not register one watcher per partition. */
    public synchronized void attach(NodeClusterControlManager manager){
        if(this.manager!=null)throw new IllegalStateException("watch already attached");
        this.manager=Objects.requireNonNull(manager);
        ops.watchManifest(manifestPath,()->{
            changeGeneration.incrementAndGet();
            cachedManifest=null;
            verified.set(null);
            manager.onControlChanged();
        });
        ops.watchDisconnect(()->{
            markSessionRevoked();
            manager.onSessionLost();
        });
    }

    /** Register the real recovery authority BEFORE starting the manager.
     * ZK reconnect cannot silently reset a revoked node grant. */
    public void useCertifiedRecovery(CertifiedRecoveryAuthority authority){
        if(recoveryAuthority!=null)
            throw new IllegalStateException("recovery authority already installed");
        recoveryAuthority=Objects.requireNonNull(authority);
    }
    public void useCertifiedManifestTransitions(CertifiedManifestTransition authority){
        if(transitionAuthority!=null)
            throw new IllegalStateException("transition authority already installed");
        transitionAuthority=Objects.requireNonNull(authority);
    }
    private synchronized void markSessionRevoked(){
        changeGeneration.incrementAndGet();
        if(!sessionRevoked)lastSessionLossNanos=System.nanoTime();
        sessionRevoked=true;
        cachedManifest=null;
        verified.set(null);
    }
    /** Only the control thread may call this. Must NOT be called by WAL,
     * Netty, state machine, receipt or client ACK threads. It enforces the
     * previous full node lease expiry and obtains a fresh ZK quorum CAS in
     * addition to the external old-master fencing/custody proof. */
    private synchronized void reauthorizeAfterLoss()throws Exception {
        CertifiedRecoveryAuthority authority=recoveryAuthority;
        Manifest before=lastTrustedManifest;
        if(authority==null || before==null || !ops.connected())
            throw new IOException("CERTIFIED_RECOVERY_REQUIRED: no authoritative rearm");
        long elapsed=System.nanoTime()-lastSessionLossNanos;
        if(elapsed<ttlNanos+TimeUnit.MILLISECONDS.toNanos(200L))
            throw new IOException("old node lease retirement delay incomplete");
        long observed=changeGeneration.get();
        Value newValue=ops.read(manifestPath);
        manifestZkReads.incrementAndGet();
        if(newValue==null)throw new IOException("missing recovered manifest");
        Manifest next=Manifest.parse(newValue.data);
        if(next.generation<=before.generation)
            throw new IOException("recovery requires a higher ZK generation");
        // Hard session revocation requires a new Epoch for ALL previously
        // owned READY partitions, not merely a new node lease generation.
        for(Assignment previous:before.assignments.values()){
            NodePartitionGrantTable.Partition p=previous.partition;
            if(!node.equals(p.primary) && !node.equals(p.replica))continue;
            Assignment candidate=next.assignments.get(p.id);
            if(candidate!=null && candidate.ready
                    && candidate.partition.epoch<=p.epoch)
                throw new IOException("recovered node reuses old partition Epoch");
        }
        authority.requireCertifiedNewEpoch(node,before,next,newValue.version);
        if(observed!=changeGeneration.get() || !ops.connected())
            throw new IOException("ZK recovery authority invalidated");
        // Majority CAS prevents a stale ZK follower read authorizing writes.
        Value lease=ops.read(leasePath);
        if(lease==null){
            if(!ops.createEphemeral(leasePath,ownerToken))
                throw new IOException("new session lease held by another process");
            lease=ops.read(leasePath);
        }
        long currentSession=ops.sessionId();
        if(currentSession<=0 || lease==null || !ownerToken.equals(lease.data)
                || lease.ephemeralOwner!=currentSession)
            throw new IOException("ZK recovery EPHEMERAL lease not owned by current session");
        Value recoveredCas=ops.compareAndSet(leasePath,lease.version,ownerToken);
        if(recoveredCas==null || recoveredCas.ephemeralOwner!=currentSession
                || ops.sessionId()!=currentSession)
            throw new IOException("ZK recovery lease CAS/session ownership failed");
        Value current=ops.read(manifestPath);
        if(current==null || current.version!=newValue.version
                || !newValue.data.equals(current.data)
                || observed!=changeGeneration.get())
            throw new IOException("recovery changed before certified cutover");
        cachedManifest=new CachedManifest(newValue,next,observed);
        sessionRevoked=false;
    }

    /**
     * Control thread only. A ZK manifest is fetched once at bootstrap and
     * on a Watch event, never on each lease heartbeat. Normal renewal uses
     * one ephemeral lease read + one majority CAS, independent of 256 shards.
     * Never write/create the authoritative assignment manifest here.
     */
    @Override public NodePartitionGrantTable.Batch renewNodeLease(String requested)
            throws Exception {
        if(closed || !node.equals(requested) || !ops.connected())
            throw new IOException("node control disconnected/incorrect identity");
        if(sessionRevoked)reauthorizeAfterLoss();
        final long started=System.nanoTime();
        final long observedGeneration=changeGeneration.get();
        CachedManifest cached=cachedManifest;
        if(cached==null || cached.watchGeneration!=observedGeneration){
            Value fromZk=ops.read(manifestPath);
            manifestZkReads.incrementAndGet();
            if(fromZk==null)throw new IOException("missing authoritative manifest");
            Manifest parsed=Manifest.parse(fromZk.data);
            Manifest prior=lastTrustedManifest;
            if(prior!=null && parsed.generation!=prior.generation){
                CertifiedManifestTransition transition=transitionAuthority;
                if(transition==null)
                    throw new IOException("CERTIFIED_MANIFEST_CUTOVER_REQUIRED");
                if(parsed.generation<prior.generation)
                    throw new IOException("manifest generation rollback");
                transition.requireCertifiedTransition(node,prior,parsed,fromZk.version);
            }
            if(observedGeneration!=changeGeneration.get())
                throw new IOException("manifest Watch changed during control load");
            cached=new CachedManifest(fromZk,parsed,observedGeneration);
            cachedManifest=cached;
        }
        Value manifestRead=cached.persisted;
        Manifest m=cached.parsed;
        Value oldLease=ops.read(leasePath);
        if(oldLease==null){
            if(!ops.createEphemeral(leasePath,ownerToken))
                throw new IOException("another physical process owns node lease");
            oldLease=ops.read(leasePath);
        }
        long activeSession=ops.sessionId();
        // A second JVM can accidentally share an ownerToken. Reading and
        // CAS-updating another session's EPHEMERAL znode must NEVER authorize
        // it as the same physical node. Bind ownership to the actual ZK ID.
        if(oldLease==null || !ownerToken.equals(oldLease.data)
                || activeSession<=0L || oldLease.ephemeralOwner!=activeSession)
            throw new IOException("node EPHEMERAL session owner mismatch");
        if(!ops.connected())throw new IOException("ZK control quorum disconnected");
        Value committed=ops.compareAndSet(leasePath,oldLease.version,ownerToken);
        if(committed!=null)leaseQuorumCasWrites.incrementAndGet();
        if(committed==null || !ops.connected()
                || committed.ephemeralOwner!=activeSession
                || ops.sessionId()!=activeSession)
            throw new IOException("ZK majority CAS/session owner did not commit lease");
        if(closed)throw new IOException("control closed during quorum CAS");
        // Watch invalidates the pinned immutable manifest. A notification
        // arriving in-flight rejects the CAS proof; ZK grant TTL and the
        // independently certified old-owner retirement window cover the
        // interval before a remote Watch event is delivered.
        if(observedGeneration!=changeGeneration.get())
            throw new IOException("manifest changed during quorum renewal");
        if(sessionRevoked)
            throw new IOException("session disconnected: higher Epoch mandatory");
        Map<String,NodePartitionGrantTable.Partition> routes=new HashMap<>();
        for(Assignment a:m.assignments.values()){
            NodePartitionGrantTable.Partition p=a.partition;
            if(a.ready && (node.equals(p.primary) || node.equals(p.replica)))
                routes.put(p.id,p);
        }
        if(routes.isEmpty())
            throw new IOException("node owns no READY partitions");
        MessageDigest digest=MessageDigest.getInstance("SHA-256");
        digest.update(manifestRead.data.getBytes(StandardCharsets.UTF_8));
        digest.update((node+"|"+manifestRead.version+"|"+
            committed.version+"|"+ownerToken).getBytes(StandardCharsets.UTF_8));
        byte[] token=digest.digest();
        NodePartitionGrantTable.Batch batch=new NodePartitionGrantTable.Batch(
            node,m.generation,started,ttlNanos,activationDelayNanos,
            routes,token);
        // An event may race even after the second ZK read; the verifier
        // rejects an in-flight batch once the Watch generation advances.
        if(observedGeneration!=changeGeneration.get())
            throw new IOException("node manifest Watch changed during CAS");
        VerifiedWindow previous=verified.get();
        NodePartitionGrantTable.Batch prior=previous!=null
            && previous.watchedGeneration==observedGeneration
            ? previous.latest:null;
        VerifiedWindow candidate=new VerifiedWindow(prior,batch,observedGeneration);
        if(!verified.compareAndSet(previous,candidate))
            throw new IOException("concurrent Watch changed grant window");
        if(observedGeneration!=changeGeneration.get()){
            verified.compareAndSet(candidate,null);
            throw new IOException("node manifest revoked before grant install");
        }
        lastTrustedManifest=m;
        return batch;
    }

    public void revokeForSessionLoss(){
        markSessionRevoked();
        NodeClusterControlManager current=manager;
        if(current!=null)current.onSessionLost();
    }
    @Override public void close(){
        closed=true;verified.set(null);
        NodeClusterControlManager current=manager;
        if(current!=null)current.onSessionLost();
    }
}
