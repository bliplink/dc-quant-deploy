package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import static org.junit.Assert.*;

public final class DemoV19FourNodeEpoch2InstallTest {
    @Rule public final TemporaryFolder folder=new TemporaryFolder();

    @Test public void certifiedFrozenSeq1ConvertsToReplayableEpoch2Checkpoint()
            throws Exception {
        Path root=folder.newFolder("wal").toPath();
        PartitionAssignment old=DemoV19FourNodeShardCatalog.layout().get(0);
        String oldPrefix, stateSha, walSha;
        Path recovered=root.resolve(
            DemoV19FourNodeEpoch2Install.recoveryDir("P000"));
        Files.createDirectories(recovered);
        try(DemoDurableJournal original=new DemoDurableJournal(root.resolve("source.wal"))){
            original.installEmptyGenesis(1,old.getPartitionId(),
                DemoV19FourNodeGenesisPreflight.exactAssignmentDigest(old));
            original.prepareAndCommitSingleForce(1,1,
                new DemoStateMachine.Operation(
                    DemoV19FourNodeSeq1NettyPilot.requestId("P000"),11));
            oldPrefix=original.committedPrefixSha256Through(1);
            byte[] state=original.state().captureSnapshot();
            stateSha=original.state().stateDigest();
            byte[] bytes=original.certifiedEpoch2SnapshotWalBytes(oldPrefix,state);
            walSha=DemoV19FourNodeGenesisCustody.sha(bytes);
            Files.write(recovered.resolve("recovered.wal"),bytes,
                StandardOpenOption.CREATE_NEW);
            try {
                original.certifiedEpoch2SnapshotWalBytes("0"+oldPrefix.substring(1),state);
                fail("wrong source prefix accepted");
            }catch(java.io.IOException expected){}
            state[state.length-1]^=1;
            try {
                original.certifiedEpoch2SnapshotWalBytes(oldPrefix,state);
                fail("tampered frozen image accepted");
            }catch(java.io.IOException expected){}
            assertEquals(1,original.lastEpoch());
            assertEquals(1,original.committedSeq());
        }
        assertEquals(walSha,
            DemoV19FourNodeEpoch2Install.requirePhysicalInstalled(
                root,old,oldPrefix,stateSha,walSha));
        try(DemoDurableJournal recoveredWal=new DemoDurableJournal(
                recovered.resolve("recovered.wal"))){
            assertEquals(2,recoveredWal.lastEpoch());
            assertEquals(1,recoveredWal.committedSeq());
            assertEquals(1,recoveredWal.snapshotSeq());
            assertEquals(oldPrefix,recoveredWal.snapshotSourcePrefix());
            assertEquals(stateSha,recoveredWal.state().stateDigest());
            assertEquals(1,recoveredWal.state().distinctRequests());
            assertEquals(11,recoveredWal.state().total());
        }
        byte[] damaged=Files.readAllBytes(recovered.resolve("recovered.wal"));
        damaged[damaged.length-1]^=1;
        Files.write(recovered.resolve("recovered.wal"),damaged,
            StandardOpenOption.TRUNCATE_EXISTING);
        try {
            DemoV19FourNodeEpoch2Install.requirePhysicalInstalled(
                root,old,oldPrefix,stateSha,walSha);
            fail("modified recovered physical WAL accepted");
        }catch(java.io.IOException expected){}
    }

    @Test public void candidateHeaderOrSnapshotModificationCannotInstall()
            throws Exception {
        PartitionAssignment old=DemoV19FourNodeShardCatalog.layout().get(128);
        DemoStateMachine source=new DemoStateMachine();
        source.apply(new DemoStateMachine.Operation(
            DemoV19FourNodeSeq1NettyPilot.requestId("P128"),17).encode());
        byte[] snapshot=source.captureSnapshot();
        String member=repeat('a'),wal=repeat('b');
        String imageSha=DemoV19FourNodeGenesisCustody.sha(snapshot);
        String prefix=DemoV19FourNodeEpoch2Image.SCOPE+"\n"+
            old.getPartitionId()+"\n"+old.getReplica()+"\n"+old.getPrimary()+
            "\nnewEpoch=2\nsourceEpoch=1\nsourceSeq=1\nmember="+member+
            "\nwal="+wal+"\nimage="+imageSha+"\n";
        byte[] p=prefix.getBytes(StandardCharsets.UTF_8);
        byte[] candidate=new byte[p.length+snapshot.length];
        System.arraycopy(p,0,candidate,0,p.length);
        System.arraycopy(snapshot,0,candidate,p.length,snapshot.length);
        assertArrayEquals(snapshot,
            DemoV19FourNodeEpoch2Install.verifiedStateFromCandidate(
                old,member,wal,imageSha,candidate));
        candidate[3]^=1;
        try{
            DemoV19FourNodeEpoch2Install.verifiedStateFromCandidate(
                old,member,wal,imageSha,candidate);
            fail("altered header accepted");
        }catch(java.io.IOException expected){}
        candidate[3]^=1;
        candidate[candidate.length-1]^=1;
        try{
            DemoV19FourNodeEpoch2Install.verifiedStateFromCandidate(
                old,member,wal,imageSha,candidate);
            fail("altered payload accepted");
        }catch(java.io.IOException expected){}
    }
    private static String repeat(char c){
        char[] s=new char[64];java.util.Arrays.fill(s,c);return new String(s);
    }
}