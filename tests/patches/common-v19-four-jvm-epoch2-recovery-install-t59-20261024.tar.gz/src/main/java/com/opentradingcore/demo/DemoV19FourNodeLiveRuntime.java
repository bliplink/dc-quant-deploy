package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;
import com.app.common.replication.*;
import com.app.common.zk.ZookeeperClient;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.CountDownLatch;
import org.apache.zookeeper.data.Stat;

/**
 * Four live, partition-routed Netty JVMs, intentionally READ-ONLY until
 * per-partition RF2 signed Genesis/READY+ACK integration is completed.
 * A PREPARING ZK assignment never grants a write.
 */
public final class DemoV19FourNodeLiveRuntime {
    private static final String STATUS="CATALOG_STATUS_V1";
    private DemoV19FourNodeLiveRuntime(){}

    static ReplicationEndpoint exactEndpoint(String node) {
        if(node==null || !node.matches("CommonHaDemo[ABCD]"))
            throw new IllegalArgumentException("node not an exact four-node voter");
        char suffix=Character.toLowerCase(node.charAt(node.length()-1));
        return new ReplicationEndpoint(node,"otc-ha-agent-"+suffix,
                35411+suffix-'a');
    }
    static List<String> owners(PartitionAssignment a) {
        if(a==null || a.replicaNodes().size()!=1)
            throw new IllegalArgumentException("RF2 needs one exact backup");
        return Arrays.asList(a.getPrimary(),a.getReplica());
    }

    static final class HeldWal implements AutoCloseable {
        final String node;
        final Map<String,DemoDurableJournal> owned;
        private HeldWal(String node,Map<String,DemoDurableJournal> owned) {
            this.node=node;this.owned=owned;
        }
        static HeldWal open(List<PartitionAssignment> plan,String node)throws Exception {
            // Preflight exactly 128 WALs, refuse unknown/dirty WAL or sharing.
            DemoV19FourNodeWalSlots.initialize(plan,node,Paths.get("/srv/v19/wal"));
            Map<String,DemoDurableJournal> live=new LinkedHashMap<>();
            try{
                for(PartitionAssignment a:plan){
                    if(node.equals(a.getPrimary()) || node.equals(a.getReplica())){
                        DemoDurableJournal wal=new DemoDurableJournal(
                                Paths.get("/srv/v19/wal",a.getPartitionId()+".wal"));
                        if(!wal.isReadyForWrites())throw new IOException("dirty WAL");
                        if(wal.committedSeq()!=0){
                            if(!DemoV19FourNodeSeq1NettyPilot.enabled()
                                    || !DemoV19FourNodeSeq1NettyPilot.selected(
                                        a.getPartitionId()))
                                throw new IOException("unexpected PREPARING WAL data");
                            DemoV19FourNodeSeq1NettyPilot.requireExactPilotWal(wal,a);
                        }
                        live.put(a.getPartitionId(),wal);
                    }
                }
                if(live.size()!=128)throw new IOException("not exactly 128 held locks");
                return new HeldWal(node,live);
            }catch(Exception failure){
                for(DemoDurableJournal wal:live.values())try{wal.close();}
                    catch(Exception ignored){failure.addSuppressed(ignored);}
                throw failure;
            }
        }
        @Override public void close()throws Exception {
            Exception first=null;
            for(DemoDurableJournal wal:owned.values())
                try{wal.close();}catch(Exception ex){if(first==null)first=ex;}
            if(first!=null)throw first;
        }
    }

    static ReplicationControlResponse handle(ZookeeperClient zk,
            List<PartitionAssignment> plan,HeldWal held,
            ReplicationControlRequest request) {
        try{
            if(request==null || !DemoV19FourNodeShardCatalog.SERVICE.equals(request.getServiceName())
                    || !STATUS.equals(request.getOperation())
                    || request.getPayload().length!=0)
                throw new IOException("PREPARING denies all writes, non-status and nonempty requests");
            String part=request.getPartitionId();
            if(part==null || !part.matches("P(0[0-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])"))
                throw new IOException("partition outside 256");
            int index=Integer.parseInt(part.substring(1));
            PartitionAssignment expected=plan.get(index);
            if(!part.equals(expected.getPartitionId())
                    || !owners(expected).contains(held.node))
                throw new IOException("node is not a legal owner of this partition");
            if(!zk.isConnected())throw new IOException("ZK quorum unavailable");
            Stat stat=new Stat();
            Object raw=zk.readData(
                DemoV19FourNodeShardCatalog.ASSIGNMENTS+"/"+part,stat);
            if(raw==null)throw new IOException("missing catalog assignment");
            PartitionAssignment live=
                DemoV19FourNodeEpoch2Transition.requireAssignment(
                    zk,expected,raw,stat.getVersion());
            DemoDurableJournal wal=held.owned.get(part);
            if(wal==null)throw new IOException("local WAL not locked");
            Map<String,Object> result=new LinkedHashMap<>();
            synchronized(wal){
                if(!wal.isReadyForWrites())
                    throw new IOException("PREPARING physical WAL is not clean");
                if(wal.committedSeq()!=0){
                    if(!DemoV19FourNodeSeq1NettyPilot.enabled()
                            || !DemoV19FourNodeSeq1NettyPilot.selected(part))
                        throw new IOException("unexpected nonempty PREPARING WAL");
                    DemoV19FourNodeSeq1NettyPilot.requireExactPilotWal(wal,expected);
                }
                result.put("committedSeq",wal.committedSeq());
                result.put("committedPrefixSha256",wal.committedPrefixSha256());
                result.put("clean",true);
                result.put("internalPilotOnly",wal.committedSeq()==1);
            }
            if(!zk.isConnected())throw new IOException("lost ZK quorum");
            result.put("node",held.node);
            result.put("partitionId",part);
            result.put("role",held.node.equals(live.getPrimary())?"PRIMARY_SLOT":"REPLICA_SLOT");
            result.put("primary",live.getPrimary());
            result.put("replica",live.getReplica());
            result.put("state",live.getState());
            result.put("epoch",live.getEpoch());
            result.put("zkVersion",stat.getVersion());
            result.put("ready",false);
            result.put("quorumDurable",false);
            return ReplicationControlResponse.ok(DemoNettyBridge.json(result));
        }catch(Exception e){
            return ReplicationControlResponse.error("FOUR_NODE_PREPARING_DENIED",
                    e.getClass().getSimpleName()+": "+e.getMessage());
        }
    }
    static void assertStatus(Map<String,Object> status,String partition,
            String exactNode,String exactRole) throws IOException {
        if(status==null || !partition.equals(status.get("partitionId"))
                || !exactNode.equals(status.get("node"))
                || !exactRole.equals(status.get("role"))
                || !("PREPARING".equals(status.get("state"))
                    || "RECOVERING".equals(status.get("state")))
                || !Boolean.FALSE.equals(status.get("ready"))
                || !Boolean.FALSE.equals(status.get("quorumDurable"))
                || !Boolean.TRUE.equals(status.get("clean"))
                || !(status.get("committedSeq") instanceof Number)
                || !(status.get("zkVersion") instanceof Number)
                || (("PREPARING".equals(status.get("state"))
                    && ((Number)status.get("zkVersion")).intValue()!=0)
                   || ("RECOVERING".equals(status.get("state"))
                    && (((Number)status.get("zkVersion")).intValue()!=1
                        || !DemoV19FourNodeSeq1NettyPilot.selected(partition)
                        || !(status.get("epoch") instanceof Number)
                        || ((Number)status.get("epoch")).longValue()!=2))))
            throw new IOException("cross-partition or premature READY/ACK status");
        long seq=((Number)status.get("committedSeq")).longValue();
        if(seq!=0 && !(seq==1 && DemoV19FourNodeSeq1NettyPilot.enabled()
                && DemoV19FourNodeSeq1NettyPilot.selected(partition)
                && Boolean.TRUE.equals(status.get("internalPilotOnly"))))
            throw new IOException("unacknowledged or unexpected PREPARING sequence");
    }
    private static void serve(String node)throws Exception {
        List<PartitionAssignment> plan=DemoV19FourNodeShardCatalog.layout();
        ZookeeperClient zk=new ZookeeperClient(DemoAssignmentBootstrap.HOSTS,null,null);
        HeldWal held=null;
        DirectNettyReplicationServer server=null;
        try {
            DemoV19FourNodeShardCatalog.audit(zk,plan,node);
            held=HeldWal.open(plan,node);
            for(char oldLead:new char[]{'A','C'}){
                String part=DemoV19FourNodeGenesisPreflight.firstShard(plan,oldLead);
                PartitionAssignment a=plan.get(Integer.parseInt(part.substring(1)));
                if(owners(a).contains(node)){
                    DemoV19FourNodeEpoch2Transition.requireLocalImage(
                        zk,a,node,Paths.get("/srv/v19/wal"),held.owned.get(part));
                    if(zk.exists(DemoV19FourNodeEpoch2Install.PROOFS+"/"+part)){
                        DemoV19FourNodeEpoch2Install.verifySavedProof(zk,a);
                        Map<String,Object> installed=com.gateway.connector.utils.JsonUtils.Deserialize(
                            String.valueOf(zk.readData(
                                DemoV19FourNodeEpoch2Install.PROOFS+"/"+part)),Map.class);
                        DemoV19FourNodeEpoch2Install.requirePhysicalInstalled(
                            Paths.get("/srv/v19/wal"),a,
                            (String)installed.get("sourceSha256"),
                            (String)installed.get("stateSha256"),
                            (String)installed.get("recoveredWalSha256"));
                    }
                }
            }
            DemoV19FourNodeGenesisPreflight identity=
                DemoV19FourNodeGenesisPreflight.open(zk,node,
                    Paths.get("/srv/v19/wal"));
            DemoV19FourNodeGenesisRecord genesis=
                new DemoV19FourNodeGenesisRecord(node,Paths.get("/srv/v19/wal"));
            DemoV19FourNodeGenesisCustody custody=
                new DemoV19FourNodeGenesisCustody(node,Paths.get("/srv/v19/wal"));
            DemoV19FourNodeSeq1NettyPilot seq1Pilot=
                new DemoV19FourNodeSeq1NettyPilot(node,Paths.get("/srv/v19/wal"));
            DemoV19FourNodeRemoteRevocation revoker=
                new DemoV19FourNodeRemoteRevocation(node,Paths.get("/srv/v19/wal"));
            DemoV19FourNodeEpoch2Image recovery=
                new DemoV19FourNodeEpoch2Image(node,Paths.get("/srv/v19/wal"));
            DemoV19FourNodeEpoch2Install installer=
                new DemoV19FourNodeEpoch2Install(node,Paths.get("/srv/v19/wal"));
            com.app.common.partition.ZkPartitionFailoverControlPlane writerControl=
                new com.app.common.partition.ZkPartitionFailoverControlPlane(
                    zk,DemoV19FourNodeShardCatalog.ASSIGNMENTS,
                    "/MDTService",DemoV19FourNodeShardCatalog.ROOT+
                        "/never-acquired-strict-client-lease-"+node,
                    node+"-strict-test-only");
            DemoV19FourNodeStrictWriterGate strictClient=
                new DemoV19FourNodeStrictWriterGate(node,zk,writerControl,writerControl);
            final HeldWal fixed=held;
            // Replication data frames cannot mutate PREPARING: fail closed.
            server=new DirectNettyReplicationServer("0.0.0.0",
                    exactEndpoint(node).getPort(),
                    batch->new ReplicationAck(ReplicationStatus.ERROR,
                        batch.getPartitionId(),batch.getEpoch(),0,1,
                        "PREPARING has no signed Genesis/READY replication authorization"),
                    request->DemoV19FourNodeGenesisPreflight.OP.equals(
                            request.getOperation())
                        ?identity.handle(zk,plan,fixed,request)
                        :DemoV19FourNodeGenesisRecord.OP.equals(request.getOperation())
                            ?genesis.fsyncGenesis(zk,plan,fixed,request)
                            :DemoV19FourNodeGenesisCustody.OP.equals(request.getOperation())
                                ?custody.handle(zk,plan,fixed,request)
                                :(DemoV19FourNodeSeq1NettyPilot.FSYNC.equals(request.getOperation())
                                  || DemoV19FourNodeSeq1NettyPilot.CERTIFY.equals(request.getOperation())
                                  || DemoV19FourNodeSeq1NettyPilot.CUSTODY.equals(request.getOperation()))
                                    ?seq1Pilot.handle(zk,plan,fixed,request)
                                    :DemoV19FourNodeRemoteRevocation.OP.equals(request.getOperation())
                                        ?revoker.handle(zk,plan,fixed,request)
                                    :DemoV19FourNodeEpoch2Image.OP.equals(request.getOperation())
                                        ?recovery.handle(zk,plan,fixed,request)
                                    :DemoV19FourNodeEpoch2Install.OP.equals(request.getOperation())
                                        ?installer.handle(zk,plan,fixed,request)
                                    :DemoV19FourNodeStrictWriterGate.OP.equals(request.getOperation())
                                        ?strictClient.handle(request)
                                        :handle(zk,plan,fixed,request));
            server.start();
            final DirectNettyReplicationServer running=server;
            final HeldWal active=held;
            Runtime.getRuntime().addShutdownHook(new Thread(()->{
                running.close();
                try{active.close();}catch(Exception ignored){}
                zk.close();
            }));
            System.out.println("FOUR_NODE_LIVE_NETTY_READ_ONLY node="+node
                    +" port="+server.getBoundPort()+" walLocks="+held.owned.size()
                    +" ready=0 ack=DENIED");
            new CountDownLatch(1).await();
        }finally{
            if(server!=null)server.close();
            if(held!=null)held.close();
            zk.close();
        }
    }
    private static void probe()throws Exception{
        List<PartitionAssignment> plan=DemoV19FourNodeShardCatalog.layout();
        long count=0;
        Map<String,Integer> hits=new TreeMap<>();
        try(DirectNettyReplicationTransport tcp=new DirectNettyReplicationTransport(10000,
                DirectNettyReplicationServer.DEFAULT_MAX_FRAME_BYTES)) {
            // Service-start is not a TCP-listening readiness signal.
            // Bounded retries for four live JVM bind/restart, never grants
            // READY or treats transient connection failure as success.
            for(char c='A';c<='D';c++){
                String exactNode=DemoV19FourNodeShardCatalog.SERVICE+c;
                PartitionAssignment sample=null;
                for(PartitionAssignment assignment:plan)
                    if(owners(assignment).contains(exactNode)){
                        sample=assignment;break;
                    }
                if(sample==null)throw new IOException("missing voter route");
                long deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(20);
                Exception last=null;
                boolean connected=false;
                while(System.nanoTime()<deadline) {
                    try{
                        ReplicationControlRequest hello=new ReplicationControlRequest(
                            DemoV19FourNodeShardCatalog.SERVICE,STATUS,
                            sample.getPartitionId(),new byte[0]);
                        ReplicationControlResponse response=tcp.control(
                            exactEndpoint(exactNode),hello).get(3,TimeUnit.SECONDS);
                        if(!response.isSuccess())throw new IOException(response.getMessage());
                        Map<String,Object> status=DemoNettyBridge.map(
                            response.getPayload());
                        String effective="RECOVERING".equals(status.get("state"))
                            ?sample.getReplica():sample.getPrimary();
                        String role=exactNode.equals(effective)
                            ?"PRIMARY_SLOT":"REPLICA_SLOT";
                        assertStatus(status,sample.getPartitionId(),exactNode,role);
                        connected=true;break;
                    }catch(Exception notYet){last=notYet;Thread.sleep(100);}
                }
                if(!connected)throw new IOException(
                    "timed out before four live Netty peers were ready: "+exactNode,last);
            }
            for(PartitionAssignment a:plan){
                String partition=a.getPartitionId();
                List<String> two=owners(a);
                String hash=null;
                for(int i=0;i<2;i++){
                    String node=two.get(i);
                    ReplicationControlRequest req=new ReplicationControlRequest(
                        DemoV19FourNodeShardCatalog.SERVICE,STATUS,partition,new byte[0]);
                    ReplicationControlResponse reply=tcp.control(exactEndpoint(node),req)
                            .get(8,TimeUnit.SECONDS);
                    if(!reply.isSuccess())throw new IOException("read denied "+partition+
                            " "+node+": "+reply.getMessage());
                    Map<String,Object> status=DemoNettyBridge.map(reply.getPayload());
                    boolean recovering="RECOVERING".equals(status.get("state"));
                    String primary=recovering?a.getReplica():a.getPrimary();
                    String replica=recovering?a.getPrimary():a.getReplica();
                    assertStatus(status,partition,node,
                        node.equals(primary)?"PRIMARY_SLOT":"REPLICA_SLOT");
                    if(!primary.equals(status.get("primary"))
                            || !replica.equals(status.get("replica")))
                        throw new IOException("Netty peer not from certified ZK catalog");
                    String now=String.valueOf(status.get("committedPrefixSha256"));
                    if(hash!=null && !hash.equals(now))
                        throw new IOException("uninitialized buddy WAL fork");
                    hash=now;
                    hits.put(node,hits.getOrDefault(node,0)+1);
                    count++;
                }
            }
            for(char c='A';c<='D';c++){
                String node=DemoV19FourNodeShardCatalog.SERVICE+c;
                if(hits.getOrDefault(node,0)!=128)
                    throw new IOException("wrong physical Netty assignment count: "+node);
            }
            ReplicationControlRequest forbidden=new ReplicationControlRequest(
                DemoV19FourNodeShardCatalog.SERVICE,"COMMIT","P000",
                DemoNettyBridge.json(Collections.singletonMap("seq",1)));
            ReplicationControlResponse negative=tcp.control(
                exactEndpoint(plan.get(0).getPrimary()),forbidden).get(8,TimeUnit.SECONDS);
            if(negative.isSuccess())
                throw new IOException("CRITICAL: PREPARING write control was admitted");
            // Try a real binary WAL replication batch against EACH of the
            // four servers. PREPARING must never mutate even a single WAL.
            for(char c='A';c<='D';c++){
                String node=DemoV19FourNodeShardCatalog.SERVICE+c;
                PartitionAssignment target=null;
                for(PartitionAssignment item:plan)
                    if(owners(item).contains(node)){target=item;break;}
                if(target==null)throw new IOException("unknown node");
                ReplicationRecord entry=new ReplicationRecord(1L,"DEMO_WAL_COMMIT",
                    "should-never-write-"+node,0L,new byte[0]);
                ReplicationBatch batch=new ReplicationBatch(
                    DemoV19FourNodeShardCatalog.SERVICE,target.getPartitionId(),
                    1L,Collections.singletonList(entry));
                ReplicationAck refused=tcp.replicate(exactEndpoint(node),batch)
                    .get(8,TimeUnit.SECONDS);
                if(refused.isSuccess())throw new IOException(
                    "CRITICAL: WAL batch accepted in PREPARING: "+node);
            }
            System.out.println("FOUR_NODE_LIVE_NETTY_PROBE_PASS partitions=256"
                +" physicalStatusRPCs="+count+" perNode=128"
                +" a_b_c_d_exactRoutes=true crossBuddyHashesEqual=true"
                +" writeRequestDenied=true allFourWalBatchRequestsDenied=true"
                +" clientReady=0 realTrades=0");
        }
    }
    public static void main(String[] args)throws Exception {
        if(args.length!=1)
            throw new IllegalArgumentException("expected exactly one safe isolated operation");
        if(args[0].matches("--serve=[ABCD]"))
            serve(DemoV19FourNodeShardCatalog.SERVICE+args[0].charAt(8));
        else if("--probe".equals(args[0]))probe();
        else if("--strict-client-denial".equals(args[0])){
            try(DirectNettyReplicationTransport tcp=new DirectNettyReplicationTransport(
                    10000,DirectNettyReplicationServer.DEFAULT_MAX_FRAME_BYTES)){
                DemoV19FourNodeStrictWriterGate.proveNoWrite(tcp);
            }
        }
        else if("--epoch2-enter-recovering".equals(args[0])){
            ZookeeperClient zk=new ZookeeperClient(
                DemoAssignmentBootstrap.HOSTS,null,null);
            try{DemoV19FourNodeEpoch2Transition.migrate(
                zk,DemoV19FourNodeShardCatalog.layout());}
            finally{zk.close();}
        }
        else if("--epoch2-prepare-images".equals(args[0])){
            ZookeeperClient zk=new ZookeeperClient(
                DemoAssignmentBootstrap.HOSTS,null,null);
            try{
                DemoV19FourNodeEpoch2Image.prepareTwo(
                    zk,DemoV19FourNodeShardCatalog.layout());
            }finally{zk.close();}
        }
        else if("--epoch2-install-two".equals(args[0])){
            ZookeeperClient zk=new ZookeeperClient(
                DemoAssignmentBootstrap.HOSTS,null,null);
            try{DemoV19FourNodeEpoch2Install.installTwo(
                zk,DemoV19FourNodeShardCatalog.layout());}
            finally{zk.close();}
        }
        else if("--revoke-negative".equals(args[0])){
            DemoV19FourNodeRemoteRevocation.assertOldRpcDenied(
                DemoV19FourNodeShardCatalog.layout());
        }
        else if("--revoke-two".equals(args[0])){
            ZookeeperClient zk=new ZookeeperClient(
                DemoAssignmentBootstrap.HOSTS,null,null);
            try{DemoV19FourNodeRemoteRevocation.prove(
                    zk,DemoV19FourNodeShardCatalog.layout());}
            finally{zk.close();}
        }
        else if("--internal-seq1".equals(args[0])){
            ZookeeperClient zk=new ZookeeperClient(
                DemoAssignmentBootstrap.HOSTS,null,null);
            try{
                DemoV19FourNodeSeq1NettyPilot.proveTwoPairs(
                    zk,DemoV19FourNodeShardCatalog.layout());
            }finally{zk.close();}
        }
        else if("--common-membership".equals(args[0])){
            ZookeeperClient zk=new ZookeeperClient(
                DemoAssignmentBootstrap.HOSTS,null,null);
            try{
                DemoV19FourNodeCommonMembership.probeTwoPairs(zk);
            }finally{zk.close();}
        }
        else if("--custody".equals(args[0])){
            ZookeeperClient zk=new ZookeeperClient(
                DemoAssignmentBootstrap.HOSTS,null,null);
            try{
                DemoV19FourNodeGenesisCustody.proveTwoPairs(
                    zk,DemoV19FourNodeShardCatalog.layout());
            }finally{zk.close();}
        }
        else if("--genesis".equals(args[0])){
            ZookeeperClient zk=new ZookeeperClient(
                DemoAssignmentBootstrap.HOSTS,null,null);
            try{
                DemoV19FourNodeGenesisRecord.proveTwoPairs(
                    zk,DemoV19FourNodeShardCatalog.layout());
            }finally{zk.close();}
        }
        else if("--preflight".equals(args[0])){
            ZookeeperClient zk=new ZookeeperClient(
                DemoAssignmentBootstrap.HOSTS,null,null);
            try{
                DemoV19FourNodeGenesisPreflight.runTwoPairPreflight(
                    zk,DemoV19FourNodeShardCatalog.layout());
            }finally{zk.close();}
        }
        else throw new IllegalArgumentException(
            "only --serve=A/B/C/D, --probe or --preflight");
    }
}
