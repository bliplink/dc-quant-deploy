package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;
import com.app.common.replication.*;
import com.app.common.zk.ZookeeperClient;
import com.gateway.connector.utils.JsonUtils;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.*;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.*;
import java.util.concurrent.TimeUnit;
import org.I0Itec.zkclient.exception.ZkNodeExistsException;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.data.Stat;

/**
 * NON-TRADING, frozen two-partition Epoch2 recovery installation. Each JVM
 * installs a real replayable Epoch2 snapshot WAL independently, after verifying
 * source fsync/custody, 2/2 old revoke proof and 2/2 frozen image proof.
 * Source WAL is never rewritten. The new WAL cannot grant READY or ACK.
 * Installation proof is NOT a new Epoch2 CommitIndex or Custody certificate.
 */
final class DemoV19FourNodeEpoch2Install {
    static final String OP="INTERNAL_EPOCH2_INSTALL_RECOVERY_WAL_V1";
    static final String PROOFS=DemoV19FourNodeShardCatalog.ROOT+"/epoch2-install-proofs";
    static final String SCOPE="EPOCH2_SNAPSHOT_WAL_INSTALLED_NO_READY_V1";
    private final String node;
    private final Path root;
    private final PrivateKey key;

    DemoV19FourNodeEpoch2Install(String node,Path root)throws Exception {
        if(node==null || !node.matches("CommonHaDemo[ABCD]")
                || root==null || !root.isAbsolute())
            throw new IOException("invalid recovery installation voter");
        this.node=node;this.root=root;
        key=KeyFactory.getInstance("RSA").generatePrivate(
            new PKCS8EncodedKeySpec(Files.readAllBytes(
                root.resolve(".preflight-identity/local.pk8"))));
    }
    static String recoveryDir(String part){return ".pilot-epoch2-installed-"+part;}
    private static String sha(byte[] bytes)throws Exception {
        return DemoV19FourNodeGenesisCustody.sha(bytes);
    }
    private static void fsyncDir(Path dir)throws Exception {
        try(FileChannel ch=FileChannel.open(dir,StandardOpenOption.READ)){
            ch.force(true);
        }
    }
    static DurableWalCommitQuorum.Membership successorMembership(
            ZookeeperClient zk,PartitionAssignment old)throws Exception {
        PartitionAssignment next=DemoV19FourNodeEpoch2Transition.recovering(old);
        List<DurableWalCommitQuorum.Member> voters=new ArrayList<>();
        for(String voter:Arrays.asList(next.getPrimary(),next.getReplica())){
            voters.add(new DurableWalCommitQuorum.Member(
                voter,"same-mac-jvm-"+voter,
                DemoV19FourNodeGenesisPreflight.pinned(zk,voter)));
        }
        return new DurableWalCommitQuorum.Membership(
            DemoV19FourNodeShardCatalog.SERVICE,old.getPartitionId(),
            next.getPrimary(),2,1,voters);
    }
    static byte[] verifiedStateFromCandidate(PartitionAssignment old,
            String oldMembership,String sourceWalSha,String expectedImageSha,
            byte[] candidate)throws Exception {
        if(old==null || candidate==null || candidate.length>1024*1024
                || expectedImageSha==null || !expectedImageSha.matches("[a-f0-9]{64}"))
            throw new IOException("invalid certified recovery input");
        String prefix=DemoV19FourNodeEpoch2Image.SCOPE+"\n"+
            old.getPartitionId()+"\n"+old.getReplica()+"\n"+old.getPrimary()+
            "\nnewEpoch=2\nsourceEpoch=1\nsourceSeq=1\nmember="+oldMembership+
            "\nwal="+sourceWalSha+"\nimage="+expectedImageSha+"\n";
        byte[] header=prefix.getBytes(java.nio.charset.StandardCharsets.UTF_8);
        if(candidate.length<=header.length)
            throw new IOException("missing frozen snapshot bytes");
        for(int i=0;i<header.length;i++){
            if(candidate[i]!=header[i])
                throw new IOException("candidate header mismatches frozen source");
        }
        byte[] state=Arrays.copyOfRange(candidate,header.length,candidate.length);
        if(!expectedImageSha.equals(sha(state)))
            throw new IOException("candidate snapshot digest mismatch");
        DemoStateMachine restored=new DemoStateMachine();
        restored.snapshot(state);
        if(restored.distinctRequests()!=1 || restored.total()!=
                DemoV19FourNodeSeq1NettyPilot.delta(old.getPartitionId())
                || restored.appliedCount(DemoV19FourNodeSeq1NettyPilot.requestId(
                    old.getPartitionId()))!=1)
            throw new IOException("unexpected recovered business state");
        return state;
    }
    static void requireSourceCustody(ZookeeperClient zk,PartitionAssignment old,
            DemoDurableJournal source,String sourceSha)throws Exception {
        DurableWalCommitQuorum.Membership member=
            DemoV19FourNodeEpoch2Transition.historicMembership(zk,old);
        try(DurableWalCertificateCustody custody=new DurableWalCertificateCustody(
                source.path().getParent().resolve(
                    ".pilot-common-custody-"+old.getPartitionId()),
                member,(epoch,seq)->{
                    if(epoch!=1 || seq!=1)
                        throw new IOException("wrong source committed watermark");
                    return source.committedPrefixSha256Through(1);
                },
                pinned->{if(!member.digest.equals(pinned.digest))
                    throw new IOException("source membership mismatch");})){
            DurableWalCommitQuorum.Certificate certified=custody.highestVerified();
            if(certified==null || certified.committedSequence!=1
                    || !sourceSha.equals(certified.commitPrefixSha256)
                    || certified.votes.size()!=2)
                throw new IOException("missing Common source CommitIndex and custody");
        }
    }
    private static void writeOnce(Path root,Path dir,String name,byte[] bytes)
            throws Exception {
        Path head=dir.resolve(name), pending=dir.resolve(name+".pending");
        if(Files.isSymbolicLink(root) || Files.isSymbolicLink(dir)
                || Files.isSymbolicLink(head)
                || Files.exists(pending,LinkOption.NOFOLLOW_LINKS))
            throw new IOException("unsafe install path or interrupted recovery");
        if(Files.exists(head,LinkOption.NOFOLLOW_LINKS)){
            if(!Files.isRegularFile(head,LinkOption.NOFOLLOW_LINKS)
                    || !Arrays.equals(Files.readAllBytes(head),bytes))
                throw new IOException("nonmatching preexisting installed WAL");
            return;
        }
        try(FileChannel ch=FileChannel.open(pending,
                StandardOpenOption.CREATE_NEW,StandardOpenOption.WRITE)){
            ByteBuffer in=ByteBuffer.wrap(bytes);
            while(in.hasRemaining())ch.write(in);
            ch.force(true);
        }
        Files.move(pending,head,StandardCopyOption.ATOMIC_MOVE);
        fsyncDir(dir);fsyncDir(root);
    }
    private static String statement(String part,String signer,String member,
            String sourceSha,String stateSha,String recoveredSha,String nonce){
        return SCOPE+"|"+part+"|"+signer+"|epoch=2|seq=1|"+member+
            "|source="+sourceSha+"|state="+stateSha+
            "|recovered="+recoveredSha+"|"+nonce;
    }
    static void verify(ZookeeperClient zk,PartitionAssignment old,String signer,
            String member,String sourceSha,String stateSha,String recoveredSha,
            String nonce,ReplicationControlResponse reply)throws Exception {
        if(reply==null || !reply.isSuccess())
            throw new IOException("remote epoch2 recovery installation refused");
        Map<String,Object> vote=DemoNettyBridge.map(reply.getPayload());
        if(!SCOPE.equals(vote.get("scope")) || !old.getPartitionId().equals(vote.get("partition"))
                || !signer.equals(vote.get("node")) || !nonce.equals(vote.get("nonce"))
                || !member.equals(vote.get("membershipSha256"))
                || !sourceSha.equals(vote.get("sourceSha256"))
                || !stateSha.equals(vote.get("stateSha256"))
                || !recoveredSha.equals(vote.get("recoveredWalSha256"))
                || !Boolean.FALSE.equals(vote.get("ready"))
                || !Boolean.FALSE.equals(vote.get("clientAck"))
                || !(vote.get("signature") instanceof String))
            throw new IOException("invalid installed epoch2 voter fields");
        Signature rsa=Signature.getInstance("SHA256withRSA");
        rsa.initVerify(DemoV19FourNodeGenesisPreflight.pinned(zk,signer));
        rsa.update(statement(old.getPartitionId(),signer,member,sourceSha,stateSha,
            recoveredSha,nonce).getBytes(java.nio.charset.StandardCharsets.UTF_8));
        if(!rsa.verify(Base64.getDecoder().decode((String)vote.get("signature"))))
            throw new IOException("forged installed epoch2 RSA vote");
    }
    private static String sign(PrivateKey key,String text)throws Exception{
        Signature sig=Signature.getInstance("SHA256withRSA");
        sig.initSign(key);sig.update(text.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        return Base64.getEncoder().encodeToString(sig.sign());
    }
    static String requirePhysicalInstalled(Path root,PartitionAssignment old,
            String sourceSha,String expectedStateSha,String expectedWalSha)
            throws Exception {
        Path dir=root.resolve(recoveryDir(old.getPartitionId()));
        Path installed=dir.resolve("recovered.wal");
        if(Files.isSymbolicLink(dir)||Files.isSymbolicLink(installed)
                || !Files.isRegularFile(installed,LinkOption.NOFOLLOW_LINKS))
            throw new IOException("physical epoch2 WAL absent");
        byte[] bytes=Files.readAllBytes(installed);
        if(!expectedWalSha.equals(sha(bytes)))
            throw new IOException("tampered epoch2 physical WAL");
        try(DemoDurableJournal wal=new DemoDurableJournal(installed)){
            if(!wal.isReadyForWrites() || wal.lastEpoch()!=2
                    || wal.committedSeq()!=1 || wal.snapshotSeq()!=1
                    || !sourceSha.equals(wal.snapshotSourcePrefix())
                    || !expectedStateSha.equals(wal.state().stateDigest())
                    || wal.state().distinctRequests()!=1)
                throw new IOException("untrusted epoch2 WAL replay state");
        }
        return expectedWalSha;
    }
    ReplicationControlResponse handle(ZookeeperClient zk,List<PartitionAssignment> plan,
            DemoV19FourNodeLiveRuntime.HeldWal held,ReplicationControlRequest req){
        try {
            if(req==null || !OP.equals(req.getOperation()) || !node.equals(held.node)
                    || !DemoV19FourNodeShardCatalog.SERVICE.equals(req.getServiceName())
                    || req.getPayload()==null || req.getPayload().length!=32
                    || !zk.isConnected())
                throw new IOException("invalid epoch2 recover install request");
            String part=req.getPartitionId();
            if(!DemoV19FourNodeSeq1NettyPilot.selected(part))
                throw new IOException("nonpilot partition");
            PartitionAssignment old=plan.get(Integer.parseInt(part.substring(1)));
            if(!DemoV19FourNodeLiveRuntime.owners(old).contains(node))
                throw new IOException("remote signer not a buddy");
            DemoDurableJournal source=held.owned.get(part);
            if(source==null)throw new IOException("source WAL not locked");
            synchronized(source){
                DemoV19FourNodeEpoch2Transition.requireLocalImage(
                    zk,old,node,root,source);
                Map<String,Object> proof=
                    DemoV19FourNodeEpoch2Transition.requireRecoveryProof(zk,old);
                String sourceSha=(String)proof.get("walSha256");
                requireSourceCustody(zk,old,source,sourceSha);
                byte[] candidate=Files.readAllBytes(root.resolve(
                    DemoV19FourNodeEpoch2Image.imagePath(part)).resolve("candidate.bin"));
                byte[] state=verifiedStateFromCandidate(
                    old,(String)proof.get("membershipSha256"),
                    sourceSha,(String)proof.get("imageSha256"),candidate);
                if(!sha(candidate).equals(proof.get("headSha256"))
                        || !Arrays.equals(state,source.state().captureSnapshot()))
                    throw new IOException("recovery image differs from source replay");
                byte[] walBytes=source.certifiedEpoch2SnapshotWalBytes(sourceSha,state);
                String walSha=sha(walBytes);
                String stateSha=source.state().stateDigest();
                Path dir=root.resolve(recoveryDir(part));
                Files.createDirectories(dir);
                if(Files.isSymbolicLink(dir))
                    throw new IOException("installed recovery directory redirected");
                writeOnce(root,dir,"recovered.wal",walBytes);
                requirePhysicalInstalled(root,old,sourceSha,stateSha,walSha);
                // Exact assignment is checked AGAIN after the durability work.
                Stat current=new Stat();
                Object raw=zk.readData(DemoV19FourNodeShardCatalog.ASSIGNMENTS+
                    "/"+part,current);
                PartitionAssignment active=DemoV19FourNodeEpoch2Transition.requireAssignment(
                    zk,old,raw,current.getVersion());
                if(current.getVersion()!=1 || active.getEpoch()!=2
                        || !"RECOVERING".equals(active.getState()))
                    throw new IOException("new epoch authority moved during recovery");
                DurableWalCommitQuorum.Membership membership=successorMembership(zk,old);
                String nonce=DemoV19FourNodeGenesisPreflight.hex(req.getPayload());
                Map<String,Object> vote=new LinkedHashMap<>();
                vote.put("scope",SCOPE);vote.put("partition",part);
                vote.put("node",node);vote.put("nonce",nonce);
                vote.put("membershipSha256",membership.digest);
                vote.put("sourceSha256",sourceSha);
                vote.put("stateSha256",stateSha);
                vote.put("recoveredWalSha256",walSha);
                vote.put("ready",false);vote.put("clientAck",false);
                vote.put("signature",sign(key,statement(
                    part,node,membership.digest,sourceSha,stateSha,walSha,nonce)));
                return ReplicationControlResponse.ok(DemoNettyBridge.json(vote));
            }
        }catch(Exception failure){
            return ReplicationControlResponse.error("EPOCH2_RECOVERY_INSTALL_DENIED",
                failure.getClass().getSimpleName()+": "+failure.getMessage());
        }
    }
    @SuppressWarnings("unchecked")
    static void verifySavedProof(ZookeeperClient zk,PartitionAssignment old)
            throws Exception {
        Stat stat=new Stat();
        Object raw=zk.readData(PROOFS+"/"+old.getPartitionId(),stat);
        if(raw==null || stat.getVersion()!=0)
            throw new IOException("no immutable epoch2 recovery installation proof");
        Map<String,Object> saved=JsonUtils.Deserialize(String.valueOf(raw),Map.class);
        DurableWalCommitQuorum.Membership member=successorMembership(zk,old);
        String source=(String)saved.get("sourceSha256");
        String state=(String)saved.get("stateSha256");
        String wal=(String)saved.get("recoveredWalSha256");
        if(!SCOPE.equals(saved.get("scope"))
                || !old.getPartitionId().equals(saved.get("partition"))
                || !member.digest.equals(saved.get("membershipSha256"))
                || source==null || !source.matches("[0-9a-f]{64}")
                || state==null || !state.matches("[0-9a-f]{64}")
                || wal==null || !wal.matches("[0-9a-f]{64}")
                || !(saved.get("nonce") instanceof String)
                || !(saved.get("votes") instanceof List)
                || ((List<?>)saved.get("votes")).size()!=2)
            throw new IOException("invalid persisted install certificate");
        List<?> votes=(List<?>)saved.get("votes");
        List<String> peers=DemoV19FourNodeLiveRuntime.owners(old);
        for(int i=0;i<2;i++)
            verify(zk,old,peers.get(i),member.digest,source,state,wal,
                (String)saved.get("nonce"),ReplicationControlResponse.ok(
                    DemoNettyBridge.json(votes.get(i))));
        Map<String,Object> candidate=DemoV19FourNodeEpoch2Transition.requireRecoveryProof(zk,old);
        if(!source.equals(candidate.get("walSha256")))
            throw new IOException("new snapshot WAL points at a different frozen source");
    }
    static void installTwo(ZookeeperClient zk,List<PartitionAssignment> plan)
            throws Exception {
        if(!zk.isConnected())throw new IOException("ZooKeeper unavailable");
        DemoV19FourNodeShardCatalog.ensurePath(zk,PROOFS);
        try(DirectNettyReplicationTransport net=new DirectNettyReplicationTransport(
                10000,DirectNettyReplicationServer.DEFAULT_MAX_FRAME_BYTES)){
            for(char lead:new char[]{'A','C'}){
                String part=DemoV19FourNodeGenesisPreflight.firstShard(plan,lead);
                PartitionAssignment old=plan.get(Integer.parseInt(part.substring(1)));
                DemoV19FourNodeEpoch2Transition.requireRecoveryProof(zk,old);
                DurableWalCommitQuorum.Membership member=successorMembership(zk,old);
                Object already=zk.exists(PROOFS+"/"+part)
                    ?zk.readData(PROOFS+"/"+part):null;
                String nonce;
                if(already!=null){
                    verifySavedProof(zk,old);
                    Map<String,Object> saved=JsonUtils.Deserialize(String.valueOf(already),Map.class);
                    nonce=(String)saved.get("nonce");
                }else{
                    byte[] challenge=new byte[32];new SecureRandom().nextBytes(challenge);
                    nonce=DemoV19FourNodeGenesisPreflight.hex(challenge);
                }
                byte[] challenge=new byte[32];
                for(int i=0;i<challenge.length;i++)
                    challenge[i]=(byte)Integer.parseInt(nonce.substring(i*2,i*2+2),16);
                String source=null,state=null,wal=null;
                List<Map<String,Object>> votes=new ArrayList<>();
                for(String peer:DemoV19FourNodeLiveRuntime.owners(old)){
                    ReplicationControlResponse response=net.control(
                        DemoV19FourNodeLiveRuntime.exactEndpoint(peer),
                        new ReplicationControlRequest(DemoV19FourNodeShardCatalog.SERVICE,
                            OP,part,challenge)).get(8,TimeUnit.SECONDS);
                    if(!response.isSuccess())
                        throw new IOException("remote installed recovery failed: "+peer+
                            " "+response.getMessage());
                    Map<String,Object> receipt=DemoNettyBridge.map(response.getPayload());
                    String s=(String)receipt.get("sourceSha256"),
                        d=(String)receipt.get("stateSha256"),
                        w=(String)receipt.get("recoveredWalSha256");
                    if(source!=null && (!source.equals(s)||!state.equals(d)||!wal.equals(w)))
                        throw new IOException("physical new Epoch2 recovery diverged");
                    source=s;state=d;wal=w;
                    verify(zk,old,peer,member.digest,source,state,wal,nonce,response);
                    votes.add(receipt);
                }
                Map<String,Object> proof=new LinkedHashMap<>();
                proof.put("scope",SCOPE);proof.put("partition",part);
                proof.put("membershipSha256",member.digest);
                proof.put("sourceSha256",source);proof.put("stateSha256",state);
                proof.put("recoveredWalSha256",wal);
                proof.put("nonce",nonce);proof.put("votes",votes);
                String path=PROOFS+"/"+part;
                if(!zk.exists(path)){
                    try{zk.create(path,JsonUtils.Serializer(proof),CreateMode.PERSISTENT);}
                    catch(ZkNodeExistsException race){}
                }
                verifySavedProof(zk,old);
                System.out.println("FOUR_NODE_EPOCH2_INSTALL_PROOF_PASS partition="+part+
                    " epoch=2 seq=1 newMembership="+member.digest+
                    " recoveredWalSha256="+wal+" signedNodes=2"+
                    " sourceImmutable=true restoreReplay=true ready=false clientAck=false");
            }
        }
    }
}