package com.opentradingcore.demo;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import org.junit.Test;
import static org.junit.Assert.*;

/** A historic Epoch1 image must be independently FULLY certified before
 * Common may use it as a recovery candidate. No client ACK or READY here. */
public final class DemoV19Rf2LearnerCertifiedEpoch1Test {
    private static final String HASH=
        "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef";
    private static final String STATE=
        "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
    private static DemoV19TcpSnapshotReceiver.Image image(){
        return new DemoV19TcpSnapshotReceiver.Image(
            new byte[]{1},1,1,HASH,STATE,"CommonHaDemoB");
    }
    private static Map<String,Object> status(String name){
        Map<String,Object> m=new LinkedHashMap<>();
        m.put("clean",true);m.put("lastEpoch",1L);
        m.put("localNode",name);m.put("committedSeq",1L);
        m.put("committedPrefixSha256",HASH);m.put("stateDigest",STATE);
        m.put("distinctRequests",1L);
        return m;
    }
    private static Map<String,Object> cert(String name){
        Map<String,Object> m=new LinkedHashMap<>();
        m.put("sourceNode",name);m.put("oldEpoch",1L);
        m.put("oldWalVoterCount",2L);m.put("certifiedSeq",1L);
        m.put("certifiedSha256",HASH);m.put("cryptographicallyVerified",true);
        return m;
    }
    private static void check(Map<String,Object> bs,Map<String,Object> as,
            Map<String,Object> bc,Map<String,Object> ac)throws IOException{
        DemoV19Rf2LearnerCatchup.requireInheritedFullyCertified(
            image(),bs,as,bc,ac,"CommonHaDemoB","CommonHaDemoA");
    }
    private static void denied(Map<String,Object> bs,Map<String,Object> as,
            Map<String,Object> bc,Map<String,Object> ac){
        try {check(bs,as,bc,ac);fail("untrusted inherited WAL accepted");}
        catch(IOException expected){}
    }
    @Test public void exactBothOldSignedHeadsMatch()throws Exception{
        check(status("CommonHaDemoB"),status("CommonHaDemoA"),
             cert("CommonHaDemoB"),cert("CommonHaDemoA"));
    }
    @Test public void staleSignedPrefixCannotCoverNewTail(){
        Map<String,Object> b=cert("CommonHaDemoB");b.put("certifiedSeq",0L);
        denied(status("CommonHaDemoB"),status("CommonHaDemoA"),
             b,cert("CommonHaDemoA"));
    }
    @Test public void missingSecondPhysicalCustodyRejected(){
        Map<String,Object> a=cert("CommonHaDemoA");a.put("cryptographicallyVerified",false);
        denied(status("CommonHaDemoB"),status("CommonHaDemoA"),
             cert("CommonHaDemoB"),a);
    }
    @Test public void mismatchedStateOrSourceRejected(){
        Map<String,Object> a=status("CommonHaDemoA");
        a.put("stateDigest","BAD");
        denied(status("CommonHaDemoB"),a,cert("CommonHaDemoB"),cert("CommonHaDemoA"));
        Map<String,Object> b=cert("CommonHaDemoB");b.put("sourceNode","Wrong");
        denied(status("CommonHaDemoB"),status("CommonHaDemoA"),
             b,cert("CommonHaDemoA"));
    }
}
