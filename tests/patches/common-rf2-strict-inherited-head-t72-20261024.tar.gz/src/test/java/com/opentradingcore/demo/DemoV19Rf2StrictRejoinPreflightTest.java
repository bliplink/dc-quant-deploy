package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import org.junit.Test;
import static org.junit.Assert.*;

public final class DemoV19Rf2StrictRejoinPreflightTest {
    private static final String HASH=repeat('a');
    private static final String OLD_HASH=repeat('b');
    private static String repeat(char c){char[] chars=new char[64];Arrays.fill(chars,c);return new String(chars);}
    private static PartitionAssignment current(){
        PartitionAssignment a=new PartitionAssignment();
        a.setPartitionId("P000");a.setPrimary("CommonHaDemoB");
        a.setEpoch(4);a.setState("READY");
        a.setReplicas(Collections.<String>emptyList());
        a.setLearners(Collections.singletonList("CommonHaDemoA"));
        return a;
    }
    private static Map<String,Object> status(){
        Map<String,Object> m=new LinkedHashMap<String,Object>();
        m.put("clean",true);m.put("partitionId","P000");m.put("committedSeq",15L);
        m.put("localNode","CommonHaDemoB");
        m.put("lastEpoch",4L);m.put("committedPrefixSha256",HASH);
        m.put("stateDigest","state-sha");m.put("distinctRequests",15L);
        return m;
    }
    private static Map<String,Object> certificate(){
        Map<String,Object> m=new LinkedHashMap<String,Object>();
        m.put("cryptographicallyVerified",true);m.put("oldEpoch",1L);
        m.put("oldWalVoterCount",2L);m.put("certifiedSeq",8L);
        m.put("certifiedSha256",OLD_HASH);
        m.put("sourceNode","CommonHaDemoB");return m;
    }
    private static Map<String,Object> statusA(){
        Map<String,Object> m=status();m.put("localNode","CommonHaDemoA");return m;
    }
    private static Map<String,Object> certificateA(){
        Map<String,Object> m=certificate();m.put("sourceNode","CommonHaDemoA");return m;
    }
    private static DemoV19Rf2StrictRejoinPreflight.Evidence verify(
            Map<String,Object> primary,Map<String,Object> replica,
            Map<String,Object> oldPrimary,Map<String,Object> oldReplica)throws IOException {
        return DemoV19Rf2StrictRejoinPreflight.compare(current(),"CommonHaDemoA",7,
                primary,replica,oldPrimary,oldReplica);
    }
    private static void denied(Map<String,Object> p,Map<String,Object> r,
            Map<String,Object> a,Map<String,Object> b){
        try {verify(p,r,a,b);fail("unsafe strict rejoin preflight was accepted");}
        catch(IOException expected) { }
    }
    @Test public void fullyMatchedPhysicalImageIsOnlyCandidateNotAck(){
        try {
            DemoV19Rf2StrictRejoinPreflight.Evidence e=verify(
                    status(),statusA(),certificate(),certificateA());
            assertEquals(4,e.epoch);assertEquals(15,e.sequence);
            assertEquals(8,e.strictGenesisSeq);assertEquals(HASH,e.prefixSha256);
            assertEquals("CommonHaDemoB",e.primary);
            assertEquals("CommonHaDemoA",e.learner);
        }catch(IOException error){throw new AssertionError(error);}
    }
    @Test public void rejectSpoofedPhysicalEndpoints(){
        Map<String,Object> b=status();b.put("localNode","CommonHaDemoB");
        denied(status(),b,certificate(),certificateA());
        Map<String,Object> c=certificate();c.put("sourceNode","UnknownNode");
        denied(status(),statusA(),c,certificateA());
    }
    @Test public void controlEpochMayAdvanceWithoutAnyNewPhysicalWalEntry()throws IOException {
        Map<String,Object> a=status();Map<String,Object> b=statusA();
        a.put("lastEpoch",3L);b.put("lastEpoch",3L);
        DemoV19Rf2StrictRejoinPreflight.Evidence proof=verify(
                a,b,certificate(),certificateA());
        assertEquals(4,proof.epoch);assertEquals(15,proof.sequence);
    }
    @Test public void rejectMissingOneOfTwoPhysicalReplicas(){
        Map<String,Object> b=statusA();b.put("committedSeq",14L);
        denied(status(),b,certificate(),certificateA());
    }
    @Test public void rejectSameSequenceDivergedWal(){
        Map<String,Object> b=statusA();b.put("committedPrefixSha256",repeat('c'));
        denied(status(),b,certificate(),certificateA());
    }
    @Test public void rejectBusinessStateMismatchEvenWhenWalHashMatches(){
        Map<String,Object> b=statusA();b.put("stateDigest","other");
        denied(status(),b,certificate(),certificateA());
    }
    @Test public void rejectDirtyRecoveryTailAndWrongEpoch(){
        Map<String,Object> b=statusA();b.put("clean",false);
        denied(status(),b,certificate(),certificateA());
        b=statusA();b.put("lastEpoch",3L);
        denied(status(),b,certificate(),certificateA());
    }
    @Test public void rejectMissingOldTwoVoterSignatures(){
        Map<String,Object> c=certificateA();c.put("oldWalVoterCount",1L);
        denied(status(),statusA(),certificate(),c);
        c=certificateA();c.put("cryptographicallyVerified",false);
        denied(status(),statusA(),certificate(),c);
    }
    @Test public void rejectTwoOldQuorumHeadsDisagreeing(){
        Map<String,Object> c=certificateA();c.put("certifiedSha256",repeat('d'));
        denied(status(),statusA(),certificate(),c);
        c=certificateA();c.put("certifiedSeq",9L);
        denied(status(),statusA(),certificate(),c);
    }
    @Test public void inheritedEpoch1FullCertifiedHeadCanEnterPreflightNotREADY()
            throws IOException {
        PartitionAssignment inherited=current();inherited.setEpoch(2);
        Map<String,Object> b=status(),a=statusA();
        b.put("lastEpoch",1L);a.put("lastEpoch",1L);
        Map<String,Object> cb=certificate(),ca=certificateA();
        cb.put("certifiedSeq",15L);ca.put("certifiedSeq",15L);
        cb.put("certifiedSha256",HASH);ca.put("certifiedSha256",HASH);
        DemoV19Rf2StrictRejoinPreflight.Evidence proof=
            DemoV19Rf2StrictRejoinPreflight.compare(inherited,
                "CommonHaDemoA",7,b,a,cb,ca);
        assertEquals(2,proof.epoch);assertEquals(15,proof.sequence);
        assertEquals(HASH,proof.oldCertifiedSha256);
    }
    @Test public void inheritedEpoch1UncertifiedTailIsNeverNewGenesis(){
        PartitionAssignment inherited=current();inherited.setEpoch(2);
        Map<String,Object> b=status(),a=statusA();
        b.put("lastEpoch",1L);a.put("lastEpoch",1L);
        Map<String,Object> cb=certificate(),ca=certificateA();
        cb.put("certifiedSeq",14L);ca.put("certifiedSeq",14L);
        cb.put("certifiedSha256",HASH);ca.put("certifiedSha256",HASH);
        try {
            DemoV19Rf2StrictRejoinPreflight.compare(inherited,
                "CommonHaDemoA",7,b,a,cb,ca);
            fail("inherited uncertified WAL tail admitted");
        } catch(IOException expected){
            assertTrue(expected.getMessage().contains("inherited Epoch1"));
        }
    }
    @Test public void rejectCertificatesBeyondCurrentWal(){
        Map<String,Object> c=certificate();c.put("certifiedSeq",16L);
        Map<String,Object> cA=certificateA();cA.put("certifiedSeq",16L);
        denied(status(),statusA(),c,cA);
    }
}
