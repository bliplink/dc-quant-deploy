package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;
import com.app.common.partition.PartitionFailoverController;
import com.app.common.partition.ZkPartitionFailoverControlPlane;
import java.io.IOException;

/** One partition, opt-in automatic A learner catch-up over authenticated
 * ZooKeeper ownership plus bounded Netty WAL image. Does NOT promote A.
 */
final class DemoV19Rf2LearnerCatchup {
    private final String local;
    private final ZkPartitionFailoverControlPlane plane;
    private final DemoJournalCatalog journals;

    DemoV19Rf2LearnerCatchup(String local,ZkPartitionFailoverControlPlane plane,
            DemoJournalCatalog journals) {
        if (!("CommonHaDemoA".equals(local) || "CommonHaDemoB".equals(local))
                || plane==null || journals==null)
            throw new IllegalArgumentException("only the fenced old A may recover as learner");
        this.local=local;this.plane=plane;this.journals=journals;
    }

    boolean once() throws Exception {
        if (!plane.isConnected()) return false;
        PartitionFailoverController.VersionedAssignment v=plane.read("P000");
        if (v==null || !valid(v.getAssignment())) return false;
        String source=v.getAssignment().getPrimary();
        if (!plane.isLive(source)) return false;
        try(DemoV19TcpClient tcp=new DemoV19TcpClient()) {
            DemoV19TcpSnapshotReceiver.Image image=tcp.snapshot(source);
            // After a ZK-only promotion, the source may not have appended an
            // entry in its newly granted epoch yet. A fully verified old WAL
            // image remains valid if the CURRENT owner and prefix agree.
            if (image.epoch<1 || image.epoch>v.getAssignment().getEpoch()
                    || !source.equals(image.node))
                throw new IOException("untrusted new owner image");
            if(image.epoch==1){
                // No customer solo ACK is allowed under STRICT_QUORUM. A
                // historical image can nevertheless be the exact, complete
                // two-witness certified old head. Neither installation nor
                // client readiness follows from that fact alone.
                if(v.getAssignment().getEpoch()!=2)
                    throw new IOException("inherited old image requires first recovery epoch");
                java.util.Map<String,Object> primary=tcp.status(source);
                java.util.Map<String,Object> learner=tcp.status(local);
                java.util.Map<String,Object> sourceCert=tcp.custodyHeadEvidence(source);
                java.util.Map<String,Object> learnerCert=tcp.custodyHeadEvidence(local);
                requireInheritedFullyCertified(image,primary,learner,
                    sourceCert,learnerCert,source,local);
                DemoDurableJournal old=journals.journal("P000");
                synchronized(old){
                    if(!old.isReadyForWrites() || old.committedSeq()!=image.committedSeq
                        || old.lastEpoch()!=1
                        || !image.sha256.equals(old.committedPrefixSha256())
                        || !image.stateDigest.equals(old.state().stateDigest()))
                        throw new IOException("old learner is not exact old certified head");
                }
                if(!plane.isConnected() || !plane.isLive(source)
                        || !plane.isLive(local))
                    throw new IOException("inherited certified head lost physical witnesses");
                PartitionFailoverController.VersionedAssignment current=
                    plane.read("P000");
                if(current==null || current.getVersion()!=v.getVersion()
                        || !valid(current.getAssignment()))
                    throw new IOException("epoch changed during inherited old-head proof");
                return true; // verified identical: NO install or READY grant
            }
            return journals.installRf2LearnerImage("P000",image,()->{
                if (!plane.isConnected() || !plane.isLive(source))
                    throw new IOException("source owner ZK membership revoked");
                PartitionFailoverController.VersionedAssignment current=plane.read("P000");
                if (current==null || current.getVersion()!=v.getVersion()
                        || !valid(current.getAssignment()))
                    throw new IOException("epoch or learner set changed during WAL installation");
            });
        }
    }

    static void requireInheritedFullyCertified(DemoV19TcpSnapshotReceiver.Image image,
            java.util.Map<String,Object> primary,java.util.Map<String,Object> learner,
            java.util.Map<String,Object> oldPrimary,java.util.Map<String,Object> oldLearner,
            String primaryId,String learnerId)throws IOException {
        if(image==null || image.epoch!=1 || image.committedSeq<1
                || !primaryId.equals(image.node) || primary==null || learner==null
                || !Boolean.TRUE.equals(primary.get("clean"))
                || !Boolean.TRUE.equals(learner.get("clean"))
                || !primaryId.equals(primary.get("localNode"))
                || !learnerId.equals(learner.get("localNode"))
                || !equalsNumber(primary.get("lastEpoch"),1)
                || !equalsNumber(learner.get("lastEpoch"),1)
                || !equalsNumber(primary.get("committedSeq"),image.committedSeq)
                || !equalsNumber(learner.get("committedSeq"),image.committedSeq)
                || !image.sha256.equals(primary.get("committedPrefixSha256"))
                || !image.sha256.equals(learner.get("committedPrefixSha256"))
                || !image.stateDigest.equals(primary.get("stateDigest"))
                || !image.stateDigest.equals(learner.get("stateDigest"))
                || !java.util.Objects.equals(primary.get("distinctRequests"),
                        learner.get("distinctRequests")))
            throw new IOException("inherited Epoch1 physical state is not identical");
        for(java.util.Map.Entry<String,java.util.Map<String,Object>> e:
                java.util.Arrays.asList(
                    new java.util.AbstractMap.SimpleEntry<>(primaryId,oldPrimary),
                    new java.util.AbstractMap.SimpleEntry<>(learnerId,oldLearner))){
            java.util.Map<String,Object> old=e.getValue();
            if(old==null || !Boolean.TRUE.equals(old.get("cryptographicallyVerified"))
                    || !e.getKey().equals(old.get("sourceNode"))
                    || !equalsNumber(old.get("oldEpoch"),1)
                    || !equalsNumber(old.get("oldWalVoterCount"),2)
                    || !equalsNumber(old.get("certifiedSeq"),image.committedSeq)
                    || !image.sha256.equals(old.get("certifiedSha256")))
                throw new IOException("inherited Epoch1 requires two complete signed custody heads");
        }
    }
    private static boolean equalsNumber(Object n,long v){
        return n instanceof Number && ((Number)n).longValue()==v;
    }

    private boolean valid(PartitionAssignment a) {
        return a!=null && "P000".equals(a.getPartitionId())
                && a.getEpoch()>=2 && a.getEpoch()<=8 && a.isRoutable()
                && !local.equals(a.getPrimary())
                && ("CommonHaDemoA".equals(a.getPrimary()) || "CommonHaDemoB".equals(a.getPrimary()))
                && a.replicaNodes().isEmpty() && a.isLearner(local);
    }
}
