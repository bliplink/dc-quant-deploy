package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;
import java.nio.file.*;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import static org.junit.Assert.*;

public class DemoV19FourNodeGenesisCustodyTest {
    @Rule public TemporaryFolder temp=new TemporaryFolder();
    private static final String PROOF="0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef";
    private static final String WAL="abcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcd";
    private final PartitionAssignment a=DemoV19FourNodeShardCatalog.layout().get(0);

    @Test public void independentlyFsyncedCustodyHasIdenticalBytesAndRestartReadback()
            throws Exception {
        Path left=temp.newFolder("left").toPath(),right=temp.newFolder("right").toPath();
        String one=DemoV19FourNodeGenesisCustody.installLocalHead(left,a,PROOF,WAL);
        String two=DemoV19FourNodeGenesisCustody.installLocalHead(right,a,PROOF,WAL);
        assertEquals(one,two);
        assertEquals(64,one.length());
        assertArrayEquals(Files.readAllBytes(left.resolve(
                ".genesis-bootstrap-custody/P000/head.bin")),
                Files.readAllBytes(right.resolve(
                ".genesis-bootstrap-custody/P000/head.bin")));
        assertEquals(one,DemoV19FourNodeGenesisCustody.installLocalHead(
            left,a,PROOF,WAL));
    }
    @Test public void refusesMembershipEvidenceChangeWithoutReplacingHead()
            throws Exception{
        Path root=temp.newFolder("original").toPath();
        DemoV19FourNodeGenesisCustody.installLocalHead(root,a,PROOF,WAL);
        Path file=root.resolve(".genesis-bootstrap-custody/P000/head.bin");
        byte[] before=Files.readAllBytes(file);
        denied(()->DemoV19FourNodeGenesisCustody.installLocalHead(
            root,a,"ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff",WAL));
        assertArrayEquals(before,Files.readAllBytes(file));
    }
    @Test public void rejectsTamperedOrPendingHeadInsteadOfOverwriting()
            throws Exception {
        Path root=temp.newFolder("dirty").toPath();
        DemoV19FourNodeGenesisCustody.installLocalHead(root,a,PROOF,WAL);
        Path dir=root.resolve(".genesis-bootstrap-custody/P000");
        Files.write(dir.resolve("head.bin"),new byte[]{4});
        denied(()->DemoV19FourNodeGenesisCustody.installLocalHead(
            root,a,PROOF,WAL));
        Files.delete(dir.resolve("head.bin"));
        Files.write(dir.resolve("head.pending"),new byte[]{5});
        denied(()->DemoV19FourNodeGenesisCustody.installLocalHead(
            root,a,PROOF,WAL));
    }
    interface Attempt{void run()throws Exception;}
    private static void denied(Attempt run)throws Exception{
        try{run.run();fail("altered Genesis evidence accepted");}
        catch(java.io.IOException expected){}
    }
}
