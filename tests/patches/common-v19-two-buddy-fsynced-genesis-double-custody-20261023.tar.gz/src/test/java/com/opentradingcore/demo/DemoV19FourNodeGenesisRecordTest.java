package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;
import java.security.*;
import org.junit.Test;
import static org.junit.Assert.*;

public final class DemoV19FourNodeGenesisRecordTest {
    private static KeyPair pair()throws Exception{
        KeyPairGenerator gen=KeyPairGenerator.getInstance("RSA");gen.initialize(2048);
        return gen.generateKeyPair();
    }
    @Test public void exactRsaGenesisStatementBindsPartitionEpochPairAndPhysicalWal()throws Exception{
        PartitionAssignment partition=DemoV19FourNodeShardCatalog.layout().get(0);
        String a="abababababababababababababababababababababababababababababababab";
        String nonce="00112233aabbccdd";
        KeyPair signer=pair(),foreign=pair();
        String statement=DemoV19FourNodeGenesisRecord.statement(
            partition,"CommonHaDemoA",a,nonce);
        String signed=DemoV19FourNodeGenesisPreflight.sign(
            signer.getPrivate(),statement);
        DemoV19FourNodeGenesisPreflight.requireSigned(
            signer.getPublic(),statement,signed);
        denied(()->DemoV19FourNodeGenesisPreflight.requireSigned(
            foreign.getPublic(),statement,signed));
        denied(()->DemoV19FourNodeGenesisPreflight.requireSigned(
            signer.getPublic(),DemoV19FourNodeGenesisRecord.statement(
                partition,"CommonHaDemoB",a,nonce),signed));
        denied(()->DemoV19FourNodeGenesisPreflight.requireSigned(
            signer.getPublic(),DemoV19FourNodeGenesisRecord.statement(
                partition,"CommonHaDemoA","ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff",
                nonce),signed));
        denied(()->DemoV19FourNodeGenesisPreflight.requireSigned(
            signer.getPublic(),DemoV19FourNodeGenesisRecord.statement(
                partition,"CommonHaDemoA",a,nonce+"ff"),signed));
        PartitionAssignment other=DemoV19FourNodeShardCatalog.layout().get(128);
        denied(()->DemoV19FourNodeGenesisPreflight.requireSigned(
            signer.getPublic(),DemoV19FourNodeGenesisRecord.statement(
                other,"CommonHaDemoA",a,nonce),signed));
    }
    private interface Unsafe{void call()throws Exception;}
    private static void denied(Unsafe op)throws Exception{
        try{op.call();fail("invalid Genesis signature accepted");}
        catch(java.io.IOException expected){}
    }
}
