package com.opentradingcore.demo;

import java.nio.file.*;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import static org.junit.Assert.*;

public final class DemoDurableJournalEmptyGenesisTest {
    @Rule public TemporaryFolder home=new TemporaryFolder();
    private static final String MEMBERS=
      "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef";
    @Test public void genesisIsFsyncedAndRestoredWithoutBusinessRequest()throws Exception{
        Path wal=home.newFile("P000.wal").toPath();
        String hash;
        try(DemoDurableJournal journal=new DemoDurableJournal(wal)){
            journal.installEmptyGenesis(1,"P000",MEMBERS);
            assertEquals(0,journal.committedSeq());
            assertEquals(0,journal.state().distinctRequests());
            assertEquals(1,journal.lastEpoch());
            assertTrue(journal.hasEmptyGenesis(1,"P000",MEMBERS));
            hash=journal.committedPrefixSha256();
            assertTrue(journal.activeBytes()>0);
            journal.installEmptyGenesis(1,"P000",MEMBERS);
            assertEquals(hash,journal.committedPrefixSha256());
        }
        try(DemoDurableJournal restored=new DemoDurableJournal(wal)){
            assertTrue(restored.hasEmptyGenesis(1,"P000",MEMBERS));
            assertEquals(hash,restored.committedPrefixSha256());
            assertEquals(0,restored.state().total());
            assertEquals(0,restored.committedSeq());
            // First actual business command MUST still be seq 1.
            restored.prepareAndCommitSingleForce(1,1,
                new DemoStateMachine.Operation("first-real-operation",3));
            assertEquals(1,restored.committedSeq());
        }
        try(DemoDurableJournal restored=new DemoDurableJournal(wal)){
            assertEquals(1,restored.committedSeq());
            assertEquals(1,restored.state().distinctRequests());
            assertEquals(3,restored.state().total());
        }
    }
    @Test public void cannotReplayAsWrongPartitionOrMembership()throws Exception{
        Path wal=home.newFile("P007.wal").toPath();
        try(DemoDurableJournal j=new DemoDurableJournal(wal)){
            j.installEmptyGenesis(1,"P007",MEMBERS);
            denied(()->j.installEmptyGenesis(1,"P008",MEMBERS));
            denied(()->j.installEmptyGenesis(1,"P007",
                "abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789"));
            assertFalse(j.hasEmptyGenesis(1,"P008",MEMBERS));
            assertEquals(0,j.committedSeq());
        }
    }
    @Test public void malformedGenesisPoisonsInsteadOfTruncating()throws Exception{
        Path wal=home.newFile("P128.wal").toPath();
        try(DemoDurableJournal j=new DemoDurableJournal(wal)){
            j.installEmptyGenesis(1,"P128",MEMBERS);
        }
        byte[] b=Files.readAllBytes(wal);
        b[39]^=1;
        Files.write(wal,b);
        try(DemoDurableJournal j=new DemoDurableJournal(wal)){
            assertFalse(j.isReadyForWrites());
            denied(()->j.installEmptyGenesis(1,"P128",MEMBERS));
            assertEquals(b.length,j.activeBytes());
        }
    }
    @Test public void cannotAttachGenesisAfterBusinessHistory()throws Exception{
        Path wal=home.newFile("P255.wal").toPath();
        try(DemoDurableJournal j=new DemoDurableJournal(wal)){
            j.prepareAndCommitSingleForce(1,1,new DemoStateMachine.Operation("old",2));
            denied(()->j.installEmptyGenesis(1,"P255",MEMBERS));
            assertEquals(1,j.committedSeq());
        }
    }
    interface Try {void call()throws Exception;}
    private static void denied(Try attempt)throws Exception{
        try{attempt.call();fail("illegal genesis accepted");}
        catch(java.io.IOException expected){}
    }
}
