package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;
import com.app.common.replication.*;
import com.app.common.zk.ZookeeperClient;
import com.gateway.connector.utils.JsonUtils;
import java.io.*;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.*;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.*;
import java.util.concurrent.TimeUnit;
import org.apache.zookeeper.data.Stat;

/**
 * DEMO-only GENESIS BOOTSTRAP custody (seq0, no client ACK and NOT a Common
 * DurableWalCertificateCustody). The independent replica fsyncs an immutable
 * copy of the ZK-pinned TWO-signer Genesis attestation in its own WAL volume.
 * A durable bootstrap image does not authorize READY/PRIMARY promotion.
 */
final class DemoV19FourNodeGenesisCustody {
    static final String OP="EMPTY_GENESIS_BOOTSTRAP_CUSTODY_INSTALL_V1";
    private static final String DOMAIN="OTC_V19_EMPTY_GENESIS_BOOTSTRAP_CUSTODY_V1";
    private static final String CONTENT="OTC_V19_EMPTY_GENESIS_CUSTODY_V1";

    private final String node;
    private final Path walRoot;
    private final PrivateKey key;
    DemoV19FourNodeGenesisCustody(String node,Path root)throws Exception{
        if(node==null || !node.matches("CommonHaDemo[ABCD]") || root==null
                || !root.isAbsolute())throw new IOException("invalid node custody root");
        this.node=node;walRoot=root;
        key=KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(
            Files.readAllBytes(root.resolve(".preflight-identity/local.pk8"))));
    }
    static String sha(byte[] bytes)throws Exception{
        return DemoV19FourNodeGenesisPreflight.hex(
            MessageDigest.getInstance("SHA-256").digest(bytes));
    }
    private static byte[] image(PartitionAssignment a,String evidenceHash,
            String walHash)throws Exception{
        String canonical=CONTENT+"\n"+a.getPartitionId()+"\n"+a.getPrimary()+"\n"+
            a.getReplica()+"\n"+
            DemoV19FourNodeGenesisPreflight.exactAssignmentDigest(a)+"\n"+
            evidenceHash+"\n"+walHash+"\n";
        return canonical.getBytes(java.nio.charset.StandardCharsets.UTF_8);
    }
    private static void forceDirectory(Path dir)throws Exception{
        try(FileChannel stream=FileChannel.open(dir,StandardOpenOption.READ)){
            stream.force(true);
        }
    }
    static String installLocalHead(Path root,PartitionAssignment a,
            String evidenceHash,String walHash)throws Exception{
        if(root==null || !root.isAbsolute() || Files.isSymbolicLink(root)
                || !evidenceHash.matches("[0-9a-f]{64}")
                || !walHash.matches("[0-9a-f]{64}"))
            throw new IOException("invalid physical custody proof");
        Path base=root.resolve(".genesis-bootstrap-custody");
        Files.createDirectories(base);
        Path parent=base.resolve(a.getPartitionId());
        Files.createDirectories(parent);
        if(Files.isSymbolicLink(base) || Files.isSymbolicLink(parent))
            throw new IOException("unsafe genesis custody directory symlink");
        byte[] expected=image(a,evidenceHash,walHash);
        Path head=parent.resolve("head.bin"),pending=parent.resolve("head.pending");
        if(Files.isSymbolicLink(head) || Files.isSymbolicLink(pending)
                || Files.exists(pending,LinkOption.NOFOLLOW_LINKS))
            throw new IOException("untrusted or torn Genesis custody");
        if(Files.exists(head,LinkOption.NOFOLLOW_LINKS)){
            if(!Arrays.equals(Files.readAllBytes(head),expected))
                throw new IOException("Genesis custody differs from authenticated WAL");
            return sha(expected);
        }
        try(FileChannel writer=FileChannel.open(pending,
                StandardOpenOption.CREATE_NEW,StandardOpenOption.WRITE)){
            ByteBuffer buffer=ByteBuffer.wrap(expected);
            while(buffer.hasRemaining())writer.write(buffer);
            writer.force(true);
        }
        // The only owner holds an independent OS WAL FileLock through caller;
        // atomic create/no replacement prevents silent evidence rollback.
        Files.move(pending,head,StandardCopyOption.ATOMIC_MOVE);
        forceDirectory(parent);
        forceDirectory(base);
        forceDirectory(root);
        if(!Arrays.equals(Files.readAllBytes(head),expected))
            throw new IOException("Genesis custody readback mismatch");
        return sha(expected);
    }
    private static String record(PartitionAssignment a,String node,
            String custodyHash,String nonce)throws Exception{
        return DOMAIN+"|"+a.getPartitionId()+"|"+node+"|"+a.getPrimary()+
            "|"+a.getReplica()+"|"+custodyHash+"|"+nonce;
    }
    ReplicationControlResponse handle(ZookeeperClient zk,List<PartitionAssignment> plan,
            DemoV19FourNodeLiveRuntime.HeldWal held,
            ReplicationControlRequest request){
        try{
            if(request==null || !OP.equals(request.getOperation())
                    || !"1".equals(System.getenv("DEMO_V19_FOUR_NODE_GENESIS_RECORD"))
                    || !DemoV19FourNodeShardCatalog.SERVICE.equals(request.getServiceName())
                    || request.getPayload()==null || request.getPayload().length!=32
                    || !zk.isConnected())
                throw new IOException("Genesis bootstrap custody not authorized");
            String partition=request.getPartitionId();
            if(!("P000".equals(partition) || "P128".equals(partition))
                    || !held.node.equals(node))
                throw new IOException("invalid selected 4-node partition");
            PartitionAssignment a=plan.get(Integer.parseInt(partition.substring(1)));
            if(!partition.equals(a.getPartitionId()) ||
                    !DemoV19FourNodeLiveRuntime.owners(a).contains(node))
                throw new IOException("not an assigned physical custodian");
            Stat assignmentVersion=new Stat();
            Object assignment=zk.readData(DemoV19FourNodeShardCatalog.ASSIGNMENTS+
                "/"+partition,assignmentVersion);
            if(assignment==null)throw new IOException("missing current assignment");
            DemoV19FourNodeShardCatalog.assertPersisted(
                a,String.valueOf(assignment),assignmentVersion.getVersion());
            Stat evidenceVersion=new Stat();
            Object historical=zk.readData(DemoV19FourNodeGenesisRecord.EVIDENCE+
                "/"+partition,evidenceVersion);
            if(historical==null || evidenceVersion.getVersion()!=0)
                throw new IOException("signed two-node Genesis evidence unavailable");
            @SuppressWarnings("unchecked")
            Map<String,Object> fields=JsonUtils.Deserialize(String.valueOf(historical),Map.class);
            if(fields==null || !"FSYNC_GENESIS_NO_READY".equals(fields.get("scope"))
                    || !partition.equals(fields.get("partitionId"))
                    || !(fields.get("receipts") instanceof List)
                    || ((List<?>)fields.get("receipts")).size()!=2
                    || !(fields.get("nonce") instanceof String)
                    || !(fields.get("walPrefixSha256") instanceof String))
                throw new IOException("missing signed physical Genesis proof");
            String nonce=(String)fields.get("nonce");
            String walHash=(String)fields.get("walPrefixSha256");
            List<?> receipts=(List<?>)fields.get("receipts");
            for(int i=0;i<2;i++){
                if(!(receipts.get(i) instanceof Map))
                    throw new IOException("malformed physical signer receipt");
                String peer=DemoV19FourNodeLiveRuntime.owners(a).get(i);
                String verified=DemoV19FourNodeGenesisRecord.verify(zk,a,peer,nonce,
                    ReplicationControlResponse.ok(DemoNettyBridge.json(receipts.get(i))));
                if(!walHash.equals(verified))
                    throw new IOException("signed peer genesis fork");
            }
            DemoDurableJournal journal=held.owned.get(partition);
            if(journal==null)throw new IOException("physical WAL FileLock missing");
            String digest=DemoV19FourNodeGenesisPreflight.exactAssignmentDigest(a);
            String custodySha;
            synchronized(journal) {
                if(!journal.hasEmptyGenesis(1,partition,digest)
                        || !walHash.equals(journal.committedPrefixSha256()))
                    throw new IOException("physical local WAL differs from dual-sign Genesis");
                custodySha=installLocalHead(walRoot,a,
                    sha(String.valueOf(historical).getBytes(
                        java.nio.charset.StandardCharsets.UTF_8)),walHash);
                if(!journal.hasEmptyGenesis(1,partition,digest)
                        || !walHash.equals(journal.committedPrefixSha256()))
                    throw new IOException("WAL changed while custody was installing");
            }
            if(!zk.isConnected())throw new IOException("lost ZK quorum after custody");
            Stat after=new Stat();Object current=zk.readData(
                DemoV19FourNodeShardCatalog.ASSIGNMENTS+"/"+partition,after);
            if(current==null || after.getVersion()!=assignmentVersion.getVersion()
                    || !String.valueOf(current).equals(String.valueOf(assignment)))
                throw new IOException("assignment changed after custody fsync");
            String requestNonce=DemoV19FourNodeGenesisPreflight.hex(request.getPayload());
            Map<String,Object> result=new LinkedHashMap<>();
            result.put("node",node);
            result.put("partitionId",partition);
            result.put("custodySha256",custodySha);
            result.put("walPrefixSha256",walHash);
            result.put("nonce",requestNonce);
            result.put("ready",false);
            result.put("quorumDurable",false);
            result.put("signed",DemoV19FourNodeGenesisPreflight.sign(
                key,record(a,node,custodySha,requestNonce)));
            return ReplicationControlResponse.ok(DemoNettyBridge.json(result));
        }catch(Exception refused){
            return ReplicationControlResponse.error("GENESIS_BOOTSTRAP_CUSTODY_DENIED",
                refused.getClass().getSimpleName()+": "+refused.getMessage());
        }
    }
    static String verify(ZookeeperClient zk,PartitionAssignment a,
            String peer,String expectedNonce,ReplicationControlResponse response)
            throws Exception{
        if(response==null || !response.isSuccess())
            throw new IOException("absent local genesis bootstrap custody");
        Map<String,Object> m=DemoNettyBridge.map(response.getPayload());
        if(!peer.equals(m.get("node"))
                || !a.getPartitionId().equals(m.get("partitionId"))
                || !expectedNonce.equals(m.get("nonce"))
                || !Boolean.FALSE.equals(m.get("ready"))
                || !Boolean.FALSE.equals(m.get("quorumDurable"))
                || !(m.get("custodySha256") instanceof String)
                || !((String)m.get("custodySha256")).matches("[0-9a-f]{64}")
                || !(m.get("walPrefixSha256") instanceof String)
                || !(m.get("signed") instanceof String))
            throw new IOException("untrusted physical bootstrap custodian");
        String checksum=(String)m.get("custodySha256");
        DemoV19FourNodeGenesisPreflight.requireSigned(
            DemoV19FourNodeGenesisPreflight.pinned(zk,peer),
            record(a,peer,checksum,expectedNonce),(String)m.get("signed"));
        return checksum;
    }
    static void proveTwoPairs(ZookeeperClient zk,List<PartitionAssignment> plan)
            throws Exception {
        try(DirectNettyReplicationTransport net=new DirectNettyReplicationTransport(
                10000,DirectNettyReplicationServer.DEFAULT_MAX_FRAME_BYTES)){
            for(char first:new char[]{'A','C'}){
                String part=DemoV19FourNodeGenesisPreflight.firstShard(plan,first);
                PartitionAssignment a=plan.get(Integer.parseInt(part.substring(1)));
                byte[] bytes=new byte[32];new SecureRandom().nextBytes(bytes);
                String nonce=DemoV19FourNodeGenesisPreflight.hex(bytes);
                String one=null;
                for(String peer:DemoV19FourNodeLiveRuntime.owners(a)){
                    ReplicationControlResponse res=net.control(
                        DemoV19FourNodeLiveRuntime.exactEndpoint(peer),
                        new ReplicationControlRequest(
                            DemoV19FourNodeShardCatalog.SERVICE,OP,part,bytes))
                        .get(8,TimeUnit.SECONDS);
                    String other=verify(zk,a,peer,nonce,res);
                    if(one!=null && !one.equals(other))
                        throw new IOException("two physical Genesis custody files differ");
                    one=other;
                }
                if(!zk.isConnected())throw new IOException("lost ZK after two custodies");
                System.out.println("FOUR_NODE_DUAL_GENESIS_LOCAL_CUSTODY_PASS partition="
                    +part+" pair="+a.getPrimary()+"/"+a.getReplica()
                    +" custodySha="+one+" physicalReplicaFiles=2"
                    +" commonCommitIndex=false ready=false clientAck=false");
            }
        }
    }
}
