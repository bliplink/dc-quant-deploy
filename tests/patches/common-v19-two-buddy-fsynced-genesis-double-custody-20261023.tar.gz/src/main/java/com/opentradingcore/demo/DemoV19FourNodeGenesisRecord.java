package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;
import com.app.common.replication.*;
import com.app.common.zk.ZookeeperClient;
import com.gateway.connector.utils.JsonUtils;
import java.io.*;
import java.security.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.TimeUnit;
import org.I0Itec.zkclient.exception.ZkNodeExistsException;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.data.Stat;

/**
 * Two-node fsynced METADATA-only Genesis in the genuine Demo physical WAL
 * frame format, with independent RSA signed physical-prefix witnesses.
 * NO SYNTHETIC BUSINESS REQUEST, NO Common client commit certificate,
 * NO ZK READY and NO trading ACK. Immutable ZK evidence is recovery input.
 */
final class DemoV19FourNodeGenesisRecord {
    static final String OP="EMPTY_GENESIS_FSYNC_V1";
    static final String EVIDENCE=DemoV19FourNodeShardCatalog.ROOT+"/genesis-record-evidence";
    static final String DOMAIN="OTC_V19_TWO_NODE_GENESIS_PHYSICAL_WAL_V1";
    private static final int EPOCH=1;

    private final String node;
    private final PrivateKey localPrivate;
    DemoV19FourNodeGenesisRecord(String node,Path walRoot)throws Exception {
        if(node==null || !node.matches("CommonHaDemo[ABCD]"))
            throw new IOException("invalid local physical signer");
        this.node=node;
        byte[] pk8=Files.readAllBytes(walRoot.resolve(".preflight-identity/local.pk8"));
        this.localPrivate=KeyFactory.getInstance("RSA")
            .generatePrivate(new java.security.spec.PKCS8EncodedKeySpec(pk8));
    }
    static String statement(PartitionAssignment a,String node,String hash,String nonce)
            throws Exception{
        return DOMAIN+"|"+a.getPartitionId()+"|"+node+"|"+a.getPrimary()+
            "|"+a.getReplica()+"|"+EPOCH+"|0|"+
            DemoV19FourNodeGenesisPreflight.exactAssignmentDigest(a)+
            "|"+hash+"|"+nonce;
    }
    ReplicationControlResponse fsyncGenesis(ZookeeperClient zk,
            List<PartitionAssignment> plan,DemoV19FourNodeLiveRuntime.HeldWal held,
            ReplicationControlRequest request){
        try{
            if(request==null || !OP.equals(request.getOperation())
                    || !"1".equals(System.getenv("DEMO_V19_FOUR_NODE_GENESIS_RECORD"))
                    || !DemoV19FourNodeShardCatalog.SERVICE.equals(request.getServiceName())
                    || request.getPayload()==null || request.getPayload().length!=32)
                throw new IOException("experimental Genesis was not explicitly authorized");
            String part=request.getPartitionId();
            if(part==null || !(part.equals(DemoV19FourNodeGenesisPreflight.firstShard(plan,'A'))
                || part.equals(DemoV19FourNodeGenesisPreflight.firstShard(plan,'C'))))
                throw new IOException("only two specifically chosen Genesis pilot partitions");
            PartitionAssignment a=plan.get(Integer.parseInt(part.substring(1)));
            if(!node.equals(held.node) || !DemoV19FourNodeLiveRuntime.owners(a).contains(node)
                    || !zk.isConnected())
                throw new IOException("wrong Genesis physical voter or control quorum");
            // Valid RSA signatures from both physical EMPTY WAL voters must
            // predate this write. This does not grant trading or READY.
            DemoV19FourNodeGenesisPreflight.requireSignedPreflight(zk,a);
            DemoDurableJournal wal=held.owned.get(part);
            if(wal==null)throw new IOException("WAL FileLock is not held by signer");
            String membership=DemoV19FourNodeGenesisPreflight.exactAssignmentDigest(a);
            String hash;
            synchronized(wal){
                wal.installEmptyGenesis(EPOCH,part,membership); // force(true)
                if(!wal.hasEmptyGenesis(EPOCH,part,membership))
                    throw new IOException("local physical Genesis not fsynced");
                hash=wal.committedPrefixSha256();
            }
            if(!zk.isConnected())throw new IOException("control quorum lost before receipt");
            // Validate ZK version and membership AGAIN after physical force.
            Stat version=new Stat();Object raw=zk.readData(
                DemoV19FourNodeShardCatalog.ASSIGNMENTS+"/"+part,version);
            if(raw==null)throw new IOException("Genesis assignment disappeared");
            DemoV19FourNodeShardCatalog.assertPersisted(
                a,String.valueOf(raw),version.getVersion());
            String nonce=DemoV19FourNodeGenesisPreflight.hex(request.getPayload());
            String signature=DemoV19FourNodeGenesisPreflight.sign(
                localPrivate,statement(a,node,hash,nonce));
            Map<String,Object> fields=new LinkedHashMap<>();
            fields.put("partitionId",part);
            fields.put("node",node);
            fields.put("epoch",EPOCH);
            fields.put("sequence",0);
            fields.put("assignmentVersion",0);
            fields.put("assignmentSha256",membership);
            fields.put("walPrefixSha256",hash);
            fields.put("nonce",nonce);
            fields.put("signed",signature);
            return ReplicationControlResponse.ok(DemoNettyBridge.json(fields));
        }catch(Exception denied){
            return ReplicationControlResponse.error("GENESIS_WAL_FSYNC_DENIED",
                denied.getClass().getSimpleName()+": "+denied.getMessage());
        }
    }
    static String verify(ZookeeperClient zk,PartitionAssignment a,String expectedNode,
            String expectedNonce,ReplicationControlResponse response)throws Exception {
        if(response==null || !response.isSuccess())
            throw new IOException("missing independent physical Genesis proof");
        Map<String,Object> m=DemoNettyBridge.map(response.getPayload());
        String membership=DemoV19FourNodeGenesisPreflight.exactAssignmentDigest(a);
        if(!expectedNode.equals(m.get("node")) ||
                !a.getPartitionId().equals(m.get("partitionId")) ||
                !(m.get("epoch") instanceof Number) ||
                ((Number)m.get("epoch")).intValue()!=EPOCH ||
                !(m.get("sequence") instanceof Number) ||
                ((Number)m.get("sequence")).intValue()!=0 ||
                !(m.get("assignmentVersion") instanceof Number) ||
                ((Number)m.get("assignmentVersion")).intValue()!=0 ||
                !membership.equals(m.get("assignmentSha256")) ||
                !expectedNonce.equals(m.get("nonce")) ||
                !(m.get("walPrefixSha256") instanceof String) ||
                !((String)m.get("walPrefixSha256")).matches("[0-9a-f]{64}") ||
                !(m.get("signed") instanceof String))
            throw new IOException("physically signed Genesis mismatched epoch/partition");
        String sha=(String)m.get("walPrefixSha256");
        DemoV19FourNodeGenesisPreflight.requireSigned(
            DemoV19FourNodeGenesisPreflight.pinned(zk,expectedNode),
            statement(a,expectedNode,sha,expectedNonce),(String)m.get("signed"));
        return sha;
    }
    @SuppressWarnings("unchecked")
    static void verifyPersisted(ZookeeperClient zk,PartitionAssignment a,
            Object raw,int evidenceVersion,DirectNettyReplicationTransport tcp)
            throws Exception{
        if(raw==null || evidenceVersion!=0 || !zk.isConnected())
            throw new IOException("missing or modified Genesis evidence");
        Map<String,Object> evidence=JsonUtils.Deserialize(String.valueOf(raw),Map.class);
        if(evidence==null || !"FSYNC_GENESIS_NO_READY".equals(evidence.get("scope"))
                || !a.getPartitionId().equals(evidence.get("partitionId"))
                || !(evidence.get("nonce") instanceof String)
                || !(evidence.get("receipts") instanceof List)
                || ((List<?>)evidence.get("receipts")).size()!=2
                || !(evidence.get("walPrefixSha256") instanceof String))
            throw new IOException("missing bounded signed Genesis evidence");
        String nonce=(String)evidence.get("nonce");
        String digest=(String)evidence.get("walPrefixSha256");
        List<?> entries=(List<?>)evidence.get("receipts");
        for(int i=0;i<2;i++){
            String voter=DemoV19FourNodeLiveRuntime.owners(a).get(i);
            if(!(entries.get(i) instanceof Map))
                throw new IOException("untrusted physical Genesis receipt");
            String accepted=verify(zk,a,voter,nonce,
                ReplicationControlResponse.ok(DemoNettyBridge.json(entries.get(i))));
            if(!digest.equals(accepted))
                throw new IOException("Genesis physical WAL hashes forked");
            // Status is read from actual node's locked WAL; it cannot rely
            // solely on old persisted RSA receipts after one node is lost.
            ReplicationControlResponse live=tcp.control(
                DemoV19FourNodeLiveRuntime.exactEndpoint(voter),
                new ReplicationControlRequest(
                    DemoV19FourNodeShardCatalog.SERVICE,
                    "CATALOG_STATUS_V1",a.getPartitionId(),new byte[0]))
                .get(8,TimeUnit.SECONDS);
            if(!live.isSuccess())throw new IOException("physical Genesis node unavailable");
            Map<String,Object> status=DemoNettyBridge.map(live.getPayload());
            if(!voter.equals(status.get("node")) ||
                    !a.getPartitionId().equals(status.get("partitionId")) ||
                    !"PREPARING".equals(status.get("state")) ||
                    !Boolean.FALSE.equals(status.get("ready")) ||
                    !Boolean.FALSE.equals(status.get("quorumDurable")) ||
                    !Boolean.TRUE.equals(status.get("clean")) ||
                    !(status.get("committedSeq") instanceof Number) ||
                    ((Number)status.get("committedSeq")).longValue()!=0 ||
                    !digest.equals(status.get("committedPrefixSha256")))
                throw new IOException("live Genesis WAL missing/forked or READY forged");
        }
        Stat stat=new Stat();Object assignment=zk.readData(
            DemoV19FourNodeShardCatalog.ASSIGNMENTS+"/"+a.getPartitionId(),stat);
        if(assignment==null)throw new IOException("Genesis assignment revoked");
        DemoV19FourNodeShardCatalog.assertPersisted(
            a,String.valueOf(assignment),stat.getVersion());
        if(!zk.isConnected())throw new IOException("control quorum disappeared");
    }
    static void proveTwoPairs(ZookeeperClient zk,List<PartitionAssignment> plan)
            throws Exception {
        try(DirectNettyReplicationTransport tcp=new DirectNettyReplicationTransport(
                10000,DirectNettyReplicationServer.DEFAULT_MAX_FRAME_BYTES)) {
            DemoV19FourNodeShardCatalog.ensurePath(zk,EVIDENCE);
            for(char lead:new char[]{'A','C'}){
                String part=DemoV19FourNodeGenesisPreflight.firstShard(plan,lead);
                PartitionAssignment a=plan.get(Integer.parseInt(part.substring(1)));
                String location=EVIDENCE+"/"+part;
                if(!zk.exists(location)){
                    // Existing signed PREPARING empty WAL evidence is a hard
                    // precondition, but it is NOT yet a signed commit ACK.
                    DemoV19FourNodeGenesisPreflight.requireSignedPreflight(zk,a);
                    byte[] challenge=new byte[32];
                    new SecureRandom().nextBytes(challenge);
                    String nonce=DemoV19FourNodeGenesisPreflight.hex(challenge);
                    String sameHash=null;
                    List<Map<String,Object>> receipts=new ArrayList<>();
                    for(String member:DemoV19FourNodeLiveRuntime.owners(a)){
                        ReplicationControlResponse res=tcp.control(
                            DemoV19FourNodeLiveRuntime.exactEndpoint(member),
                            new ReplicationControlRequest(
                                DemoV19FourNodeShardCatalog.SERVICE,OP,part,challenge))
                            .get(8,TimeUnit.SECONDS);
                        String hash=verify(zk,a,member,nonce,res);
                        if(sameHash!=null && !sameHash.equals(hash))
                            throw new IOException("two physical Genesis WALs differ");
                        sameHash=hash;
                        receipts.add(DemoNettyBridge.map(res.getPayload()));
                    }
                    Map<String,Object> proof=new LinkedHashMap<>();
                    proof.put("scope","FSYNC_GENESIS_NO_READY");
                    proof.put("partitionId",part);
                    proof.put("nonce",nonce);
                    proof.put("walPrefixSha256",sameHash);
                    proof.put("receipts",receipts);
                    try{zk.create(location,JsonUtils.Serializer(proof),CreateMode.PERSISTENT);}
                    catch(ZkNodeExistsException competing){}
                }
                Stat st=new Stat();Object original=zk.readData(location,st);
                verifyPersisted(zk,a,original,st.getVersion(),tcp);
                System.out.println("FOUR_NODE_BUDDY_GENESIS_WAL_FSYNC_PASS partition="+part
                    +" pair="+a.getPrimary()+"/"+a.getReplica()
                    +" physicalWalSha="+DemoNettyBridge.map(
                            tcp.control(DemoV19FourNodeLiveRuntime.exactEndpoint(a.getPrimary()),
                                new ReplicationControlRequest(DemoV19FourNodeShardCatalog.SERVICE,
                                    "CATALOG_STATUS_V1",part,new byte[0]))
                            .get(8,TimeUnit.SECONDS).getPayload()).get("committedPrefixSha256")
                    +" epoch=1 walSeq=0 businessCommands=0"
                    +" twoSignedReceipts=true zkEvidenceImmutable=true"
                    +" quorumCommitIndex=false ready=false clientAck=false");
            }
        }
    }
}
