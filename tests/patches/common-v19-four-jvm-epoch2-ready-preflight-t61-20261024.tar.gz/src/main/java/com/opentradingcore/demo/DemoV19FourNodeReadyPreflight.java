package com.opentradingcore.demo;

import com.app.common.partition.PartitionAssignment;
import com.app.common.replication.*;
import com.app.common.zk.ZookeeperClient;
import com.gateway.connector.utils.JsonUtils;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.*;
import java.util.concurrent.TimeUnit;
import org.apache.zookeeper.data.Stat;

/**
 * T61: physically re-evaluate the completed new Epoch2 recovery under live
 * Netty and current ZooKeeper. Strict PRE-READY gate; never publishes READY
 * or acknowledges an order. If either peer cannot replay Common custody or
 * the historical source is not revoked, the entire group fails closed.
 *
 * Single Mac four JVMs are NOT independent host fault domains.
 */
final class DemoV19FourNodeReadyPreflight {
    static final String OP="INTERNAL_EPOCH2_READY_PHYSICAL_PREFLIGHT_V1";
    static final String SCOPE="FOUR_NODE_EPOCH2_READY_PREFLIGHT_NO_ACK_V1";
    private final String node;
    private final Path root;
    private final PrivateKey key;
    DemoV19FourNodeReadyPreflight(String node,Path root)throws Exception{
        if(node==null || !node.matches("CommonHaDemo[ABCD]"))
            throw new IOException("invalid isolated voter");
        this.node=node;this.root=root;
        this.key=KeyFactory.getInstance("RSA").generatePrivate(
            new PKCS8EncodedKeySpec(Files.readAllBytes(
                root.resolve(".preflight-identity/local.pk8"))));
    }

    private static String statement(String part,String node,String membership,
            String source,String recovered,String nonce){
        return SCOPE+"|"+part+"|"+node+"|epoch=2|seq=1|"+membership+
            "|source="+source+"|recovered="+recovered+"|"+nonce+
            "|localOldRevoked=true|commonCustodyVerified=true|ready=false|ack=false";
    }
    static void requireExactRecoveryAssignment(ZookeeperClient zk,
            PartitionAssignment old)throws Exception{
        Stat v=new Stat();
        Object raw=zk.readData(DemoV19FourNodeShardCatalog.ASSIGNMENTS+
            "/"+old.getPartitionId(),v);
        PartitionAssignment next=
            DemoV19FourNodeEpoch2Transition.requireAssignment(
                zk,old,raw,v.getVersion());
        if(v.getVersion()!=1 || next.getEpoch()!=2
                || next.isRoutable() || !"RECOVERING".equals(next.getState())
                || !old.getReplica().equals(next.getPrimary()))
            throw new IOException("not the exact isolated current recovering authority");
    }
    ReplicationControlResponse handle(ZookeeperClient zk,
            List<PartitionAssignment> plan,
            DemoV19FourNodeLiveRuntime.HeldWal held,
            ReplicationControlRequest request){
        try{
            if(request==null || !OP.equals(request.getOperation())
                    || request.getPayload()==null || request.getPayload().length!=32
                    || !DemoV19FourNodeShardCatalog.SERVICE.equals(
                        request.getServiceName()) || !zk.isConnected()
                    || !node.equals(held.node))
                throw new IOException("invalid ready preflight probe");
            String part=request.getPartitionId();
            if(!DemoV19FourNodeSeq1NettyPilot.selected(part))
                throw new IOException("unbounded ready preflight partition");
            PartitionAssignment old=plan.get(Integer.parseInt(part.substring(1)));
            if(!DemoV19FourNodeLiveRuntime.owners(old).contains(node))
                throw new IOException("not assigned peer");
            DemoDurableJournal source=held.owned.get(part);
            if(source==null)throw new IOException("no exclusive old physical WAL");
            synchronized(source){
                requireExactRecoveryAssignment(zk,old);
                DemoV19FourNodeEpoch2Transition.requireLocalImage(
                    zk,old,node,root,source);
                // Startup checks are not enough: re-open the Common
                // CommitIndex/Custody, requiring both source and new proofs.
                DemoV19FourNodeEpoch2Common.verifyLocalAfterRestart(
                    zk,old,node,root);
                @SuppressWarnings("unchecked")
                Map<String,Object> image=JsonUtils.Deserialize(String.valueOf(
                    zk.readData(DemoV19FourNodeEpoch2Install.PROOFS+"/"+part)),Map.class);
                String sourceSha=(String)image.get("sourceSha256");
                String walSha=(String)image.get("recoveredWalSha256");
                if(source.committedSeq()!=1 || source.lastEpoch()!=1
                        || !source.isReadyForWrites()
                        || !sourceSha.equals(source.committedPrefixSha256Through(1)))
                    throw new IOException("source WAL mutated under pre-ready gate");
                DurableWalCommitQuorum.Membership member=
                    DemoV19FourNodeEpoch2Install.successorMembership(zk,old);
                String oldMember=DemoV19FourNodeEpoch2Transition.historicMembership(
                    zk,old).digest;
                Path oldDir=root.resolve(".pilot-old-epoch-revoked-"+part);
                Path oldHead=oldDir.resolve("head.bin");
                String expectedOld=DemoV19FourNodeRemoteRevocation.expectedPayload(
                    old,oldMember,sourceSha)+"\n";
                if(Files.isSymbolicLink(oldDir) || Files.isSymbolicLink(oldHead)
                        || !Files.isRegularFile(oldHead,
                            LinkOption.NOFOLLOW_LINKS)
                        || !java.util.Arrays.equals(Files.readAllBytes(oldHead),
                            expectedOld.getBytes(java.nio.charset.StandardCharsets.UTF_8)))
                    throw new IOException("not exactly the durable old-publisher fence");
                String nonce=DemoV19FourNodeGenesisPreflight.hex(
                    request.getPayload());
                Signature rsa=Signature.getInstance("SHA256withRSA");
                rsa.initSign(key);
                rsa.update(statement(part,node,member.digest,sourceSha,walSha,
                    nonce).getBytes(java.nio.charset.StandardCharsets.UTF_8));
                requireExactRecoveryAssignment(zk,old);
                Map<String,Object> result=new LinkedHashMap<>();
                result.put("scope",SCOPE);result.put("partition",part);
                result.put("node",node);result.put("nonce",nonce);
                result.put("membershipSha256",member.digest);
                result.put("sourceSha256",sourceSha);
                result.put("recoveredWalSha256",walSha);
                result.put("ready",false);result.put("clientAck",false);
                result.put("signature",Base64.getEncoder().encodeToString(
                    rsa.sign()));
                return ReplicationControlResponse.ok(DemoNettyBridge.json(result));
            }
        }catch(Exception rejected){
            return ReplicationControlResponse.error("EPOCH2_READY_PREFLIGHT_DENIED",
                rejected.getClass().getSimpleName()+": "+rejected.getMessage());
        }
    }
    static void verify(ZookeeperClient zk,PartitionAssignment old,String voter,
            String member,String source,String wal,String nonce,
            ReplicationControlResponse response)throws Exception{
        if(response==null || !response.isSuccess())
            throw new IOException("physical ready preflight absent");
        Map<String,Object> fields=DemoNettyBridge.map(response.getPayload());
        if(!SCOPE.equals(fields.get("scope"))
                || !old.getPartitionId().equals(fields.get("partition"))
                || !voter.equals(fields.get("node"))
                || !nonce.equals(fields.get("nonce"))
                || !member.equals(fields.get("membershipSha256"))
                || !source.equals(fields.get("sourceSha256"))
                || !wal.equals(fields.get("recoveredWalSha256"))
                || !Boolean.FALSE.equals(fields.get("ready"))
                || !Boolean.FALSE.equals(fields.get("clientAck"))
                || !(fields.get("signature") instanceof String))
            throw new IOException("ready preflight crossed assignment boundary");
        Signature rsa=Signature.getInstance("SHA256withRSA");
        rsa.initVerify(DemoV19FourNodeGenesisPreflight.pinned(zk,voter));
        rsa.update(statement(old.getPartitionId(),voter,member,source,wal,
            nonce).getBytes(java.nio.charset.StandardCharsets.UTF_8));
        if(!rsa.verify(Base64.getDecoder().decode(
                (String)fields.get("signature"))))
            throw new IOException("untrusted physical ready preflight signature");
    }
    static void probeTwo(ZookeeperClient zk,List<PartitionAssignment> plan)
            throws Exception{
        try(DirectNettyReplicationTransport tcp=new DirectNettyReplicationTransport(
                10000,DirectNettyReplicationServer.DEFAULT_MAX_FRAME_BYTES)){
            for(char lead:new char[]{'A','C'}){
                String part=DemoV19FourNodeGenesisPreflight.firstShard(
                    plan,lead);
                PartitionAssignment old=plan.get(Integer.parseInt(part.substring(1)));
                requireExactRecoveryAssignment(zk,old);
                DemoV19FourNodeEpoch2Common.verifyProof(zk,old);
                @SuppressWarnings("unchecked")
                Map<String,Object> recovered=JsonUtils.Deserialize(String.valueOf(
                    zk.readData(DemoV19FourNodeEpoch2Install.PROOFS+"/"+part)),Map.class);
                String source=(String)recovered.get("sourceSha256"),
                    wal=(String)recovered.get("recoveredWalSha256");
                DurableWalCommitQuorum.Membership member=
                    DemoV19FourNodeEpoch2Install.successorMembership(zk,old);
                byte[] challenge=new byte[32];new SecureRandom().nextBytes(challenge);
                String nonce=DemoV19FourNodeGenesisPreflight.hex(challenge);
                for(String voter:DemoV19FourNodeLiveRuntime.owners(old)){
                    ReplicationControlResponse response=tcp.control(
                        DemoV19FourNodeLiveRuntime.exactEndpoint(voter),
                        new ReplicationControlRequest(
                            DemoV19FourNodeShardCatalog.SERVICE,OP,part,challenge))
                        .get(8,TimeUnit.SECONDS);
                    verify(zk,old,voter,member.digest,source,wal,nonce,response);
                }
                requireExactRecoveryAssignment(zk,old);
                DemoV19FourNodeEpoch2Common.verifyProof(zk,old);
                System.out.println("FOUR_NODE_EPOCH2_READY_PREFLIGHT_PASS partition="+part+
                    " verifiedPhysicalVoters=2 newEpochCommonIndexAndCustody=true"+
                    " oldPublisherPermanentlyRevoked=true"+
                    " hostFaultDomainsIndependent=false"+
                    " zkState=RECOVERING ready=false clientAck=false");
            }
        }
    }
}